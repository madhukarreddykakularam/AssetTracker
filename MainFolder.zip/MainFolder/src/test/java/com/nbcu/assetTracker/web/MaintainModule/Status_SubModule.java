package com.nbcu.assetTracker.web.MaintainModule;

import java.lang.reflect.Method;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Status_SubModule extends Commonstudio
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(Status_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Statuses_Field_Validation(Method m,String username,String password,String Action,String InvalidStatusValue,String UpdateAction) throws Exception
	{
		try
		{   
			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful
			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
			
			
	//Verify that All the sub modules are present under the maintain tab		
			Boolean verifyCurrentLocation=assetTrackMaintainPage.lnk_Maintain(wdriver,"Current Locations").isDisplayed();
			logger.log(LogStatus.PASS,"Current Locations ","Current Locations is displayed :"+verifyCurrentLocation);

			Boolean verifyCurrentSubLocation=assetTrackMaintainPage.lnk_Maintain(wdriver,"Current Sublocations").isDisplayed();
			logger.log(LogStatus.PASS,"Current Sublocations","Current Sublocations is displayed :"+verifyCurrentSubLocation);

			Boolean verifyPermanentLocation=assetTrackMaintainPage.lnk_Maintain(wdriver,"Permanent Locations").isDisplayed();
			logger.log(LogStatus.PASS,"Permanent Locations","Permanent Locations is disabdisplayedled :"+verifyPermanentLocation);

			Boolean verifyPermanentSubLocation=assetTrackMaintainPage.lnk_Maintain(wdriver,"Permanent Sublocations").isDisplayed();
			logger.log(LogStatus.PASS,"Permanent Sublocations","Permanent Sublocations is displayed :"+verifyPermanentSubLocation);

			Boolean verifyMyPref=assetTrackMaintainPage.lnk_Maintain(wdriver,"My Preferences").isDisplayed();
			logger.log(LogStatus.PASS,"My Preferences","My Preferences is displayed :"+verifyMyPref);
			
			Boolean verifyManufacturers=assetTrackMaintainPage.lnk_Maintain(wdriver,"Manufacturers").isDisplayed();
			logger.log(LogStatus.PASS,"Manufacturers","Manufacturers is displayed :"+verifyManufacturers);
			
			Boolean verifyModels=assetTrackMaintainPage.lnk_Maintain(wdriver,"Models").isDisplayed();
			logger.log(LogStatus.PASS,"Models","Models is displayed :"+verifyModels);
			
			Boolean verifyTypes=assetTrackMaintainPage.lnk_Maintain(wdriver,"Types").isDisplayed();
			logger.log(LogStatus.PASS,"Types","Types is displayed :"+verifyTypes);
			
			Boolean verifyVendors=assetTrackMaintainPage.lnk_Maintain(wdriver,"Vendors").isDisplayed();
			logger.log(LogStatus.PASS,"Vendors","Vendors is disabled :"+verifyVendors);
			
			Boolean verifyDivisions=assetTrackMaintainPage.lnk_Maintain(wdriver,"Divisions").isDisplayed();
			logger.log(LogStatus.PASS,"Divisions","Divisions is disabled :"+verifyDivisions);
			
			Boolean verifySiteNames=assetTrackMaintainPage.lnk_Maintain(wdriver,"Site Names").isDisplayed();
			logger.log(LogStatus.PASS,"Site Names","Site Names is disabled :"+verifySiteNames);
			
			Boolean verifyWorkerDivAssocs=assetTrackMaintainPage.lnk_Maintain(wdriver,"Worker-Div Assocs").isDisplayed();
			logger.log(LogStatus.PASS,"Worker-Div Assocs","Worker-Div Assocs is disabled :"+verifyWorkerDivAssocs);
			
			Boolean verifyStatuses=assetTrackMaintainPage.lnk_Maintain(wdriver,"Statuses").isDisplayed();
			logger.log(LogStatus.PASS,"Statuses","Statuses is disabled :"+verifyStatuses);
			
	//Click on Statuses link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Statuses"));
			logger.log(LogStatus.PASS,"Statuses link","Statuses link  is clicked ");  

	//Verify that the Maintain Manufactuers page is displayed
			String VerifyMaintainTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Statuses").getText();
			Assert.assertEquals("Maintain Statuses", VerifyMaintainTitle);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Statuses"));
		
	//Select ADD from the Action dropdown
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
			}
			
				
	//Generate a random value
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,2000);
			String RandomStatusValue;
			RandomStatusValue=RandomValue+"TESTINGADDFUNCTONALITY";

			
	//Enter the New Statuses name which is less than 50 characters
			assetTrackMaintainPage.txt_NewStatusName(wdriver).sendKeys(RandomStatusValue);
			logger.log(LogStatus.PASS,"New Status Name","New Status name is entered: "+RandomStatusValue);	


	//Click on save button      
			Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(2000);
			WebimplicitWait(wdriver);

	//Verify that the Confirmation message is displayed
			String VerifyConfirmationMessage=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			String Concatenate= "Status "+"'"+RandomStatusValue+"'"+ " has been added.";
			Assert.assertEquals(Concatenate,VerifyConfirmationMessage);
			logger.log(LogStatus.PASS,"Confirmation message is displayed.","Confirmation message  "+VerifyConfirmationMessage+ " is displayed");
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
			
			
	//Enter the Status value more than 50 characters
			assetTrackMaintainPage.txt_NewStatusName(wdriver).clear();
			assetTrackMaintainPage.txt_NewStatusName(wdriver).sendKeys(InvalidStatusValue);
			logger.log(LogStatus.PASS,"New Status Name","New Status Name is entered with more than 50 characters: "+InvalidStatusValue);	

	//Verify that more than 50 characters cannot be entered in the New Status text box
			String VerifyStatusText=assetTrackMaintainPage.txt_NewStatusName(wdriver).getText().trim();
			Assert.assertNotEquals(InvalidStatusValue, VerifyStatusText);
			logger.log(LogStatus.PASS,"More than 50 characters","More than 50 characters cannot be added ");
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewStatusName(wdriver));
			
			
	//Enter a value which is equal to 50 characters		
			RandomStatusValue=RandomValue+"TESTINGADDFUNCTONALITYNEWVALUEVALIDDATATOBEADD";
	        int RandomStatusValue_Length=RandomStatusValue.length();
	        assetTrackMaintainPage.txt_NewStatusName(wdriver).clear();
	       assetTrackMaintainPage.txt_NewStatusName(wdriver).sendKeys(RandomStatusValue);
	         
	//verify that the Max length to be entered in the New Status edit box is 50    
	        String verifyMaxlength=assetTrackMaintainPage.txt_NewStatusName(wdriver).getAttribute("maxlength");
	        String  RandomStatusValue_Length_Int=Integer.toString(RandomStatusValue_Length);
	        Assert.assertEquals(RandomStatusValue_Length_Int, verifyMaxlength.toString());
	        logger.log(LogStatus.PASS,"The length of the text field","The length of the text field is :"+RandomStatusValue_Length_Int);

	//Click on save button      
			Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			WebimplicitWait(wdriver);
			
		
	//Verify that the Confirmation message is displayed
			WebDriverWait wait1 = new WebDriverWait(wdriver,100);
			String Concatenate1= "Status "+"'"+RandomStatusValue+"'"+ " has been added.";
			wait1.until(ExpectedConditions.visibilityOf(assetTrackMaintainPage.msg_ConfirmationdDynamic(wdriver,RandomStatusValue)));
			String VerifyConfirmationMessage1=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();	
			Assert.assertEquals(Concatenate1,VerifyConfirmationMessage1);
			logger.log(LogStatus.PASS,"Confirmation message is displayed.","Confirmation message "+VerifyConfirmationMessage1+ " is displayed");
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
				
	//Select UPDATE from the Action dropdown
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),UpdateAction);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(UpdateAction);
			}		

	//Select the Added Status from the dropdown
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Status(wdriver),RandomStatusValue);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdown_Status(wdriver));
				SelectAction.selectByVisibleText(RandomStatusValue);
			}	
					
			
	//Enter the Status name and click on save 
			String RandomUpdatedStatusValue;
			RandomUpdatedStatusValue=RandomValue+"UPDATED";
			assetTrackMaintainPage.txt_NewStatusName(wdriver).sendKeys(RandomUpdatedStatusValue);
			logger.log(LogStatus.PASS,"Updated Status Name","Updated name is entered: "+RandomUpdatedStatusValue);

	//Click on save button  
			Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			WebimplicitWait(wdriver);
			
	//Verify that the Confirmation message is displayed
			
			WebDriverWait wait = new WebDriverWait(wdriver,100);
			String Concatenate2= "Status "+"'"+RandomUpdatedStatusValue+"'"+ "has been Updated.";
			wait.until(ExpectedConditions.visibilityOf(assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomUpdatedStatusValue)));
			String VerifyConfirmationMessage2=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();	
			Assert.assertEquals(Concatenate2,VerifyConfirmationMessage2);
			logger.log(LogStatus.PASS,"Confirmation message is displayed.","Confirmation message "+VerifyConfirmationMessage2+ " is displayed");
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
		  
			
	//Verify that both added and updated values are present under the Status dropdown	
			String VerifyTextInDropdown=assetTrackMaintainPage.drpdown_Status(wdriver).getAttribute("innetText");
			Assert.assertEquals(RandomStatusValue,VerifyTextInDropdown);
			Assert.assertEquals(RandomUpdatedStatusValue,VerifyTextInDropdown);
			logger.log(LogStatus.PASS,"Added and Updated Status Values are displayed.","Added and Updated Status Values "+RandomStatusValue+ "and" +RandomUpdatedStatusValue+" are present in the dropdown");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);   

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}  

	

}
