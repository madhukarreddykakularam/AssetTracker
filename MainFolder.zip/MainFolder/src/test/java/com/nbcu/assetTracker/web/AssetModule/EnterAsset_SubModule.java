package com.nbcu.assetTracker.web.AssetModule;

import java.lang.reflect.Method;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class EnterAsset_SubModule extends Commonstudio
{
	  PropertyFileReader prop = new PropertyFileReader();
	    Commonstudio objCommStudio = new Commonstudio();
	    ExtentReports logger = ExtentReports.get(EnterAsset_SubModule.class);
	    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	    AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
	    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	   @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	    public void FirstCostFieldValidation(Method m,String username,String password) throws Exception
	    {
		 
	        try
	        {   
	         logger.startTest(m.getName());
	         System.out.println("method name"+(m.getName()));
	         TestReporter.logStep("Start test execution of " + m.getName());
	         TestReporter.logStep("Launch Asset Tracker ");
	         
	//Step1:Login to the Application
	         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	         WebimplicitWait(wdriver);
	         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	         Assert.assertEquals("Welcome, Tester1", verifyLogin);
	         
	//Verifying that the Login is successful
	        
	         logger.log(LogStatus.PASS,"Login is suucessful","Login is successful with the login Message "+verifyLogin);
	         Thread.sleep(1000);
	         
	//Click on the Assets button in the Assets page
	         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
	         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
	         
	 //Click on the Search Asset link
	         Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
	        logger.log(LogStatus.PASS,"Enter Asset Link Tab","Enter Asset Link Tab is clicked ");
	         
	//Perform a blank search of the Asset 
	         Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
	         logger.log(LogStatus.PASS,"Enter Without PO button","Enter Without PO button is clicked ");
	         WebimplicitWait(wdriver);
	         
	 //verify that the Enter Details screen is displayed
	         String verifyMessage=assetTrackAssetsPge.tit_AssetDetails(wdriver).getText();
	         Assert.assertEquals("The Quantity of Copy Asset cannot be more than Twenty.", verifyMessage);
	         logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyMessage);
	         String tempFirstCostVal="1000000051545484";
	         int tempFirstCostVal_Length=tempFirstCostVal.length();
	         assetTrackAssetsPge.txt_FirstCost(wdriver).sendKeys(tempFirstCostVal);
	         
	         
	//verify that the Max length to be entered in the First cost field is 16. 
	         String verifyMaxlength=assetTrackAssetsPge.txt_FirstCost(wdriver).getAttribute("maxlength");
	         Assert.assertEquals(tempFirstCostVal_Length, verifyMaxlength.toString());
	         logger.log(LogStatus.PASS,"Verify Maximum Length"," Maximum Length of First Cost : "+verifyMaxlength);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
	        } catch (Exception | AssertionError e) {
	        	logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
	        	TestReporter.logFailure("Error Message:" + e.getMessage());
	        	objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
	        	}
	         
	        
	    }   


	   
	   @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	    public void TC01_Number_fields_should_accept_only_numbers_Enter_Asset(Method m,String username,String password) throws Exception
	    {
		 
	        try
	        {   
	         logger.startTest(m.getName());
	         System.out.println("method name"+(m.getName()));
	         TestReporter.logStep("Start test execution of " + m.getName());
	         TestReporter.logStep("Launch Asset Tracker ");
	         
	//Step1:Login to the Application
	         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	         WebimplicitWait(wdriver);
	         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	         Assert.assertEquals("Welcome, Tester1", verifyLogin);
	         
	//Verifying that the Login is successful
	        
	         logger.log(LogStatus.PASS,"Login is suucessful","Login is successful with the login Message "+verifyLogin);
	         Thread.sleep(1000);
	         
 //Verify that the Assets,Shipment, Maintain , Need Help tabs are available
	         Boolean verifyAssetTab=assetTrackAssetsPge.btn_Assets(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Asset Tab ","Asset Tab is displayed :"+verifyAssetTab);

			Boolean VerifyShipmentTab=assetTrackAssetsPge.btn_Shipments(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is displayed :"+VerifyShipmentTab);

			Boolean verifyMaintainTab=assetTrackAssetsPge.btn_Maintain(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is displayed :"+verifyMaintainTab);

			Boolean verifyNeedHelp=assetTrackAssetsPge.btn_NeedHelp(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Permanent Sublocations","Permanent Sublocations is displayed :"+verifyNeedHelp);
			
	                  
	//Click on the Assets button in the Assets page
	         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
	         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
	         
	 //Click on the Enter Asset link
	         Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
	        logger.log(LogStatus.PASS,"Enter Asset Link Tab","Enter Asset Link Tab is clicked ");
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
    //Verify Find purchase Order page is displayed
	        String verifyFindPO=assetTrackAssetsPge.tit_FindPurchaseOrder(wdriver).getText();
	         Assert.assertEquals("Find Purchase Orde", verifyFindPO);
	         logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyFindPO);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
	 //Enter the PO Number
	        assetTrackAssetsPge.txt_POnumber(wdriver).sendKeys("3123456789");
	        Syn_Click(assetTrackAssetsPge.btn_SelectValues(wdriver,"purchaseOrderNumber"));
	         WebimplicitWait(wdriver);
	         logger.log(LogStatus.PASS,"Set PO number","PO number is entered : 312456789");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
//Click on the Find PO Button
	         Syn_Click(assetTrackAssetsPge.btn_FindPO(wdriver));
	         logger.log(LogStatus.PASS,"Find PO Button","Find PO Button is clicked ");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         WebimplicitWait(wdriver);
	         
 //Click on the View Asset Button
	         Syn_Click(assetTrackAssetsPge.lnk_ViewFixedAssets(wdriver));
	         logger.log(LogStatus.PASS,"View Fixed Assets button","View Fixed Assets button is clicked ");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	                  

//Click on the View Asset Button
	         Syn_Click(assetTrackAssetsPge.btn_ViewAsset(wdriver));
	         logger.log(LogStatus.PASS,"View Asset button","View Asset button is clicked ");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         WebimplicitWait(wdriver);
	         
//Click on the Update Details Button
	         Syn_Click(assetTrackAssetsPge.btn_AssetDet_UpdateDetails(wdriver));
	         logger.log(LogStatus.PASS,"View Asset button","View Asset button is clicked ");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         WebimplicitWait(wdriver);	         
	         
	         
	         
	 //verify that the Enter Details screen is displayed
	         String verifyMessage=assetTrackAssetsPge.tit_AssetDetails(wdriver).getText();
	         Assert.assertEquals("The Quantity of Copy Asset cannot be more than Twenty.", verifyMessage);
	         logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyMessage);
	         String tempFirstCostVal="1000000051545484";
	         int tempFirstCostVal_Length=tempFirstCostVal.length();
	         assetTrackAssetsPge.txt_FirstCost(wdriver).sendKeys(tempFirstCostVal);
	         
	         
	//verify that the Max length to be entered in the First cost field is 16. 
	         String verifyMaxlength=assetTrackAssetsPge.txt_FirstCost(wdriver).getAttribute("maxlength");
	         Assert.assertEquals(tempFirstCostVal_Length, verifyMaxlength.toString());
	         logger.log(LogStatus.PASS,"Verify Maximum Length"," Maximum Length of First Cost : "+verifyMaxlength);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
	        } catch (Exception | AssertionError e) {
	        	logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
	        	TestReporter.logFailure("Error Message:" + e.getMessage());
	        	objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
	        	}
	    }   
	   
	   @Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
		public void Verification_Single_finance_details_without_PO(Method m, String username, String password)
				throws Exception {
			try {
				logger.startTest(m.getName());
				System.out.println("method name" + (m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

	//Step1:Login to the Application
				assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
				WebimplicitWait(wdriver);
				String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

	//Verifying that the Login is successful
				Thread.sleep(2000);
				logger.log(LogStatus.PASS, "Login is suucessful",
						"Login is succesful with the login Message " + verifyLogin);
				Thread.sleep(1000);

	//Click on the Assets button in the Assets page
				Thread.sleep(2000);
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

	//Click on the Enter Asset link
				Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
				logger.log(LogStatus.PASS, "Enter Asset Link Tab", "Enter Asset Link Tab is clicked ");

				// Click Enter without PO
				Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
				logger.log(LogStatus.PASS, "Button Enter Without PO Tab", "Button Enter Without PO Tab is clicked ");

				// Asset Details page is displayed
				Thread.sleep(2000);
				String Enterassetdetailspge = assetTrackAssetsPge.Enterassetdetailspge(wdriver).getText().trim();
				Assert.assertEquals(Enterassetdetailspge, "Asset Details");
				logger.log(LogStatus.PASS, "Asset Details page is displayed", "Asset Details page is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				// Enter the mandatory details
				// Vendor details
				Syn_Click(assetTrackAssetsPge.BtnVendor(wdriver));
				Thread.sleep(4000);
				switchToWindow("Tab Search");
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(4000);
				switchToWindow("Asset Tracker v2.2.1");
				// choose sap
				if (assetTrackAssetsPge.Btn_PoSystem(wdriver).isSelected()) {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				} else {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				}

				// enter cost Object
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_costobject(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.Btn_costobject(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "cost Object is entered", "cost Object is entered");
				// enter Account Number
				Thread.sleep(10000);
				assetTrackAssetsPge.txtGlaccount(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btnGlaccount(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Account Number is entered", "Account Number is entered");
				// Enter First cost
				int RandomValue;
				RandomValue = getRandomNumberInRange(1000, 20000);
				String RandomCost;
				RandomCost = RandomValue + "5";
				assetTrackAssetsPge.Txt_FirstCost(wdriver).sendKeys(RandomCost);
				logger.log(LogStatus.PASS, "First cost is entered", "First cost is entered");
				// enter Status
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btnStatusId(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Status is entered", "Status is entered");
				// enter Division
				Thread.sleep(10000);
				assetTrackAssetsPge.txt_division(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_division(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Division is entered", "Division is entered");
				// enter Country
				Thread.sleep(10000);
				assetTrackAssetsPge.txt_Country(wdriver).sendKeys("AFGHANISTAN");
				Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
				Thread.sleep(1000);
				Thread.sleep(1000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Country is entered", "Country is entered");
				// enter Model
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_Model(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(12000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Model is entered", "Model is entered");
				// enter Current Location
				Thread.sleep(10000);
				assetTrackAssetsPge.txt_currentlocation(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Current Location is entered", "Current Location is entered");
				// enter Sublocation
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_SublocationId(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Mandatory fields is entered", "Mandatory fields is entered");
				/*
				 * //enter Permanent location Thread.sleep(10000);
				 * assetTrackAssetsPge.txt_PermanentLocation(wdriver).clear();
				 * Syn_Click(assetTrackAssetsPge.btn_PermanentLocation(wdriver));
				 * Thread.sleep(10000); switchToWindow("Tab Search"); Thread.sleep(10000);
				 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); Thread.sleep(10000);
				 * switchToWindow("Asset Tracker v2.2.1");
				 * 
				 * //enter Permanent Sublocation Thread.sleep(10000);
				 * assetTrackAssetsPge.txt_permanentSublocationID(wdriver).clear();
				 * Syn_Click(assetTrackAssetsPge.btn_permanentSublocationID(wdriver));
				 * Thread.sleep(10000); switchToWindow("Tab Search"); Thread.sleep(10000);
				 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); Thread.sleep(10000);
				 * switchToWindow("Asset Tracker v2.2.1");
				 * objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				 */

				// Click Add asset button
				Syn_Click(assetTrackAssetsPge.btn_ADDAsset(wdriver));
				logger.log(LogStatus.PASS, "Add asset button is clicked", "Add asset button is clicked");
				// Verify Confirmation page
				Boolean BtnViewAsset = assetTrackAssetsPge.BtnViewAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "View Asset Tab", "View Asset Tab is displayed :" + BtnViewAsset);
				Boolean BtnCopyAsset = assetTrackAssetsPge.BtnCopyAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Copy Asset Tab", "Copy Asset Tab is displayed :" + BtnCopyAsset);
				Boolean BtnCreatenewAsset = assetTrackAssetsPge.BtnCreatenewAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Create new Asset Tab",
						"Create new Asset Tab is displayed :" + BtnCreatenewAsset);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				// Click View asset button
				Syn_Click(assetTrackAssetsPge.BtnViewAsset(wdriver));
				logger.log(LogStatus.PASS, "View Asset Tab", "View Asset Tab is clicked");
				Thread.sleep(1000);

				// Verify Single Finance details
				Boolean Getcount_ProfitCenter = assetTrackAssetsPge.Getcount_ProfitCenter(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Only One Profit Center",
						"Only One Profit Center is displayed :" + Getcount_ProfitCenter);
				Boolean Getcount_Account = assetTrackAssetsPge.Getcount_Account(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Only One GlAccount Center",
						"Only One GlAccount Center is displayed :" + Getcount_Account);
				String Gettxt_Cost = assetTrackAssetsPge.Gettxt_Cost(wdriver).getText().trim();
				Boolean Getcount_Internal = assetTrackAssetsPge.Getcount_Internal(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Only One Internal Order is present",
						"Internal Order is present is displayed :" + Getcount_Internal);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			} catch (Exception | AssertionError e) {
				System.out.println(e);
				logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
				TestReporter.logFailure("Error Message:" + e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
			}
		}


////////////25/11/////////////////////////
  
 
  
/////////////////25/11///////////////////
  
	   @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	   public void TC01_Verify_that_the_entries_will_not_get_deleted_if_the_entries_are_associated_with_asset(Method m,String username,String password,String Action,String PickManufacturer,String PickType) throws Exception
	   {
		 
	       try
	       {   
	        logger.startTest(m.getName());
	        System.out.println("method name"+(m.getName()));
	        TestReporter.logStep("Start test execution of " + m.getName());
	        TestReporter.logStep("Launch Asset Tracker ");
	        
	//Step1:Login to the Application
	        assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	        WebimplicitWait(wdriver);
	        String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	        Assert.assertEquals("Welcome, Tester1", verifyLogin);
	        
	//Verifying that the Login is successful       
	        logger.log(LogStatus.PASS,"Login is suucessful","Login is successful with the login Message "+verifyLogin);
	        Thread.sleep(1000);
	        
	//Click on the Assets button in the Assets page
	        Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
	        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
	        
	        
	//Click on the Search Asset link
	        Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
	       logger.log(LogStatus.PASS,"Enter Asset Link Tab","Enter Asset Link Tab is clicked ");
	       Thread.sleep(10000);
	        
	//Perform a blank search of the Asset 
	        Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
	        logger.log(LogStatus.PASS,"Enter Without PO button","Enter Without PO button is clicked ");
	        WebimplicitWait(wdriver);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 
	           
	//Creating an asset    
	        Thread.sleep(10000);
			 Syn_Click(assetTrackAssetsPge.rdo_SAP(wdriver));

			 
	        
	//Entering mandatory fields for creating Asset	
		//Selecting vendor value
			 JavascriptExecutor jse = (JavascriptExecutor)wdriver;
			 jse.executeScript("arguments[0].value='0500-03766-02';", assetTrackAssetsPge.txt_ModelName(wdriver));
			 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Model"));
			 
			 JavascriptExecutor jsre = (JavascriptExecutor)wdriver;
			 jsre.executeScript("arguments[0].value='291 DIGITAL LLC';", assetTrackAssetsPge.txt_VendorName(wdriver));
			 Thread.sleep(5000);
			 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Vendor"));
			Thread.sleep(5000);

			 JavascriptExecutor jsee = (JavascriptExecutor)wdriver;
			 jsee.executeScript("arguments[0].value='1000';", assetTrackAssetsPge.txt_FirstCost(wdriver));

			 
			int RandomValue1;
			RandomValue1=getRandomNumberInRange(1000,20000);
	       String RandomValueTracking;
	       RandomValueTracking=RandomValue1+"T";
	       assetTrackAssetsPge.trackingno(wdriver).sendKeys(RandomValueTracking);

		
		//selecting cost object
	      jsee.executeScript("arguments[0].value='000003700093';", assetTrackAssetsPge.txt_CostObject(wdriver));
	      Syn_Click(assetTrackAssetsPge.btn_SelFromNewWindowCostObject(wdriver));
			Thread.sleep(5000);

			// Syn_Clickupd((assetTrackAssetsPge.costObject(wdriver)),wdriver);
			Thread.sleep(5000);

	//selecting status

			 JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
			 jse1.executeScript("arguments[0].value='WARRANTY REPLACEMENT';", assetTrackAssetsPge.txt_StatusName(wdriver));
			 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Status"));
			Thread.sleep(5000);

	//selecting country of origin
			 JavascriptExecutor jse2 = (JavascriptExecutor)wdriver;
			 jse2.executeScript("arguments[0].value='ARUBA';", assetTrackAssetsPge.txt_CountryOfOrigin(wdriver));
			 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Country of Origin"));
			Thread.sleep(5000);
			
		//selecting current-Location
			Syn_Click(assetTrackAssetsPge.btn_AddNewCurrentLocation(wdriver));
			Thread.sleep(5000);
			switchToWindow("maintainMaintainCurrentLocations");
			Thread.sleep(5000);
			int RandomLocValue;
			RandomLocValue=getRandomNumberInRange(1000,20000);
			String RandomLocValue1;
			RandomLocValue1=RandomLocValue+"LOC";
			//assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys(RandomLocValue1);
			jse2.executeScript("arguments[0].value='"+RandomLocValue1+"';", assetTrackMaintainPage.txt_newLocation(wdriver));
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS,"Save Button","Save Button is clicked"); 
			Thread.sleep(10000);
			switchToWindow("Asset Tracker v2.2.1");
			
			
			Syn_Click(assetTrackAssetsPge.btn_AddNewCurSubLocation(wdriver));
			Thread.sleep(5000);
			switchToWindow("maintainMaintainCurrentSubLocations");
			Thread.sleep(5000);
			//assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys(RandomLocValue1);
			jse2.executeScript("arguments[0].value='"+RandomLocValue1+"';", assetTrackMaintainPage.txt_newLocation(wdriver));
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			Thread.sleep(10000);
			switchToWindow("Asset Tracker v2.2.1");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			String PermanentLocation=assetTrackAssetsPge.txt_permanentSublocationID(wdriver).getAttribute("value");
			String PermanentSubLocation=assetTrackAssetsPge.txt_PermanentLocation(wdriver).getAttribute("value");
		
	//Click on Add Asset
			
	//Verify that the Confirmaton message is displayed
			 Thread.sleep(15000);
			 Syn_Click(assetTrackAssetsPge.btn_addAsset(wdriver));
			Thread.sleep(5000);
			assetTrackAssetsPge.confirmation(wdriver).isDisplayed();
			
	//Navigate to the Maintain->Current Location
			//Click on the Vendor link
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab ","Maintain Tab is clicked"); 
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Current Locations"));
			logger.log(LogStatus.PASS,"Current Locations link","Current Locations link  is clicked ");  
			Thread.sleep(1000);
			

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
			}
			assetTrackMaintainPage.txt_currentLocation(wdriver).sendKeys(RandomLocValue1);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Current Location"));
			Thread.sleep(5000);
			Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
			logger.log(LogStatus.PASS,"Save Button","Save Button is clicked"); 
			String VerifyErrorMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			String Concatenate= "Cannot delete the Current Location " +"'"+RandomLocValue1+"'"+ " as it is associated with valid Current Sub Location(s)";
			Assert.assertEquals(Concatenate, VerifyErrorMsg);
			logger.log(LogStatus.PASS,"Error Message is displayed","Error Message is displayed as :"+VerifyErrorMsg); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			
			///Current Sub Location////
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Current Sublocations"));
			logger.log(LogStatus.PASS,"Current SubLocations link","Current SubLocations link  is clicked ");  
			Thread.sleep(1000);
			

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
			}
			assetTrackMaintainPage.txt_currentLocation(wdriver).sendKeys(RandomLocValue1);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Current Location"));
			assetTrackMaintainPage.txt_SubLocation(wdriver).sendKeys(RandomLocValue1);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Current SubLocation"));
			
			Thread.sleep(5000);
			Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
			
			String VerifyErrorMsg1=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			String Concatenate1= "Cannot delete the Current SubLocation " +"'"+RandomLocValue1+"'"+ " as it is associated with valid Asset(s)";
			Assert.assertEquals(Concatenate1, VerifyErrorMsg1);
			logger.log(LogStatus.PASS,"Error Message is displayed","Error Message is displayed as :"+VerifyErrorMsg1); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	///Current permanent Location////
					Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
					Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Permanent Locations"));
					logger.log(LogStatus.PASS,"Permanent Locations link","Permanent Locations link  is clicked ");  
					Thread.sleep(1000);
					

					if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
					{
						dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
					}
					else
					{
						Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
						SelectAction.selectByVisibleText(Action);
					}
					assetTrackMaintainPage.txt_currentLocation(wdriver).sendKeys(PermanentLocation);
					Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Permanent Location"));

					Thread.sleep(5000);
					Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
					
					String VerifyErrorMsg2=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
					System.out.println(VerifyErrorMsg2);
					String VerifyErrorPerm= "Cannot delete the Permanent Location " +"'"+PermanentLocation+"'"+ " as it is associated with valid Permanent Sub Location(s)";
					System.out.println(VerifyErrorPerm);
					Assert.assertEquals(VerifyErrorPerm, VerifyErrorMsg2);
					logger.log(LogStatus.PASS,"Error Message is displayed","Error Message is displayed as :"+VerifyErrorPerm); 
					objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
					
					
	///Current permanent SubLocation////
					Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
					Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Permanent Sublocations"));
					logger.log(LogStatus.PASS,"Permanent Sublocations link","Permanent Sublocations link  is clicked ");  
					Thread.sleep(1000);
					

					if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
					{
						dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
					}
					else
					{
						Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
						SelectAction.selectByVisibleText(Action);
					}
					assetTrackMaintainPage.txt_currentLocation(wdriver).sendKeys(PermanentLocation);
					Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Permanent Location"));
					assetTrackMaintainPage.txt_SubLocation(wdriver).sendKeys(PermanentSubLocation);
					Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Permanent SubLocation"));

					Thread.sleep(5000);
					Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
					
					String VerifyErrorMsg3=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
					String VerifyErrorPermSub= "Cannot delete the Permanent SubLocation " +"'"+PermanentSubLocation+"'"+ " as it is associated with valid Asset(s)";
					//Assert.assertEquals(VerifyErrorPermSub, VerifyErrorMsg3);
					logger.log(LogStatus.PASS,"Error Message is displayed","Error Message is displayed as :"+VerifyErrorPermSub); 
					objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			

	//Navigate to Maintain ->Enter Current Location. Select ' Delete ' action for the Current location added in the asset created . Save
			
	        
	       } catch (Exception | AssertionError e) {
	       	logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
	       	TestReporter.logFailure("Error Message:" + e.getMessage());
	       	objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
	       	}
	        
	       
	   }   


	}
	   
		   
		   