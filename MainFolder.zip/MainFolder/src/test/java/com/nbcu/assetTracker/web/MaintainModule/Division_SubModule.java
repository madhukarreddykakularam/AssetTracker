package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Division_SubModule extends Commonstudio 
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(Division_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Your_Division_Positive_Flow(Method m,String username,String password,String Action,String CurrentLocation,String PermanentLocation,String PermanentSubLocation) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Divsions(wdriver));
			logger.log(LogStatus.PASS,"Divisions link","Divisions link  is clicked ");  

			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomDivisionName;
			RandomDivisionName=RandomValue+"D";

			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);

			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomDivisionName);
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered: "+RandomDivisionName);

			//Click on the Save button                
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the Search Asset link
			Syn_Click(assetTrackMaintainPage.lnk_MyPreferences(wdriver));
			logger.log(LogStatus.PASS,"My Preferences link","My Preferences link  is clicked ");

			//Verify that the Maintain My Preferences page is displayed
			String VerifyPrefernceTitle=assetTrackMaintainPage.tit_MyPreferences(wdriver).getText();
			Assert.assertEquals("Maintain My Preferences", VerifyPrefernceTitle);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value in the Divisions section
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).sendKeys(RandomDivisionName);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Division"));
			Thread.sleep(1000);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Division"));
			logger.log(LogStatus.PASS,"Divison Selection","Division is selected from the list :"+RandomDivisionName);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Division is selected     
			String VerifyEnteredDivision=assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).getAttribute("value");
			Assert.assertEquals(RandomDivisionName, VerifyEnteredDivision);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value from Default Current Location
			assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).sendKeys(CurrentLocation);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Default Current Location"));
			Thread.sleep(1000);
			logger.log(LogStatus.PASS,"Default Current Location","Default Current Location is selected from the list :"+CurrentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Default Current Location is selected     
			String VerifyCurrentLoc=assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).getAttribute("value");
			Assert.assertEquals(CurrentLocation, VerifyCurrentLoc);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Select any value from Default Permanent Location
			assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).sendKeys(PermanentLocation);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Default Permanent Location"));
			Thread.sleep(1000);
			logger.log(LogStatus.PASS,"Default Permanent Location","Default Permanent Location is selected from the list :"+PermanentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Default Permanent Location is selected     
			String VerifyPermanentLoc=assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).getAttribute("value");
			Assert.assertEquals(PermanentLocation, VerifyPermanentLoc);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);       

			//Select any value from Default Permanent Sub Location
			assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).sendKeys(PermanentSubLocation);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Default Permanent Sublocation"));
			Thread.sleep(1000);
			logger.log(LogStatus.PASS,"Default Permanent Location","Default Permanent Location is selected from the list :"+PermanentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Default Permanent Sub Location is selected     
			String VerifyPermanentSubLoc=assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).getAttribute("value");
			Assert.assertEquals(PermanentSubLocation, VerifyPermanentSubLoc);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			//Click on the save button
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);   


			//Verify that the Confirmation message s displayed
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			Assert.assertEquals("You have successfully updated your preferences.", VerifyConfirmationMsg);
			Thread.sleep(1000);  

			//Click on the Cancel button
			Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000); 

			//Verify that the main screen is displayed after clicking on the Cancel button
			String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
			logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}


	//---------------------------------------------------------------------------------------------------------------//
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Your_Division_Negative_Flow(Method m,String username,String password,String Action,String CurrentLocation,String InvalidCurrenLocation,String PermanentLocation,String InvalidPermanentLocation,String PermanentSubLocation,String InvPermanentSubLocation,String InvalidDivisionData) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful
			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the My Preferences link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"My Preferences"));
			logger.log(LogStatus.PASS,"My Preferences link","My Preferences link  is clicked "); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Verify that the Maintain My Preferences page is displayed
			String VerifyPrefernceTitle=assetTrackMaintainPage.tit_MyPreferences(wdriver).getText();
			Assert.assertEquals("Maintain My Preferences", VerifyPrefernceTitle);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Clear all the values in all the fields
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).clear();

			//Click on the Save button                
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Verify that the Error message is displayed
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			Assert.assertEquals("Division must be specified.", VerifyConfirmationMsg);
			logger.log(LogStatus.PASS,"Error Validation message is displayed","Error "+VerifyConfirmationMsg+ " is displayed");
			Thread.sleep(1000);  


			//Select any value in the Divisions section

			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).sendKeys(InvalidDivisionData);
			logger.log(LogStatus.PASS,"Invalid Division is entered","Invalid Division" +InvalidDivisionData+ "is entered:");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Invalid Division is entered     
			String VerifyEnteredDivision=assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).getAttribute("value");
			Assert.assertEquals(InvalidDivisionData, VerifyEnteredDivision);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value from Default Current Location
			assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).sendKeys(InvalidCurrenLocation);
			logger.log(LogStatus.PASS,"Default Current Location","Default Current Location is selected from the list :"+InvalidCurrenLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Default Current Location is selected     
			String VerifyCurrentLoc=assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).getAttribute("value");
			Assert.assertEquals(InvalidCurrenLocation, VerifyCurrentLoc);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value from Default Permanent Location

			assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).sendKeys(InvalidPermanentLocation);
			logger.log(LogStatus.PASS,"Default Permanent Location","Default Permanent Location is selected from the list :"+InvalidPermanentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Default Permanent Location is selected     
			String VerifyPermanentLoc=assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).getAttribute("value");
			Assert.assertEquals(InvalidPermanentLocation, VerifyPermanentLoc);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);       

			//Select any value from Default Permanent Sub Location              
			assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).sendKeys(InvPermanentSubLocation);
			logger.log(LogStatus.PASS,"Default Permanent Location","Default Permanent Location is selected from the list :"+InvPermanentSubLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Default Permanent Sub Location is selected     
			String VerifyPermanentSubLoc=assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).getAttribute("value");
			Assert.assertEquals(InvPermanentSubLocation, VerifyPermanentSubLoc);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			//Click on the save button
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);   


			//Verify that the Error message s displayed
			String VerifyErrorMessage=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			Assert.assertEquals("Division must be specified.", VerifyErrorMessage);
			logger.log(LogStatus.PASS,"Error Validation message is displayed","Error "+VerifyErrorMessage+ " is displayed");
			Thread.sleep(1000);  


			//Select any value from Default Current Location
			assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultCurrentLocation(wdriver).sendKeys(CurrentLocation);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Default Current Location"));
			Thread.sleep(1000);
			logger.log(LogStatus.PASS,"Default Current Location","Default Current Location is selected from the list :"+CurrentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value from Default Permanent Location
			assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultPermanentLocation(wdriver).sendKeys(PermanentLocation);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Default Permanent Location"));
			Thread.sleep(1000);
			logger.log(LogStatus.PASS,"Default Permanent Location","Default Permanent Location is selected from the list :"+PermanentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Select any value from Default Permanent Sub Location              
			assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).clear();
			assetTrackMaintainPage.txt_PrefDefaultPermSubLocation(wdriver).sendKeys(PermanentSubLocation);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Default Permanent Sublocation"));
			Thread.sleep(1000);
			logger.log(LogStatus.PASS,"Default Permanent Location","Default Permanent Location is selected from the list :"+PermanentLocation);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Switch to the Tab Search window
			switchToWindow("Tab Search");
			WebimplicitWait(wdriver);

			//Verify that the Error message s displayed
			String VerifyLocationErrorMessage=assetTrackMaintainPage.msg_NoMatches(wdriver).getText().trim();
			String Concatenate= "No matches found for "+"'"+PermanentSubLocation+"'";
			Assert.assertEquals(Concatenate,VerifyLocationErrorMessage);
			logger.log(LogStatus.PASS,"Error message is displayed.","Error "+VerifyLocationErrorMessage+ " is displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}




	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Division_Positive_Inputs(Method m,String username,String password,String Action,String DeleteAction,String UpdateAction) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");


			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Divsions(wdriver));
			logger.log(LogStatus.PASS,"Divisions link","Divisions link  is clicked ");  

			//Selection any Action from te dropdown   
			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);

			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys("TODAY SHOW");
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered ");


			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomDivisionName;
			RandomDivisionName=RandomValue+"PO";

			//Select ADD from the action 
			Select SelectAddAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAddAction.selectByVisibleText(Action);

			assetTrackMaintainPage.txt_NewDivision(wdriver).clear();
			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomDivisionName);
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered: "+RandomDivisionName);


			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);


			//Verify that the confirmation message is displayed
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();

			// String Div =quote(RandomDivisionName);
			String Concatenate= "Division "+"'"+RandomDivisionName+"'"+ " has been added.";
			Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(1000);

			//Select Update action
			Select SelectUpdateAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectUpdateAction.selectByVisibleText(UpdateAction);

			//Verify that the New Manufacturer field is disabled
			Boolean verifyNewDivisionField=assetTrackMaintainPage.txt_NewDivision(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Manufacturer field","New Manufacturer field is not enabled :"+verifyNewDivisionField);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			Boolean verifyNewDivisiondropdown=assetTrackMaintainPage.drpdown_Division(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Manufacturer field","New Manufacturer field is not enabled :"+verifyNewDivisiondropdown);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			//Select the Division to be updated
			Select SelectDivision=new Select(assetTrackMaintainPage.drpdown_Division(wdriver));
			SelectDivision.selectByVisibleText(RandomDivisionName);
			Thread.sleep(1000);


			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Verify that the confirmation message is displayed
			String VerifyErrornMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			System.out.println(VerifyErrornMsg);
			String DivConcatenate= "Division "+"\""+RandomDivisionName+"\""+ " already exists.";
			Assert.assertEquals(DivConcatenate, VerifyErrornMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
			System.out.println(DivConcatenate);

			String RandomUpdatedDivisionName;
			RandomUpdatedDivisionName=RandomValue+"NEWD";

			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomUpdatedDivisionName);
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered: "+RandomUpdatedDivisionName);


			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);


			//Verify that the confirmation message is displayed
			String VerifyUpdatedMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			String DivisionUpdated= "Division "+"'"+RandomUpdatedDivisionName+"'"+ " has been updated.";
			Assert.assertEquals(DivisionUpdated, VerifyUpdatedMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);   


			//Select Delete action
			Select SelectDeleteAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectDeleteAction.selectByVisibleText(DeleteAction);

			//Verify that the New Manufacturer field is disabled
			Boolean verifyNewDivisionField1=assetTrackMaintainPage.txt_NewDivision(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Manufacturer field","New Manufacturer field is not enabled :"+verifyNewDivisionField1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);    


			Boolean verifyNewDivisiondropdown1=assetTrackMaintainPage.drpdown_Division(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Divsion field","New Divsion field is not enabled :"+verifyNewDivisiondropdown1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			//Select the Division to be updated
			Select SelectDeleteDivision=new Select(assetTrackMaintainPage.drpdown_Division(wdriver));
			SelectDeleteDivision.selectByVisibleText(RandomUpdatedDivisionName);
			Thread.sleep(1000);    

			//Click on save button 
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);
			WebimplicitWait(wdriver);

			//Verify that the confirmation message is displayed
			String VerifyDeletedMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			String NewConcatenate= "Division "+"'"+RandomUpdatedDivisionName+"'"+ " has been deleted.";
			Assert.assertEquals(NewConcatenate, VerifyDeletedMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on Cancel button 
			Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Verify that the main screen is displayed after clicking on the Cancel button
			Thread.sleep(1000);
			String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
			logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
			Thread.sleep(1000);
		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Verification_of_division_update_in_Mypreference(Method m,String username,String password,String Currency,String Action,String currentLocation,String permanentlocation,String permanentsublocation,String cost,String costObjectNumber,String Account) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Set up: Firstly create a Division .
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	     logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	     Thread.sleep(1000);
	     
	//Click on the Maintain button in the Assets page
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	     
	//Click on the  Division link
	     Syn_Click(assetTrackMaintainPage.lnk_Divsions(wdriver));
	     logger.log(LogStatus.PASS,"Division link Tab","Division link Tab is clicked ");
	      
	        
	     String RandomValue;
	     RandomValue=RandomStringUtils.randomAlphabetic(5);
	     String RandomModelName;
	     RandomModelName=RandomValue.toUpperCase();
	    
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
	     }
	     else
	     {
	       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
	       SelectDivision.selectByVisibleText(Action);
	     }
	     //Enter Divison name
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomModelName);
	      
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	       
	     String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
	     String Concatenate= "Division" +" '" + RandomModelName + "' "+ "has been added.";
	     Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	    //Click on the Maintain button in the Assets page
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	     
	   //Click on the MyPreferences link
	     Syn_Click(assetTrackMaintainPage.lnk_MyPreferences(wdriver));
	     logger.log(LogStatus.PASS,"MyPreferences link Tab","MyPreferences link Tab is clicked ");
	     
	     //Enter Divison name
	     Thread.sleep(2000);
	     assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
	     assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).sendKeys(RandomModelName); 
	     Syn_Click(assetTrackMaintainPage.btn_division(wdriver));
	     Thread.sleep(5000);
	     switchToWindow("Tab Search");
	     String title= wdriver.getTitle();
	     if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	     {
	     assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     }
	     else {
	     Syn_Click(assetTrackMaintainPage.btn_division(wdriver));
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(2000);
	     switchToWindow("Asset Tracker v2.2.1");
		 }	 
	     logger.log(LogStatus.PASS,"Enter the Divison Type ","Divison Type is entered ");
	     
	     //enter current location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_currentlocation(wdriver).clear();
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.btn_currentlocation(wdriver));
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered ");
	     
	     
	   //enter Permanent location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_permanentlocation(wdriver).clear();
	     //  assetTrackMaintainPage.txt_permanentlocation(wdriver).sendKeys(permanentlocation);
	     Syn_Click(assetTrackMaintainPage.btn_permanentlocation(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Permanent location ","Permanent location is entered ");
	    
	     //enter Permanent Sub location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_permanentsublocation(wdriver).clear();
	   //  assetTrackMaintainPage.txt_permanentsublocation(wdriver).sendKeys(permanentsublocation);
	     Syn_Click(assetTrackMaintainPage.btn_permanentsublocation(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Permanent sub location ","Permanent sub location is entered ");
	     
	     //enter Cost Object number
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_costObjectNumber(wdriver).clear();
	    // assetTrackMaintainPage.txt_costObjectNumber(wdriver).sendKeys(costObjectNumber);
	     Syn_Click(assetTrackMaintainPage.btn_costObjectNumber(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Permanent sub location ","Permanent sub location is entered ");
	     
	   //enter Account number
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_accountNumber(wdriver).clear();
	   //  assetTrackMaintainPage.txt_accountNumber(wdriver).sendKeys(Account);
	     Syn_Click(assetTrackMaintainPage.btn_accountNumber(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Account number","Account number is entered ");
	     
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drp_currencyCode(wdriver),Currency);
	     }
	     else
	     {
	        Select SelectDivision=new Select(assetTrackMaintainPage.drp_currencyCode(wdriver));
	        SelectDivision.selectByVisibleText(Currency);
	     }
	     
	     //enter weight
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.radio_weigt1(wdriver));
	     WebimplicitWait(wdriver);
	     logger.log(LogStatus.PASS,"weight is clicked","weight is clicked");  
	     
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //Verify confirmation message
	     String VerifyConfirmationMsg1=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
	     Assert.assertEquals(VerifyConfirmationMsg1, "You have successfully updated your preferences.");
	     logger.log(LogStatus.PASS,"confirmation message :" +VerifyConfirmationMsg1);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	      
	     //enter new divison name
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
	     assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).sendKeys("CNBC MIXED"); 
	     Syn_Click(assetTrackMaintainPage.btn_division(wdriver));
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	       logger.log(LogStatus.PASS,"Enter the Divison Type ","Divison Type is entered ");
	     
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //Verify confirmation message
	     String VerifyConfirmationMsg11=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
	     Assert.assertEquals(VerifyConfirmationMsg11, "You have successfully updated your preferences.");
	     logger.log(LogStatus.PASS,"confirmation message :" +VerifyConfirmationMsg11);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	      }
			    catch (Exception | AssertionError e) {
			     System.out.println(e);
			         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
					 TestReporter.logFailure("Error Message:"+e.getMessage());
					  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
			    }
	}   
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Setting_up_Division(Method m,String username,String password,String Action) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Divsions(wdriver));
			logger.log(LogStatus.PASS,"Divisions link","Divisions link  is clicked ");  

			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomDivisionName;
			RandomDivisionName=RandomValue+"D";

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Thread.sleep(3000);	
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
				WebimplicitWait(wdriver);
			}

			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomDivisionName);
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered: "+RandomDivisionName);

			//Click on the Save button                
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			String Concatenate= "Division "+"'"+RandomDivisionName+"'"+ " has been added.";
			Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
			Thread.sleep(1000);
			

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
			
			//Navigate to Worker-Div Assocs Tab
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Worker-Div Assocs"));
			logger.log(LogStatus.PASS,"Worker-Div Assocs Tab","Worker-Div Assocs Tab is clicked ");
			
			Thread.sleep(10000);
			
			Syn_Click(assetTrackMaintainPage.txt_newWorkerName(wdriver));
			assetTrackMaintainPage.txt_newWorkerName(wdriver).sendKeys("MARK, A");
			
			Syn_Click(assetTrackMaintainPage.btn_FindName(wdriver));
			Thread.sleep(20000);
			switchToWindow("Tab Search");
			WebimplicitWait(wdriver);
			Thread.sleep(30000);
			wdriver.findElement(By.xpath("//input[@value='455471']")).click();
			//Syn_Click(assetTrackMaintainPage.sel_ValueWorker(wdriver));
			Thread.sleep(20000);
			
			switchToWindow("Asset Tracker v2.2.1");
			WebimplicitWait(wdriver);
			String WorkerName=assetTrackMaintainPage.txt_newWorkerName(wdriver).getAttribute("value");
			System.out.println(WorkerName);
			
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Thread.sleep(3000);	
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
				WebimplicitWait(wdriver);
			}
			logger.log(LogStatus.PASS,"Action is selected","ADD Action is selected ");

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpDivisionName(wdriver),RandomDivisionName);
			}
			else
			{
				Thread.sleep(3000);	
				Select SelectAction=new Select(assetTrackMaintainPage.drpDivisionName(wdriver));
				SelectAction.selectByVisibleText(RandomDivisionName);
				WebimplicitWait(wdriver);
				
			}
			logger.log(LogStatus.PASS,"Division is selected","Division is selected ");
			//Syn_Click(assetTrackMaintainPage.txt_newWorkerName(wdriver));
			//assetTrackMaintainPage.txt_newWorkerName(wdriver).sendKeys("MARK, A");
			
			// JavascriptExecutor jsee = (JavascriptExecutor)wdriver;
			// jsee.executeScript("arguments[0].value='MARK, A';", assetTrackMaintainPage.txt_newWorkerName(wdriver));
			 
			 
			/*Syn_Click(assetTrackMaintainPage.btn_FindName(wdriver));
			Thread.sleep(20000);
			switchToWindow("Tab Search");
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackMaintainPage.sel_ValueWorker(wdriver));
			Thread.sleep(20000);
			switchToWindow("Asset Tracker v2.2.1");
			WebimplicitWait(wdriver);
			String WorkerName=assetTrackMaintainPage.txt_newWorkerName(wdriver).getAttribute("value");*/
			Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked");
			Thread.sleep(3000);	
			String VerifyWorkDivAdded=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			String Concatenate1= "'"+WorkerName+"'"+ " has been added as Finance Contact for "+"'"+RandomDivisionName+"'" ;
			Assert.assertEquals(Concatenate1, VerifyWorkDivAdded);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
			Thread.sleep(1000);

			
			 logger.log(LogStatus.PASS,"confirmation message :" +VerifyWorkDivAdded);
		     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		     
		      }
				    catch (Exception | AssertionError e) {
				     System.out.println(e);
				         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
						 TestReporter.logFailure("Error Message:"+e.getMessage());
						  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
				    }
		}   
	



}
