package com.nbcu.assetTracker.web.MaintainModule;

//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Manufacturer_SubModule extends Commonstudio
{

	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(Manufacturer_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Manufacturer_Delete(Method m,String username,String password,String Action,String DeleteAction) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			TestReporter.logStep("Login Successful with message"+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page

			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
			TestReporter.logStep("Maintain Tab is clicked");  
			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Manufacturers(wdriver));
			logger.log(LogStatus.PASS,"Manufacturers link","Manufacturers link  is clicked ");  

			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomManufacturerName;
			RandomManufacturerName=RandomValue+"D";

			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);

			assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomManufacturerName);
			logger.log(LogStatus.PASS,"New Manufacturer Name","New Manufacturer name is entered: "+RandomManufacturerName);


			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(2000);
			WebimplicitWait(wdriver);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the Search Asset link
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackMaintainPage.lnk_Manufacturers(wdriver));
			logger.log(LogStatus.PASS,"Manufacturers link","Manufacturers link  is clicked ");

			//Verify that the Maintain My Preferences page is displayed
			String VerifyPrefernceTitle=assetTrackMaintainPage.tit_MantainManufacturers(wdriver).getText();
			Assert.assertEquals("Maintain Manufacturers", VerifyPrefernceTitle);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select Delete Action from the dropdown
			Thread.sleep(1000);
			Select SelectNewAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectNewAction.selectByVisibleText(DeleteAction);   


			//Verify that the New Manufacturer field is disabled
			Boolean verifyNewManufactField=assetTrackMaintainPage.txt_NewName(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Manufacturer field","New Manufacturer field is not enabled :"+verifyNewManufactField);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  


			//Select the Manufacturer from the list
			Select SelectManufacturer=new Select(assetTrackMaintainPage.drpdownManufacturer(wdriver));
			SelectManufacturer.selectByVisibleText(RandomManufacturerName);  
			logger.log(LogStatus.PASS," Select Manufacturer "," Manufacturer " +RandomManufacturerName+" is selected from the list");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on save button
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Verify that the confirmation message is displayed
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			String Concatenate= "Manufacturer "+"'"+RandomManufacturerName+"'"+ " has been deleted.";
			//String DivConcatenate= "Division "+"'"+RandomDivisionName+"'"+ " already exists.";
			Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	} 
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Manufacturer_Negative_Inputs(Method m,String username,String password,String Action,String InvalidManufacturerName) throws Exception
	{
		try
		{   
			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful
			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the Manufacturers link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Manufacturers"));
			logger.log(LogStatus.PASS,"Manufacturers link","Manufacturers link  is clicked ");  

			//Verify that the Maintain Manufactuers page is displayed
			String VerifyPrefernceTitle=assetTrackMaintainPage.tit_MantainManufacturers(wdriver).getText();
			Assert.assertEquals("Maintain Manufacturers", VerifyPrefernceTitle);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomManufacturerName;
			RandomManufacturerName=RandomValue+"D";

			//Click on save button      
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(2000);
			WebimplicitWait(wdriver);

			//Verify that the error message is displayed
			String VerifyErrornMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			Assert.assertEquals("Action must be specified.", VerifyErrornMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Enter the Manufacturer name and click on save without selecting any action
			assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomManufacturerName);
			logger.log(LogStatus.PASS,"New Manufacturer Name","New Division name is entered: "+RandomManufacturerName);

			//Click on save button  
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(2000);
			WebimplicitWait(wdriver);

			//Verify that the error message is displayed
			String VerifyErrornMsg1=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			Assert.assertEquals("Action must be specified.", VerifyErrornMsg1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);    

			//Verify that the default values are displayed 
			String DefaultAction= assetTrackMaintainPage.drpdownAction(wdriver).getAttribute("nodeName");
			Assert.assertEquals("SELECT", DefaultAction);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			String DefaultManufactValue=assetTrackMaintainPage.drpdownManufacturer(wdriver).getAttribute("nodeName");
			Assert.assertEquals("SELECT", DefaultManufactValue);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select ADD from the Action dropdown

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
			}
			//Enter Invalid value in the Manufacturer text field
			assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(InvalidManufacturerName);
			logger.log(LogStatus.PASS,"Invalid Manufacturer Name","Invalid Manufacture Name is entered: "+InvalidManufacturerName);

			//Click on save button
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Verify that the confirmation message is displayed
			WebDriverWait wait1 = new WebDriverWait(wdriver,100);
			wait1.until(ExpectedConditions.visibilityOf(assetTrackMaintainPage. msg_Error_Dynamic(wdriver,"Enter a valid New Manufacturer Name")));
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
			Assert.assertEquals("Enter a valid New Manufacturer Name", VerifyConfirmationMsg);
			logger.log(LogStatus.PASS,"Error message is displayed","Error message is displayed as : "+VerifyConfirmationMsg);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Error(wdriver));

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	} 
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Manufacturer_Update(Method m,String username,String password,String Action,String UpdateAction) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	     logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	     Thread.sleep(2000);
	     
	//Click on the Maintain button in the Assets page
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	     WebimplicitWait(wdriver);
	 //Create a Division
	//Click on the Divsions link
	     Syn_Click(assetTrackMaintainPage.lnk_Manufacturers(wdriver));
	     logger.log(LogStatus.PASS,"Manufacturers link","Manufacturers link  is clicked ");  
	     
	 //Select the Add Divisions from the dropdown
	     int RandomValue;
	     RandomValue=getRandomNumberInRange(1000,20000);
	     String RandomManufacturerName;
	     RandomManufacturerName=RandomValue+"D";
	     String RandomManufacturerName1=RandomManufacturerName+"F";
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	   String RandomVendorName="ADD";
	   String RandomVendorName1="UPDATE";
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

	     {

	       dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomVendorName);

	     }

	     else

	     {

	        Select SelectDivision=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));

	        SelectDivision.selectByVisibleText(RandomVendorName);

	     }
	     //Add manufacture name
	     assetTrackMaintainPage.txt_Newmanufacturer(wdriver).sendKeys(RandomManufacturerName);
	     logger.log(LogStatus.PASS,"New Manufacturer Name","New Division name is entered: "+RandomManufacturerName);
	     
	     
	     Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
	     logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	     
	     //Verify ADD message
	     String Verify_Message1=assetTrackMaintainPage.ADD_Message(wdriver).getText().trim();
	     Verify_Message1=Verify_Message1.replace("'", " ");
	     String Concatenate= "Manufacturer" +"  "   + RandomManufacturerName + "  "+ "has been added.";
	     Assert.assertEquals(Verify_Message1,Concatenate);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	      
	 //Select Update Action from the dropdown
	    // ((JavascriptExecutor)wdriver).executeScript("var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }", assetTrackMaintainPage.drpdownAction(wdriver), "UPDATE");
	          Thread.sleep(2000);
	          if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

	          {
	        	
	            dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomVendorName1);

	          }

	          else

	          {

	             Select SelectDivision=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));

	             SelectDivision.selectByVisibleText(RandomVendorName1);

	          }
				  
	         
	  //Click on save button
	     Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
	     logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
	     Thread.sleep(1000);
	     
	   //Verify that the confirmation message is displayed
	     String Verify_Message2=assetTrackMaintainPage.Validation_Message(wdriver).getText().trim();
	     Assert.assertEquals(Verify_Message2,"New Manufacturer must be specified.");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	        
	   //Select the Manufacturer from the list
	     Thread.sleep(1000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

	     {
	    	  WebimplicitWait(wdriver);
	    	  WebimplicitWait(wdriver);

	       dropDownSelectJavaScript(assetTrackMaintainPage.drpdownManufacturer(wdriver),RandomManufacturerName);

	     }

	     else

	     {

	        Select SelectDivision=new Select(assetTrackMaintainPage.drpdownManufacturer(wdriver));

	        SelectDivision.selectByVisibleText(RandomManufacturerName);

	     }
				 /*String verifyNewManufactField=assetTrackMaintainPage.txt_Newmanufacturer(wdriver).getText();
				 Select SelectManufacturer=new Select(assetTrackMaintainPage.drpdownManufacturer(wdriver));
				 SelectManufacturer.selectByVisibleText(RandomManufacturerName);*/
			     Thread.sleep(1000);
			     assetTrackMaintainPage.txt_Newmanufacturer(wdriver).clear();
			     assetTrackMaintainPage.txt_Newmanufacturer(wdriver).sendKeys(RandomManufacturerName1);
			     logger.log(LogStatus.PASS," Select Manufacturer "," Manufacturer" +RandomManufacturerName1+"is updated");
			     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //Click on save button
	     Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
	     logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
	     Thread.sleep(2000);
	     
	     
	    //Verify updated message
	     String Verify_Message=assetTrackMaintainPage.Updated_Message(wdriver).getText().trim();
	     Verify_Message=Verify_Message.replace("'", " ");
	     String Concatenate1= "Manufacturer" +"  "   + RandomManufacturerName1 + "  "+ "has been updated.";
	     Assert.assertEquals(Verify_Message,Concatenate1);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 
	    }
		    catch (Exception | AssertionError e) {
		     System.out.println(e);
		     System.out.println(e);
	         //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
	         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
	 		 TestReporter.logFailure("Error Message:"+e.getMessage());
	 		  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		     
		    }
		} 



}
