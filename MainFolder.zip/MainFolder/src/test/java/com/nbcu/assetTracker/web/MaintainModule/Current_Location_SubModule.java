package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Current_Location_SubModule extends Commonstudio 
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(Current_Location_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Current_Location_Negative_Flow(Method m,String username,String password,String Action,String Update,String Delete) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Set up: Firstly create a Division .
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	     logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	     Thread.sleep(1000);
	     
	//Click on the Maintain button in the Assets page
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	        
	//Click on the  current locations link
	     Syn_Click(assetTrackMaintainPage.lnk_currentlocations(wdriver));
	     logger.log(LogStatus.PASS,"current locations Tab","current locations Tab is clicked ");
	     Thread.sleep(1000);
	     
	     //Verify text present on location page
	     String VerifyConfirmationMsg=assetTrackMaintainPage.verifylocation(wdriver).getText().trim();
	     String Message="Select whether you want to add, update, or delete a Current Location.";
	     Assert.assertEquals(VerifyConfirmationMsg,Message);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
	     String RandomValue;
	     RandomValue=RandomStringUtils.randomAlphabetic(5);
	     String RandomModelName;
	     RandomModelName=RandomValue.toUpperCase();
	    
	     //Select Add from dropdown
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
	     }
	     else
	     {
	       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
	       SelectDivision.selectByVisibleText(Action);
	     }
	     logger.log(LogStatus.PASS,"ADD Dropdown","ADD Dropdown is Selected ");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //select Update from dropdown
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Update);
	     }
	     else
	     {
	       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
	       SelectDivision.selectByVisibleText(Update);
	     }
	     logger.log(LogStatus.PASS,"Update Dropdown","Update Action is Selected ");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //select current location
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.btn_currentlocation_Sub(wdriver));
	     switchToWindow("Tab Search");
	    Thread.sleep(15000);
	    String title= wdriver.getTitle();
	    if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	    {
	    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	    WebimplicitWait(wdriver);
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    switchToWindow("Asset Tracker v2.2.1");
	    }
	    else {
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    Thread.sleep(12000);
	    switchToWindow("Asset Tracker v2.2.1");
		 }	
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered ");
	     
	     //enter new current location
	     Thread.sleep(1000);
	     assetTrackMaintainPage.txt_newLocation(wdriver).clear();
	     assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys("@#$%"); 
	     logger.log(LogStatus.PASS,"Enter the invalid input in new current location ","invalid input in new current location is entered ");
	       
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	     Thread.sleep(1000);
	     
	   //Verify validation message
	     String VerifyMsg=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
	     String Message1="Enter a valid New Location.";
	     Assert.assertEquals(VerifyMsg,Message1);
	     logger.log(LogStatus.PASS,"Validation Message","Validation Message :"+VerifyMsg);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     wdriver.navigate().to("https://assettrackerqa.inbcu.com/fats/maintainMaintainCurrentLocations");
	     
	   //select Delete from dropdown
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Delete);
	     }
	     else
	     {
	       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
	       SelectDivision.selectByVisibleText(Delete);
	     }
	     logger.log(LogStatus.PASS,"Delete Dropdown","Delete Action is Selected ");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //select current location
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.btn_currentlocation_Sub(wdriver));
	     switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	    {
	    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	    WebimplicitWait(wdriver);
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    switchToWindow("Asset Tracker v2.2.1");
	    }
	    else {
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    Thread.sleep(3000);
	    switchToWindow("Asset Tracker v2.2.1");
		 }	
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered ");
	          
	     //erase current location
	     Thread.sleep(1000);
	     assetTrackMaintainPage.txt_currentLocation(wdriver).clear();
	     logger.log(LogStatus.PASS,"Erase the input in current location "," input in current location is erased");
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	          
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	     
	   //Verify validation message
	     Thread.sleep(3000);
	     String VerifyMsg1=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
	     String Message11="Current Location must be specified.";
	     Assert.assertEquals(VerifyMsg1,Message11);
	     logger.log(LogStatus.PASS,"Validation Message","Validation Message :"+VerifyMsg1);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	    
	   //Verify validation message
	     Thread.sleep(2000);
	     String VerifyMesg=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
	     String Messag="Current Location must be specified.";
	     Assert.assertEquals(VerifyMesg,Messag);
	     logger.log(LogStatus.PASS,"Validation Message","Validation Message :"+VerifyMesg);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
	     
	     //select current location
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.btn_currentlocation_Sub(wdriver));
	     switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	    {
	    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	    WebimplicitWait(wdriver);
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    switchToWindow("Asset Tracker v2.2.1");
	    }
	    else {
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    Thread.sleep(3000);
	    switchToWindow("Asset Tracker v2.2.1");
		 }	
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered ");
	      
	     //Cancel Button is clicked
	     Syn_Click(assetTrackMaintainPage.Btn_Cancel(wdriver));
	     logger.log(LogStatus.PASS,"Cancel Tab","Cancel button is clicked ");
	     
	   //Click on the Maintain button in the Assets page
	     Thread.sleep(2000);
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	        
	//Click on the  current locations link
	     Syn_Click(assetTrackMaintainPage.lnk_currentlocations(wdriver));
	     logger.log(LogStatus.PASS,"current locations Tab","current locations Tab is clicked ");
	     Thread.sleep(1000);
	     
	     //select Update from dropdown
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Update);
	     }
	     else
	     {
	       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
	       SelectDivision.selectByVisibleText(Update);
	     }
	     logger.log(LogStatus.PASS,"Update Dropdown","Update Action is Selected ");
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     //select current location
	     WebimplicitWait(wdriver);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.btn_currentlocation_Sub(wdriver));
	     switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	    {
	    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	    WebimplicitWait(wdriver);
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    switchToWindow("Asset Tracker v2.2.1");
	    }
	    else {
	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	    Thread.sleep(3000);
	    switchToWindow("Asset Tracker v2.2.1");
		 }	
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered ");
	     
	      }
			    catch (Exception | AssertionError e) {
			     System.out.println(e);
			         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
					 TestReporter.logFailure("Error Message:"+e.getMessage());
					  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
			    }
	}   
	
	

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Current_Location_EndToEnd(Method m,String username,String password,String Action) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Set up: Firstly create a Division .
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	     logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	     Thread.sleep(1000);
	     
	//Click on the Maintain button in the Assets page
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	        
	//Click on the  current locations link
	     
	     Syn_Click(assetTrackMaintainPage.lnk_currentlocations(wdriver));
	     logger.log(LogStatus.PASS,"current locations Tab","current locations Tab is clicked ");
	     Thread.sleep(1000);
	     
	   //Verify that the Maintain My Preferences page is displayed
		String VerifyPrefernceTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Current Locations").getText();
		Assert.assertEquals("Maintain Current Locations", VerifyPrefernceTitle);
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
		 Boolean verifySaveButton=assetTrackMaintainPage.btn_SaveModel(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifySaveButton);
         Boolean verifyCancelButton=assetTrackMaintainPage.btn_CancelMaintain(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Cancel Button Tab is displayed :"+verifyCancelButton);
		
			
		if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
		{
			dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
		}
		else
		{
			Thread.sleep(3000);	
			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);
			WebimplicitWait(wdriver);
		}	
		Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
		WebElement option = SelectAction.getFirstSelectedOption();
		String SelectedAction = option.getText().trim();
		Assert.assertEquals(SelectedAction, "ADD");
		logger.log(LogStatus.PASS,"ADD Action  ","ADD Action is selected ");
			
//User enters New Location and Clicks on Save button.
			
		int RandomValue;
		RandomValue=getRandomNumberInRange(1000,20000);
		String RandomLocation;
		RandomLocation=RandomValue+"PO";
		assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys(RandomLocation);
		Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
		Thread.sleep(10000);
		
//System should save the new location in database and repopulate the parent page with newly added location.
	//Verify the Confirmation Message is populated
	//Verify that the value is entered  
		String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
		String Concatenate= "Current Location "+"'"+RandomLocation+"'"+ " has been added.";
		Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
		Thread.sleep(1000);
			
//System should save the new location in database and repopulate the parent page with newly added location.
		String verifyCurrentLocationPopulated=assetTrackMaintainPage.txt_currentLocation(wdriver).getAttribute("value");
		Assert.assertEquals(verifyCurrentLocationPopulated, RandomLocation);
		logger.log(LogStatus.PASS,"Current Location Added ","Current Location Added in the parent window as : " +verifyCurrentLocationPopulated);
		Thread.sleep(1000);
		
//User enters New Location and Clicks on Cancel button.
		assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys(RandomLocation);
		Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
		WebimplicitWait(wdriver);
		
//Verify that the main screen is displayed after clicking on the Cancel button,without saving the data
		Thread.sleep(1000);
		String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
		Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
		logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
		Thread.sleep(1000);		
			
			
	    }
	    catch (Exception | AssertionError e) {
	     System.out.println(e);
	     logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
		 TestReporter.logFailure("Error Message:"+e.getMessage());
		  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
	    }
}   

}



