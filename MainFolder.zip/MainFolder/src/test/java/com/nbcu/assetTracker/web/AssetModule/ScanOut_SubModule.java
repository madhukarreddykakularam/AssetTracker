package com.nbcu.assetTracker.web.AssetModule;

import static org.testng.Assert.assertTrue;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ScanOut_SubModule extends Commonstudio
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(ScanOut_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_Scan_Out_Field_Validation(Method m, String username1, String password1, String State,
			String Country, String username2, String password2) throws Exception {
		try {
			int i;
			for (i = 0; i <= 1; i++) {

				logger.startTest(m.getName());
				System.out.println("method name" + (m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

//Step1:Login to the Application
				if (i == 0) {
					String username = username1;
					String password = password1;
					assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
					WebimplicitWait(wdriver);
					String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
					Assert.assertEquals("Welcome, Tester1", verifyLogin);

//Verify that the login is successful
					logger.log(LogStatus.PASS, "Login is suucessful",
							"Login is succesful with the login Message " + verifyLogin);
					Thread.sleep(1000);
				} else {
					wdriver.navigate().to("https://assettrackerqa.inbcu.com/");
					WebimplicitWait(wdriver);
					JavascriptExecutor js = (JavascriptExecutor) wdriver;
					js.executeScript("arguments[0].value='501213225';", wdriver.findElement(By.id("username")));
					js.executeScript("arguments[0].value='Pa55word';", wdriver.findElement(By.id("password")));
					org.openqa.selenium.By my_button = By.xpath("//button[contains(text(),'SIGN IN')]");
					WebclickWhenElementReady(wdriver, my_button, 10);
					String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
					Assert.assertEquals("Welcome, Tester4", verifyLogin);
//Verify that the login is successful
					logger.log(LogStatus.PASS, "Login is suucessful",
							"Login is succesful with the login Message " + verifyLogin);
					Thread.sleep(1000);
				}

//Click on the Assets button in the Assets page
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

//Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub menus should get displayed 
				Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
				Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
				Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
				Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

				// Click on the Scan Out Asset link
				Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
				logger.log(LogStatus.PASS, "Scan Out Asset Link Tab", "Scan Out Asset Link Tab is clicked ");

//Verify that the Scan out page is displayed.
				Boolean VerifyScanoutAssetField = assetTrackAssetsPge.header_ScanOutAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Scan Out Tab", "Scan Out Tab is displayed :" + VerifyScanoutAssetField);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				String RandomValue;
				RandomValue = RandomStringUtils.randomAlphabetic(5);
				String RandomName;
				RandomName = RandomValue.toUpperCase();
				String Randomemail = RandomName + "@mail.com";

				int RandomValue1;
				RandomValue1 = getRandomNumberInRange(1000, 20000);
				String RandomValuezip;
				RandomValuezip = RandomValue1 + "2";

				// Click on the add new button for contact name
				Syn_Click(assetTrackAssetsPge.btn_Addnew_Contact(wdriver));
				logger.log(LogStatus.PASS, "Add new button for contact name Tab",
						"Add new button for contact name Tab is clicked ");
				WebimplicitWait(wdriver);
				switchToWindow("Contact Name");
				WebimplicitWait(wdriver);
				// enter all the mandatory fields
				assetTrackAssetsPge.txt_Firstname(wdriver).sendKeys(RandomName);
				assetTrackAssetsPge.txt_lastname(wdriver).sendKeys(RandomName);
				assetTrackAssetsPge.txt_emailid(wdriver).sendKeys(Randomemail);
				assetTrackAssetsPge.txt_phone(wdriver).sendKeys(RandomName);
				assetTrackAssetsPge.txt_Address(wdriver).sendKeys(RandomName);
				if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
					dropDownSelectJavaScript(assetTrackAssetsPge.drp_state(wdriver), State);
				} else {
					Select SelectDivision = new Select(assetTrackAssetsPge.drp_state(wdriver));
					SelectDivision.selectByVisibleText(State);
				}
				assetTrackAssetsPge.txt_city(wdriver).sendKeys(RandomName);
				assetTrackAssetsPge.txt_Zip(wdriver).sendKeys(RandomValuezip);
				if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
					dropDownSelectJavaScript(assetTrackAssetsPge.drp_country(wdriver), Country);
				} else {
					Select SelectDivision = new Select(assetTrackAssetsPge.drp_country(wdriver));
					SelectDivision.selectByVisibleText(Country);
				}
				// Click save button
				Syn_Click(assetTrackAssetsPge.btn_Save(wdriver));
				Thread.sleep(15000);
				logger.log(LogStatus.PASS, "Contact information is saved", "Contact information is saved");

				switchToWindow("Asset Tracker v2.2.1");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				// Contact name is entered
				Syn_Click(assetTrackAssetsPge.btn_contact(wdriver));
				Thread.sleep(2000);
				switchToWindow("Tab Search");
				Thread.sleep(2000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				logger.log(LogStatus.PASS, "Contact information is picked", "Contact information is picked");
				switchToWindow("Asset Tracker v2.2.1");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				wdriver.navigate().to("http://ssologin.qa.inbcu.com/login/logoff.jsp");
				/*
				 * Alert alert = wdriver.switchTo().alert(); alert.accept(); Alert alert1 =
				 * wdriver.switchTo().alert(); alert1.accept();
				 */

			}
		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void SCAN_OUT_No_return_Date(Method m, String username, String password) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);
			Thread.sleep(1000);

			// Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
			// menus should get displayed
			Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
			Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
			Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
			Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

			// Click on the Scan out Asset link
			Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan out Asset Link Tab", "Scan out Asset Link Tab is clicked ");

			// Verify that location, Sublocation, Inventory; Contact name should get
			// displayed
			Boolean VerifyPPMC = assetTrackAssetsPge.VerifyPPMC(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan in Tab", "PPMC Tab is displayed :" + VerifyPPMC);
			Boolean VerifyLocation = assetTrackAssetsPge.VerifyLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation);
			String VerifyLocation1 = assetTrackAssetsPge.VerifyLocation(wdriver).getText().trim();
			String Name = "* Current Location";
			Assert.assertEquals(VerifyLocation1, Name);
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation1);
			// sub location
			Boolean Verify_SubLocation = assetTrackAssetsPge.Verify_SubLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Verify_SubLocation Tab", "SubLocation Tab is displayed :" + Verify_SubLocation);
			String VerifySubLocation1 = assetTrackAssetsPge.Verify_SubLocation(wdriver).getText().trim();
			String Name1 = "* Current Sub-Location";
			Assert.assertEquals(VerifySubLocation1, Name1);
			logger.log(LogStatus.PASS, "Sub Location Tab", "SubLocation Tab is displayed :" + VerifySubLocation1);
			// Contact name
			Boolean VerifyContactName = assetTrackAssetsPge.VerifyContactName(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Contact Tab", "Contact Name Tab is displayed :" + VerifyContactName);
			String VerifyContactName1 = assetTrackAssetsPge.VerifyContactName(wdriver).getText().trim();
			String Name2 = "* Contact Name";
			Assert.assertEquals(VerifyContactName1, Name2);
			logger.log(LogStatus.PASS, "contact name Tab", "contact name Tab is displayed :" + VerifyContactName1);

			Boolean VerifyObjectType = assetTrackAssetsPge.VerifyObjectType(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Object type in Tab", "Object Type Tab is displayed :" + VerifyObjectType);
			Boolean VerifyDrpObjectType = assetTrackAssetsPge.VerifyDrpObjectType(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Object type in Tab", "Object Type Tab is displayed :" + VerifyDrpObjectType);
			Boolean VerifyBudjetCode = assetTrackAssetsPge.VerifyBudjetCode(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Budjet Code in Tab", "Budjet Code Tab is displayed :" + VerifyBudjetCode);

			// Return date
			Boolean VerifyExpReturndate = assetTrackAssetsPge.VerifyExpReturndate(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyExpReturndate);
			String VerifyExpReturndate1 = assetTrackAssetsPge.VerifyExpReturndate(wdriver).getText().trim();
			String Name3 = "* Expected Return Date";
			Assert.assertEquals(VerifyExpReturndate1, Name3);
			logger.log(LogStatus.PASS, "Return date Tab",
					"Expeted Return date Tab is displayed :" + VerifyExpReturndate1);

			Boolean VerifyInventory = assetTrackAssetsPge.VerifyInventory(wdriver).isSelected();
			Boolean Flag = true;
			Assert.assertEquals(VerifyInventory, Flag);
			logger.log(LogStatus.PASS, "VerifyInventory Tab", "Inventory Tab is selected :" + VerifyInventory);

			String date = assetTrackAssetsPge.txt_ExpReturndate(wdriver).getText().trim();
			if (date.isEmpty()) {
				logger.log(LogStatus.PASS, "ExpReturndate Tab", "ExpReturndate Tab is Null");
			}
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			assetTrackAssetsPge.txt_location(wdriver).clear();
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked Without entering any data", "Continue Tab is clicked");

			// Validation message
			String ValidMsg1 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg1,
					"Current Location must be specified.\n" + "Current Sub-Location must be specified.\n"
							+ "Contact Name must be specified.\n" + "Expected Return Date must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Validation_SCAN_IN_OUT_ExpecRetDt_NoRetDate(Method m, String username, String password, String State, String Country, String datefieldVal) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Scan out Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan out Asset Link Tab", "Scan out Asset Link Tab is clicked ");

			// Verify that location, Sublocation, Inventory; Contact name should get
			// displayed
			Boolean VerifyPPMC = assetTrackAssetsPge.VerifyPPMC(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan in Tab", "PPMC Tab is displayed :" + VerifyPPMC);
			Boolean VerifyLocation = assetTrackAssetsPge.VerifyLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation);
			String VerifyLocation1 = assetTrackAssetsPge.VerifyLocation(wdriver).getText().trim();
			String Name = "* Current Location";
			Assert.assertEquals(VerifyLocation1, Name);
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation1);
			// sub location
			Boolean Verify_SubLocation = assetTrackAssetsPge.Verify_SubLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Verify_SubLocation Tab", "SubLocation Tab is displayed :" + Verify_SubLocation);
			String VerifySubLocation1 = assetTrackAssetsPge.Verify_SubLocation(wdriver).getText().trim();
			String Name1 = "* Current Sub-Location";
			Assert.assertEquals(VerifySubLocation1, Name1);
			logger.log(LogStatus.PASS, "Sub Location Tab", "SubLocation Tab is displayed :" + VerifySubLocation1);
			// Contact name
			Boolean VerifyContactName = assetTrackAssetsPge.VerifyContactName(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Contact Tab", "Contact Name Tab is displayed :" + VerifyContactName);
			String VerifyContactName1 = assetTrackAssetsPge.VerifyContactName(wdriver).getText().trim();
			String Name2 = "* Contact Name";
			Assert.assertEquals(VerifyContactName1, Name2);
			logger.log(LogStatus.PASS, "contact name Tab", "contact name Tab is displayed :" + VerifyContactName1);

			Boolean VerifyObjectType = assetTrackAssetsPge.VerifyObjectType(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Object type in Tab", "Object Type Tab is displayed :" + VerifyObjectType);
			Boolean VerifyDrpObjectType = assetTrackAssetsPge.VerifyDrpObjectType(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Object type in Tab", "Object Type Tab is displayed :" + VerifyDrpObjectType);
			Boolean VerifyBudjetCode = assetTrackAssetsPge.VerifyBudjetCode(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Budjet Code in Tab", "Budjet Code Tab is displayed :" + VerifyBudjetCode);

			// Return date
			Boolean VerifyExpReturndate = assetTrackAssetsPge.VerifyExpReturndate(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyExpReturndate);
			String VerifyExpReturndate1 = assetTrackAssetsPge.VerifyExpReturndate(wdriver).getText().trim();
			String Name3 = "* Expected Return Date";
			Assert.assertEquals(VerifyExpReturndate1, Name3);
			logger.log(LogStatus.PASS, "Return date Tab",
					"Expeted Return date Tab is displayed :" + VerifyExpReturndate1);

			Boolean VerifyInventory = assetTrackAssetsPge.VerifyInventory(wdriver).isSelected();
			Boolean Flag = true;
			Assert.assertEquals(VerifyInventory, Flag);
			logger.log(LogStatus.PASS, "VerifyInventory Tab", "Inventory Tab is selected :" + VerifyInventory);

			String date = assetTrackAssetsPge.txt_ExpReturndate(wdriver).getText().trim();
			if (date.isEmpty()) {
				logger.log(LogStatus.PASS, "ExpReturndate Tab", "ExpReturndate Tab is Null");
			}
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// current Location is entered
			assetTrackAssetsPge.txt_location(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.btn_location(wdriver));
			Thread.sleep(7000);
			switchToWindow("Tab Search");
			Thread.sleep(7000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			switchToWindow("Asset Tracker v2.2.1");
			String Location = assetTrackAssetsPge.txt_location(wdriver).getText().trim();
			logger.log(LogStatus.PASS, "current Location Tab", "current Location is selected");

			// current Sub Location is entered
			assetTrackAssetsPge.txt_sublocation(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.btn_sublocation(wdriver));
			Thread.sleep(7000);
			switchToWindow("Tab Search");
			Thread.sleep(7000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(5000);
			switchToWindow("Asset Tracker v2.2.1");
			String SubLocation = assetTrackAssetsPge.txt_sublocation(wdriver).getText().trim();
			logger.log(LogStatus.PASS, "current Sub Location Tab", "current Sub Location is selected");

			/*
			 * //Contact name is entered
			 * Syn_Click(assetTrackAssetsPge.btn_contact(wdriver)); Thread.sleep(2000);
			 * switchToWindow("Tab Search"); Thread.sleep(2000);
			 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			 * logger.log(LogStatus.PASS,"Contact information is picked"
			 * ,"Contact information is picked"); switchToWindow("Asset Tracker v2.2.1");
			 * String Contact=assetTrackAssetsPge.txt_contactname(wdriver).getText().trim();
			 * logger.log(LogStatus.PASS,"Contact name Tab","Contact name is selected");
			 * objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			 */
			// Verify that the Scan out page is displayed.
			Boolean VerifyScanoutAssetField = assetTrackAssetsPge.header_ScanOutAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan Out Tab", "Scan Out Tab is displayed :" + VerifyScanoutAssetField);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			String RandomValue;
			RandomValue = RandomStringUtils.randomAlphabetic(5);
			String RandomName;
			RandomName = RandomValue.toUpperCase();
			String Randomemail = RandomName + "@mail.com";

			int RandomValue1;
			RandomValue1 = getRandomNumberInRange(1000, 20000);
			String RandomValuezip;
			RandomValuezip = RandomValue1 + "2";

			// Click on the add new button for contact name
			Syn_Click(assetTrackAssetsPge.btn_Addnew_Contact(wdriver));
			logger.log(LogStatus.PASS, "Add new button for contact name Tab",
					"Add new button for contact name Tab is clicked ");
			WebimplicitWait(wdriver);
			Thread.sleep(7000);
			switchToWindow("Contact Name");
			WebimplicitWait(wdriver);
			Thread.sleep(5000);
			// enter all the mandatory fields
			assetTrackAssetsPge.txt_Firstname(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_lastname(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_emailid(wdriver).sendKeys(Randomemail);
			assetTrackAssetsPge.txt_phone(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_Address(wdriver).sendKeys(RandomName);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				dropDownSelectJavaScript(assetTrackAssetsPge.drp_state(wdriver), State);
			} else {
				Select SelectDivision = new Select(assetTrackAssetsPge.drp_state(wdriver));
				SelectDivision.selectByVisibleText(State);
			}
			assetTrackAssetsPge.txt_city(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_Zip(wdriver).sendKeys(RandomValuezip);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				dropDownSelectJavaScript(assetTrackAssetsPge.drp_country(wdriver), Country);
			} else {
				Select SelectDivision = new Select(assetTrackAssetsPge.drp_country(wdriver));
				SelectDivision.selectByVisibleText(Country);
			}

			// Click save button
			Syn_Click(assetTrackAssetsPge.btn_Save(wdriver));
			Thread.sleep(25000);
			WebimplicitWait(wdriver);
			WebimplicitWait(wdriver);
			logger.log(LogStatus.PASS, "Contact information is saved", "Contact information is saved");

			switchToWindow("Asset Tracker v2.2.1");

			String Contact = assetTrackAssetsPge.txt_contactname(wdriver).getText().trim();
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");

			// Validation message
			String ValidMsg1 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg1, "Expected Return Date must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Date is entered
			/*
			 * Syn_Click(assetTrackAssetsPge.Btn_Date(wdriver)); Thread.sleep(2000);
			 * switchToWindow("Calendar"); Thread.sleep(4000);
			 * Syn_Click(assetTrackAssetsPge.CurrentDate(wdriver)); Thread.sleep(4000);
			 * switchToWindow("Asset Tracker v2.2.1");
			 */

			WebElement element1 = wdriver.findElementByXPath("//input[@class='txtDate']");
			selectDateJavScriptExe(datefieldVal, element1);

			logger.log(LogStatus.PASS, "Date Tab", "Date is selected");
			String Newdate = assetTrackAssetsPge.txt_ExpReturndate(wdriver).getText().trim();

			// deselect the inventory
			Syn_Click(assetTrackAssetsPge.VerifyInventory(wdriver));
			logger.log(LogStatus.PASS, "deselect the inventory", "deselect the inventory");
			Thread.sleep(2000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");

			// Scan Out Page is displayed
			Boolean Verify_scanin = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan Out Page", "Scan Out Page is displayed :" + Verify_scanin);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Cancel Button
			Syn_Click(assetTrackAssetsPge.Btn_Cancel(wdriver));
			logger.log(LogStatus.PASS, "Cancel Tab is clicked Without entering any data", "Cancel Tab is clicked");

			// The Data entered is same as previous one
			String Newdate1 = assetTrackAssetsPge.txt_ExpReturndate(wdriver).getText().trim();
			Assert.assertEquals(Newdate, Newdate1);
			String Contact1 = assetTrackAssetsPge.txt_contactname(wdriver).getText().trim();
			Assert.assertEquals(Contact, Contact1);
			String SubLocation1 = assetTrackAssetsPge.txt_sublocation(wdriver).getText().trim();
			Assert.assertEquals(SubLocation, SubLocation1);
			String Location1 = assetTrackAssetsPge.txt_location(wdriver).getText().trim();
			Assert.assertEquals(Location, Location1);
			logger.log(LogStatus.PASS, "The Data entered is same as previous one",
					"The Data entered is same as previous one");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// select the inventory
			Syn_Click(assetTrackAssetsPge.VerifyInventory(wdriver));
			logger.log(LogStatus.PASS, "select the inventory", "select the inventory");
			Thread.sleep(2000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");

			// Scan Out Page is displayed
			Boolean Verify_scanin1 = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan Out Page", "Scan Out Page is displayed :" + Verify_scanin1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_ScanOut_Negative_flow(Method m, String username, String password, String State, String Country, String datefieldVal) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Scan out Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan out Asset Link Tab", "Scan out Asset Link Tab is clicked ");

			// Verify that location, Sublocation, Inventory; Contact name should get
			// displayed
			Boolean VerifyPPMC = assetTrackAssetsPge.VerifyPPMC(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan in Tab", "PPMC Tab is displayed :" + VerifyPPMC);
			Boolean VerifyLocation = assetTrackAssetsPge.VerifyLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation);
			String VerifyLocation1 = assetTrackAssetsPge.VerifyLocation(wdriver).getText().trim();
			String Name = "* Current Location";
			Assert.assertEquals(VerifyLocation1, Name);
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation1);
			// sub location
			Boolean Verify_SubLocation = assetTrackAssetsPge.Verify_SubLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Verify_SubLocation Tab", "SubLocation Tab is displayed :" + Verify_SubLocation);
			String VerifySubLocation1 = assetTrackAssetsPge.Verify_SubLocation(wdriver).getText().trim();
			String Name1 = "* Current Sub-Location";
			Assert.assertEquals(VerifySubLocation1, Name1);
			logger.log(LogStatus.PASS, "Sub Location Tab", "SubLocation Tab is displayed :" + VerifySubLocation1);
			// Contact name
			Boolean VerifyContactName = assetTrackAssetsPge.VerifyContactName(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Contact Tab", "Contact Name Tab is displayed :" + VerifyContactName);
			String VerifyContactName1 = assetTrackAssetsPge.VerifyContactName(wdriver).getText().trim();
			String Name2 = "* Contact Name";
			Assert.assertEquals(VerifyContactName1, Name2);
			logger.log(LogStatus.PASS, "contact name Tab", "contact name Tab is displayed :" + VerifyContactName1);

			// Return date
			Boolean VerifyExpReturndate = assetTrackAssetsPge.VerifyExpReturndate(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyExpReturndate);
			String VerifyExpReturndate1 = assetTrackAssetsPge.VerifyExpReturndate(wdriver).getText().trim();
			String Name3 = "* Expected Return Date";
			Assert.assertEquals(VerifyExpReturndate1, Name3);
			logger.log(LogStatus.PASS, "Return date Tab",
					"Expeted Return date Tab is displayed :" + VerifyExpReturndate1);

			Boolean VerifyInventory = assetTrackAssetsPge.VerifyInventory(wdriver).isSelected();
			Boolean Flag = true;
			Assert.assertEquals(VerifyInventory, Flag);
			logger.log(LogStatus.PASS, "VerifyInventory Tab", "Inventory Tab is selected :" + VerifyInventory);

			String date = assetTrackAssetsPge.txt_ExpReturndate(wdriver).getAttribute("value");
			if (date.isEmpty()) {
				logger.log(LogStatus.PASS, "ExpReturndate Tab", "ExpReturndate Tab is Null");
			}
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Invalid Values are entered in the location field
			//Invalid current Location is entered
			assetTrackAssetsPge.txt_location(wdriver).clear();
			assetTrackAssetsPge.txt_location(wdriver).sendKeys("@#$%^");
			logger.log(LogStatus.PASS, "Invalid current Location is entered", "Invalid current Location is entered");
			
			//Invalid current Sub Location is entered
			assetTrackAssetsPge.txt_sublocation(wdriver).clear();
			assetTrackAssetsPge.txt_sublocation(wdriver).sendKeys("@#$%^");
			logger.log(LogStatus.PASS, "Invalid current sub Location is entered", "Invalid current sub Location is entered");
			
			//Invalid Contact name is entered
			assetTrackAssetsPge.txt_contactname(wdriver).clear();
			assetTrackAssetsPge.txt_contactname(wdriver).sendKeys("@#$%^");
			logger.log(LogStatus.PASS, " Invalid Contact name is entered", "Invalid Contact name is entered");
			
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			
			// Validation message
			String ValidMsg1 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg1,"Select Current Location only from pop up.\n" + 
					"Select Current Sub-Location only from pop up.\n" + 
					"Please Select Contact Name only from pop-up.\n" + 
					"Expected Return Date must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Blank Values are entered in the location field
			//Blank current Location is entered
			assetTrackAssetsPge.txt_location(wdriver).clear();
			logger.log(LogStatus.PASS, "Blank current Location is entered", "Blank current Location is entered");
			
			//Blank current Sub Location is entered
			assetTrackAssetsPge.txt_sublocation(wdriver).clear();
			logger.log(LogStatus.PASS, "Blank current sub Location is entered", "Blank current sub Location is entered");
			
			//Blank Contact name is entered
			assetTrackAssetsPge.txt_contactname(wdriver).clear();
			logger.log(LogStatus.PASS, " Blank Contact name is entered", "Blank Contact name is entered");
			
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			
			// Validation message
			String ValidMsg2 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg2,"Current Location must be specified.\n" + 
					"Current Sub-Location must be specified.\n" + 
					"Contact Name must be specified.\n" + 
					"Expected Return Date must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg2);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// current Location is entered
			assetTrackAssetsPge.txt_location(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.btn_location(wdriver));
			Thread.sleep(15000);
			switchToWindow("Tab Search");
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			String Location = assetTrackAssetsPge.txt_location(wdriver).getText().trim();
			logger.log(LogStatus.PASS, "current Location Tab", "current Location is selected");

			// current Sub Location is entered
			assetTrackAssetsPge.txt_sublocation(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.btn_sublocation(wdriver));
			Thread.sleep(15000);
			switchToWindow("Tab Search");
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			String SubLocation = assetTrackAssetsPge.txt_sublocation(wdriver).getAttribute("value");
			logger.log(LogStatus.PASS, "current Sub Location Tab", "current Sub Location is selected");
			
			String RandomValue;
			RandomValue = RandomStringUtils.randomAlphabetic(5);
			String RandomName;
			RandomName = RandomValue.toUpperCase();
			String Randomemail = RandomName + "@mail.com";

			int RandomValue1;
			RandomValue1 = getRandomNumberInRange(1000, 20000);
			String RandomValuezip;
			RandomValuezip = RandomValue1 + "2";

			// Click on the add new button for contact name
			Syn_Click(assetTrackAssetsPge.btn_Addnew_Contact(wdriver));
			logger.log(LogStatus.PASS, "Add new button for contact name Tab",
					"Add new button for contact name Tab is clicked ");
			WebimplicitWait(wdriver);
			Thread.sleep(15000);
			switchToWindow("Contact Name");
			WebimplicitWait(wdriver);
			Thread.sleep(15000);
			// enter all the mandatory fields
			assetTrackAssetsPge.txt_Firstname(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_lastname(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_emailid(wdriver).sendKeys(Randomemail);
			assetTrackAssetsPge.txt_phone(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_Address(wdriver).sendKeys(RandomName);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				dropDownSelectJavaScript(assetTrackAssetsPge.drp_state(wdriver), State);
			} else {
				Select SelectDivision = new Select(assetTrackAssetsPge.drp_state(wdriver));
				SelectDivision.selectByVisibleText(State);
			}
			assetTrackAssetsPge.txt_city(wdriver).sendKeys(RandomName);
			assetTrackAssetsPge.txt_Zip(wdriver).sendKeys(RandomValuezip);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				dropDownSelectJavaScript(assetTrackAssetsPge.drp_country(wdriver), Country);
			} else {
				Select SelectDivision = new Select(assetTrackAssetsPge.drp_country(wdriver));
				SelectDivision.selectByVisibleText(Country);
			}

			// Click save button
			Syn_Click(assetTrackAssetsPge.btn_Save(wdriver));
			Thread.sleep(25000);
			WebimplicitWait(wdriver);
			WebimplicitWait(wdriver);
			logger.log(LogStatus.PASS, "Contact information is saved", "Contact information is saved");

			switchToWindow("Asset Tracker v2.2.1");

			String Contact = assetTrackAssetsPge.txt_contactname(wdriver).getAttribute("value");
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");

			// Validation message
			String ValidMsg11 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg11, "Expected Return Date must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg11);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//New current Location is entered
			assetTrackAssetsPge.txt_location(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.Btn_AddnewLocation(wdriver));
			Thread.sleep(15000);
			switchToWindow("maintainMaintainCurrentLocations");
			Thread.sleep(15000);
			switchToWindow("maintainMaintainCurrentLocations");
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			Thread.sleep(15000);
			// Validation message
			switchToWindow("maintainMaintainCurrentLocations");
			String ValidMsg111 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg111, "New Location must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg111);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(15000);
			switchToWindow("maintainMaintainCurrentLocations");
			JavascriptExecutor jse = (JavascriptExecutor) wdriver;
			jse.executeScript("arguments[0].value='@@@@@';", assetTrackAssetsPge.NewSubLocation_txt(wdriver));
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			Thread.sleep(15000);
			// Validation message
			switchToWindow("maintainMaintainCurrentLocations");
			String ValidMsg3 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg3, "Enter a valid New Location.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg3);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(15000);
			//assetTrackAssetsPge.NewLocation_txt(wdriver).sendKeys(RandomValue);
			switchToWindow("maintainMaintainCurrentLocations");
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
			jse.executeScript("arguments[0].value='"+RandomValue+"';", assetTrackAssetsPge.NewLocation_txt(wdriver));
			logger.log(LogStatus.PASS, "New Location is entered ", "New Location is entered");
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			String Location1 = assetTrackAssetsPge.txt_location(wdriver).getAttribute("value");
			logger.log(LogStatus.PASS, "current Location Tab", "New current Location is Addded");
			
			//New Sub Location is entered
			Syn_Click(assetTrackAssetsPge.Btn_AddnewSubLocation(wdriver));
			Thread.sleep(50000);
			switchToWindow("maintainMaintainCurrentSubLocations");
			Thread.sleep(50000);
			JavascriptExecutor jse1 = (JavascriptExecutor) wdriver;
			jse1.executeScript("arguments[0].value='"+RandomValue+"';", assetTrackAssetsPge.NewSubLocation_txt(wdriver));
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			String Location11 = assetTrackAssetsPge.txt_location(wdriver).getAttribute("value");
			logger.log(LogStatus.PASS, "current sub Location Tab", "New current sub Location is Addded");
			
			WebElement element1 = wdriver.findElementByXPath("//input[@class='txtDate']");
			selectDateJavScriptExe(datefieldVal, element1);

			logger.log(LogStatus.PASS, "Date Tab", "Date is selected");
			String Newdate = assetTrackAssetsPge.txt_ExpReturndate(wdriver).getAttribute("value");
			
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Scan Out Page is displayed
			Boolean Verify_scanin = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan Out Page", "Scan Out Page is displayed :" + Verify_scanin);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			
			// Validation message
			String ValidMsg4 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg4, "Please provide at least one Tracking Number.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg3);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Enter tracking number which is not present in the system
			//assetTrackAssetsPge.Tracking_txt(wdriver).sendKeys("PPPPP");
			JavascriptExecutor jse3 = (JavascriptExecutor) wdriver;
			jse3.executeScript("arguments[0].value='PPPPP';", assetTrackAssetsPge.Tracking_txt(wdriver));
			Thread.sleep(2000);
			Syn_Click(assetTrackAssetsPge.btnAdd(wdriver));
			
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			
			// Validation message
			Thread.sleep(5000);
			String ValidMsg5 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg5, "Tracking Number (PPPPP) cannot be found in the system.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg5);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(2000);
			Syn_Click(assetTrackAssetsPge.TrackingNumber(wdriver));
			// Click Remove Button
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.Btn_Remove(wdriver));
			Thread.sleep(15000);
			logger.log(LogStatus.PASS, "Remove Tab is clicked ", "Remove Tab is clicked");
			
			//Enter valid tracking number 
			//assetTrackAssetsPge.Tracking_txt(wdriver).sendKeys("2017");
			JavascriptExecutor jse4 = (JavascriptExecutor) wdriver;
			jse4.executeScript("arguments[0].value='2017';", assetTrackAssetsPge.Tracking_txt(wdriver));
			Syn_Click(assetTrackAssetsPge.btnAdd(wdriver));
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
					
			//Confirm Button is clicked
			Thread.sleep(2000);
			 JavascriptExecutor jse11 = (JavascriptExecutor)wdriver;
			  jse11.executeScript("scroll(0, 250);");	 
			Syn_Click(assetTrackAssetsPge.Btn_confirm(wdriver));
			logger.log(LogStatus.PASS, "Confirm Tab is clicked ", "Confirm Tab is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Home button is clicked
			Thread.sleep(3000);
			Syn_Click(assetTrackAssetsPge.Btn_Home(wdriver));
			logger.log(LogStatus.PASS, "Home Tab is clicked ", "Home Tab is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Scan out Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan out Asset Link Tab", "Scan out Asset Link Tab is clicked ");

			// current Sub Location is entered
			assetTrackAssetsPge.txt_sublocation(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.btn_sublocation(wdriver));
			Thread.sleep(15000);
			switchToWindow("Tab Search");
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "current Sub Location Tab", "current Sub Location is selected");
					
			//Contact is entered
			JavascriptExecutor jse9 = (JavascriptExecutor) wdriver;
			jse1.executeScript("arguments[0].value='"+Contact+"';", assetTrackAssetsPge.NewSubLocation_txt(wdriver));
			Syn_Click(assetTrackAssetsPge.btn_contact(wdriver));
			Thread.sleep(15000);
			Thread.sleep(15000);
			Thread.sleep(15000);
			Thread.sleep(15000);
			Thread.sleep(15000);
			Thread.sleep(15000);
			switchToWindow("Tab Search");
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Contact Tab", "Contact is selected");
			
			WebElement element = wdriver.findElementByXPath("//input[@class='txtDate']");
			selectDateJavScriptExe(datefieldVal, element);

			logger.log(LogStatus.PASS, "Date Tab", "Date is selected");
			
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked ", "Continue Tab is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Scan Out Page is displayed
			Boolean Verify_scanin1 = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan Out Page", "Scan Out Page is displayed :" + Verify_scanin1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			
		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}
	
	 @Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
		public void Verification_PrintablePage_DetailsofNewlyaddedAsset(Method m, String username, String password)
				throws Exception {
			try {
				logger.startTest(m.getName());
				System.out.println("method name" + (m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

	//Step1:Login to the Application
				assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
				WebimplicitWait(wdriver);
				String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

	//Verifying that the Login is successful
				Thread.sleep(2000);
				logger.log(LogStatus.PASS, "Login is suucessful",
						"Login is succesful with the login Message " + verifyLogin);
				Thread.sleep(1000);

	//Click on the Assets button in the Assets page
				Thread.sleep(2000);
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

	//Click on the Enter Asset link
				Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
				logger.log(LogStatus.PASS, "Enter Asset Link Tab", "Enter Asset Link Tab is clicked ");

				// Click Enter without PO
				Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
				logger.log(LogStatus.PASS, "Button Enter Without PO Tab", "Button Enter Without PO Tab is clicked ");

				// Asset Details page is displayed
				Thread.sleep(2000);
				String Enterassetdetailspge = assetTrackAssetsPge.Enterassetdetailspge(wdriver).getText().trim();
				Assert.assertEquals(Enterassetdetailspge, "Asset Details");
				logger.log(LogStatus.PASS, "Asset Details page is displayed", "Asset Details page is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				// Enter the mandatory details
				// Vendor details
				Syn_Click(assetTrackAssetsPge.BtnVendor(wdriver));
				Thread.sleep(4000);
				switchToWindow("Tab Search");
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(4000);
				switchToWindow("Asset Tracker v2.2.1");
				// choose sap
				if (assetTrackAssetsPge.Btn_PoSystem(wdriver).isSelected()) {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				} else {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				}

				// enter cost Object
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_costobject(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.Btn_costobject(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(4000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "cost Object is entered", "cost Object is entered");
				// enter Account Number
				Thread.sleep(5000);
				assetTrackAssetsPge.txtGlaccount(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btnGlaccount(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Account Number is entered", "Account Number is entered");
				// Enter First cost
				int RandomValue;
				RandomValue = getRandomNumberInRange(1000, 20000);
				String RandomCost;
				RandomCost = RandomValue + "5";
				assetTrackAssetsPge.Txt_FirstCost(wdriver).sendKeys(RandomCost);
				logger.log(LogStatus.PASS, "First cost is entered", "First cost is entered");
				// enter Status
				Thread.sleep(10000);
				int RandomValue11;
				RandomValue11 = getRandomNumberInRange(1000000, 20000000);
				String TrakingNumber = String.valueOf(RandomValue11);
				assetTrackAssetsPge.txt_TrackingItemNo(wdriver).sendKeys(TrakingNumber);
				logger.log(LogStatus.PASS, "Tracking Number is entered", "Tracking Number is entered");
				
				
				assetTrackAssetsPge.EnterAssetPage_StatusTextBox(wdriver).sendKeys("CNBC GREEN UPDATE");
				Thread.sleep(3000);
				
			
				Syn_Click(assetTrackAssetsPge.btnStatusId(wdriver));
				logger.log(LogStatus.PASS, "Status is entered", "Status is entered");
				
				/*Syn_Click(assetTrackAssetsPge.btnStatusId(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValue1Window(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Status is entered", "Status is entered");*/
				// enter Division

				
				
				
				Thread.sleep(10000);
				assetTrackAssetsPge.txt_division(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_division(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Division is entered", "Division is entered");
				// enter Country
				Thread.sleep(10000);
				assetTrackAssetsPge.txt_Country(wdriver).sendKeys("AFGHANISTAN");
				Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
				Thread.sleep(1000);
				Thread.sleep(1000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Country is entered", "Country is entered");
				// enter Model
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_Model(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Model is entered", "Model is entered");
				// enter Current Location
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_currentlocation(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Current Location is entered", "Current Location is entered");
				// enter Sublocation
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SublocationId(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Mandatory fields is entered", "Mandatory fields is entered");
				
				  //enter Permanent location Thread.sleep(10000);
				 //assetTrackAssetsPge.txt_PermanentLocation(wdriver).clear();
				  Syn_Click(assetTrackAssetsPge.btn_PermanentLocation(wdriver));
				  Thread.sleep(5000);
				  switchToWindow("Tab Search"); 
				  Thread.sleep(5000);
				  Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				  Thread.sleep(5000);
				  switchToWindow("Asset Tracker v2.2.1");
				  
				  //enter Permanent Sublocation Thread.sleep(10000);
				  //assetTrackAssetsPge.txt_permanentSublocationID(wdriver).clear();
				  Syn_Click(assetTrackAssetsPge.btn_permanentSublocationID(wdriver));
				  Thread.sleep(5000); 
				  switchToWindow("Tab Search"); 
				  Thread.sleep(5000);
				  Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				  Thread.sleep(5000);
				  switchToWindow("Asset Tracker v2.2.1");
				  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				 
				  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			         
				// Click Add asset button
				Syn_Click(assetTrackAssetsPge.btn_ADDAsset(wdriver));
				logger.log(LogStatus.PASS, "Add asset button is clicked", "Add asset button is clicked");
				Thread.sleep(5000);
				// Verify Confirmation page
				/*Boolean BtnViewAsset = assetTrackAssetsPge.BtnViewAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "View Asset Tab", "View Asset Tab is displayed :" + BtnViewAsset);
				Boolean BtnCopyAsset = assetTrackAssetsPge.BtnCopyAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Copy Asset Tab", "Copy Asset Tab is displayed :" + BtnCopyAsset);
				Boolean BtnCreatenewAsset = assetTrackAssetsPge.BtnCreatenewAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Create new Asset Tab",
						"Create new Asset Tab is displayed :" + BtnCreatenewAsset);*/
				/*objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				// Click View asset button
				Syn_Click(assetTrackAssetsPge.BtnViewAsset(wdriver));
				logger.log(LogStatus.PASS, "View Asset Tab", "View Asset Tab is clicked");
				Thread.sleep(1000);

				// Verify Single Finance details
				Boolean Getcount_ProfitCenter = assetTrackAssetsPge.Getcount_ProfitCenter(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Only One Profit Center",
						"Only One Profit Center is displayed :" + Getcount_ProfitCenter);
				Boolean Getcount_Account = assetTrackAssetsPge.Getcount_Account(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Only One GlAccount Center",
						"Only One GlAccount Center is displayed :" + Getcount_Account);
				String Gettxt_Cost = assetTrackAssetsPge.Gettxt_Cost(wdriver).getText().trim();
				Boolean Getcount_Internal = assetTrackAssetsPge.Getcount_Internal(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Only One Internal Order is present",
						"Internal Order is present is displayed :" + Getcount_Internal);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
*/
				//Click on the Assets button in the Assets page
		        Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
		        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
		         
		         
		//Click on the Scan In Tab button in the Assets page
		         Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
		         logger.log(LogStatus.PASS,"Scan Out Tab","Scan Out Tab is clicked ");
		  
		         Thread.sleep(5000);
		       //set current location
		           Syn_Click(assetTrackAssetsPge.btn_ScanOutPageCurrentLocation(wdriver));
		           Thread.sleep(10000);
		         Syn_Sleep();
		         Syn_Sleep();
		         switchToWindow("Tab Search");
		         Syn_Sleep();
		         Syn_Click(assetTrackAssetsPge.radiobtn_ScanInCurrentLocationSelection(wdriver));
		         Syn_Sleep();
		         Syn_Sleep();
		         logger.log(LogStatus.PASS,"Set current loaction","current loaction is Set Successfully ");
		         switchToWindow("Asset Tracker v2.2.1");
		        
		        
		         //set current location
		         Thread.sleep(8000);
		         Syn_Click(assetTrackAssetsPge.btn_ScanOutPageCurrentSubLocation(wdriver));
		         Thread.sleep(5000);
		         
		         switchToWindow("Tab Search");
		        
		         
		         
		         
		         
		         
		        // Syn_Click(assetTrackAssetsPge.radiobtn_ScanOutCurrentSubLocationSelection(wdriver));
		         Syn_Click(assetTrackAssetsPge.radiobtn_ScanInCurrentSubLocationSelection(wdriver));
		         logger.log(LogStatus.PASS,"Set current loaction","current loaction is Set Successfully ");
		         switchToWindow("Asset Tracker v2.2.1");
		         
		         
		         
		         //set contact name
		         Syn_Click(assetTrackAssetsPge.btn_ScanOutPageContactName(wdriver));
		         Syn_Sleep();
		         Thread.sleep(10000);
		         
		         Thread.sleep(10000);
		         
		         Thread.sleep(10000);
		       
		         Thread.sleep(20000);
		    
		        
		         
		         switchToWindow("Tab Search");
		         Syn_Sleep();
		         Syn_Click(assetTrackAssetsPge.radiobtn_ScanInCurrentSubLocationSelection(wdriver));
		         Syn_Sleep();
		         Syn_Sleep();
		         logger.log(LogStatus.PASS,"Set scan out page contact name","scan out page contact name is Set Successfully ");
		          switchToWindow("Asset Tracker v2.2.1");
		         Syn_Sleep();
		         Syn_Sleep();
		         
		      // Create object of SimpleDateFormat class and decide the format
		        
		         
		         
		         //set calender date
		         Syn_Click(assetTrackAssetsPge.btn_ScanOutPageCalenderIcon(wdriver));
		         Thread.sleep(5000);
		         switchToWindow("Calendar");
		         
		         Syn_Click(assetTrackAssetsPge.btn_ScanOutPageCalenderDate(wdriver));
		         switchToWindow("Asset Tracker v2.2.1");
		         
		         logger.log(LogStatus.PASS,"Calender date should be set","calender date is set successfully");
		         
		         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		         
		         Syn_Click(assetTrackAssetsPge.btn_ScanInPageContinueButton(wdriver));
		        Thread.sleep(5000);
		         
		         
		         //add value
		      
		       // String acttext = "";
		                 assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(TrakingNumber);
		                // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys("10132895");
		             // Robot r = new Robot();
		                 assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Keys.ENTER);
		                 Syn_Sleep();
		                 Syn_Sleep();
		                 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		                 logger.log(LogStatus.PASS,"Single valid tracking number should be added without any error message","Single valid tracking number is added without any error message");
		                 
		                
		       

		        
		        Syn_Click(assetTrackAssetsPge.btn_ScanInPageAddTrackingNumContinueButton(wdriver));
		       
		        Thread.sleep(1000);
		       WebElement select = assetTrackAssetsPge.btn_ScanInPrintablePagebtn(wdriver);
		((JavascriptExecutor) wdriver).executeScript("arguments[0].scrollIntoView(true);", select);

		        Boolean verifyprintablepagebtn=assetTrackAssetsPge.btn_ScanInPrintablePagebtn(wdriver).isDisplayed();
		        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		        logger.log(LogStatus.PASS,"verify printable page btn","verify printable page btn is displayed :"+verifyprintablepagebtn);

		        
		      
		        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		        Thread.sleep(1000);
		        //tracking headers
		        ArrayList<String> ScanInHeaders = new ArrayList<String>();
		        List<WebElement> ScanInPageHeaderDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[1]"));
		        for(int h=1;h<=ScanInPageHeaderDetails.size()-1;h++)
		{
		   
		WebElement headers = ScanInPageHeaderDetails.get(h);
		String hDetails = headers.getText();
		ScanInHeaders.add(hDetails);
		    
		}
		    //manufacturer
		        ArrayList<String> ScanInHeaderLatestShipment = new ArrayList<String>();
		        List<WebElement> ScanInHeaderLatestShipmentDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[2]"));
		        for(int l=1;l<=ScanInHeaderLatestShipmentDetails.size()-1;l++)
		{
		   
		WebElement latestshipmentheaders = ScanInHeaderLatestShipmentDetails.get(l);
		String hshipmentDetails = latestshipmentheaders.getText();
		ScanInHeaders.add(hshipmentDetails);
		    
		} 
		        //model
		        ArrayList<String> ScanInHeaderCaseNum = new ArrayList<String>();
		        List<WebElement> ScanInHeaderCaseNumDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[3]"));
		        for(int l=1;l<=ScanInHeaderCaseNumDetails.size()-1;l++)
		{
		   
		WebElement caseNumheaders = ScanInHeaderCaseNumDetails.get(l);
		String hcasenumDetails = caseNumheaders.getText();
		ScanInHeaders.add(hcasenumDetails);
		    
		} 
		        //type 
		        ArrayList<String> ScanInHeaderManufacturer = new ArrayList<String>();
		        List<WebElement> ScanInManufacturerDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[4]"));
		        for(int l=1;l<=ScanInManufacturerDetails.size()-1;l++)
		{
		   
		WebElement Manufacturerheaders = ScanInManufacturerDetails.get(l);
		String hmanuDetails = Manufacturerheaders.getText();
		ScanInHeaders.add(hmanuDetails);
		    
		} 
		        
		     
		     
		        WebElement quantityscanout = wdriver.findElement(By.xpath("//tr[@id='original_header']/../tr/td[5]/input"));
		    String quantitypDetails = quantityscanout.getAttribute("value");
		ScanInHeaders.add(quantitypDetails);

		        
		        
		        
		        
		        //comments 
		        ArrayList<String> ScanInHeadermodel = new ArrayList<String>();
		        List<WebElement> ScanInHeadermodelDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[6]"));
		        for(int l=1;l<=ScanInHeadermodelDetails.size()-1;l++)
		{
		   
		WebElement Modelheaders = ScanInHeadermodelDetails.get(l);
		String hmodelDetails = Modelheaders.getText().trim();
		ScanInHeaders.add(hmodelDetails);
		    
		} 
		      
		       
		        
		        
		        
		        
		        
		        
		        
		        
		        
		        WebElement scroll = assetTrackAssetsPge.btn_ScanInPrintablePagebtn(wdriver);
		((JavascriptExecutor) wdriver).executeScript("arguments[0].scrollIntoView(true);", scroll);

		        Syn_Click(assetTrackAssetsPge.btn_ScanInPrintablePagebtn(wdriver));
		        Thread.sleep(5000);
		        switchToWindow1("Asset Tracker v2.2.1");
		        Syn_Sleep();
		        
		       // Boolean itemNum=assetTrackAssetsPge.Lbl_PrintablePage_itemNum(wdriver).isDisplayed();
		        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		      //tracking number
		        ArrayList<String> printablepageDetails = new ArrayList<String>();
		        List<WebElement> printablepageTrackingNumDetails =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[2]"));
		        for(int l=1;l<=printablepageTrackingNumDetails.size()-1;l++)
		{
		   
		WebElement printablepageTrackingNumheaders = printablepageTrackingNumDetails.get(l);
		String htrnumbersprintablepageDetails = printablepageTrackingNumheaders.getText();
		printablepageDetails.add(htrnumbersprintablepageDetails);
		    
		} 
		        
		        
		      //manufacturer
		    //    ArrayList<String> ScanInHeaderLatestShipment = new ArrayList<String>();
		        List<WebElement> ScanInPageHeaderLatestShipmentDetails =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[3]"));
		        for(int l=1;l<=ScanInPageHeaderLatestShipmentDetails.size()-1;l++)
		{
		   
		WebElement scanInPagelatestshipmentheaders = ScanInPageHeaderLatestShipmentDetails.get(l);
		String scaninhshipmentDetails = scanInPagelatestshipmentheaders.getText();
		printablepageDetails.add(scaninhshipmentDetails);
		    
		} 
		        //model
		        ArrayList<String> ScanInHeaderCaseNum1 = new ArrayList<String>();
		        List<WebElement> ScanInHeaderCaseNumDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[4]"));
		        for(int l=1;l<=ScanInHeaderCaseNumDetails1.size()-1;l++)
		{
		   
		WebElement caseNumheaders1 = ScanInHeaderCaseNumDetails1.get(l);
		String hcasenumDetails1 = caseNumheaders1.getText();
		printablepageDetails.add(hcasenumDetails1);
		    
		} 
		        //type 
		        ArrayList<String> ScanInHeaderManufacturer1 = new ArrayList<String>();
		        List<WebElement> ScanInManufacturerDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[5]"));
		        for(int l=1;l<=ScanInManufacturerDetails1.size()-1;l++)
		{
		   
		WebElement Manufacturerheaders1 = ScanInManufacturerDetails1.get(l);
		String hmanuDetails1 = Manufacturerheaders1.getText();
		printablepageDetails.add(hmanuDetails1);
		    
		} 
		        
		      //quantity 
		        ArrayList<String> ScanInHeadermodel1 = new ArrayList<String>();
		        List<WebElement> ScanInHeadermodelDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[6]"));
		        for(int l=1;l<=ScanInHeadermodelDetails1.size()-1;l++)
		{
		   
		WebElement Modelheaders1 = ScanInHeadermodelDetails1.get(l);
		String hmodelDetails1 = Modelheaders1.getText().trim();
		printablepageDetails.add(hmodelDetails1);
		    
		} 
		      
		        //comments
		     //   ArrayList<String> ScanInHeadertype1 = new ArrayList<String>();
		        List<WebElement> ScanInHeadertypeDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[7]"));
		        for(int l=1;l<=ScanInHeadertypeDetails1.size()-1;l++)
		{
		   
		WebElement typeheaders11 = ScanInHeadertypeDetails1.get(l);
		String typeDetails11 = typeheaders11.getText().trim();
		printablepageDetails.add(typeDetails11);
		    
		}
		     
		        if (ScanInHeaders.equals(printablepageDetails)) 
		        {
		        logger.log(LogStatus.PASS,"Scan Out page and printable page details should be same",
		        "Scan Out page and printable page details are same");
		            System.out.println("Equal"); 
		        }
		        else
		        {
		        logger.log(LogStatus.FAIL,"Scan Out page and printable page details should be same",
		        "Scan Out page and printable page details are not same");
		          
		            System.out.println("Not equal"); 
		       }
		       				
				
			} catch (Exception | AssertionError e) {
				System.out.println(e);
				logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
				TestReporter.logFailure("Error Message:" + e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
			}
		}
	
	 @Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
		public void AssetModule_ScanOut_AssetInProgress_PositiveFlow(Method m, String username, String password) throws Exception {
			try {

				logger.startTest(m.getName());
				System.out.println("method name" + (m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

				// Step1:Login to the Application

				assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
				WebimplicitWait(wdriver);
				String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

				// Verify that the login is successful
				logger.log(LogStatus.PASS, "Login is suucessful",
						"Login is succesful with the login Message " + verifyLogin);
				Thread.sleep(1000);

				// Click on the Assets button in the Assets page
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

				// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
				// menus should get displayed
				Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
				Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
				Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
				Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

				// Click on the Scan out Asset link
				Syn_Click(assetTrackAssetsPge.lnk_ScanOutAsset(wdriver));
				logger.log(LogStatus.PASS, "Scan out Asset Link Tab", "Scan out Asset Link Tab is clicked ");

				// Verify that location, Sublocation, Inventory; Contact name should get
				// displayed
				Boolean VerifyPPMC = assetTrackAssetsPge.VerifyPPMC(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Scan in Tab", "PPMC Tab is displayed :" + VerifyPPMC);
				Boolean VerifyLocation = assetTrackAssetsPge.VerifyLocation(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation);
				String VerifyLocation1 = assetTrackAssetsPge.VerifyLocation(wdriver).getText().trim();
				String Name = "* Current Location";
				Assert.assertEquals(VerifyLocation1, Name);
				logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation1);
				// sub location
				Boolean Verify_SubLocation = assetTrackAssetsPge.Verify_SubLocation(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Verify_SubLocation Tab", "SubLocation Tab is displayed :" + Verify_SubLocation);
				String VerifySubLocation1 = assetTrackAssetsPge.Verify_SubLocation(wdriver).getText().trim();
				String Name1 = "* Current Sub-Location";
				Assert.assertEquals(VerifySubLocation1, Name1);
				logger.log(LogStatus.PASS, "Sub Location Tab", "SubLocation Tab is displayed :" + VerifySubLocation1);
				// Contact name
				Boolean VerifyContactName = assetTrackAssetsPge.VerifyContactName(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Contact Tab", "Contact Name Tab is displayed :" + VerifyContactName);
				String VerifyContactName1 = assetTrackAssetsPge.VerifyContactName(wdriver).getText().trim();
				String Name2 = "* Contact Name";
				Assert.assertEquals(VerifyContactName1, Name2);
				logger.log(LogStatus.PASS, "contact name Tab", "contact name Tab is displayed :" + VerifyContactName1);

				Boolean VerifyObjectType = assetTrackAssetsPge.VerifyObjectType(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Object type in Tab", "Object Type Tab is displayed :" + VerifyObjectType);
				Boolean VerifyDrpObjectType = assetTrackAssetsPge.VerifyDrpObjectType(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Object type in Tab", "Object Type Tab is displayed :" + VerifyDrpObjectType);
				Boolean VerifyBudjetCode = assetTrackAssetsPge.VerifyBudjetCode(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Budjet Code in Tab", "Budjet Code Tab is displayed :" + VerifyBudjetCode);

				// Return date
				Boolean VerifyExpReturndate = assetTrackAssetsPge.VerifyExpReturndate(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyExpReturndate);
				String VerifyExpReturndate1 = assetTrackAssetsPge.VerifyExpReturndate(wdriver).getText().trim();
				String Name3 = "* Expected Return Date";
				Assert.assertEquals(VerifyExpReturndate1, Name3);
				logger.log(LogStatus.PASS, "Return date Tab",
						"Expeted Return date Tab is displayed :" + VerifyExpReturndate1);
				assetTrackAssetsPge.txt_location(wdriver).clear();
				Thread.sleep(2000);
				Boolean VerifyInventory = assetTrackAssetsPge.VerifyInventory(wdriver).isSelected();
				Boolean Flag = true;
				Assert.assertEquals(VerifyInventory, Flag);
				logger.log(LogStatus.PASS, "VerifyInventory Tab", "Inventory Tab is selected by default:" + VerifyInventory);

				Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue Tab is clicked Without entering any data", "Continue Tab is clicked");

				// Validation message
				String ValidMsg1 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
				Assert.assertEquals(ValidMsg1,
						"Current Location must be specified.\n" + "Current Sub-Location must be specified.\n"
								+ "Contact Name must be specified.\n" + "Expected Return Date must be specified.");
				logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg1);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				Syn_Click(assetTrackAssetsPge.CurrentLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current location", "Current location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
			    
			    myExecutor.executeScript("document.getElementsByName('personResponsible')[0].value=' ABC, ABC'");
			    Syn_Click(assetTrackAssetsPge.ContactName_Lookup(wdriver));
			    logger.log(LogStatus.PASS,"Contact name lookup","Contact name lookup is clicked");
			    Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    
			    WebElement element4 = wdriver.findElementByXPath("//input[@name='dateExpectedBack']");
			    selectDateJavScriptExe("10/01/2020", element4);
			    	
			    Thread.sleep(3000);
			    Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue Tab is clicked Without entering any data", "Continue Tab is clicked");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
				String msgContent= assetTrackAssetsPge.msg_CopyAsset(wdriver).getText();
				Assert.assertTrue(msgContent.contains("Current Sub-Location must be specified."));
				logger.log(LogStatus.PASS, "Error message", "Error message is dispalyed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
				Syn_Click(assetTrackAssetsPge.CurrentSubLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current sub location", "Current sub location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current sub location field","Current sub location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);

			    Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue Tab is clicked Without entering any data", "Continue Tab is clicked");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				boolean Cancel = assetTrackAssetsPge.Btn_Cancel(wdriver).isDisplayed();
				logger.log(LogStatus.PASS, "Add Tracking number", "Add Tracking number option is displayed :" + Cancel);
				//need to add asset with in service status
				
				myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10688T1'");
				Syn_Click(assetTrackAssetsPge.btnAdd(wdriver));
	 		    Thread.sleep(2000);
	 		    
	 		    Syn_Click(assetTrackAssetsPge.btn_ScanInPageAddTrackingNumContinueButton(wdriver));
	 		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
	 		    Thread.sleep(3000);
	 	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	        
	 	        Syn_Click(assetTrackAssetsPge.btn_ChangeLayout(wdriver));
	 		    logger.log(LogStatus.PASS,"ChangeLayout button","ChangeLayout is clicked");
	 		    Thread.sleep(3000);
	 	       
	 		    //Thread.sleep(5000);
			    switchToWindow("Change Layout");
			    Thread.sleep(5000);
			    Syn_Click(assetTrackAssetsPge.ChangeLayout_Status(wdriver));
			    Thread.sleep(1000);
			    Syn_Click(assetTrackAssetsPge.ChangeLayout_AddSelect(wdriver));
			    Thread.sleep(2000);
			    Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			    Thread.sleep(2000);
			    logger.log(LogStatus.PASS,"Status field","Status field is added");
			    Thread.sleep(2000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
				
			    String Status= assetTrackAssetsPge.ScanOut_AssetDetails_Status(wdriver).getText().trim();
				Assert.assertEquals(Status, "IN SERVICE");
				logger.log(LogStatus.PASS, "Status of the asset", "Status of the asset is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
				Syn_Click(assetTrackAssetsPge.Btn_Cancel(wdriver));
			    Thread.sleep(2000);
			    logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked");
			    Thread.sleep(2000);
			    Syn_Click(assetTrackAssetsPge.ScanOut_TrackingNumber(wdriver));
			    Thread.sleep(2000);
				
			    Syn_Click(assetTrackAssetsPge.Btn_Remove(wdriver));
				Thread.sleep(3000);
				logger.log(LogStatus.PASS, "Remove Tab is clicked ", "Remove Tab is clicked");
				
				myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='1012836'");
				Syn_Click(assetTrackAssetsPge.btnAdd(wdriver));
	 		    Thread.sleep(2000);
	 		    
	 		    Syn_Click(assetTrackAssetsPge.btn_ScanInPageAddTrackingNumContinueButton(wdriver));
	 		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
	 		    Thread.sleep(5000);
	 	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	        
	 	        
	 	        
				  ArrayList<String> ScanInHeaders = new ArrayList<String>();
			        List<WebElement> ScanInPageHeaderDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[1]"));
			        for(int h=1;h<=ScanInPageHeaderDetails.size()-1;h++)
			{
			   
			WebElement headers = ScanInPageHeaderDetails.get(h);
			String hDetails = headers.getText();
			ScanInHeaders.add(hDetails);
			    
			}
			    //manufacturer
			        ArrayList<String> ScanInHeaderLatestShipment = new ArrayList<String>();
			        List<WebElement> ScanInHeaderLatestShipmentDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[2]"));
			        for(int l=1;l<=ScanInHeaderLatestShipmentDetails.size()-1;l++)
			{
			   
			WebElement latestshipmentheaders = ScanInHeaderLatestShipmentDetails.get(l);
			String hshipmentDetails = latestshipmentheaders.getText();
			ScanInHeaders.add(hshipmentDetails);
			    
			} 
			        //model
			        ArrayList<String> ScanInHeaderCaseNum = new ArrayList<String>();
			        List<WebElement> ScanInHeaderCaseNumDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[3]"));
			        for(int l=1;l<=ScanInHeaderCaseNumDetails.size()-1;l++)
			{
			   
			WebElement caseNumheaders = ScanInHeaderCaseNumDetails.get(l);
			String hcasenumDetails = caseNumheaders.getText();
			ScanInHeaders.add(hcasenumDetails);
			    
			} 
			        //type 
			        ArrayList<String> ScanInHeaderManufacturer = new ArrayList<String>();
			        List<WebElement> ScanInManufacturerDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[4]"));
			        for(int l=1;l<=ScanInManufacturerDetails.size()-1;l++)
			{
			   
			WebElement Manufacturerheaders = ScanInManufacturerDetails.get(l);
			String hmanuDetails = Manufacturerheaders.getText();
			ScanInHeaders.add(hmanuDetails);
			    
			} 
			     
			    WebElement quantityscanout = wdriver.findElement(By.xpath("//tr[@id='original_header']/../tr/td[5]/input"));
			    String quantitypDetails = quantityscanout.getAttribute("value");
			ScanInHeaders.add(quantitypDetails);

			        
			        //comments 
			        ArrayList<String> ScanInHeadermodel = new ArrayList<String>();
			        List<WebElement> ScanInHeadermodelDetails =  wdriver.findElements(By.xpath("//tr[@id='original_header']/../tr/td[6]"));
			        for(int l=1;l<=ScanInHeadermodelDetails.size()-1;l++)
			{
			   
			WebElement Modelheaders = ScanInHeadermodelDetails.get(l);
			String hmodelDetails = Modelheaders.getText().trim();
			ScanInHeaders.add(hmodelDetails);
			    
			} 
			         
			        WebElement scroll = assetTrackAssetsPge.btn_ScanInPrintablePagebtn(wdriver);
			((JavascriptExecutor) wdriver).executeScript("arguments[0].scrollIntoView(true);", scroll);

			        Syn_Click(assetTrackAssetsPge.btn_ScanInPrintablePagebtn(wdriver));
			        Thread.sleep(5000);
			        switchToWindow1("Asset Tracker v2.2.1");
			        Syn_Sleep();
			        
			       // Boolean itemNum=assetTrackAssetsPge.Lbl_PrintablePage_itemNum(wdriver).isDisplayed();
			        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			      //tracking number
			        ArrayList<String> printablepageDetails = new ArrayList<String>();
			        List<WebElement> printablepageTrackingNumDetails =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[2]"));
			        for(int l=1;l<=printablepageTrackingNumDetails.size()-1;l++)
			{
			   
			WebElement printablepageTrackingNumheaders = printablepageTrackingNumDetails.get(l);
			String htrnumbersprintablepageDetails = printablepageTrackingNumheaders.getText();
			printablepageDetails.add(htrnumbersprintablepageDetails);
			    
			} 
			        
			        
			      //manufacturer
			    //    ArrayList<String> ScanInHeaderLatestShipment = new ArrayList<String>();
			        List<WebElement> ScanInPageHeaderLatestShipmentDetails =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[3]"));
			        for(int l=1;l<=ScanInPageHeaderLatestShipmentDetails.size()-1;l++)
			{
			   
			WebElement scanInPagelatestshipmentheaders = ScanInPageHeaderLatestShipmentDetails.get(l);
			String scaninhshipmentDetails = scanInPagelatestshipmentheaders.getText();
			printablepageDetails.add(scaninhshipmentDetails);
			    
			} 
			        //model
			        ArrayList<String> ScanInHeaderCaseNum1 = new ArrayList<String>();
			        List<WebElement> ScanInHeaderCaseNumDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[4]"));
			        for(int l=1;l<=ScanInHeaderCaseNumDetails1.size()-1;l++)
			{
			   
			WebElement caseNumheaders1 = ScanInHeaderCaseNumDetails1.get(l);
			String hcasenumDetails1 = caseNumheaders1.getText();
			printablepageDetails.add(hcasenumDetails1);
			    
			} 
			        //type 
			        ArrayList<String> ScanInHeaderManufacturer1 = new ArrayList<String>();
			        List<WebElement> ScanInManufacturerDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[5]"));
			        for(int l=1;l<=ScanInManufacturerDetails1.size()-1;l++)
			{
			   
			WebElement Manufacturerheaders1 = ScanInManufacturerDetails1.get(l);
			String hmanuDetails1 = Manufacturerheaders1.getText();
			printablepageDetails.add(hmanuDetails1);
			    
			} 
			        
			      //quantity 
			        ArrayList<String> ScanInHeadermodel1 = new ArrayList<String>();
			        List<WebElement> ScanInHeadermodelDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[6]"));
			        for(int l=1;l<=ScanInHeadermodelDetails1.size()-1;l++)
			{
			   
			WebElement Modelheaders1 = ScanInHeadermodelDetails1.get(l);
			String hmodelDetails1 = Modelheaders1.getText().trim();
			printablepageDetails.add(hmodelDetails1);
			    
			} 
			      
			        //comments
			     //   ArrayList<String> ScanInHeadertype1 = new ArrayList<String>();
			        List<WebElement> ScanInHeadertypeDetails1 =  wdriver.findElements(By.xpath("(//title[contains(text(),'Scan Out (Printable)')]/../../../..//table)[5]/tbody/tr[2]//tbody/tr/td[7]"));
			        for(int l=1;l<=ScanInHeadertypeDetails1.size()-1;l++)
			{
			   
			WebElement typeheaders11 = ScanInHeadertypeDetails1.get(l);
			String typeDetails11 = typeheaders11.getText().trim();
			printablepageDetails.add(typeDetails11);
			    
			}
			     
			        if (ScanInHeaders.equals(printablepageDetails)) 
			        {
			        logger.log(LogStatus.PASS,"Scan Out page and printable page details should be same",
			        "Scan Out page and printable page details are same");
			            System.out.println("Equal"); 
			        }
			        else
			        {
			        logger.log(LogStatus.FAIL,"Scan Out page and printable page details should be same",
			        "Scan Out page and printable page details are not same");
			          
			            System.out.println("Not equal"); 
			       }
			  
				
			        


			} catch (Exception | AssertionError e) {
				logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
				TestReporter.logFailure("Error Message:" + e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
			}

		}
	 
	 
	 
	 @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
		public void AddNewContact_whileScanout_foranexistingAsset(Method m,String username,String password) throws Exception
		{
			try
			{
				logger.startTest(m.getName());
				System.out.println("method name"+(m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

				//Step1:Login to the Application
				assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
				WebimplicitWait(wdriver);
				String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

				//Verifying that the Login is successful

				logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
				Thread.sleep(1000);


				//Click on the Assets button in the Assets page
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
				logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search For Assets button", "Search For Assets button is Clicked");
				Thread.sleep(5000);
				String TrackingNumber=wdriver.findElement(By.xpath("//tr[9]/td[@class='dataCenter'][2]")).getText();
				
				
				Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets_ModifySearch(wdriver));
				logger.log(LogStatus.PASS, "Modify search button", "Modify search button is Clicked");
				
				assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
				logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.AssetDetails_ScanOutButton(wdriver));
				logger.log(LogStatus.PASS, "ScanOut Button", "Scan Out Button is clicked ");

				Boolean ScanOutPage = assetTrackAssetsPge.tit_AssetTitle(wdriver,"Scan Out").isDisplayed();
				logger.log(LogStatus.PASS, "Scan Out page",
				"Scan Out page details page is displayed :" + ScanOutPage);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				Syn_Click(assetTrackAssetsPge.btn_Addnew_Contact(wdriver));
				logger.log(LogStatus.PASS, "Add New contact Button", "Add New Button contact is clicked ");
				Thread.sleep(5000);
				switchToWindow("Contact Name");
				Thread.sleep(5000);
				
				int RandomValue;
	            RandomValue=getRandomNumberInRange(1000,2000);
	            String RandomSiteValue;
	            RandomSiteValue=RandomValue+"TESTINGADDFUNCTONALITYNEWCONTACTFIRSRANDLASTNA";
	            int RandomSiteValue_Length=RandomSiteValue.length();
	            assetTrackAssetsPge.txt_Firstname(wdriver).clear();
	            assetTrackAssetsPge.txt_Firstname(wdriver).sendKeys(RandomSiteValue);
	            
	            Thread.sleep(3000);
				
				assetTrackAssetsPge.txt_lastname(wdriver).clear();
	            assetTrackAssetsPge.txt_lastname(wdriver).sendKeys(RandomSiteValue);
	            String Email="Test"+RandomValue+"@test.com";
	            assetTrackAssetsPge.txt_emailid(wdriver).sendKeys(Email);
	            assetTrackAssetsPge.txt_city(wdriver).sendKeys("TestCity");
	            assetTrackAssetsPge.txt_phone(wdriver).sendKeys("9876543210");
	            assetTrackAssetsPge.txt_Address(wdriver).sendKeys("Address");
	            //assetTrackAssetsPge.drp_state(wdriver).sendKeys("9876543210");
	            //WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    	    Select selectdd=new Select(assetTrackAssetsPge.drp_state(wdriver));
	    	    	
	    	    selectdd.selectByVisibleText("ALABAMA");
	    	    Thread.sleep(4000);
	    	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
	    	    assetTrackAssetsPge.txt_Zip(wdriver).sendKeys("987654");
	            
	    	    Syn_Click(assetTrackAssetsPge.btn_Save(wdriver));
				logger.log(LogStatus.PASS, "Save Button", "Save Button contact is clicked ");
				Thread.sleep(12000);
				switchToWindow("Asset Tracker v2.2.1");
				Thread.sleep(3000);
	    	     
				String Contact = assetTrackAssetsPge.txt_contactname(wdriver).getText().trim();
				//Assert.assertTrue(Contact.contains(RandomSiteValue));
				logger.log(LogStatus.PASS, "Newly added Contact Name", "Newly added Contact Name is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				assetTrackAssetsPge.ScanOutPage_CurrentLocation(wdriver).clear();
				Thread.sleep(3000);
				Syn_Click(assetTrackAssetsPge.CurrentLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current location", "Current location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    Syn_Click(assetTrackAssetsPge.CurrentSubLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current sub location", "Current sub location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current sub location field","Current sub location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    WebElement element4 = wdriver.findElementByXPath("//input[@name='dateExpectedBack']");
			    selectDateJavScriptExe("10/01/2020", element4);
			    	
			    Thread.sleep(3000);
			    Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue button", "Continue button is clicked");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.btn_ScanInPageContinueButton(wdriver));
				logger.log(LogStatus.PASS, "confirm button", "confirm button is clicked and scanout is completed");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				String Successmsg = assetTrackAssetsPge.ScanOut_SuccessMessage(wdriver).getText().trim();
				Assert.assertEquals(Successmsg, "Your Items have been successfully scanned out.");
				logger.log(LogStatus.PASS, "Scan out is successfull", "Scan out is successfull and message displayed as:" + Successmsg);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    	    
	    	    
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
				logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
				Thread.sleep(3000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				/*Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets_ModifySearch(wdriver));
				logger.log(LogStatus.PASS, "Modify search button", "Modify search button is Clicked");
				*/
				String script= "arguments[0].setAttribute('value','"+TrackingNumber+"');";

		        JavascriptExecutor js = ((JavascriptExecutor) wdriver);

//		        WebElement ele= wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']"));

		        //js.executeScript(script, wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']")));
		        js.executeScript(script, assetTrackAssetsPge.txt_trackingNumber(wdriver));
				//assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
				logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");
				// Click on the Search for Asset link
				Thread.sleep(5000);
				
	    	    Date dat= new Date();
	    	    String TransactionDate= new SimpleDateFormat("MM/dd/yyyy").format(dat);
	    	    Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
				logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				String verifyAssetShippedMessage=assetTrackAssetsPge.Asset_ViewHistory(wdriver).getText();
				// verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
				assertTrue(verifyAssetShippedMessage.contains(TransactionDate));
				logger.log(LogStatus.PASS,"History","History is updated : "+verifyAssetShippedMessage);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			}
			catch (Exception | AssertionError e) {
				System.out.println(e);
				//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
				logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
				TestReporter.logFailure("Error Message:"+e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 		
				}
			}
	

	 @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
		public void AddNewContact_Scanout_ForAnewAsset(Method m,String username,String password) throws Exception
		{
			try
			{
				logger.startTest(m.getName());
				System.out.println("method name"+(m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

				//Step1:Login to the Application
				assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
				WebimplicitWait(wdriver);
				String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

				//Verifying that the Login is successful

				logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
				Thread.sleep(1000);

				int RandomValue;
	            RandomValue=getRandomNumberInRange(1000,2000);
				String TrackingNumber="AssetTest"+RandomValue;
				
				
				
				//Click on the Assets button in the Assets page
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				

				 Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
			        logger.log(LogStatus.PASS,"Enter Asset Link Tab","Enter Asset Link Tab is clicked ");
			         
			//Perform a blank search of the Asset 
		         Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
		         logger.log(LogStatus.PASS,"Enter Without PO button","Enter Without PO button is clicked ");
		         WebimplicitWait(wdriver);
		         
		         Thread.sleep(2000);
				String Enterassetdetailspge = assetTrackAssetsPge.Enterassetdetailspge(wdriver).getText().trim();
				Assert.assertEquals(Enterassetdetailspge, "Asset Details");
				logger.log(LogStatus.PASS, "Asset Details page is displayed", "Asset Details page is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				// Enter the mandatory details
				// Vendor details
				Syn_Click(assetTrackAssetsPge.BtnVendor(wdriver));
				Thread.sleep(4000);
				switchToWindow("Tab Search");
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(4000);
				switchToWindow("Asset Tracker v2.2.1");
				// choose sap
				if (assetTrackAssetsPge.Btn_PoSystem(wdriver).isSelected()) {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				} else {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				}

				// enter cost Object
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_costobject(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.Btn_costobject(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "cost Object is entered", "cost Object is entered");
				// enter Account Number
				Thread.sleep(5000);
				
				String script= "arguments[0].setAttribute('value','"+TrackingNumber+"');";
				JavascriptExecutor js = ((JavascriptExecutor) wdriver);
				js.executeScript(script, assetTrackAssetsPge.txt_trackingNumber(wdriver));
				//assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				
				Thread.sleep(5000);
				assetTrackAssetsPge.txtGlaccount(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btnGlaccount(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Account Number is entered", "Account Number is entered");
				// Enter First cost
				int RandomValue1;
				RandomValue1 = getRandomNumberInRange(1000, 20000);
				String RandomCost1;
				RandomCost1 = RandomValue1 + "5";
				assetTrackAssetsPge.Txt_FirstCost(wdriver).sendKeys(RandomCost1);
				logger.log(LogStatus.PASS, "First cost is entered", "First cost is entered");
				// enter Status
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btnStatusId(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Status is entered", "Status is entered");
				// enter Division
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_division(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_division(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Division is entered", "Division is entered");
				// enter Country
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_Country(wdriver).sendKeys("AFGHANISTAN");
				Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
				Thread.sleep(1000);
				Thread.sleep(1000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Country is entered", "Country is entered");
				// enter Model
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_Model(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Model is entered", "Model is entered");
				// enter Current Location
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_currentlocation(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Current Location is entered", "Current Location is entered");
				// enter Sublocation
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SublocationId(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Mandatory fields is entered", "Mandatory fields is entered");
				/*
				 * //enter Permanent location Thread.sleep(10000);
				 * assetTrackAssetsPge.txt_PermanentLocation(wdriver).clear();
				 * Syn_Click(assetTrackAssetsPge.btn_PermanentLocation(wdriver));
				 * Thread.sleep(10000); switchToWindow("Tab Search"); Thread.sleep(10000);
				 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); Thread.sleep(10000);
				 * switchToWindow("Asset Tracker v2.2.1");
				 * 
				 * //enter Permanent Sublocation Thread.sleep(10000);
				 * assetTrackAssetsPge.txt_permanentSublocationID(wdriver).clear();
				 * Syn_Click(assetTrackAssetsPge.btn_permanentSublocationID(wdriver));
				 * Thread.sleep(10000); switchToWindow("Tab Search"); Thread.sleep(10000);
				 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); Thread.sleep(10000);
				 * switchToWindow("Asset Tracker v2.2.1");
				 * objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				 */

				// Click Add asset button
				Syn_Click(assetTrackAssetsPge.btn_ADDAsset(wdriver));
				logger.log(LogStatus.PASS, "Add asset button is clicked", "Add asset button is clicked");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.BtnViewAsset(wdriver));
				logger.log(LogStatus.PASS, "View Asset Tab", "View Asset Tab is clicked");
				Thread.sleep(4000);

				
				Syn_Click(assetTrackAssetsPge.AssetDetails_ScanOutButton(wdriver));
				logger.log(LogStatus.PASS, "ScanOut Button", "Scan Out Button is clicked ");

				Boolean ScanOutPage = assetTrackAssetsPge.tit_AssetTitle(wdriver,"Scan Out").isDisplayed();
				logger.log(LogStatus.PASS, "Scan Out page",
				"Scan Out page details page is displayed :" + ScanOutPage);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				Syn_Click(assetTrackAssetsPge.btn_Addnew_Contact(wdriver));
				logger.log(LogStatus.PASS, "Add New contact Button", "Add New Button contact is clicked ");
				Thread.sleep(5000);
				switchToWindow("Contact Name");
				Thread.sleep(5000);
				
				
	            String RandomSiteValue;
	            RandomSiteValue=RandomValue+"TESTINGADDFUNCTONALITYNEWCONTACTFIRSRANDLASTNA";
	            int RandomSiteValue_Length=RandomSiteValue.length();
	            assetTrackAssetsPge.txt_Firstname(wdriver).clear();
	            assetTrackAssetsPge.txt_Firstname(wdriver).sendKeys(RandomSiteValue);
	            
	            Thread.sleep(3000);
				
				assetTrackAssetsPge.txt_lastname(wdriver).clear();
	            assetTrackAssetsPge.txt_lastname(wdriver).sendKeys(RandomSiteValue);
	            String Email="Test"+RandomValue+"@test.com";
	            assetTrackAssetsPge.txt_emailid(wdriver).sendKeys(Email);
	            assetTrackAssetsPge.txt_city(wdriver).sendKeys("TestCity");
	            assetTrackAssetsPge.txt_phone(wdriver).sendKeys("9876543210");
	            assetTrackAssetsPge.txt_Address(wdriver).sendKeys("Address");
	            //assetTrackAssetsPge.drp_state(wdriver).sendKeys("9876543210");
	            //WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    	    Select selectdd=new Select(assetTrackAssetsPge.drp_state(wdriver));
	    	    	
	    	    selectdd.selectByVisibleText("ALABAMA");
	    	    Thread.sleep(4000);
	    	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
	    	    assetTrackAssetsPge.txt_Zip(wdriver).sendKeys("987654");
	            
	    	    Syn_Click(assetTrackAssetsPge.btn_Save(wdriver));
				logger.log(LogStatus.PASS, "Save Button", "Save Button contact is clicked ");
				Thread.sleep(12000);
				switchToWindow("Asset Tracker v2.2.1");
				Thread.sleep(3000);
	    	     
				String Contact = assetTrackAssetsPge.txt_contactname(wdriver).getText().trim();
				//Assert.assertTrue(Contact.contains(RandomSiteValue));
				logger.log(LogStatus.PASS, "Newly added Contact Name", "Newly added Contact Name is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				assetTrackAssetsPge.ScanOutPage_CurrentLocation(wdriver).clear();
				Thread.sleep(3000);
				Syn_Click(assetTrackAssetsPge.CurrentLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current location", "Current location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    Syn_Click(assetTrackAssetsPge.CurrentSubLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current sub location", "Current sub location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current sub location field","Current sub location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    WebElement element4 = wdriver.findElementByXPath("//input[@name='dateExpectedBack']");
			    selectDateJavScriptExe("10/01/2020", element4);
			    	
			    Thread.sleep(3000);
			    Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue button", "Continue button is clicked");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.btn_ScanInPageContinueButton(wdriver));
				logger.log(LogStatus.PASS, "confirm button", "confirm button is clicked and scanout is completed");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				String Successmsg = assetTrackAssetsPge.ScanOut_SuccessMessage(wdriver).getText().trim();
				Assert.assertEquals(Successmsg, "Your Items have been successfully scanned out.");
				logger.log(LogStatus.PASS, "Scan out is successfull", "Scan out is successfull and message displayed as:" + Successmsg);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    	    
	    	    
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
				logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
				Thread.sleep(3000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				/*Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets_ModifySearch(wdriver));
				logger.log(LogStatus.PASS, "Modify search button", "Modify search button is Clicked");
				*/
				String script1= "arguments[0].setAttribute('value','"+TrackingNumber+"');";

		       // JavascriptExecutor js = ((JavascriptExecutor) wdriver);

//		        WebElement ele= wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']"));

		        //js.executeScript(script, wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']")));
		        js.executeScript(script1, assetTrackAssetsPge.txt_trackingNumber(wdriver));
				//assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
				logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");
				// Click on the Search for Asset link
				Thread.sleep(5000);
				
	    	    Date dat= new Date();
	    	    String TransactionDate= new SimpleDateFormat("MM/dd/yyyy").format(dat);
	    	    Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
				logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				String verifyAssetShippedMessage=assetTrackAssetsPge.Asset_ViewHistory(wdriver).getText();
				// verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
				assertTrue(verifyAssetShippedMessage.contains(TransactionDate));
				logger.log(LogStatus.PASS,"History","History is updated : "+verifyAssetShippedMessage);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			}
			catch (Exception | AssertionError e) {
				System.out.println(e);
				//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
				logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
				TestReporter.logFailure("Error Message:"+e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 		
				}
			}


	 @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
		public void Verify_ScanOut_CostObjectNo_newlycreatedassetscanout(Method m,String username,String password) throws Exception
		{
			try
			{
				logger.startTest(m.getName());
				System.out.println("method name"+(m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

				//Step1:Login to the Application
				assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
				WebimplicitWait(wdriver);
				String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

				//Verifying that the Login is successful

				logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
				Thread.sleep(1000);

				int RandomValue;
	            RandomValue=getRandomNumberInRange(1000,2000);
				String TrackingNumber="AssetTest"+RandomValue;
				
				
				
				//Click on the Assets button in the Assets page
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				

				 Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
			     	logger.log(LogStatus.PASS,"Enter Asset Link Tab","Enter Asset Link Tab is clicked ");
			         
			//Perform a blank search of the Asset 
		         Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
		         	logger.log(LogStatus.PASS,"Enter Without PO button","Enter Without PO button is clicked ");
		         WebimplicitWait(wdriver);
		         
		        Thread.sleep(2000);
				String Enterassetdetailspge = assetTrackAssetsPge.Enterassetdetailspge(wdriver).getText().trim();
				Assert.assertEquals(Enterassetdetailspge, "Asset Details");
				logger.log(LogStatus.PASS, "Asset Details page is displayed", "Asset Details page is displayed");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				// Enter the mandatory details
				// Vendor details
				Syn_Click(assetTrackAssetsPge.BtnVendor(wdriver));
				Thread.sleep(4000);
				switchToWindow("Tab Search");
				Thread.sleep(4000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(4000);
				
				switchToWindow("Asset Tracker v2.2.1");
				// choose sap
				if (assetTrackAssetsPge.Btn_PoSystem(wdriver).isSelected()) {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				} else {
					Syn_Click(assetTrackAssetsPge.Btn_PoSystem(wdriver));
				}

				// enter cost Object
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_costobject(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.Btn_costobject(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "cost Object is entered", "cost Object is entered");
				// enter Account Number
				Thread.sleep(5000);
				
				String script= "arguments[0].setAttribute('value','"+TrackingNumber+"');";
				JavascriptExecutor js = ((JavascriptExecutor) wdriver);
				js.executeScript(script, assetTrackAssetsPge.txt_trackingNumber(wdriver));
				//assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				
				Thread.sleep(5000);
				assetTrackAssetsPge.txtGlaccount(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btnGlaccount(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Account Number is entered", "Account Number is entered");
				// Enter First cost
				int RandomValue1;
				RandomValue1 = getRandomNumberInRange(1000, 20000);
				String RandomCost1;
				RandomCost1 = RandomValue1 + "5";
				assetTrackAssetsPge.Txt_FirstCost(wdriver).sendKeys(RandomCost1);
				logger.log(LogStatus.PASS, "First cost is entered", "First cost is entered");
				// enter Status
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btnStatusId(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Status is entered", "Status is entered");
				// enter Division
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_division(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_division(wdriver));
				Thread.sleep(10000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Division is entered", "Division is entered");
				// enter Country
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_Country(wdriver).sendKeys("AFGHANISTAN");
				Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
				Thread.sleep(1000);
				Thread.sleep(1000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Country is entered", "Country is entered");
				// enter Model
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_Model(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Model is entered", "Model is entered");
				// enter Current Location
				Thread.sleep(5000);
				assetTrackAssetsPge.txt_currentlocation(wdriver).clear();
				Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Current Location is entered", "Current Location is entered");
				// enter Sublocation
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SublocationId(wdriver));
				Thread.sleep(5000);
				switchToWindow("Tab Search");
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
				Thread.sleep(5000);
				switchToWindow("Asset Tracker v2.2.1");
				logger.log(LogStatus.PASS, "Mandatory fields is entered", "Mandatory fields is entered");
				/*
				 * //enter Permanent location Thread.sleep(10000);
				 * assetTrackAssetsPge.txt_PermanentLocation(wdriver).clear();
				 * Syn_Click(assetTrackAssetsPge.btn_PermanentLocation(wdriver));
				 * Thread.sleep(10000); switchToWindow("Tab Search"); Thread.sleep(10000);
				 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); Thread.sleep(10000);
				 * switchToWindow("Asset Tracker v2.2.1");
				 * 
				 * //enter Permanent Sublocation Thread.sleep(10000);
				 * assetTrackAssetsPge.txt_permanentSublocationID(wdriver).clear();
				 * Syn_Click(assetTrackAssetsPge.btn_permanentSublocationID(wdriver));
				 * Thread.sleep(10000); switchToWindow("Tab Search"); Thread.sleep(10000);
				 * Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); Thread.sleep(10000);
				 * switchToWindow("Asset Tracker v2.2.1");
				 * objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				 */

				// Click Add asset button
				Syn_Click(assetTrackAssetsPge.btn_ADDAsset(wdriver));
				logger.log(LogStatus.PASS, "Add asset button is clicked", "Add asset button is clicked");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.BtnViewAsset(wdriver));
				logger.log(LogStatus.PASS, "View Asset Tab", "View Asset Tab is clicked");
				Thread.sleep(4000);

				
				Syn_Click(assetTrackAssetsPge.AssetDetails_ScanOutButton(wdriver));
				logger.log(LogStatus.PASS, "ScanOut Button", "Scan Out Button is clicked ");

				Boolean ScanOutPage = assetTrackAssetsPge.tit_AssetTitle(wdriver,"Scan Out").isDisplayed();
				logger.log(LogStatus.PASS, "Scan Out page",
				"Scan Out page details page is displayed :" + ScanOutPage);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				/*Syn_Click(assetTrackAssetsPge.btn_Addnew_Contact(wdriver));
				logger.log(LogStatus.PASS, "Add New contact Button", "Add New Button contact is clicked ");
				Thread.sleep(5000);
				switchToWindow("Contact Name");
				Thread.sleep(5000);
				
				
	            String RandomSiteValue;
	            RandomSiteValue=RandomValue+"TESTINGADDFUNCTONALITYNEWCONTACTFIRSRANDLASTNA";
	            int RandomSiteValue_Length=RandomSiteValue.length();
	            assetTrackAssetsPge.txt_Firstname(wdriver).clear();
	            assetTrackAssetsPge.txt_Firstname(wdriver).sendKeys(RandomSiteValue);
	            
	            Thread.sleep(3000);
				
				assetTrackAssetsPge.txt_lastname(wdriver).clear();
	            assetTrackAssetsPge.txt_lastname(wdriver).sendKeys(RandomSiteValue);
	            String Email="Test"+RandomValue+"@test.com";
	            assetTrackAssetsPge.txt_emailid(wdriver).sendKeys(Email);
	            assetTrackAssetsPge.txt_city(wdriver).sendKeys("TestCity");
	            assetTrackAssetsPge.txt_phone(wdriver).sendKeys("9876543210");
	            assetTrackAssetsPge.txt_Address(wdriver).sendKeys("Address");
	            //assetTrackAssetsPge.drp_state(wdriver).sendKeys("9876543210");
	            //WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    	    Select selectdd=new Select(assetTrackAssetsPge.drp_state(wdriver));
	    	    	
	    	    selectdd.selectByVisibleText("ALABAMA");
	    	    Thread.sleep(4000);
	    	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
	    	    assetTrackAssetsPge.txt_Zip(wdriver).sendKeys("987654");
	            
	    	    Syn_Click(assetTrackAssetsPge.btn_Save(wdriver));
				logger.log(LogStatus.PASS, "Save Button", "Save Button contact is clicked ");
				Thread.sleep(12000);
				switchToWindow("Asset Tracker v2.2.1");*/
				Thread.sleep(3000);
				
				
				assetTrackAssetsPge.ScanOutPage_CurrentLocation(wdriver).clear();
				Thread.sleep(3000);
				Syn_Click(assetTrackAssetsPge.CurrentLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current location", "Current location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    Syn_Click(assetTrackAssetsPge.CurrentSubLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current sub location", "Current sub location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current sub location field","Current sub location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    
			    JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
			    myExecutor.executeScript("document.getElementsByName('personResponsible')[0].value=' ABC, ABC'");
			    Syn_Click(assetTrackAssetsPge.ContactName_Lookup(wdriver));
			    logger.log(LogStatus.PASS,"Contact name lookup","Contact name lookup is clicked");
			    Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    logger.log(LogStatus.PASS, "Contact Name", "Contact Name is selected");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
				Syn_Click(assetTrackAssetsPge.ScanoutPage_ScanoutCostOjectNumberLookUp(wdriver));
			    logger.log(LogStatus.PASS,"Scan out CostOject Number lookup","Scan out CostOject Number lookup is clicked");
			    Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    logger.log(LogStatus.PASS, "Scan out CostOject Number", "Scan out CostOject Number is selected");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
				
				WebElement element4 = wdriver.findElementByXPath("//input[@name='dateExpectedBack']");
			    selectDateJavScriptExe("10/01/2020", element4);
			    Thread.sleep(3000);
			    
			    Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue button", "Continue button is clicked");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(4000);
				
				String expCostobject = assetTrackAssetsPge.ScanOut_ScanoutCostOjectNumber(wdriver).getText().trim();
				
				Syn_Click(assetTrackAssetsPge.btn_printablepage(wdriver));
				logger.log(LogStatus.PASS, "Printable page button", "Printable page button is clicked");
				Thread.sleep(5000);
				
				switchToWindow1("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
				
			    String actCostobject = assetTrackAssetsPge.PrintablePage_ScanoutCostOjectNumber(wdriver).getText().trim();
				Assert.assertEquals(actCostobject, expCostobject);
				//Assert.assertTrue(actCostobject.contains(expCostobject));
				logger.log(LogStatus.PASS, "Scan out CostObject", "Scan out CostObject is displayed correctly");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(2000);
				wdriver.close();
				Thread.sleep(3000);
				switchToWindow("Asset Tracker v2.2.1");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.btn_ScanInPageContinueButton(wdriver));
				logger.log(LogStatus.PASS, "confirm button", "confirm button is clicked and scanout is completed");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				String Successmsg = assetTrackAssetsPge.ScanOut_SuccessMessage(wdriver).getText().trim();
				Assert.assertEquals(Successmsg, "Your Items have been successfully scanned out.");
				logger.log(LogStatus.PASS, "Scan out is successfull", "Scan out is successfull and message displayed as:" + Successmsg);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    	    
	    	    
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
				logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
				Thread.sleep(3000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				/*Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets_ModifySearch(wdriver));
				logger.log(LogStatus.PASS, "Modify search button", "Modify search button is Clicked");
				*/
				String script1= "arguments[0].setAttribute('value','"+TrackingNumber+"');";

		       // JavascriptExecutor js = ((JavascriptExecutor) wdriver);

//		        WebElement ele= wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']"));

		        //js.executeScript(script, wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']")));
		        js.executeScript(script1, assetTrackAssetsPge.txt_trackingNumber(wdriver));
				//assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
				logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");
				// Click on the Search for Asset link
				Thread.sleep(5000);
				
	    	    /*Date dat= new Date();
	    	    String TransactionDate= new SimpleDateFormat("MM/dd/yyyy").format(dat);*/
	    	    Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
				logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				String ViewHistoryCostObject=assetTrackAssetsPge.ViewHistory_Scanout_CostObject(wdriver).getText();
				// verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
				Assert.assertEquals(ViewHistoryCostObject, expCostobject);
				//assertTrue(verifyAssetShippedMessage.contains(TransactionDate));
				logger.log(LogStatus.PASS,"Scan out CostObject","Scan out CostObject is updated and displayed as : "+ViewHistoryCostObject);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			}
			catch (Exception | AssertionError e) {
				System.out.println(e);
				//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
				logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
				TestReporter.logFailure("Error Message:"+e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 		
				}
			}
	 @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
		public void VerifyScanOut_CostObjectexistingasset_scanout(Method m,String username,String password) throws Exception
		{
			try
			{
				logger.startTest(m.getName());
				System.out.println("method name"+(m.getName()));
				TestReporter.logStep("Start test execution of " + m.getName());
				TestReporter.logStep("Launch Asset Tracker ");

				//Step1:Login to the Application
				assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
				WebimplicitWait(wdriver);
				String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
				Assert.assertEquals("Welcome, Tester1", verifyLogin);

				//Verifying that the Login is successful

				logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
				Thread.sleep(1000);


				//Click on the Assets button in the Assets page
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
				logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search For Assets button", "Search For Assets button is Clicked");
				Thread.sleep(5000);
				//String TrackingNumber=wdriver.findElement(By.xpath("//tr[9]/td[@class='dataCenter'][2]")).getText();
				String TrackingNumber="10584399";
				
				
				Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets_ModifySearch(wdriver));
				logger.log(LogStatus.PASS, "Modify search button", "Modify search button is Clicked");
				
				assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
				logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.AssetDetails_ScanOutButton(wdriver));
				logger.log(LogStatus.PASS, "ScanOut Button", "Scan Out Button is clicked ");

				Boolean ScanOutPage = assetTrackAssetsPge.tit_AssetTitle(wdriver,"Scan Out").isDisplayed();
				logger.log(LogStatus.PASS, "Scan Out page",
				"Scan Out page details page is displayed :" + ScanOutPage);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
Thread.sleep(3000);
				
				
				assetTrackAssetsPge.ScanOutPage_CurrentLocation(wdriver).clear();
				Thread.sleep(3000);
				Syn_Click(assetTrackAssetsPge.CurrentLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current location", "Current location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    Syn_Click(assetTrackAssetsPge.CurrentSubLocation_Lookup(wdriver));
				logger.log(LogStatus.PASS, "Current sub location", "Current sub location is clicked ");
				Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    logger.log(LogStatus.PASS,"Current sub location field","Current sub location field is entered");
		        Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    
			    JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
			    myExecutor.executeScript("document.getElementsByName('personResponsible')[0].value=' ABC, ABC'");
			    Syn_Click(assetTrackAssetsPge.ContactName_Lookup(wdriver));
			    logger.log(LogStatus.PASS,"Contact name lookup","Contact name lookup is clicked");
			    Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    logger.log(LogStatus.PASS, "Contact Name", "Contact Name is selected");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
				Syn_Click(assetTrackAssetsPge.ScanoutPage_ScanoutCostOjectNumberLookUp(wdriver));
			    logger.log(LogStatus.PASS,"Scan out CostOject Number lookup","Scan out CostOject Number lookup is clicked");
			    Thread.sleep(5000);
			    switchToWindow("Tab Search");
			    Thread.sleep(5000);
			    selValueWindow(wdriver);
			    Thread.sleep(5000);
			    switchToWindow("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
			    logger.log(LogStatus.PASS, "Scan out CostOject Number", "Scan out CostOject Number is selected");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
				
				WebElement element4 = wdriver.findElementByXPath("//input[@name='dateExpectedBack']");
			    selectDateJavScriptExe("10/01/2020", element4);
			    Thread.sleep(3000);
			    
			    Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
				logger.log(LogStatus.PASS, "Continue button", "Continue button is clicked");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(4000);
				
				String expCostobject = assetTrackAssetsPge.ScanOut_ScanoutCostOjectNumber(wdriver).getText().trim();
				
				Syn_Click(assetTrackAssetsPge.btn_printablepage(wdriver));
				logger.log(LogStatus.PASS, "Printable page button", "Printable page button is clicked");
				Thread.sleep(5000);
				
				switchToWindow1("Asset Tracker v2.2.1");
			    Thread.sleep(5000);
				
			    String actCostobject = assetTrackAssetsPge.PrintablePage_ScanoutCostOjectNumber(wdriver).getText().trim();
				Assert.assertEquals(actCostobject, expCostobject);
				//Assert.assertTrue(actCostobject.contains(expCostobject));
				logger.log(LogStatus.PASS, "Scan out CostObject", "Scan out CostObject is displayed correctly");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(2000);
				wdriver.close();
				Thread.sleep(3000);
				switchToWindow("Asset Tracker v2.2.1");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.btn_ScanInPageContinueButton(wdriver));
				logger.log(LogStatus.PASS, "confirm button", "confirm button is clicked and scanout is completed");
				Thread.sleep(2000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				
				String Successmsg = assetTrackAssetsPge.ScanOut_SuccessMessage(wdriver).getText().trim();
				Assert.assertEquals(Successmsg, "Your Items have been successfully scanned out.");
				logger.log(LogStatus.PASS, "Scan out is successfull", "Scan out is successfull and message displayed as:" + Successmsg);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    	    
	    	    
				Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
				logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

				//Click on the Search Asset link
				Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
				logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
				Thread.sleep(3000);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				/*Syn_Click(assetTrackAssetsPge.Assets_SearchForAssets_ModifySearch(wdriver));
				logger.log(LogStatus.PASS, "Modify search button", "Modify search button is Clicked");
				*/
				String script= "arguments[0].setAttribute('value','"+TrackingNumber+"');";

		        JavascriptExecutor js = ((JavascriptExecutor) wdriver);

//		        WebElement ele= wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']"));

		        //js.executeScript(script, wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']")));
		        js.executeScript(script, assetTrackAssetsPge.txt_trackingNumber(wdriver));
				//assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(TrackingNumber);
				logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");
				Thread.sleep(5000);
				
				Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
				logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

				// Click on the Search for Asset link
				Thread.sleep(5000);
				Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
				logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");
				// Click on the Search for Asset link
				Thread.sleep(5000);

	    	    /*Date dat= new Date();
	    	    String TransactionDate= new SimpleDateFormat("MM/dd/yyyy").format(dat);*/
	    	    Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
				logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				String ViewHistoryCostObject=assetTrackAssetsPge.ViewHistory_Scanout_CostObject(wdriver).getText();
				// verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
				Assert.assertEquals(ViewHistoryCostObject, expCostobject);
				//assertTrue(verifyAssetShippedMessage.contains(TransactionDate));
				logger.log(LogStatus.PASS,"Scan out CostObject","Scan out CostObject is updated and displayed as : "+ViewHistoryCostObject);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			}
			catch (Exception | AssertionError e) {
				System.out.println(e);
				//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
				logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
				TestReporter.logFailure("Error Message:"+e.getMessage());
				objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 		
				}
			}
	
	 

}
