package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_ShipmentsPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class SiteName_SubModule extends Commonstudio
{
	PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    ExtentReports logger = ExtentReports.get(SiteName_SubModule.class);
    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
    AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
    AssetTrack_ShipmentsPage assetTrackShipmentsPge=new AssetTrack_ShipmentsPage();
    
    
   @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Maintain_Module_Site_Names_Negative_Flow(Method m,String username,String password,String Action,String InvalidSiteName,String ZipCode,String StateValue,String SelectionAction,String MaximumValue) throws Exception
    {
           try
           {   

                  logger.startTest(m.getName());
                  System.out.println("method name"+(m.getName()));
                  TestReporter.logStep("Start test execution of " + m.getName());
                  TestReporter.logStep("Launch Asset Tracker ");

                  assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
                  
                  WebimplicitWait(wdriver);
                  String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
                  Assert.assertEquals("Welcome, Tester1", verifyLogin);

                  //Verifying that the Login is successful
                  logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
                  Thread.sleep(1000);

                  //Click on the Maintain button in the Maintain page
                  Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
                  logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

                  //Click on the Site Names link
                  Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Site Names"));
                  logger.log(LogStatus.PASS,"Site Names link","Site Names link  is clicked "); 
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);


                  //Verify that the Maintain My Site Names page is displayed
                  String VerifySiteNamesTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Site Names").getText();
                  Assert.assertEquals("Maintain Site Names", VerifySiteNamesTitle);
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);


    //Click on the Save button      
                  Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
                  logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
                  Thread.sleep(1000);
                  
                  

    //Verify that the Error message is displayed
                  String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
                  Assert.assertEquals("Action must be specified.", VerifyConfirmationMsg);
                  logger.log(LogStatus.PASS,"Error Validation message is displayed","Error "+VerifyConfirmationMsg+ " is displayed");
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  Thread.sleep(1000);  


    //Select ADD Action from the Action dropdown and Enter Invalid data in the Site Name
                  if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
                  {
                         dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
                  }
                  else
                  {
                         Thread.sleep(2000);  
                         Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
                         SelectAction.selectByVisibleText(Action);
                  }
                  
                  
                  Thread.sleep(2000);
                  
                  //JavascriptExecutor js = (JavascriptExecutor)wdriver;
                  //js.executeScript("arguments[0].value='Msitenames';", assetTrackMaintainPage.txt_NewSiteName(wdriver));
                  //assetTrackMaintainPage.txt_NewSiteName(wdriver).click();
                  assetTrackMaintainPage.txt_NewSiteName(wdriver).sendKeys(InvalidSiteName);
                  Thread.sleep(2000);
                  assetTrackMaintainPage.txt_SiteZipCode(wdriver).click();
                  assetTrackMaintainPage.txt_SiteZipCode(wdriver).sendKeys(ZipCode);
                  logger.log(LogStatus.PASS,"Zip Code","Zip Code" +ZipCode+ "is entered:");
                  //objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_SiteZipCode(wdriver));
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  Thread.sleep(3000);
                  
                  if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
                  {
                         dropDownSelectJavaScript(assetTrackMaintainPage.drpdownSiteState(wdriver),StateValue);
                  }
                  else
                  {
                         Select SelectAction=new Select(assetTrackMaintainPage.drpdownSiteState(wdriver));
                         SelectAction.selectByVisibleText(StateValue);
                  }
                  Thread.sleep(3000);
                  //JavascriptExecutor js = (JavascriptExecutor)wdriver;
                  //js.executeScript("arguments[0].value='Msitenames';", assetTrackMaintainPage.txt_NewSiteName(wdriver));
                  //assetTrackMaintainPage.txt_NewSiteName(wdriver).click();
                  //assetTrackMaintainPage.txt_NewSiteName(wdriver).sendKeys(InvalidSiteName);
                  logger.log(LogStatus.PASS,"Invalid Site Name is entered","Invalid Site Name" +InvalidSiteName+ "is entered:");
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  
                  
    //Click on the Save button      
                  Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
                  logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
                  Thread.sleep(3000);
                  
    //Verify that the Error message is displayed
                  String VerifyErrornMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
                  Assert.assertEquals("Enter a valid Site Name", VerifyErrornMsg);
                  logger.log(LogStatus.PASS,"Error Validation message is displayed","Error :-"+VerifyErrornMsg+ " is displayed");
                  Thread.sleep(3000);               
                  
                  
    //Clear all the mandatory fields and click on Save button
                  if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
                  {
                         dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),SelectionAction);
                  }
                  else
                  {
                         Thread.sleep(3000);  
                         Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
                         SelectAction.selectByVisibleText(SelectionAction);
                  }
                  

    //Click on the Save button 
                  Thread.sleep(3000); 
                  Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
                  logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
                  Thread.sleep(2000);
                  
    //Verify that the Error message is displayed
                  String VerifyErrorMessage2=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
                  Assert.assertEquals("Action must be specified.", VerifyErrorMessage2);
                  logger.log(LogStatus.PASS,"Error Validation message is displayed","Error "+VerifyErrorMessage2+ " is displayed");
                  Thread.sleep(1000);     
                  
    //Select ADD dropdown and enter the new value that is greater than the maxlength of the edit box              
                  if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
                  {
                         dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
                  }
                  else
                  {
                         Thread.sleep(3000);  
                         Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
                         SelectAction.selectByVisibleText(Action);
                         WebimplicitWait(wdriver);
                  }             

    //Enter the text more than the length of the edit box
                  WebimplicitWait(wdriver);
                  Thread.sleep(2000);  
                  assetTrackMaintainPage.txt_NewSiteName(wdriver).sendKeys(MaximumValue);
                  logger.log(LogStatus.PASS,"Invalid Site Name is entered","Invalid Site Name" +MaximumValue+ "is entered:");
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  
    //Verify that more than 50 characters cannot be entered in the New Status text box
                  String VerifyStatusText=assetTrackMaintainPage.txt_NewSiteName(wdriver).getText().trim();
                  Assert.assertNotEquals(MaximumValue, VerifyStatusText);
                  logger.log(LogStatus.PASS,"More than 100 characters","More than 100 characters cannot be added ");
                  objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewSiteName(wdriver));
                               
                               
    //Enter a value which is equal to the maximum length   
                  int RandomValue;
                  RandomValue=getRandomNumberInRange(1000,2000);
                  String RandomSiteValue;
                  RandomSiteValue=RandomValue+"TESTINGADDFUNCTONALITYNEWVALUEVALIDDATATOBEADDTESTINGADDFUNCTONALITYNEWVALUEVALIDDATATOBEADDASDF";
            int RandomSiteValue_Length=RandomSiteValue.length();
            assetTrackMaintainPage.txt_NewSiteName(wdriver).clear();
            assetTrackMaintainPage.txt_NewSiteName(wdriver).sendKeys(RandomSiteValue);
                           
    //verify that the Max length to be entered in the New Status edit box is 50    
            String verifyMaxlength=assetTrackMaintainPage.txt_NewSiteName(wdriver).getAttribute("maxlength");
            String  RandomStatusValue_Length_Int=Integer.toString(RandomSiteValue_Length);
            Assert.assertEquals(RandomStatusValue_Length_Int, verifyMaxlength.toString());
            logger.log(LogStatus.PASS,"The length of the text field","The length of the text field is :"+RandomStatusValue_Length_Int);

           
           }
           catch (Exception | AssertionError e) {
                  System.out.println(e);
                  //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
                  logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
                  TestReporter.logFailure("Error Message:"+e.getMessage());
                  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
           }
           
    }  
           @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
           public void MaintainModule_SiteNames_AlternateFlow(Method m,String username,String password) throws Exception
           {
                  try
                  {   

                         logger.startTest(m.getName());
                         System.out.println("method name"+(m.getName()));
                         TestReporter.logStep("Start test execution of " + m.getName());
                         TestReporter.logStep("Launch Asset Tracker ");

                         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
                         
                         WebimplicitWait(wdriver);
                         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
                         Assert.assertEquals("Welcome, Tester1", verifyLogin);

                         //Verifying that the Login is successful
                         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
                         Thread.sleep(1000);

                         //Click on the Maintain button in the Maintain page
                         Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
                         logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

                         //Click on the Site Names link
                         Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Site Names"));
                         logger.log(LogStatus.PASS,"Site Names link","Site Names link  is clicked "); 
                         objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                         Thread.sleep(3000);
                         //Verify that the Maintain My Site Names page is displayed
                         String VerifySiteNamesTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Site Names").getText();
                         Assert.assertEquals("Maintain Site Names", VerifySiteNamesTitle);
                         objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                         List<String> Expectedoptions=new ArrayList<String>();
                         Expectedoptions.add("ADD");
                         Expectedoptions.add("DELETE");
                         Expectedoptions.add("UPDATE");
                         
                         Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
                         List<WebElement> options=SelectAction.getOptions();
                         List<String> options1=new ArrayList<String>();
                         for(int i=1;i<options.size();i++)
                         {
                        	String opt= options.get(i).getText(); 
                        	options1.add(opt);
                         }
                         Assert.assertEquals(options1, Expectedoptions);
                         logger.log(LogStatus.PASS,"Action options","Action options are displayed correctly");

                         
                        Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
             	 	    logger.log(LogStatus.PASS, "Shipments Tab", "Shipments Tab is clicked ");
             	 	    Thread.sleep(3000);
             	 	    // Click on Enter shipment
             	 	    
             	 	    Syn_Click(assetTrackMaintainPage.lnk_EnterShipment(wdriver));
             	 	    logger.log(LogStatus.PASS,"Enter shipment button","Enter shipment button is clicked ");
             	 	    // Shipment page
             	 	    Thread.sleep(1000);
             	 	   
             	 	    // Edit Address button corresponding to ship from
             	 	    Syn_Click(assetTrackMaintainPage.btn_ShipfromeditAddress(wdriver));
             	 	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
             	 	    Thread.sleep(5000);
             	 	    
             	 	    switchToWindow("Ship From: Address Info");
             	 	    Thread.sleep(5000);
             	 	  String Sitename="1A";
             	 	  assetTrackMaintainPage.txt_searchsitefrom(wdriver).sendKeys(Sitename);
          	 	    
          	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
          	 	    
          	 	    Thread.sleep(5000);
             	 	    Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
             	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
             	 	    
             	 	    /*switchToWindow("Tab Search");
             	 	    logger.log(LogStatus.PASS,"search site name","search site name lookup is opened ");
           	 	    
	          	 	    Thread.sleep(5000);
	          	 	    selValueWindow(wdriver);
	          	 	    Thread.sleep(5000);
	          	 	    switchToWindow("Ship From: Address Info");*/
	          	 	    Thread.sleep(5000);
             	 	   
	          	 	    assetTrackMaintainPage.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
		     	 	    Syn_Click(assetTrackMaintainPage.btn_searchattn(wdriver));
		     	 	    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
		     	 	    Thread.sleep(5000);
		     	 	    switchToWindow("Tab Search");
		     	 	    Thread.sleep(5000);
		     	 	    selValueWindow(wdriver);
		     	 	    Thread.sleep(5000);
		     	 	    switchToWindow("Ship From: Address Info");
		     	 	    Thread.sleep(5000);
		     	 	    logger.log(LogStatus.PASS,"ATTN	field","ATTN field is entered");
		     	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		     	 	  int RandomValue=getRandomNumberInRange(100,200);
		     	 	  String Rand= String.valueOf(RandomValue);
	                  assetTrackMaintainPage.ShipFrom_City(wdriver).clear();
	                  JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
	     	  	     
	                  myExecutor.executeScript("document.getElementsByName('city')[0].value='"+Rand+"'");
	                 // assetTrackMaintainPage.ShipFrom_City(wdriver).sendKeys(Rand);
	                  Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	                  logger.log(LogStatus.PASS,"save button","save  button is clicked ");
	      	 	    
	                  Thread.sleep(5000);
	                  switchToWindow("Asset Tracker v2.2.1");
	                  Thread.sleep(5000);
	                  String CityFrom =assetTrackMaintainPage.ShipFrom_CityFrom(wdriver).getAttribute("value");
	                  Assert.assertEquals(CityFrom, Rand);
	                  logger.log(LogStatus.PASS,"City From","City From is displayed as "+CityFrom);
	                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	                  
	                  
	                  Syn_Click(assetTrackMaintainPage.btn_ShipfromeditTo(wdriver));
	                  logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	      	 	    
	      	 	    Thread.sleep(5000);
	      	 	    switchToWindow("Consigned To: Address Info");
	      	 	    Thread.sleep(5000);
	      	 	   myExecutor.executeScript("document.getElementsByName('locationName')[0].value='1A'");
	      	 	    //assetTrackMaintainPage.txt_searchsitefrom(wdriver).sendKeys(Sitename);
	      	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
		      	 	Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
	      	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	      	 	    
	      	 	   /* Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
         	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");*/
         	 	   /* 
         	 	    switchToWindow("Tab Search");
         	 	    logger.log(LogStatus.PASS,"search site name","search site name lookup is opened ");
       	 	    	Thread.sleep(5000);
          	 	    selValueWindow(wdriver);
          	 	    Thread.sleep(5000);
          	 	    switchToWindow("Consigned To: Address Info");*/
          	 	    Thread.sleep(7000);
         	 	   
          	 	    //assetTrackMaintainPage.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
          	 	    myExecutor.executeScript("document.getElementsByName('attention')[0].value=' ABC, ABC'");
	     	 	    Syn_Click(assetTrackMaintainPage.btn_searchattn(wdriver));
	     	 	    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
	     	 	    Thread.sleep(5000);
	     	 	    switchToWindow("Tab Search");
	     	 	    Thread.sleep(5000);
	     	 	    selValueWindow(wdriver);
	     	 	    Thread.sleep(5000);
	     	 	    switchToWindow("Consigned To: Address Info");
	     	 	    Thread.sleep(5000);
	     	 	    logger.log(LogStatus.PASS,"ATTN	field","ATTN field is entered");
	     	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	     	 	  int RandomValue1=getRandomNumberInRange(100,200);
	     	 	  String Rand1= String.valueOf(RandomValue1);
                  assetTrackMaintainPage.ShipFrom_City(wdriver).clear();
                  myExecutor.executeScript("document.getElementsByName('city')[0].value='"+Rand1+"'");
                  //assetTrackMaintainPage.ShipFrom_City(wdriver).sendKeys(Rand1);
                  Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
                  logger.log(LogStatus.PASS,"save button","save  button is clicked ");
      	 	    
                  Thread.sleep(5000);
              switchToWindow("Asset Tracker v2.2.1");
              Thread.sleep(5000);
              String CityTo =assetTrackMaintainPage.ShipFrom_CityTo(wdriver).getAttribute("value");
              Assert.assertEquals(CityTo, Rand1);
              logger.log(LogStatus.PASS,"City To","City To is updated as "+CityTo);
              objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  
	            WebElement element4 = wdriver.findElementByXPath("//input[@name='shipDate']");
	  	 	    selectDateJavScriptExe("27/12/2020", element4);
	  	 	    WebElement element5 = wdriver.findElementByXPath("//input[@name='expectedReturnDate']");
	  	 	    selectDateJavScriptExe("27/12/2020", element5);
	  	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
      	 	    
      	 	 assetTrackShipmentsPge.txt_currentlocation(wdriver).clear();
             Thread.sleep(3000);
             //WebElement loc = wdriver.findElementByXPath("(//div[@class='tabImage'])[1]");
             Thread.sleep(3000);
            // myExecutor.executeScript("arguments[0].click();", loc);
             Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentLocationLookUp(wdriver));
             
             Thread.sleep(5000);
     	    switchToWindow("Tab Search");
     	    Thread.sleep(5000);
     	    selValueWindow(wdriver);
     	    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
             Thread.sleep(5000);
     	    switchToWindow("Asset Tracker v2.2.1");
     	    Thread.sleep(5000);
     	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtab(wdriver));
     	    logger.log(LogStatus.PASS, "Selected current sub location  ");

     	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtabsearch(wdriver));
     	    Thread.sleep(5000);
     	    switchToWindow("Tab Search");
     	    Thread.sleep(5000);
     	    selValueWindow(wdriver);
     	    logger.log(LogStatus.PASS,"Current sublocation field","Current sublocation field is entered");
             Thread.sleep(5000);
     	    switchToWindow("Asset Tracker v2.2.1");
     	    Thread.sleep(5000);
      	 	Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
		    logger.log(LogStatus.PASS,"Save button","Save is clicked");
		    Thread.sleep(4000);
		    String ShipmentID= assetTrackMaintainPage.WayBillPage_ShipmentIDNo(wdriver).getAttribute("value");
		    Thread.sleep(4000);
		    Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
            logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
Thread.sleep(2000);
            //Click on the Site Names link
            Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Site Names"));
            logger.log(LogStatus.PASS,"Site Names link","Site Names link  is clicked "); 
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);

          
            Thread.sleep(3000);
            //Verify that the Maintain My Site Names page is displayed
           /* String VerifySiteNamesTitle1=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Site Names").getText();
            Assert.assertEquals("Maintain Site Names", VerifySiteNamesTitle1);
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);*/
            
            Select SelectAction1=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
            SelectAction1.selectByVisibleText("UPDATE");
            Thread.sleep(2000);
            myExecutor.executeScript("document.getElementsByName('locationName')[0].value='"+Sitename+"'");
            
            //assetTrackMaintainPage.txt_searchsitefrom(wdriver).sendKeys(Sitename);
  	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
  	 	    Thread.sleep(2000);
 	 	    Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
 	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
 	 	    Thread.sleep(5000);
 	 	    
 	 	    assetTrackMaintainPage.Maintain_SiteNames_Address1(wdriver).clear();
 	 	  Thread.sleep(2000);
 	 	  int RandomV=getRandomNumberInRange(100,200);
 	 	  String Rand11= String.valueOf(RandomV);
 	 	  String Address="Test"+Rand11;
 	 	    //assetTrackMaintainPage.Maintain_SiteNames_Address1(wdriver).sendKeys(Address);
 	 	  myExecutor.executeScript("document.getElementsByName('address1')[0].value='"+Address+"'");
          
 	 	  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 	 	Thread.sleep(2000);
 	 	  Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
 	 	  logger.log(LogStatus.PASS,"Save","Save is clicked "); 
          objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 	 	   
          String Message= assetTrackMaintainPage.msg_Confirmation(wdriver).getText();
          Assert.assertTrue(Message.contains("has been updated"));
          logger.log(LogStatus.PASS,"Success message","Success message displayed as "+Message);
          objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
         
          
          Thread.sleep(3000);
          	Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
	 	    logger.log(LogStatus.PASS, "Shipments Tab", "Shipments Tab is clicked ");
	 	    Thread.sleep(3000);
	 	    // Click on Enter shipment
	 	    
	 	    Syn_Click(assetTrackMaintainPage.lnk_EnterShipment(wdriver));
	 	    logger.log(LogStatus.PASS,"Enter shipment button","Enter shipment button is clicked ");
	 	    // Shipment page
	 	    Thread.sleep(1000);
	 	   
	 	    // Edit Address button corresponding to ship from
	 	    Syn_Click(assetTrackMaintainPage.btn_ShipfromeditAddress(wdriver));
	 	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	 	    Thread.sleep(5000);
	 	    
	 	    switchToWindow("Ship From: Address Info");
	 	    Thread.sleep(5000);
	 	  //String Sitename="1A";
	 	 // assetTrackMaintainPage.txt_searchsitefrom(wdriver).sendKeys(Sitename);
	 	  myExecutor.executeScript("document.getElementsByName('locationName')[0].value='"+Sitename+"'");
	 	   
 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
 	    
 	    Thread.sleep(5000);
	 	    Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	 	    
	 	    /*switchToWindow("Tab Search");
	 	    logger.log(LogStatus.PASS,"search site name","search site name lookup is opened ");
	 	    
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    Thread.sleep(5000);
	 	    switchToWindow("Ship From: Address Info");*/
	 	    Thread.sleep(5000);
	 	   myExecutor.executeScript("document.getElementsByName('attention')[0].value=' ABC, ABC'");
	 	   // assetTrackMaintainPage.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	 	    Syn_Click(assetTrackMaintainPage.btn_searchattn(wdriver));
	 	    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    Thread.sleep(5000);
	 	    switchToWindow("Ship From: Address Info");
	 	    Thread.sleep(5000);
	 	    logger.log(LogStatus.PASS,"ATTN	field","ATTN field is entered");
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	 	   Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));	
	        logger.log(LogStatus.PASS,"save button","save  button is clicked ");
	 	    
	        Thread.sleep(5000);
	        switchToWindow("Asset Tracker v2.2.1");
	        Thread.sleep(5000);
	        String actualAddress = assetTrackMaintainPage.WayBillPage_Shipfrom_Address1(wdriver).getAttribute("value");
	        Assert.assertEquals(actualAddress, Address);
	        logger.log(LogStatus.PASS,"Address","Updated Address is displayed correctly as "+Message);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
	        
	        Syn_Click(assetTrackMaintainPage.btn_ShipfromeditTo(wdriver));
	        logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Consigned To: Address Info");
	 	    Thread.sleep(5000);
	 	   myExecutor.executeScript("document.getElementsByName('locationName')[0].value='1A'");
	 	    //assetTrackMaintainPage.txt_searchsitefrom(wdriver).sendKeys(Sitename);
	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
		 	 Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	 	    
	 	   /* Syn_Click(assetTrackMaintainPage.btn_searchsitefromtab(wdriver));
		    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");*/
		   /* 
		    switchToWindow("Tab Search");
		    logger.log(LogStatus.PASS,"search site name","search site name lookup is opened ");
		    
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    Thread.sleep(5000);
	 	    switchToWindow("Consigned To: Address Info");*/
	 	    Thread.sleep(5000);
		   //assetTrackMaintainPage.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	 	   myExecutor.executeScript("document.getElementsByName('attention')[0].value=' ABC, ABC'");
	 	    Syn_Click(assetTrackMaintainPage.btn_searchattn(wdriver));
		    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
		    Thread.sleep(5000);
		    switchToWindow("Tab Search");
		    Thread.sleep(5000);
		    selValueWindow(wdriver);
		    Thread.sleep(5000);
		    switchToWindow("Consigned To: Address Info");
		    Thread.sleep(5000);
		    logger.log(LogStatus.PASS,"ATTN	field","ATTN field is entered");
		    objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			
		    Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
		    logger.log(LogStatus.PASS,"save button","save  button is clicked ");
			    
		    Thread.sleep(5000);
		    switchToWindow("Asset Tracker v2.2.1");
		    Thread.sleep(5000);
		    String actualAddressto = assetTrackMaintainPage.WayBillPage_ShipTo_Address1(wdriver).getAttribute("value");
	        Assert.assertEquals(actualAddressto, Address);
	        logger.log(LogStatus.PASS,"Address","Updated Address is displayed correctly as "+Message);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
		    
		    WebElement element44 = wdriver.findElementByXPath("//input[@name='shipDate']");
			selectDateJavScriptExe("27/12/2020", element44);
			   
		    WebElement element55 = wdriver.findElementByXPath("//input[@name='expectedReturnDate']");
		    selectDateJavScriptExe("27/12/2020", element55);
		    objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
		    
			 assetTrackShipmentsPge.txt_currentlocation(wdriver).clear();
			Thread.sleep(3000);
			//WebElement loc = wdriver.findElementByXPath("(//div[@class='tabImage'])[1]");
			Thread.sleep(3000);
			// myExecutor.executeScript("arguments[0].click();", loc);
			Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentLocationLookUp(wdriver));
			
			Thread.sleep(5000);
			switchToWindow("Tab Search");
			Thread.sleep(5000);
			selValueWindow(wdriver);
			logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
			Thread.sleep(5000);
			switchToWindow("Asset Tracker v2.2.1");
			Thread.sleep(5000);
			Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtab(wdriver));
			logger.log(LogStatus.PASS, "Selected current sub location  ");
			
			Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtabsearch(wdriver));
			Thread.sleep(5000);
			switchToWindow("Tab Search");
			Thread.sleep(5000);
			selValueWindow(wdriver);
			logger.log(LogStatus.PASS,"Current sublocation field","Current sublocation field is entered");
			Thread.sleep(5000);
			switchToWindow("Asset Tracker v2.2.1");
			Thread.sleep(5000);
			Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);
			
			Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
	        logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
	        Thread.sleep(2000);
	 //Click on the Search Shipment link
	        Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
	        logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
	        Thread.sleep(3000);
	        //assetTrackMaintainPage.SearchShipment_ShipmentID(wdriver).sendKeys(ShipmentID);
	        myExecutor.executeScript("document.getElementsByName('searchShipmentID')[0].value='"+ShipmentID+"'");
	        Thread.sleep(4000);
	        
	        Syn_Click(assetTrackMaintainPage.SearchShipment_ShipmentIDlookup(wdriver));
	        logger.log(LogStatus.PASS,"Select values","Select values is clicked ");
	        Thread.sleep(3000);
	        
	        Syn_Click(assetTrackMaintainPage.SearchShipment_SearchForShipments(wdriver));
	        logger.log(LogStatus.PASS,"Search For Shipment","Search For Shipment is clicked ");
	        Thread.sleep(4000);
	        
	        String AddressText= assetTrackMaintainPage.SearchShipment_ShipFromDetails(wdriver).getText();
	        Assert.assertFalse(AddressText.contains(Address));
	        logger.log(LogStatus.PASS,"Address","Address is displayed correctly with previous data");
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);   
	        
	        String AddressToText= assetTrackMaintainPage.SearchShipment_ShipToDetails(wdriver).getText();
	        Assert.assertFalse(AddressToText.contains(Address));
	        logger.log(LogStatus.PASS,"Address","Address is displayed correctly with previous data");
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
 	 	  
          }
          catch (Exception | AssertionError e) {
                 System.out.println(e);
                 //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
                 logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
                 TestReporter.logFailure("Error Message:"+e.getMessage());
                 objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
          }
                     
           
    }




    
}
