package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;
import java.util.Set;

import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Model_SubModule extends Commonstudio
{
	PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    ExtentReports logger = ExtentReports.get(Model_SubModule.class);
    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
    AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
    
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
       public void Maintain_ModelDelete(Method m,String username,String password,String PickManufacturer,String Action,String DeleteAction,String ModelWeight,String PickType) throws Exception
       {
           try
           {   
            
            logger.startTest(m.getName());
            System.out.println("method name"+(m.getName()));
            TestReporter.logStep("Start test execution of " + m.getName());
            TestReporter.logStep("Launch Asset Tracker ");
            
   //Set up: Firstly create a Model .
            assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
            WebimplicitWait(wdriver);
            String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
            Assert.assertEquals("Welcome, Tester1", verifyLogin);
            
   //Verifying that the Login is successful
           
            logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
            Thread.sleep(1000);
            
   //Click on the Assets button in the Assets page
            Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
            logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
            
    //Click on the Search Asset link
            Syn_Click(assetTrackMaintainPage.lnk_Models(wdriver));
            logger.log(LogStatus.PASS,"Models link Tab","Models link Tab is clicked ");

            int RandomValue;
            RandomValue=getRandomNumberInRange(1000,20000);
            String RandomModelName;
            RandomModelName=RandomValue+"M";
            
        
            if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
   	     {
   	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
   	     }
   	     else
   	     {
   	       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
   	       SelectDivision.selectByVisibleText(Action);
   	     }
   	     logger.log(LogStatus.PASS,"ADD Dropdown","ADD Dropdown is Selected ");
   	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
   	     
   	     //select Update from dropdown
   	     Thread.sleep(2000);
            Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));
            logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");
            WebimplicitWait(wdriver);
            WebimplicitWait(wdriver);
            switchToWindow("Tab Search");
            String title= wdriver.getTitle();
            if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
    	    {
    	    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
    	    WebimplicitWait(wdriver);
    	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
    	    switchToWindow("Asset Tracker v2.2.1");
    	    }
    	    else {
    	    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
    	    Thread.sleep(12000);
    	    switchToWindow("Asset Tracker v2.2.1");
    		 }	
    	     logger.log(LogStatus.PASS,"Enter the Pick Manufacturer ","Pick Manufacturer is entered ");
    	     
    	     //enter new current location
    	     Thread.sleep(1000);
            
            
            
            assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
            Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
            logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");
            
            assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
            logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
            //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));
            
            assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
            WebimplicitWait(wdriver);
            WebimplicitWait(wdriver);
           
            Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
            
           
            logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
            
            assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
            logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
            //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_ModelWeight(wdriver));
            Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
            logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            
            
    //Test Steps starts now.
   //Select Delete from the Action Dropdown
            WebimplicitWait(wdriver);
            WebimplicitWait(wdriver);
            Select SelectDeleteAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
            SelectDeleteAction.selectByVisibleText(DeleteAction);
            WebimplicitWait(wdriver);
            
            Boolean verifyPickUpDisabled=assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"Pick Up field","Pick Up field is disabled :"+verifyPickUpDisabled);
            
            Boolean verifyWeightDisabled=assetTrackMaintainPage.txt_ModelWeight(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"Weight field","Weight field is disabled :"+verifyWeightDisabled);
            
            Boolean verifyPickTypedisabled=assetTrackMaintainPage.txt_PickType(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"Pick Type field","Pick Type field is disabled :"+verifyPickTypedisabled);
            
    
            Boolean verifyNewtypeDisabled=assetTrackMaintainPage.txt_PickNewType(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"New Model  field","New Model  field is disabled :"+verifyNewtypeDisabled);
            
            Boolean verifyHTSDisabled=assetTrackMaintainPage.txt_HTSCode(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"HTS Code field","HTS Code field is disabled :"+verifyHTSDisabled);

            Boolean verifyECCNDisabled=assetTrackMaintainPage.txt_ECCNCode(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"ECCN Code field","ECCN Code field is disable :"+verifyECCNDisabled);
            
            
            Boolean verifyModelNameDisabled=assetTrackMaintainPage.txt_NewModelName(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"New Model Name field","New Model Name field is disabled :"+verifyModelNameDisabled);
            
            Boolean verifyModelNameEnabled=assetTrackMaintainPage.txt_ModelName(wdriver).isEnabled();
            logger.log(LogStatus.PASS,"Model name field","Model name field is enabled :"+verifyModelNameEnabled);
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            
            //assetTrackMaintainPage.txt_NewModelName(wdriver).clear();
            assetTrackMaintainPage.txt_ModelName(wdriver).sendKeys(RandomModelName);
            Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Model"));
            logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name" +RandomModelName+ "is entered ");
            //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_ModelName(wdriver));
            
           // String verifyNewModelName=assetTrackMaintainPage.txt_ModelName(wdriver).getText();
            //Assert.assertEquals(RandomModelName, verifyNewModelName);
            
            String verifyPicktype=assetTrackMaintainPage.txt_PickType(wdriver).getText();
            Assert.assertEquals(PickType, verifyPicktype);
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            
            Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
            logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            
            String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
            String Concatenate= "Model" +RandomModelName+ "has been deleted";
            Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
            //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
            
           }
           catch (Exception | AssertionError e) {
            System.out.println(e);
            //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
            logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
            TestReporter.logFailure("Error Message:"+e.getMessage());
            objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
           }
       }   
       

    
  //  ------------------------------------2---------------------------------------------------//
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Add_new_HTS_code(Method m,String username,String password,String PickManufacturer,String Action,String ModelWeight,String PickType) throws Exception
    {
           try
           {   

                  logger.startTest(m.getName());
                  System.out.println("method name"+(m.getName()));
                  TestReporter.logStep("Start test execution of " + m.getName());
                  TestReporter.logStep("Launch Asset Tracker ");

    //Set up: 
                  assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
                  WebimplicitWait(wdriver);
                  String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
                  Assert.assertEquals("Welcome, Tester1", verifyLogin);

    //Verifying that the Login is successful
                  logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
                  Thread.sleep(1000);
                 

    //Click on the Maintain button
                  Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
                  logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
                  
                  
    //Click on the Models link
                  Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Models"));
                  logger.log(LogStatus.PASS,"Site Names link","Site Names link  is clicked "); 
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  
    //Verify that the Maintain My Site Names page is displayed
                  String VerifySiteNamesTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Models").getText();
                  Assert.assertEquals("Maintain Models", VerifySiteNamesTitle);
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);        
                  
                  
    //Click on the Add New button next to the HTS Code field
                  Syn_Click(assetTrackMaintainPage.btn_AddNewHTSCode(wdriver));
                  logger.log(LogStatus.PASS,"Add New Button","Add new Button");        

    //New window is opened
                  switchToWindow("maintainMaintainHTS");
                  WebimplicitWait(wdriver);

    //The new window should display the Maintain HTS page with NEW HTS Code text field with save and cancel buttons.
                  Boolean verifySaveButton=assetTrackMaintainPage.btn_SaveModel(wdriver).isDisplayed();
                  logger.log(LogStatus.PASS,"My Preferences","My Preferences is displayed :"+verifySaveButton);
                  
                  Boolean verifyCancelButton=assetTrackMaintainPage.btn_CancelMaintain(wdriver).isDisplayed();
                  logger.log(LogStatus.PASS,"Manufacturers","Manufacturers is displayed :"+verifyCancelButton);
                  
                  Boolean verifyNewHTSCodeField=assetTrackMaintainPage.txt_NewHTSCode(wdriver).isDisplayed();
                  logger.log(LogStatus.PASS,"Models","Models is displayed :"+verifyNewHTSCodeField);
                         
                  int RandomValue;
                  RandomValue=getRandomNumberInRange(10000,20000);
                  String HTSCode,ModelName;
                  HTSCode=RandomValue+"12";
                  ModelName=RandomValue+"Model";
                  
    //Enter the HTS Code is entered
                  assetTrackMaintainPage.txt_NewHTSCode(wdriver).sendKeys(HTSCode);
                  logger.log(LogStatus.PASS,"HTS Code","HTS Codee" +HTSCode+ "is entered:");
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                  
    //Click on the Save button
                  Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
                  logger.log(LogStatus.PASS,"Save button","Save button is clicked ");  
                  
    //Switched back to the Parent window
                  switchToWindow("Asset Tracker v2.2.1");
                  WebimplicitWait(wdriver);  
                  
    //verify that the HTS Code Added is displayed in the text field
            String verifyHTSCode=assetTrackMaintainPage.txt_HTSCode(wdriver).getAttribute("value");
            Assert.assertEquals(HTSCode,verifyHTSCode);
            logger.log(LogStatus.PASS,"The HTS Code Added is displayed in the text field","he HTS Code Added is displayed in the text field as :"+verifyHTSCode);

            
            if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
                  {
                         dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
                  }
                  else
                  {
                         Thread.sleep(3000);  
                         Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
                         SelectAction.selectByVisibleText(Action);
                         WebimplicitWait(wdriver);
                  }             
                  assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
                  Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
                  logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");

                  assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(ModelName);
                  logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
                  objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));

                  assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
                  WebimplicitWait(wdriver);
                  WebimplicitWait(wdriver);
                  Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
                  logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
                  assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
                  logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
                  objCommStudio.getScreenshoteachStepWeb(wdriver, true);

    //Click on Cancel button 
                  Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
                  logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
                  Thread.sleep(1000);

    //Verify that the main screen is displayed after clicking on the Cancel button
                  Thread.sleep(1000);
                  String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
                  Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
                  logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
                  Thread.sleep(1000);
    }
           catch (Exception | AssertionError e) {
                  System.out.println(e);
                  //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
                  logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
                  TestReporter.logFailure("Error Message:"+e.getMessage());
                  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
           }
    }

    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Add_New_Model(Method m,String username,String password,String PickManufacturer,String Action,String ModelWeight,String PickType) throws Exception
    {
    	try
    	{   

    		logger.startTest(m.getName());
    		System.out.println("method name"+(m.getName()));
    		TestReporter.logStep("Start test execution of " + m.getName());
    		TestReporter.logStep("Launch Asset Tracker ");

    		//Set up: Firstly create a Model .
    		assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
    		WebimplicitWait(wdriver);
    		String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
    		Assert.assertEquals("Welcome, Tester1", verifyLogin);

    		//Verifying that the Login is successful

    		logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
    		Thread.sleep(1000);

    		//Click on the Assets button in the Assets page
    		Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
    		logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

    		//Click on the Search Asset link
    		Syn_Click(assetTrackMaintainPage.lnk_Models(wdriver));
    		logger.log(LogStatus.PASS,"Models link Tab","Models link Tab is clicked ");
    		
    		
    //Verify that the Maintain Models page is displayed
    		String VerifySiteNamesTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Models").getText();
    		Assert.assertEquals("Maintain Models", VerifySiteNamesTitle);
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);		
    				
    //Maintain Models page should be displayed with Save and Cancel buttons
    		Boolean verifySaveButton=assetTrackMaintainPage.btn_SaveModel(wdriver).isDisplayed();
    		logger.log(LogStatus.PASS,"Save button","Save button is displayed :"+verifySaveButton);
    		
    		Boolean verifyCancelButton=assetTrackMaintainPage.btn_CancelMaintain(wdriver).isDisplayed();
    		logger.log(LogStatus.PASS,"Cancel button","Cancel button is displayed :"+verifyCancelButton);

    		int RandomValue;
    		RandomValue=getRandomNumberInRange(1000,20000);
    		String RandomModelName;
    		RandomModelName=RandomValue+"M";

    //Select ADD Action from the Actions drop down
    		Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
    		SelectAction.selectByVisibleText(Action);

    //Entering all the Mandatory details.
    		assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
    		Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
    		logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");

    		assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
    		logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
    		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));

    		assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
    		WebimplicitWait(wdriver);
    		Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
    		logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");

    		assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
    		logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		
    //Click on the Save button
    		Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
    		logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		

    //Enter all the fields and click on Cancel button
    		assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
    		logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
    		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));
    		
    //Click on the Cancel button
    		Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
    		logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked ");
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);

    //Verify that the main screen is displayed after clicking on the Cancel button
    		Thread.sleep(1000);
    		String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
    		Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
    		logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		Thread.sleep(1000);


    	}
    	catch (Exception | AssertionError e) {
    		System.out.println(e);
    		//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
    		logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
    		TestReporter.logFailure("Error Message:"+e.getMessage());
    		objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
    	}
    }



    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Add_new_Exp_Classification_code(Method m,String username,String password,String PickManufacturer,String Action,String ModelWeight,String PickType) throws Exception
    {
    	try
    	{   

    		logger.startTest(m.getName());
    		System.out.println("method name"+(m.getName()));
    		TestReporter.logStep("Start test execution of " + m.getName());
    		TestReporter.logStep("Launch Asset Tracker ");

    //Set up: 
    		assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
    		WebimplicitWait(wdriver);
    		String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
    		Assert.assertEquals("Welcome, Tester1", verifyLogin);

    //Verifying that the Login is successful
    		logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
    		Thread.sleep(1000);

    //Click on the Maintain button
    		Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
    		logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
    		
    		
    //Click on the Models link
    		Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Models"));
    		logger.log(LogStatus.PASS,"Site Names link","Site Names link  is clicked "); 
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		
    //Verify that the Maintain Models page is displayed
    		String VerifySiteNamesTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Models").getText();
    		Assert.assertEquals("Maintain Models", VerifySiteNamesTitle);
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);		
    		
    		
    //Click on the Add New button next to the HTS Code field
    		Syn_Click(assetTrackMaintainPage.btn_AddNewECCCode(wdriver));
    		logger.log(LogStatus.PASS,"Add New Button","Add new Button");		

    //New window is opened
    		switchToWindow("maintainMaintainHTS");
    		WebimplicitWait(wdriver);

    //The new window should display the Maintain HTS page with NEW HTS Code text field with save and cancel buttons.
    		Boolean verifySaveButton=assetTrackMaintainPage.btn_SaveModel(wdriver).isDisplayed();
    		logger.log(LogStatus.PASS,"My Preferences","My Preferences is displayed :"+verifySaveButton);
    		
    		Boolean verifyCancelButton=assetTrackMaintainPage.btn_CancelMaintain(wdriver).isDisplayed();
    		logger.log(LogStatus.PASS,"Manufacturers","Manufacturers is displayed :"+verifyCancelButton);
    		
    		Boolean verifyNewHTSCodeField=assetTrackMaintainPage.txt_NewHTSCode(wdriver).isDisplayed();
    		logger.log(LogStatus.PASS,"Models","Models is displayed :"+verifyNewHTSCodeField);
    			
    		int RandomValue;
    		RandomValue=getRandomNumberInRange(10000,20000);
    		String ECCCode,ModelName;
    		ECCCode=RandomValue+"12";
    		ModelName=RandomValue+"Model";
    		
    //Enter the HTS Code is entered
    		assetTrackMaintainPage.txt_NewECCCode(wdriver).sendKeys(ECCCode);
    		logger.log(LogStatus.PASS,"ECC Code","ECC Code" +ECCCode+ "is entered:");
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		
    //Click on the Save button
    		Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
    		logger.log(LogStatus.PASS,"Save button","Save button is clicked ");	
    		
    //Switched back to the Parent window
    		switchToWindow("Asset Tracker v2.2.1");
    		WebimplicitWait(wdriver);	
    		
    //verify that the HTS Code Added is displayed in the text field
            String verifyECCCode=assetTrackMaintainPage.txt_ECCNCode(wdriver).getAttribute("value");
            Assert.assertEquals(ECCCode,verifyECCCode);
            logger.log(LogStatus.PASS,"The HTS Code Added is displayed in the text field","he HTS Code Added is displayed in the text field as :"+verifyECCCode);

            
            if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
    		{
    			dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
    		}
    		else
    		{
    			Thread.sleep(3000);	
    			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
    			SelectAction.selectByVisibleText(Action);
    			WebimplicitWait(wdriver);
    		}		
    		assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
    		Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
    		logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");

    		assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(ModelName);
    		logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
    		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));

    		assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
    		WebimplicitWait(wdriver);
    		WebimplicitWait(wdriver);
    		Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
    		logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
    		assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
    		logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
    		objCommStudio.getScreenshoteachStepWeb(wdriver, true);

    //Click on Cancel button 
    		Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
    		logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked ");
    		Thread.sleep(1000);

    //Verify that the main screen is displayed after clicking on the Cancel button
    		Thread.sleep(1000);
    		String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
    		Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
    		logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
    		Thread.sleep(1000);
    }
    	catch (Exception | AssertionError e) {
    		System.out.println(e);
    		//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
    		logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
    		TestReporter.logFailure("Error Message:"+e.getMessage());
    		objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
    	}
    }

    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Maintain_Module_Model_Negative_Inputs(Method m,String username,String password,String PickManufacturer,String Action,String ModelWeight,String PickType) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
    //Set up: Firstly create a Model .
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
    //Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
    //Click on the Maintain button in the Assets page
         Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
         logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
         
    //Click on the  Models link
         Syn_Click(assetTrackMaintainPage.lnk_Models(wdriver));
         logger.log(LogStatus.PASS,"Models link Tab","Models link Tab is clicked ");
         
        
         //Verify the weight with asterisk is present or not.
         Boolean verifyWeightdisplayed=assetTrackMaintainPage.txt_ModelWeight(wdriver).isDisplayed();
         Boolean Flag=true;
         Assert.assertEquals(verifyWeightdisplayed, Flag);
         logger.log(LogStatus.PASS,"Weight field","Weight field is dispalyed :"+verifyWeightdisplayed);
         Boolean Asterisk=assetTrackMaintainPage.FontColor(wdriver).isDisplayed();
         Assert.assertEquals(Asterisk, Flag);
         logger.log(LogStatus.PASS,"Asterisk field","Asterisk with Weight field is dispalyed :"+Asterisk);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         //Click on save button
         Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         Thread.sleep(2000);
         
         //Verify action message
         String Verify_Message=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
          Assert.assertEquals(Verify_Message,"Action must be specified.");
          logger.log(LogStatus.PASS,"Action message","action message is dispalyed ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
         int RandomValue;
         RandomValue=getRandomNumberInRange(1000,20000);
         String RandomModelName;
         RandomModelName=RandomValue+"M";
            Thread.sleep(2000);
         if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

         {
       	
           dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);

         }

         else

         {

            Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

            SelectDivision.selectByVisibleText(Action);

         }
    		  
         Syn_Click_RunTime(assetTrackMaintainPage.btn_newmodel(wdriver),"JavaScriptClick");
        assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys("###");
         
         
         /*Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
         SelectAction.selectByVisibleText(Action);*/
         
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
         Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
         WebimplicitWait(wdriver);
         WebimplicitWait(wdriver);
         WebimplicitWait(wdriver);
         logger.log(LogStatus.PASS,"PickManufacturer type","PickManufacturer is selected ");
         
      //   assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
      //   logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
        
         
         assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
         Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
         logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
         
         assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
         logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         Thread.sleep(3000);
        
          //Verify action message
         String Verify_Message1=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
          Assert.assertEquals(Verify_Message1,"Enter a valid Model Name.");
          logger.log(LogStatus.PASS,"Action message","Enter a valid Model Name");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         assetTrackMaintainPage.txt_NewModelName(wdriver).clear();
         assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
         logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
          
         //Clicks Manufacture radio button and type text
         Syn_Click(assetTrackMaintainPage.Manufactureradio(wdriver));
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys("QWERTY");
         
         //Type text in ECCn
          assetTrackMaintainPage.txt_ECCNCode(wdriver).sendKeys("QWERTY");
          
        //Click on save button
          Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
          logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
          Thread.sleep(2000);
          
        //Verify validation message
          String Validate_Message=assetTrackMaintainPage.Validmesg(wdriver).getText().trim();
           Assert.assertEquals(Validate_Message,"Select Manufacturer only from the pop-up.");
           String Validate_Message1=assetTrackMaintainPage.Validmesg1(wdriver).getText().trim();
           Assert.assertEquals(Validate_Message1,"Select Export Classification Code only from the pop-up.");
          objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
          
          
          //pickup manufacture and pick up type is selected
          assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
          assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
          Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
          WebimplicitWait(wdriver);
          logger.log(LogStatus.PASS,"Pick up manufacture type","PickManufacturer is selected ");
         
          assetTrackMaintainPage.txt_PickType(wdriver).clear();
          assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
          Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
          WebimplicitWait(wdriver);
          logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
          objCommStudio.getScreenshoteachStepWeb(wdriver, true);
          
          
          //writing incorrect dimensions and validation message
          assetTrackMaintainPage.Text_Dimensions_len(wdriver).sendKeys("&&&");
          assetTrackMaintainPage.Text_Dimensions_widt(wdriver).sendKeys("@&&");
          assetTrackMaintainPage.Text_Dimensions_height(wdriver).sendKeys("##");
          logger.log(LogStatus.PASS,"dimensions type","dimensions is selected ");
          assetTrackMaintainPage.txt_ECCNCode(wdriver).clear();
          Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
          
          String ValidDimensions=assetTrackMaintainPage.ValidDimensions(wdriver).getText().trim();
          Assert.assertEquals(ValidDimensions,"Length is not a valid number.");
          logger.log(LogStatus.PASS,"ValidDimensions","ValidDimensions message is printed ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
          
       //writing correct dimensions and validation message
         assetTrackMaintainPage.Text_Dimensions_len(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_len(wdriver).sendKeys("5");
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).sendKeys("4");
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).sendKeys("3");
         logger.log(LogStatus.PASS,"dimensions type","dimensions is selected ");
         
         assetTrackMaintainPage.txt_NewModelName(wdriver).clear();

       //Click on save button
         Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         Thread.sleep(2000);
         
         //Verify action message
         String Verify_Message2=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
          Assert.assertEquals(Verify_Message2,"New Model must be specified.");
          logger.log(LogStatus.PASS,"Action message","New Model must be specified.");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         
         assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
         logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
             
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
         String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
         String Concatenate= "Model" +" '" + RandomModelName + "' "+ "has been added.";
         Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);

        }
        catch (Exception | AssertionError e) {
         System.out.println(e);
             logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
    		 TestReporter.logFailure("Error Message:"+e.getMessage());
    		  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
        }
    }   

    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Maintain_Module_Model_Update(Method m,String username,String password,String PickManufacturer,String Action,String ModelWeight,String PickType,String UpdateAction,String NewPickManufacturer,String NewPickType) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
    //Set up: Firstly create a Model .
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
    //Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
    //Click on the Maintain button in the Assets page
         Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
         logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
         
    //Click on the  Models link
         Syn_Click(assetTrackMaintainPage.lnk_Models(wdriver));
         logger.log(LogStatus.PASS,"Models link Tab","Models link Tab is clicked ");
          
            
         int RandomValue;
         RandomValue=getRandomNumberInRange(1000,20000);
         String RandomModelName;
         RandomModelName=RandomValue+"M";
         String RandomModelName1=RandomModelName+"E";
         
            Thread.sleep(2000);
                        
         if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

         {
       	
           dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);

         }

         else

         {

            Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

            SelectDivision.selectByVisibleText(Action);

         }
         WebimplicitWait(wdriver);
         Thread.sleep(3000);
         Syn_Click_RunTime(assetTrackMaintainPage.btn_newmodel(wdriver),"JavaScriptClick");
         assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
             
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
         Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
         logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");
               
         assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
         Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
         logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
         
         assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
         logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
           
         String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
         String Concatenate= "Model" +" '" + RandomModelName + "' "+ "has been added.";
         Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
       //Test Steps starts now.
         //Select update from the Action Dropdown
         
         wdriver.navigate().to("https://assettrackerqa.inbcu.com/fats/maintainMaintainModels#");
         if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

         {
       	
           dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),UpdateAction);

         }

         else

         {

            Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

            SelectDivision.selectByVisibleText(UpdateAction);

         }
         
        
         //Actions action = new Actions(wdriver);
        // WebElement we = wdriver.findElement(By.xpath("//select[@name='actionCode']"));
        // action.moveToElement(we).click().perform();
         //WebElement we1 = wdriver.findElement(By.xpath("//select[@name='actionCode']/option[4]"));
         //action.moveToElement(we1).click().build().perform();
         
         		Thread.sleep(3000);
                 Boolean verifyModelNameDisabled=assetTrackMaintainPage.txt_NewModelName(wdriver).isEnabled();
                 Boolean Flag=false;
                 Assert.assertEquals(verifyModelNameDisabled, Flag);
                 logger.log(LogStatus.PASS,"New Model Name field","New Model Name field is disabled");
                   
                 Thread.sleep(2000);
                 assetTrackMaintainPage.txt_ModelName(wdriver).clear();
                 assetTrackMaintainPage.txt_ModelName(wdriver).sendKeys(RandomModelName);
                 Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Model"));
                 logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
                 logger.log(LogStatus.PASS,"Respective fields should be Prefilled ","Respective fields are Prefilled ");
                 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                 Thread.sleep(3000);
                 
                 assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
                 assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(NewPickManufacturer);
                 Syn_Click(assetTrackMaintainPage.btn_SelectPickManufacture(wdriver));
                 logger.log(LogStatus.PASS,"Pick up manufacturer","Pick up manufacturer is selected ");
                 Thread.sleep(1000);
                    
    			  assetTrackMaintainPage.txt_PickType(wdriver).clear();
    			  assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(NewPickType);
    			  Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
    			  logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
         		         
    		     Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
    		     logger.log(LogStatus.PASS,"save button","save button Tab is clicked ");
      		     Thread.sleep(3000);
        
    		      //Verify confirmation message
    		     String VerifyConfirmationMsg1=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
    		     String Concatenate1= "Model" +" '" + RandomModelName + "' "+ "has been updated.";
    		     Assert.assertEquals(Concatenate1, VerifyConfirmationMsg1);
    		     logger.log(LogStatus.PASS,"Model Tab","Model is added :" +VerifyConfirmationMsg1);
    		     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		     
    		     assetTrackMaintainPage.txt_ModelName(wdriver).clear();
    		     assetTrackMaintainPage.txt_ModelName(wdriver).sendKeys(RandomModelName);
                 Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Model"));
                 logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
                 logger.log(LogStatus.PASS,"Respective fields should be Prefilled with updated data ","Respective fields are Prefilled with updated data");
                 Thread.sleep(1000);
                 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		     
                    
                 if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

                 {
               	
                   dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);

                 }

                 else

                 {

                    Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

                    SelectDivision.selectByVisibleText(Action);

                 }
                 Thread.sleep(1000);
                 
                 if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
                 {
                 Syn_Click_RunTime(assetTrackMaintainPage.btn_newmodel(wdriver),"JavaScriptClick");
                 assetTrackMaintainPage.txt_NewModelName(wdriver).clear();
                 assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName1);
    		     
    		     //Clicks Manufacture radio button and pickup type and type text
                 Syn_Click_RunTime(assetTrackMaintainPage.Manufactureradio(wdriver),"JavaScriptClick");
    		    // Syn_Click(assetTrackMaintainPage.Manufactureradio(wdriver));
    		     assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
    		     assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(RandomModelName1);
                 }
                 else
                 {
                	 Syn_Click(assetTrackMaintainPage.btn_newmodel(wdriver));
                     assetTrackMaintainPage.txt_NewModelName(wdriver).clear();
                     assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName1);
        		     
        		     //Clicks Manufacture radio button and pickup type and type text
           		     Syn_Click(assetTrackMaintainPage.Manufactureradio(wdriver));
        		     assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
        		     assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(RandomModelName1); 
                 }
    		     assetTrackMaintainPage.txt_PickType(wdriver).clear();
    		     assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(RandomModelName1);
    		     logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
    		     
    		     //Model Weight is added
    		     assetTrackMaintainPage.txt_ModelWeight(wdriver).clear();
    		      assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
    		      logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
    		     
    		      
    		      //Click on save button
    		      Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
    		      logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
    		      Thread.sleep(2000);
    		      
    		      //Verify validation message
    		      String Validate_Message=assetTrackMaintainPage.Validmesg(wdriver).getText().trim();
    		       Assert.assertEquals(Validate_Message,"Select Manufacturer only from the pop-up.");
    		      objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
    		      
    		       //pickup manufacture and pick up type is selected
    		      assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
    		      assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
    		      Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
    		      WebimplicitWait(wdriver);
    		      logger.log(LogStatus.PASS,"Pick up manufacture type","PickManufacturer is selected ");
    		     
    		      assetTrackMaintainPage.txt_PickType(wdriver).clear();
    		      assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
    		      Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
    		      WebimplicitWait(wdriver);
    		      logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
    		      objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		      		     	      		      		
    		     //Click on save button
    		     Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
    		     logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
    		     Thread.sleep(2000);
    		     		   
    		      //Verify confirmation message
    		     String VerifyConfirmationMsg2=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
    		     String Concatenate2= "Model" +" '" + RandomModelName1 + "' "+ "has been added.";
    		    // Assert.assertEquals(Concatenate2, VerifyConfirmationMsg2);
    		     logger.log(LogStatus.PASS,"Model is added","message :" +VerifyConfirmationMsg2);
    		     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    		     
    		     wdriver.navigate().to("https://assettrackerqa.inbcu.com/fats/maintainMaintainModels#");
    		     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

    		     {
    		   	
    		       dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),UpdateAction);

    		     }

    		     else

    		     {

    		        Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

    		        SelectDivision.selectByVisibleText(UpdateAction);

    		     }
    		     assetTrackMaintainPage.txt_ModelName(wdriver).sendKeys(RandomModelName1);
                 Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Model"));
                Thread.sleep(2000);
                 logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
                 logger.log(LogStatus.PASS,"Model name is present ","Model name is present");
                
    		     
    		
    		    }
    		    catch (Exception | AssertionError e) {
    		     System.out.println(e);
    		         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
    				 TestReporter.logFailure("Error Message:"+e.getMessage());
    				  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
    		    }
    }
 
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void validation_for_max_length_and_saving_values_for_manufacture_and_Type(Method m,String username,String password,String Action,String PickManufacturer,String PickType,String ModelWeight,String modelength,String Width,String Height) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
         //Set up: Firstly create a Model .
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
         //Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(5000);
         
         //Click on the maintains button in the Assets page
         Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
         
         //verify the sub menus are present are not
         Thread.sleep(5000);
         Boolean lnk_Models=assetTrackMaintainPage.lnk_Models(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Model Sub Menu field","Model Sub Menu field is displayed :"+lnk_Models);
         
         Boolean lnk_Manufacturers=assetTrackMaintainPage.lnk_Manufacturers(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Manufacturers Sub Menu field","Manufacturers Sub Menu field is displayed :"+lnk_Manufacturers);
         
         Boolean lnk_currentlocations=assetTrackMaintainPage.lnk_currentlocations(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"currentlocations Sub Menu field","currentlocations Sub Menu field is displayed :"+lnk_currentlocations);
                  
         Boolean lnk_currentsublocations=assetTrackMaintainPage.lnk_currentsublocations(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"currentsublocations Sub Menu field","currentsublocations Sub Menu field is displayed :"+lnk_currentsublocations); 
         
         Boolean lnk_MyPreferences=assetTrackMaintainPage.lnk_MyPreferences(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"MyPreferences Sub Menu field","MyPreferences Sub Menu field is displayed :"+lnk_MyPreferences);
         
         Boolean lnk_Divsions=assetTrackMaintainPage.lnk_Divsions(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Divsions Sub Menu field","Divsions Sub Menu field is displayed :"+lnk_Divsions);
         
         Boolean lnk_SiteNames=assetTrackMaintainPage.lnk_SiteNames(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"SiteNames Sub Menu field","SiteNames Sub Menu field is displayed :"+lnk_SiteNames);
         
         Boolean lnk_Vendors=assetTrackMaintainPage.lnk_Vendors(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Vendors Sub Menu field","Vendors Sub Menu field is displayed :"+lnk_Vendors);
         
         Boolean lnk_Types=assetTrackMaintainPage.lnk_Types(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Types Sub Menu field","Types Sub Menu field is displayed :"+lnk_Types);
         
         Boolean lnk_Statuses=assetTrackMaintainPage.lnk_Statuses(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Statuses Sub Menu field","Statuses Sub Menu field is displayed :"+lnk_Statuses);
         
         Boolean lnk_WorkerDivAssocs=assetTrackMaintainPage.lnk_WorkerDivAssocs(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"WorkerDivAssocs Sub Menu field","WorkerDivAssocs Sub Menu field is displayed :"+lnk_WorkerDivAssocs);
         
         Boolean lnk_PermanentLocations=assetTrackMaintainPage.lnk_PermanentLocations(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"PermanentLocations Sub Menu field","PermanentLocations Sub Menu field is displayed :"+lnk_PermanentLocations);
         
         //Click on the Model link
         Thread.sleep(5000);
         Syn_Click(assetTrackMaintainPage.lnk_Models(wdriver));
         logger.log(LogStatus.PASS,"Models link Tab","Models link Tab is clicked ");

         int RandomValue;
         RandomValue=getRandomNumberInRange(1000,20000);
         String RandomModelName;
         RandomModelName=RandomValue+"M";
         
     
         if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

	     {
	   	
	       dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);

	     }

	     else

	     {

	        Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

	        SelectDivision.selectByVisibleText(Action);

	     }
         
         //pickup manufacture and pick up type is selected
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
         Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
         WebimplicitWait(wdriver);
         Thread.sleep(2000);
         logger.log(LogStatus.PASS,"Pick up manufacture type","PickManufacturer is selected ");
        
         assetTrackMaintainPage.txt_PickType(wdriver).clear();
         assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
         Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
         WebimplicitWait(wdriver);
         Thread.sleep(2000);
         logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
         logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         String Max="9999999999999999";
         
         assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(Max);
         logger.log(LogStatus.PASS,"Enter the Model Weight ","Maximum Model Weight is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_len(wdriver).sendKeys(Max);
         logger.log(LogStatus.PASS,"Enter the Model length ","Maximum Model length is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).sendKeys(Max);
         logger.log(LogStatus.PASS,"Enter the Model Width ","Maximum Model Width is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).sendKeys(Max);
         logger.log(LogStatus.PASS,"Enter the Model Height ","Maximum Model Height is entered ");
         
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_ModelWeight(wdriver));
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         Thread.sleep(2000);
         String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
         Assert.assertEquals(VerifyConfirmationMsg, "Length cannot be greater than 9999999999.99 IN");
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         assetTrackMaintainPage.txt_ModelWeight(wdriver).clear();
         assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);
         logger.log(LogStatus.PASS,"Enter the Model Weight ","Valid Model Weight is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_len(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_len(wdriver).sendKeys(modelength);
         logger.log(LogStatus.PASS,"Enter the Model length ","Valid Model length is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).sendKeys(Max);
         logger.log(LogStatus.PASS,"Enter the Model Width ","Maximum Model Width is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).sendKeys(Height);
         logger.log(LogStatus.PASS,"Enter the Model Height ","Valid MaxWidthModel Height is entered ");
         
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         Thread.sleep(2000);
         String VerifyConfirmationMsg1=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
         Assert.assertEquals(VerifyConfirmationMsg1, "Width cannot be greater than 9999999999.99 IN");
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
         Thread.sleep(2000);
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_widt(wdriver).sendKeys(Width);
         logger.log(LogStatus.PASS,"Enter the Model Width ","Valid Model Width is entered ");
         
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).sendKeys(Max);
         logger.log(LogStatus.PASS,"Enter the Model Height ","Maximum Model Height is entered ");
         
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         Thread.sleep(2000);
         String VerifyConfirmationMsg11=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
         Assert.assertEquals(VerifyConfirmationMsg11, "Height cannot be greater than 9999999999.99 IN");
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Error(wdriver));
        
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).clear();
         assetTrackMaintainPage.Text_Dimensions_height(wdriver).sendKeys(Height);
         logger.log(LogStatus.PASS,"Enter the Model Height ","Model Height is entered ");
         
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         Thread.sleep(2000);
         String VerifyConfirmationMsg12=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
         String Valid= "Model" +" '" + RandomModelName + "' "+ "has been added.";
         Assert.assertEquals(VerifyConfirmationMsg12,Valid);
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
         
        }
        catch (Exception | AssertionError e) {
         System.out.println(e);
         //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
         TestReporter.logFailure("Error Message:"+e.getMessage());
         objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
        }
    }   
     
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)

    public void Export_Classification_Code_Add_New_Model(Method m,String username,String password,String Action,String PickManufacturer,String PickType,String ModelWeight,String modelength,String Width,String Height,String PickManufacturerSpaceData,String PickManufacturerSpclData,String PickManufacturer1,String PickManufacturer2,String PickManufacturer3,String PickManufacturer4,String PickManufacturer5) throws Exception

    {
    try

            {  
    logger.startTest(m.getName());
    System.out.println("method name"+(m.getName()));
    TestReporter.logStep("Start test execution of " + m.getName());
   TestReporter.logStep("Launch Asset Tracker ");

   wdriver.manage().window().maximize();

   //Set up: Firstly create a Model .

   assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);

   WebimplicitWait(wdriver);

   String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();

   Assert.assertEquals("Welcome, Tester1", verifyLogin);

 

            //Verifying that the Login is successful

 

            logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);

            Thread.sleep(1000);

 

            //Click on the Assets button in the Assets page

   Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));

   logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");



                               //Click on the Search Asset link

   Syn_Click(assetTrackMaintainPage.lnk_Models(wdriver));

   logger.log(LogStatus.PASS,"Models link Tab","Models link Tab is clicked ");

 

   

//Verify that the Maintain Models page is displayed

   String VerifySiteNamesTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Models").getText();

   Assert.assertEquals("Maintain Models", VerifySiteNamesTitle);

   objCommStudio.getScreenshoteachStepWeb(wdriver, true);                      

                                   

//Maintain Models page should be displayed with Save and Cancel buttons

   Boolean verifySaveButton=assetTrackMaintainPage.btn_SaveModel(wdriver).isDisplayed();

   logger.log(LogStatus.PASS,"Save button","Save button is displayed :"+verifySaveButton);

 

   Boolean verifyCancelButton=assetTrackMaintainPage.btn_CancelMaintain(wdriver).isDisplayed();

   logger.log(LogStatus.PASS,"Cancel button","Cancel button is displayed :"+verifyCancelButton);

 

            int RandomValue;

            RandomValue=getRandomNumberInRange(1000,20000);

            String RandomModelName;

            RandomModelName=RandomValue+"M";

 

            if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))

 {

              dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);

                     }

                     else

                     {

                       Select SelectDivision=new Select(assetTrackMaintainPage.drpdownAction(wdriver));

                       SelectDivision.selectByVisibleText(Action);

                     }

                     logger.log(LogStatus.PASS,"ADD Dropdown","ADD Dropdown is Selected ");

                     objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                     

                     //select Update from dropdown

                     Thread.sleep(2000);

 

                     Boolean verifyPickUpDisabled=assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).isEnabled();

             logger.log(LogStatus.PASS,"Pick Manufacturer field","Pick Manufacturer field is enabled :"+verifyPickUpDisabled);

                     

                     Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver)); //select vendor 1st option
                     Thread.sleep(4000);
                     switchToWindow("Tab Search");

                     Thread.sleep(4000);

    //Entering all the Mandatory details.

                     String title= wdriver.getTitle();

                        if(title.equalsIgnoreCase("NBCUniversal SSO Login"))

                        {

                        assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);

                        WebimplicitWait(wdriver);

                        Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
                        Thread.sleep(2000);
                        switchToWindow("Asset Tracker v2.2.1");

                        }

                        else {

                        Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option

                        Thread.sleep(2000);

                        switchToWindow("Asset Tracker v2.2.1");

                                    }            

                         logger.log(LogStatus.PASS,"Enter the Pick Manufacturer ","Pick Manufacturer is entered ");

                       

                         //enter new current location

                         Thread.sleep(1000);

                   

                        assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);

                    logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");

                    objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));

                   

                    Syn_Click(assetTrackMaintainPage.PickUp_Type_PopupButton(wdriver)); //select vendor 1st option
                    Thread.sleep(3000);
                         switchToWindow("Tab Search");

                         Thread.sleep(3000);

   //Entering all the Mandatory details.

                         String title1= wdriver.getTitle();

                                    if(title1.equalsIgnoreCase("NBCUniversal SSO Login"))

                                    {

                                    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);

                                    WebimplicitWait(wdriver);

                                    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
                                    Thread.sleep(2000);
                                    switchToWindow("Asset Tracker v2.2.1");

                                    }

                                    else {

                                    Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option

                                    Thread.sleep(4000);

                                    switchToWindow("Asset Tracker v2.2.1");

                                                }            

                                    logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");

                                   

                                     //enter new current location

                                     Thread.sleep(1000);

                               

                                assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys(ModelWeight);

                                logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                               

    //Click on the Save button

                                Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));

                                logger.log(LogStatus.PASS,"Save button","Save button is clicked ");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);
                                Thread.sleep(3000);
                               

                               

                                String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();

            String Concatenate= "Model '" +RandomModelName+ "' has been added.";

            Assert.assertEquals(Concatenate, VerifyConfirmationMsg);

            //objCommStudio.getScreenshoteachStepWeb(wdriver, true);

            objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));

           

           

           

            Syn_Click(assetTrackMaintainPage.New_Manufacturer_RadioButton(wdriver));

                                logger.log(LogStatus.PASS,"Radio button","Radio button is clicked ");

                               

                                Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));

                                logger.log(LogStatus.PASS,"Save button","Save button is clicked ");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                               

                                String VerifyManufactureConfirmationMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();

            String Concatenate1= "Manufacturer must be specified.";

            Assert.assertEquals(Concatenate1, VerifyManufactureConfirmationMsg);

            //objCommStudio.getScreenshoteachStepWeb(wdriver, true);

            objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Error(wdriver));

           

            Syn_Click(assetTrackMaintainPage.PickUpManufacturer_RadioButton(wdriver));

            logger.log(LogStatus.PASS,"Pick Up Manufacturer Radio button","Pick Up Manufacturer Radio button is clicked ");

           

            String DefaultValue=assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).getAttribute("value").trim();
            Assert.assertEquals(DefaultValue, "");
            logger.log(LogStatus.PASS,"Pick manufacturer should not have any default value","No default value is displayed");
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);

            assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturerSpaceData);
            logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

            objCommStudio.getScreenshoteachStepWeb(wdriver, true);

            Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));
            Thread.sleep(4000);
                               

                         Set<String> availableWindows = wdriver.getWindowHandles();

                                if (availableWindows.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

                                }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }

                                switchToWindow("Tab Search");
                                Thread.sleep(1000);
                                wdriver.close();
                                Thread.sleep(2000);
                                switchToWindow("Asset Tracker v2.2.1");

                               
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturerSpclData);

                                logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                                Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));
                                Thread.sleep(3000);
                               

                             Set<String> availableWindows1 = wdriver.getWindowHandles();

                                if (availableWindows1.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

               }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }
                                Thread.sleep(2000);
                                switchToWindow("Tab Search");
                                Thread.sleep(1000);
                                wdriver.close();
                                Thread.sleep(3000);
                                switchToWindow("Asset Tracker v2.2.1");

                               
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer1);

                                logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                                Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));

                                Thread.sleep(3000);

                             Set<String> availableWindows2 = wdriver.getWindowHandles();

                                if (availableWindows2.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

                                }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }

                                switchToWindow("Tab Search");
                                Thread.sleep(1000);
                                wdriver.close();
                                Thread.sleep(2000);
                                switchToWindow("Asset Tracker v2.2.1");

                               
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer2);

                                logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                                Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));

                                Thread.sleep(3000);

                          Set<String> availableWindows3 = wdriver.getWindowHandles();

                                if (availableWindows3.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

               }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }

                                switchToWindow("Tab Search");

                                wdriver.close();

                                switchToWindow("Asset Tracker v2.2.1");

                               
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();
                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer3);

                                logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                                Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));

                                Thread.sleep(3000);

                      Set<String> availableWindows4 = wdriver.getWindowHandles();

                                if (availableWindows4.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

              }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }

                                switchToWindow("Tab Search");

                                wdriver.close();

                                switchToWindow("Asset Tracker v2.2.1");

                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();

                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer4);

                                logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                                Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));

                               
                                Thread.sleep(3000);
                             Set<String> availableWindows5 = wdriver.getWindowHandles();

                                if (availableWindows5.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

               }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }

                                switchToWindow("Tab Search");

                                wdriver.close();

                                switchToWindow("Asset Tracker v2.2.1");

                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).clear();

                                assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer5);

                                logger.log(LogStatus.PASS,"Enter the Pick Manufacturer with spaces","Pick Manufacturer is entered with spaces");

                                objCommStudio.getScreenshoteachStepWeb(wdriver, true);

                                Syn_Click(assetTrackMaintainPage.PickUp_Manufacture_PopupButton(wdriver));

                                Thread.sleep(3000);

                             Set<String> availableWindows6 = wdriver.getWindowHandles();

                                if (availableWindows6.size() > 1)

                                {

                                                logger.log(LogStatus.PASS,"The popup should be displayed with matched values","The popup is displayed with matched values");

               }

                                else

                                {

                                                logger.log(LogStatus.FAIL,"The popup should be displayed with matched values","The popup is not displayed with matched values");

                                }

                                switchToWindow("Tab Search");

                                wdriver.close();

                                switchToWindow("Asset Tracker v2.2.1");

 

 

                }

                catch (Exception | AssertionError e) {

                                System.out.println(e);

                                //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");

                                logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());

                                TestReporter.logFailure("Error Message:"+e.getMessage());

                                objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);

                }

    }


}
