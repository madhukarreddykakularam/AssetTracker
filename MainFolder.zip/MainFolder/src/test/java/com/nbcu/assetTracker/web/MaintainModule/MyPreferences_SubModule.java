package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class MyPreferences_SubModule extends Commonstudio 
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(MyPreferences_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_ModelMyPreferencesEnterAssetWithoutPO(Method m,String username,String password,String Action) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Divsions(wdriver));
			logger.log(LogStatus.PASS,"Divisions link","Divisions link  is clicked ");  

			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomDivisionName;
			RandomDivisionName=RandomValue+"D";


			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);

			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomDivisionName);
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered: "+RandomDivisionName);


			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the Search Asset link
			Syn_Click(assetTrackMaintainPage.lnk_MyPreferences(wdriver));
			logger.log(LogStatus.PASS,"My Preferences link","My Preferences link  is clicked ");

			//Verify that the Maintain My Preferences page is displayed
			String VerifyPrefernceTitle=assetTrackMaintainPage.tit_MyPreferences(wdriver).getText();
			Assert.assertEquals("Maintain My Preferences", VerifyPrefernceTitle);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value in the Divisions section
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).sendKeys(RandomDivisionName);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Division"));
			Thread.sleep(1000);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Division"));
			logger.log(LogStatus.PASS,"Divison Selection","Division is selected from the list :"+RandomDivisionName);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			String VerifyEnteredDivision=assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).getAttribute("value");
			Assert.assertEquals(RandomDivisionName, VerifyEnteredDivision);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Click on the Save button
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Confirmation message s displayed
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			Assert.assertEquals("You have successfully updated your preferences.", VerifyConfirmationMsg);
			Thread.sleep(1000);

			//Click on Asset Module tab
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

			//Click on the Enter Asset link
			Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Enter Asset Link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on Enter Without # button
			Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
			logger.log(LogStatus.PASS,"Enter without PO# button","Enter without PO# button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Entered Division in My preferences Page is displayed in the Assets Page
			String VerifyAssetDivision=assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).getAttribute("value");
			Assert.assertEquals(RandomDivisionName, VerifyAssetDivision);
			logger.log(LogStatus.PASS,"Verify the entered Division in Assets page","Verified the entered Division in Assets page is same: "+RandomDivisionName);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}   


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_ModelMyPreferencesEnterAssetWithPO(Method m,String username,String password,String Action,String PONumber) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Divsions(wdriver));
			logger.log(LogStatus.PASS,"Divisions link","Divisions link  is clicked ");  

			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomDivisionName;
			RandomDivisionName=RandomValue+"D";


			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);

			assetTrackMaintainPage.txt_NewDivision(wdriver).sendKeys(RandomDivisionName);
			logger.log(LogStatus.PASS,"New Division Name","New Division name is entered: "+RandomDivisionName);


			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the Search Asset link
			Syn_Click(assetTrackMaintainPage.lnk_MyPreferences(wdriver));
			logger.log(LogStatus.PASS,"My Preferences link","My Preferences link  is clicked ");

			//Verify that the Maintain My Preferences page is displayed
			String VerifyPrefernceTitle=assetTrackMaintainPage.tit_MyPreferences(wdriver).getText();
			Assert.assertEquals("Maintain My Preferences", VerifyPrefernceTitle);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Select any value in the Divisions section
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
			Thread.sleep(1000);
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).sendKeys(RandomDivisionName);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Division"));
			Thread.sleep(1000);
			Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver," Division"));
			logger.log(LogStatus.PASS,"Divison Selection","Division is selected from the list :"+RandomDivisionName);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			String VerifyEnteredDivision=assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).getAttribute("value");
			Assert.assertEquals(RandomDivisionName, VerifyEnteredDivision);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the Save button
			Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Confirmation message s displayed
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
			Assert.assertEquals("You have successfully updated your preferences.", VerifyConfirmationMsg);
			Thread.sleep(1000);

			//Click on Asset Module tab
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

			//Click on the Enter Asset link
			Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Enter Asset Link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Enter a PO number 
			assetTrackAssetsPge.txt_POnumber(wdriver).sendKeys(PONumber);
			WebimplicitWait(wdriver);
			logger.log(LogStatus.PASS,"Set PO number","PO number is entered :"+ PONumber);

			//Click on the Find PO# button
			Syn_Click(assetTrackAssetsPge.btn_FindPO(wdriver));
			logger.log(LogStatus.PASS,"Find PO# button","Find PO# button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on Add line Item button
			Syn_Click(assetTrackAssetsPge.btn_AddLineItem(wdriver,1));
			logger.log(LogStatus.PASS,"Add Line Item button","Add Line Item button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Line Item tab is displayed
			Boolean verifyLineItemDisplayed=assetTrackAssetsPge.btn_LineItem(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Line Item Tab","Line Item Tab is displayed :"+verifyLineItemDisplayed);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify that the Asset Tab is displayed

			Boolean verifyAssetTabDisplayed=assetTrackAssetsPge.btn_AssetLineItem(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyAssetTabDisplayed);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Keep the Divisions field blank
			assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();

			//Enter the Tracking Asset Number under the Assets Tab   
			Syn_Click(assetTrackAssetsPge.btn_AssetLineItem(wdriver));
			logger.log(LogStatus.PASS,"Find PO# button","Find PO# button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			String RandomTrackingNo;
			RandomTrackingNo=RandomValue+"T";
			assetTrackAssetsPge.txt_TrackingItemNo(wdriver).sendKeys(RandomTrackingNo);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the Save button 
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS,"Save button ","Save button is clicked ");

			//Verify that the Error message is displayed when the Division field is blank
			String verifyErrorMessage=assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals("Division must be specified.", verifyErrorMessage);
			logger.log(LogStatus.PASS,"Error without Division"," Error is displayed when the division field is left blank: "+verifyErrorMessage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	} 
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_MyPreference_Negative_Flow(Method m,String username,String password,String Currency,String Action,String currentLocation,String permanentlocation,String permanentsublocation,String cost,String costObjectNumber,String Account) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Set up: Firstly create a Division .
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	     logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	     Thread.sleep(10000);
	     
	//Click on the Maintain button in the Assets page
	     Thread.sleep(10000);
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	     
	     //Click on the MyPreferences link
	     Syn_Click(assetTrackMaintainPage.lnk_MyPreferences(wdriver));
	     logger.log(LogStatus.PASS,"MyPreferences link Tab","MyPreferences link Tab is clicked ");
	      
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	      Thread.sleep(3000);
	    
	     //Verify confirmation message
	     String VerifyConfirmationMsg=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
	     Assert.assertEquals(VerifyConfirmationMsg, "No value has been changed.");
	     logger.log(LogStatus.PASS,"confirmation message :" +VerifyConfirmationMsg);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     
	     String RandomValue;
	     RandomValue=RandomStringUtils.randomAlphabetic(5);
	     String RandomModelName;
	     RandomModelName=RandomValue.toUpperCase();
	    int randomNumber=getRandomNumberInRange(1000,70000);
	    String Random=randomNumber + "3";
	     
	   //Enter Divison name
	     Thread.sleep(2000);
	     assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
	     Syn_Click(assetTrackMaintainPage.btn_division(wdriver));
	     Thread.sleep(5000);
	     switchToWindow("Tab Search");
	     String title= wdriver.getTitle();
	     if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	     {
	     assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     }
	     else {
	     Thread.sleep(2000);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(5000);
	     switchToWindow("Asset Tracker v2.2.1");
		 }	 
	     logger.log(LogStatus.PASS,"Enter the Divison Type ","Divison Type is entered ");
	     
	     //enter current location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_currentlocation(wdriver).clear();
	     assetTrackMaintainPage.txt_currentlocation(wdriver).sendKeys(RandomModelName);
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered Manually");
	     
	   //enter Permanent location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_permanentlocation(wdriver).clear();
	     assetTrackMaintainPage.txt_permanentlocation(wdriver).sendKeys(RandomModelName);
	     logger.log(LogStatus.PASS,"Enter the Permanent location ","Permanent location is entered Manually");
	    
	     //enter Permanent Sub location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_permanentsublocation(wdriver).clear();
	     assetTrackMaintainPage.txt_permanentsublocation(wdriver).sendKeys(RandomModelName);
	     logger.log(LogStatus.PASS,"Enter the Permanent sub location ","Permanent sub location is entered Manually");
	     
	     //enter Cost Object number
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_costObjectNumber(wdriver).clear();
	     assetTrackMaintainPage.txt_costObjectNumber(wdriver).sendKeys(Random);
	     logger.log(LogStatus.PASS,"Enter the Permanent sub location ","Permanent sub location is entered Manually");
	     
	   //enter Account number
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_accountNumber(wdriver).clear();
	     assetTrackMaintainPage.txt_accountNumber(wdriver).sendKeys(Random);
	     logger.log(LogStatus.PASS,"Enter the Account number","Account number is entered Manually");
	     
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drp_currencyCode(wdriver),Currency);
	     }
	     else
	     {
	        Select SelectDivision=new Select(assetTrackMaintainPage.drp_currencyCode(wdriver));
	        SelectDivision.selectByVisibleText(Currency);
	     }
	     
	     //enter weight in kg
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.radio_weigt2(wdriver));
	     WebimplicitWait(wdriver);
	     logger.log(LogStatus.PASS,"weight in kg is clicked","weight in kg is clicked");  
	     
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	   Thread.sleep(4000);
	     //Verify confirmation message
	     String VerifyConfirmationMsg2=assetTrackMaintainPage.Action_Message(wdriver).getText().trim();
	     if(VerifyConfirmationMsg2.equalsIgnoreCase("Select Current Location only from the pop-up.")) {
	     logger.log(LogStatus.PASS,"Validation message is displayed" );
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     }   
	     //Enter Divison name
	     Thread.sleep(2000);
	     assetTrackMaintainPage.txt_Divison_Prefernces(wdriver).clear();
	     Syn_Click(assetTrackMaintainPage.btn_division(wdriver));
	     Thread.sleep(5000);
	     switchToWindow("Tab Search");
	     if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
	     {
	     assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     }
	     else {
	     Thread.sleep(2000);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(2000);
	     switchToWindow("Asset Tracker v2.2.1");
		 }	 
	     logger.log(LogStatus.PASS,"Enter the Divison Type ","Divison Type is entered ");
	     
	     //enter current location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_currentlocation(wdriver).clear();
	     WebimplicitWait(wdriver);
	     Syn_Click(assetTrackMaintainPage.btn_currentlocation(wdriver));
	     switchToWindow("Tab Search");
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the current location ","current location is entered ");
	          
	   //enter Permanent location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_permanentlocation(wdriver).clear();
	     //  assetTrackMaintainPage.txt_permanentlocation(wdriver).sendKeys(permanentlocation);
	     Syn_Click(assetTrackMaintainPage.btn_permanentlocation(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Thread.sleep(7000);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(7000);
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Permanent location ","Permanent location is entered ");
	    
	     //enter Permanent Sub location
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_permanentsublocation(wdriver).clear();
	   //  assetTrackMaintainPage.txt_permanentsublocation(wdriver).sendKeys(permanentsublocation);
	     Syn_Click(assetTrackMaintainPage.btn_permanentsublocation(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Thread.sleep(7000);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(7000);
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Permanent sub location ","Permanent sub location is entered ");
	     
	     //enter Cost Object number
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_costObjectNumber(wdriver).clear();
	    // assetTrackMaintainPage.txt_costObjectNumber(wdriver).sendKeys(costObjectNumber);
	     Syn_Click(assetTrackMaintainPage.btn_costObjectNumber(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Thread.sleep(5000);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(5000);
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Permanent sub location ","Permanent sub location is entered ");
	     
	   //enter Account number
	     WebimplicitWait(wdriver);
	     assetTrackMaintainPage.txt_accountNumber(wdriver).clear();
	   //  assetTrackMaintainPage.txt_accountNumber(wdriver).sendKeys(Account);
	     Syn_Click(assetTrackMaintainPage.btn_accountNumber(wdriver));
	     WebimplicitWait(wdriver);
	     switchToWindow("Tab Search");
	     Thread.sleep(5000);
	     Syn_Click(assetTrackMaintainPage.selValueWindow(wdriver)); //select vendor 1st option
	     Thread.sleep(5000);
	     switchToWindow("Asset Tracker v2.2.1");
	     logger.log(LogStatus.PASS,"Enter the Account number","Account number is entered ");
	     
	     Thread.sleep(2000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
	     {
	   	  dropDownSelectJavaScript(assetTrackMaintainPage.drp_currencyCode(wdriver),Currency);
	     }
	     else
	     {
	        Select SelectDivision=new Select(assetTrackMaintainPage.drp_currencyCode(wdriver));
	        SelectDivision.selectByVisibleText(Currency);
	     }
	     
	     //enter weight in kg
	     WebimplicitWait(wdriver);
	     Thread.sleep(1000);
	     if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
	     if(assetTrackMaintainPage.radio_weigt2(wdriver).isSelected())
	     {
	    	 Syn_Click_RunTime(assetTrackMaintainPage.radio_weigt1(wdriver),"JavaScriptClick");	 
	     WebimplicitWait(wdriver);
	     logger.log(LogStatus.PASS,"weight in LB is clicked","weight in LB is clicked");  
	     }
	     else
	     {
	    	 Syn_Click_RunTime(assetTrackMaintainPage.radio_weigt2(wdriver),"JavaScriptClick");	 
	    	  logger.log(LogStatus.PASS,"weight in kg is clicked","weight in KG is clicked");
	     }
	    
	     }
	     else {
	    	  if(assetTrackMaintainPage.radio_weigt2(wdriver).isSelected())
	    	     {
	    	    	 Syn_Click(assetTrackMaintainPage.radio_weigt1(wdriver));	 
	    	     WebimplicitWait(wdriver);
	    	     logger.log(LogStatus.PASS,"weight in LB is clicked","weight in LB is clicked");  
	    	     }
	    	     else
	    	     {
	    	    	  Syn_Click(assetTrackMaintainPage.radio_weigt2(wdriver));	  
	    	    	  logger.log(LogStatus.PASS,"weight in kg is clicked","weight in KG is clicked");
	    	     }
	    	       	 
	     }
	     //save button is clicked
	     Syn_Click(assetTrackMaintainPage.btn_SavePreferences(wdriver));
	     logger.log(LogStatus.PASS,"Save Tab","Save button is clicked ");
	     
	     //Verify confirmation message
	     Thread.sleep(1000);
	     String VerifyConfirmationMsg1=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
	     Assert.assertEquals(VerifyConfirmationMsg1, "You have successfully updated your preferences.");
	     logger.log(LogStatus.PASS,"confirmation message :" +VerifyConfirmationMsg1);
	     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	      
	     
	      }
			    catch (Exception | AssertionError e) {
			     System.out.println(e);
			         logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
					 TestReporter.logFailure("Error Message:"+e.getMessage());
					  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
			    }
	}   


}
