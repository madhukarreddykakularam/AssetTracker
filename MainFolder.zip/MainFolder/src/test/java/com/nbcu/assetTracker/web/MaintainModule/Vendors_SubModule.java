package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;


public class Vendors_SubModule extends Commonstudio 
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(Vendors_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Vendor_Positive_Flow(Method m,String username,String password,String Action,String DeleteAction,String UpdateAction) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");


			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Vendors"));
			logger.log(LogStatus.PASS,"Vendors link","Vendors link  is clicked ");  
			Thread.sleep(1000);


			//Selection any Action from the dropdown  
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
			}


			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomVendorName;
			RandomVendorName=RandomValue+"PO";

			//Enter a New Vendor Name
			assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomVendorName);
			logger.log(LogStatus.PASS,"New Vendor Name","New Vendor name is entered: "+RandomVendorName);

			//CLick on the Cancel button   
			Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
			logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked ");
			Thread.sleep(1000);

			//Verify that the main screen is displayed after clicking on the Cancel button,without saving the data
			Thread.sleep(1000);
			String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
			logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
			Thread.sleep(1000);


			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");

			//Click on the Vendor link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Vendors"));
			logger.log(LogStatus.PASS,"Vendors link","Vendors link  is clicked ");  
			Thread.sleep(1000);

			//Selection any Action from the dropdown 
		  
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
			}
			else
			{
				Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectAction.selectByVisibleText(Action);
			}



			//Enter a New Vendor Name
			assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomVendorName);
			logger.log(LogStatus.PASS,"New Vendor Name","New Vendor name is entered: "+RandomVendorName);


			//CLick on the save button   
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			Thread.sleep(2000);


			//Verify that the value is entered  
			String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();

			// String Div =quote(RandomDivisionName);
			String Concatenate= "Vendor "+"'"+RandomVendorName+"'"+ " has been added.";
			Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
			//objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
			Thread.sleep(1000);

			//Select Update action

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),UpdateAction);
			}
			else
			{
				Select SelectUpdateAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectUpdateAction.selectByVisibleText(UpdateAction);
			}


			//Verify that the New Vendor field is disabled
			Boolean verifyNewVendorField=assetTrackMaintainPage.txt_NewName(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Vendor text field","New Vendor text field is not enabled :"+verifyNewVendorField);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			Boolean verifyNewVendordropdown=assetTrackMaintainPage.drpdown_Vendor(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Vendor dropdown field","New Vendor dropdown field is  enabled :"+verifyNewVendordropdown);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			//Select the Vendor to be updated
			Thread.sleep(1000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomVendorName);
			}
			else
			{
				Select SelectDivision=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));
				SelectDivision.selectByVisibleText(RandomVendorName);
			}


			String RandomUpdatedVendorName;
			RandomUpdatedVendorName=RandomValue+"NEWD";
			//Enter the New name to be updated
			assetTrackMaintainPage.txt_NewName(wdriver).clear();
			assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomUpdatedVendorName);
			logger.log(LogStatus.PASS,"New Vendor Name","New Vendor name is entered: "+RandomUpdatedVendorName);

			//Click on Save button     
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));

			// adding this code again for workaround to do update function
			//Select the Vendor to be updated
			Thread.sleep(2000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomVendorName);
			}
			else
			{
				Select SelectDivision=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));
				//SelectDivision.selectByVisibleText(RandomVendorName);
			}
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			WebDriverWait wait = new WebDriverWait(wdriver,200);
			wait.until(ExpectedConditions.visibilityOf(assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomUpdatedVendorName)));
			String VerifyUpdatedMsg=assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomUpdatedVendorName).getText().trim();
			String VendorUpdated = "Vendor "+"'"+RandomUpdatedVendorName+"'"+ " has been updated.";
			Assert.assertEquals(VendorUpdated, VerifyUpdatedMsg);
			//objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomUpdatedVendorName));

			//Select Delete action
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),DeleteAction);
			}
			else
			{
				Select SelectDeleteAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectDeleteAction.selectByVisibleText(DeleteAction);
			}


			//Verify that the New Manufacturer field is disabled
			Boolean verifyNewVendorField1=assetTrackMaintainPage.txt_NewName(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Vendor field","New Vendor field is not enabled :"+verifyNewVendorField1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);    


			Boolean verifyNewVendordropdown1=assetTrackMaintainPage.drpdown_Vendor(wdriver).isEnabled();
			logger.log(LogStatus.PASS,"New Vendor field","New Vendor field is enabled :"+verifyNewVendordropdown1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);  

			//Select the Division to be deleted

			Thread.sleep(1000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomUpdatedVendorName);
			}
			else
			{
				Select SelectDeleteDivision=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));
				SelectDeleteDivision.selectByVisibleText(RandomUpdatedVendorName);
			}


			//Click on save button 
			Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");

			//Verify that the confirmation message is displayed

			WebDriverWait wait1 = new WebDriverWait(wdriver,100);
			wait1.until(ExpectedConditions.visibilityOf(assetTrackMaintainPage.msg_ConfirmationdDynamic_Add_Delete(wdriver,RandomUpdatedVendorName,"deleted")));
			String VerifyDeletedMsg=assetTrackMaintainPage.msg_ConfirmationdDynamic_Add_Delete(wdriver,RandomUpdatedVendorName,"deleted").getText().trim();
			String Vendordeleted = "Vendor "+"'"+RandomUpdatedVendorName+"'"+ " has been deleted.";
			Assert.assertEquals(Vendordeleted, VerifyDeletedMsg);
			//objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_ConfirmationdDynamic_Add_Delete(wdriver,RandomUpdatedVendorName,"deleted"));   
		}
		catch (Exception | AssertionError e) 
		{
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}


	//----------------------------------------------------------------------------------------------------------------------

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_Module_Vendors_Alternate_Flow(Method m,String username,String password,String Action,String UpdateAction) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);
			

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the Maintain link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Vendors"));
			logger.log(LogStatus.PASS,"Vendors link","Vendors link  is clicked ");  
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(1000);


			//Select the Add Divisions from the dropdown
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomVendorName,RandomVendorName1,RandomVendorName2;
			RandomVendorName1 = RandomValue+" VEN";
			RandomVendorName2=RandomValue+" SPACE"+" ";
			for(int i = 0;i<=2;i++)
			{
				Thread.sleep(5000);
				WebimplicitWait(wdriver);
				if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
				{
					dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
				}
				else
				{
					Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
					SelectAction.selectByVisibleText(Action);
				}

				if  (i==0 || i==2)
				{ 
					RandomVendorName=RandomVendorName1;
				}
				else 
				{
					RandomVendorName=RandomVendorName2;
				}
				assetTrackMaintainPage.txt_NewName(wdriver).clear();

				assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomVendorName);
				logger.log(LogStatus.PASS,"New Vendor Name","New Vendor name is entered: "+RandomVendorName);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);

				//Click on the Save button            
				Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
				logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				Thread.sleep(1000);

				//Verify that the confirmation message is displayed
				if  (i==0 || i==1)
				{         
					if  (i==0)
					{
						RandomVendorName=RandomVendorName1;
					}
					else 
					{
						RandomVendorName=RandomVendorName2;
						RandomVendorName=RandomVendorName2.trim();
					}
					//Thread.sleep(5000);
					WebDriverWait wait = new WebDriverWait(wdriver,100);
					
					//wait.until(ExpectedConditions.textToBePresentInElement(assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomVendorName), RandomVendorName));
					wait.until(ExpectedConditions.visibilityOf(assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomVendorName)));

					String VerifyAddedMsg=assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomVendorName).getText().trim();
					System.out.println(VerifyAddedMsg);
					
					String NewConcatenate= "Vendor "+"'"+RandomVendorName+"'"+ " has been added.";
					logger.log(LogStatus.PASS,"Vendor is added","Vendor is added: "+RandomVendorName);
					Assert.assertEquals(NewConcatenate, VerifyAddedMsg);
					objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				}
				else 
				{
					RandomVendorName=RandomVendorName1;
					String VerifyErrorMsg=assetTrackMaintainPage.msg_Error(wdriver).getText().trim();
					String Concatenate= "Vendor "+"\""+RandomVendorName+"\""+ " already exists.";
					Assert.assertEquals(Concatenate, VerifyErrorMsg);
					logger.log(LogStatus.PASS,"Vendor already exists Error","Vendor already exists: "+RandomVendorName);
					objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				}
			}  

			//Select Update from the updateAction dropdown 
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),UpdateAction);
			}
			else
			{
				Select SelectUpdateAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
				SelectUpdateAction.selectByVisibleText(UpdateAction);
			}


			//Select the Added Vendors

			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomVendorName1);
			}
			else
			{
				Select SelectVendor=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));
				SelectVendor.selectByVisibleText(RandomVendorName1);
			}


			logger.log(LogStatus.PASS,"Added value is saved in the database","Added value is saved in the database: "+RandomVendorName1);
			Thread.sleep(1000);


			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
			{
				RandomVendorName2=RandomVendorName2.trim();
				dropDownSelectJavaScript(assetTrackMaintainPage.drpdown_Vendor(wdriver),RandomVendorName2);
			}
			else
			{
				Select SelectVendor1=new Select(assetTrackMaintainPage.drpdown_Vendor(wdriver));
				RandomVendorName2=RandomVendorName2.trim();
				SelectVendor1.selectByVisibleText(RandomVendorName2);
				Thread.sleep(1000);
			}
			
			logger.log(LogStatus.PASS,"Added value is saved in the database","Added value is saved in the database: "+RandomVendorName2);
			Thread.sleep(1000);

		}
		catch (Exception | AssertionError e) 
		{
			System.out.println(e);
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}  


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Add_New_Vendor(Method m,String username,String password,String Action) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Maintain button in the Assets page
			Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");


			//Create a Division
			//Click on the Divsions link
			Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Vendors"));
			logger.log(LogStatus.PASS,"Vendors link","Vendors link  is clicked ");  
			Thread.sleep(1000);

			//Selection any Action from the dropdown   

			for(int i = 0;i<=1;i++)
			{
				if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
				{
					dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
				}
				else
				{
					Thread.sleep(3000);	
					Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
					SelectAction.selectByVisibleText(Action);
					WebimplicitWait(wdriver);
				}	
				//Select the Add Divisions from the dropdown
				int RandomValue;
				RandomValue=getRandomNumberInRange(1000,20000);
				String RandomVendorName;
				RandomVendorName=RandomValue+"PO";

				//Enter a New Vendor Name
				assetTrackMaintainPage.txt_NewName(wdriver).sendKeys(RandomVendorName);
				logger.log(LogStatus.PASS,"New Vendor Name","New Vendor name is entered: "+RandomVendorName);

				//CLick on the Cancel button  
				if (i==0)
				{
					Syn_Click(assetTrackMaintainPage.btn_SaveManufacturer(wdriver));
					logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
					Thread.sleep(1000);

					String VerifyAddedMsg=assetTrackMaintainPage. msg_ConfirmationdDynamic(wdriver,RandomVendorName).getText().trim();
					System.out.println(VerifyAddedMsg);
					String NewConcatenate= "Vendor "+"'"+RandomVendorName+"'"+ " has been added.";
					logger.log(LogStatus.PASS,"Vendor is added","Vendor is added: "+RandomVendorName);
					Assert.assertEquals(NewConcatenate, VerifyAddedMsg);
					objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				}
				else
				{
					Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
					logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked ");
					Thread.sleep(1000);

					//Verify that the main screen is displayed after clicking on the Cancel button,without saving the data
					Thread.sleep(1000);
					String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
					Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
					logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
					Thread.sleep(1000);
				}
			}

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}
}
