package com.nbcu.assetTracker.web.ShipMentModule;

import static org.testng.Assert.assertTrue;

import java.lang.reflect.Method;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_ShipmentsPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.nbcu.assetTracker.web.Web_AssetTracker_ShipmentModule;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class SearchShipment_Submodule extends Commonstudio
{
	PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    ExtentReports logger = ExtentReports.get(SearchShipment_Submodule.class);
    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
    AssetTrack_ShipmentsPage assetTrackShipmentsPge=new AssetTrack_ShipmentsPage();
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void ShipmentCase_Copy_PositiveFlow(Method m,String username,String password,String quantity,String trackingNo) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
        logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
        Thread.sleep(1000);
         
//Click on the Shipments tab
        Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
        logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
         
 //Click on the Search Shipment link
         Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
        logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
        
     
//Click on the Show Latest Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
        logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked "); 
        
 //Click on any record from the table      
        AssetTableDataSelect("11210",7,"click");
        
        
//Click on the Copy Shipment button for the selected record
        Syn_Click(assetTrackShipmentsPge.btn_CopyShipment(wdriver));
        logger.log(LogStatus.PASS,"Copy Shipment button ","Copy Shipment button is clicked "); 
        WebimplicitWait(wdriver);
    
        switchToWindow("Confirm");
 
//Save the Shipment Number selected for the Verification
        String VerifyCaseCopyMessage=assetTrackShipmentsPge. msg_CopyShipmentCase(wdriver).getText().trim();
        Assert.assertEquals("Would you like to copy the Cases as well?", VerifyCaseCopyMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+VerifyCaseCopyMessage);
               
//Verify Yes, No , Cancel button exists
        Boolean verifyYesButton=assetTrackShipmentsPge.btn_CopyShipmentCaseYes(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyYesButton);
        Boolean verifyNoButton=assetTrackShipmentsPge.btn_CopyShipmentCaseNo(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyNoButton);
        Boolean verifyCancelButton=assetTrackShipmentsPge.btn_CopyShipmentCaseCancel(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyCancelButton);
        
        
//Click on the Yes button in the Confirmation window
        Syn_Click(assetTrackShipmentsPge.btn_CopyShipmentCaseYes(wdriver));
        logger.log(LogStatus.PASS,"Yes button ","Yes button is clicked in the confirmation window"); 
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        
        WebimplicitWait(wdriver);
        switchToWindow("Asset Tracker v2.2.1");
        
  
//Click on the Finish Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShipmentFinish(wdriver));
        logger.log(LogStatus.PASS,"Finish button ","Finish button is clicked "); 
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
        explicitlywaitAlert_Web();
        String verifyAlertMessage= wdriver.switchTo().alert().getText();
        Assert.assertEquals("Clicking Finish updates the location of all the assets in this shipment.Are you sure you want to finish the shipment?", verifyAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);
    
//Click on the cancel button in the alert
       Alert alert= wdriver.switchTo().alert();
       alert.accept();
       
 //Click on Update Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
       logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked"); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
 //Click on Copy Case button
       Syn_Click(assetTrackShipmentsPge.btn_CopyCase(wdriver));
       logger.log(LogStatus.PASS,"Copy Case button ","Copy Case buttonn is clicked"); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
        explicitlywaitAlert_Web();
    	  
        String verifyCopyCaseAlertMessage= wdriver.switchTo().alert().getText();
        Assert.assertEquals("The changes made to the shipment will be saved", verifyAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyCopyCaseAlertMessage);
    	    
    	//Click on the cancel button in the alert
       Alert alert1= wdriver.switchTo().alert();
       alert1.accept();   
       
     //Entering a value greater than or equal to 99
       assetTrackShipmentsPge.txt_CopyQuantity(wdriver).sendKeys(quantity);
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
//Click on the Create button 
       Syn_Click(assetTrackShipmentsPge.btn_CopyCreate(wdriver));
       WebimplicitWait(wdriver);
       logger.log(LogStatus.PASS,"Create button","Create button is clicked ");
       
//Enter the tracking No       
       assetTrackShipmentsPge.txt_ShipmentTracking(wdriver).sendKeys(trackingNo);//1196076551
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
       
//Click on the Save  button 
       Syn_Click(assetTrackShipmentsPge.btn_SaveCopyShipment(wdriver));
       WebimplicitWait(wdriver);
       logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
       
       
 //Click on Finish in the Wayfill Manifest page
     //Click on the Finish Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_ShipmentFinish(wdriver));
       logger.log(LogStatus.PASS,"Finish button ","Finish button is clicked "); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);

      
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
        explicitlywaitAlert_Web();
    	  
        String verifyFinishAlert= wdriver.switchTo().alert().getText();
        Assert.assertEquals("Clicking Finish updates the location of all the assets in this shipment.Are you sure you want to finish the shipment?", verifyAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyFinishAlert);
    	    	    
 //Click on the ok button in the alert
       Alert alert2= wdriver.switchTo().alert();
       alert2.accept();   
        }       

//Verify that the Shipment is saved
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   


 @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Shipment_Module_Search_Shipment_Search_Tracking_no_Ipad(Method m,String username,String password,String TrackingNumber) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Shipments tab
         Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
         logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
         
 //Click on the Search Shipment link
         Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
        logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
        
//Click on the Show Latest Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
       logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked ");
       
 //Verify that the different buttons are present in the Show Shipments screen
       Boolean verifModifySearchbtn=assetTrackShipmentsPge.btn_ModifySearch(wdriver).isDisplayed();
		logger.log(LogStatus.PASS,"Modify Search button","Modify Search button is displayed :"+verifModifySearchbtn);
		
		Boolean verifyCancelButton=assetTrackShipmentsPge.btn_GlobalUpdate(wdriver).isDisplayed();
		logger.log(LogStatus.PASS,"Global Update button","Global Update button is displayed :"+verifyCancelButton);
		
		Boolean verifyNewHTSCodeField=assetTrackShipmentsPge.btn_SortResults(wdriver).isDisplayed();
		logger.log(LogStatus.PASS,"Sort Results","Sort Results button is displayed :"+verifyNewHTSCodeField);
		
		Boolean verifyChangeLayout=assetTrackShipmentsPge.btn_ChangeLayout(wdriver).isDisplayed();
		logger.log(LogStatus.PASS,"Change Layout button","Change Layout button is displayed :"+verifyChangeLayout);
    
//Click on View button 
		//Click on any record from the table      
       // AssetTableDataSelect("11296",7,"click");
		Syn_Click(assetTrackShipmentsPge.btn_View(wdriver));
        logger.log(LogStatus.PASS,"View button ","View button is clicked "); 
		
        
//Click on the Update Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
        logger.log(LogStatus.PASS,"Update Shipment Link ","Update Shipment is clicked "); 
        
        
        // while (true)
       // {
          //if (assetTrackShipmentsPge.btn_RemoveCase(wdriver).isDisplayed())
           // {
            //	Syn_Click(assetTrackShipmentsPge.btn_RemoveCase(wdriver));
            //	explicitlywaitAlert_Web();
            //    Alert alert= wdriver.switchTo().alert();
            //    alert.accept();	
            //} 
            //else
           // {
           // 	WebimplicitWait(wdriver); 
           // }
       // }
    
 //Click on the Add Case button
        Syn_Click(assetTrackShipmentsPge.btn_AddCase(wdriver));
        logger.log(LogStatus.PASS,"Add Case button ","Add Case button is clicked ");
       // objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackShipmentsPge.btn_AddCase(wdriver));
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        int RandomValue;
		RandomValue=getRandomNumberInRange(100,200);
		String RandomCaseNum;
		RandomCaseNum=RandomValue+"12";
		WebimplicitWait(wdriver); 
		Thread.sleep(2000);
		assetTrackShipmentsPge.txt_CaseNumber(wdriver).clear();
		assetTrackShipmentsPge.txt_CaseNumber(wdriver).sendKeys(RandomCaseNum);
         
 //Click on the Add Units button
         Syn_Click(assetTrackShipmentsPge.btn_AddUnits(wdriver));
         logger.log(LogStatus.PASS,"Add Units button ","Add Units button is clicked ");
         
//Enter the Tracking Number    
         assetTrackShipmentsPge.txt_AddCaseTrackingNum(wdriver).sendKeys(TrackingNumber);
 		logger.log(LogStatus.PASS,"Tracking Number ","Tracking Number is entered ");
 		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackShipmentsPge.txt_AddCaseTrackingNum(wdriver));

//Click on the Add Case button
        
        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
        logger.log(LogStatus.PASS,"Add Item button ","Add Item button is clicked ");
        
//Click on the Continue button
        Syn_Click(assetTrackShipmentsPge. btn_AddCaseContinue(wdriver));
        logger.log(LogStatus.PASS,"Continue button ","Continue button is clicked ");
 
//Click on the Save button
        Syn_Click(assetTrackShipmentsPge. btn_AddCaseSave(wdriver));
        logger.log(LogStatus.PASS,"Save button ","Save button is clicked ");
        
      //Expand the Case details
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
        Syn_Click(assetTrackShipmentsPge.btn_CaseDetailsExpand(wdriver,RandomCaseNum));
        logger.log(LogStatus.PASS,"Case Details Expand ","Case Details is Expanded ");       
        
  //Verify that the added asset details are present
        String verifyCaseDetails=assetTrackShipmentsPge.txt_CaseDetails(wdriver,TrackingNumber).getAttribute("innerText");        
		logger.log(LogStatus.PASS,"Tracking Details","Current Location field is displayed :"+verifyCaseDetails);
		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackShipmentsPge.txt_CaseDetails(wdriver,TrackingNumber));
		WebimplicitWait(wdriver); 
		Thread.sleep(3000);
		Syn_Click(assetTrackShipmentsPge.btn_RemoveCase(wdriver,RandomCaseNum));
        logger.log(LogStatus.PASS,"Remove Case button ","Remove Case button is clicked");  
        explicitlywaitAlert_Web();
        Alert alert= wdriver.switchTo().alert();
        alert.accept();
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
        
        }       

      //Verify that the Shipment is saved
        catch (Exception | AssertionError e) {
    		System.out.println(e);
    		//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
    		logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
    		TestReporter.logFailure("Error Message:"+e.getMessage());
    		objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
    	}
          }   
    


  @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void ShipmentCase_Delete_PositiveFlow(Method m,String username,String password) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Shipments tab
         Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
         logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
         
 //Click on the Search Shipment link
         Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
        logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
        
//Click on the Show Latest Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
       logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked ");      
        
//Click on the View button for any record
       Syn_Click(assetTrackShipmentsPge.btn_View(wdriver));
       logger.log(LogStatus.PASS,"View button ","View button is clicked "); 

//Save the Shipment Number selected for the Verification
       String VerifyShipping=assetTrackShipmentsPge.txt_Verify_ShipmentNo(wdriver).getText().trim();
       
//Click on the Delete Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_DeleteShipment(wdriver));
       logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked "); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
       explicitlywaitAlert_Web();
  
       String verifyAlertMessage= wdriver.switchTo().alert().getText();
       Assert.assertEquals("Are you sure  you want to Delete?", verifyAlertMessage);
       logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);
    
//Click on the cancel button in the alert
       
       Alert alert= wdriver.switchTo().alert();
       alert.dismiss();

 //Click on the Delete Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_DeleteShipment(wdriver));
       logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked"); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);

   //Click on the Ok button in the alert
       explicitlywaitAlert_Web();
       alert.accept();
       
       //Confirmation page is displayed
       String verifyConfirmationPage=assetTrackShipmentsPge.tit_Confirmation_Page(wdriver).getText();
       Assert.assertEquals("Confirmation", verifyConfirmationPage);
       logger.log(LogStatus.PASS,"Verification Successfull","Verified the Confirmation message : "+verifyConfirmationPage);
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
       
     //Verifying that the Confirmation message is displayed after deleting the Shipment
       String verifyConfirmationMessage=assetTrackShipmentsPge.msg_ConfirmDeleteShipment(wdriver).getText();
      Assert.assertEquals("Shipment has been deleted sucessfully.", verifyConfirmationMessage);
      logger.log(LogStatus.PASS,"Verification Successfull","Verified the Confirmation message : "+verifyConfirmationMessage);
      objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
       
//Click on the Search Shipment buton
      Syn_Click(assetTrackShipmentsPge.btn_SearchShipmentAction(wdriver));
      logger.log(LogStatus.PASS,"Search Shipment button","Search Shipment button is clicked ");
      
  
 //Enter the Deleted Shipment Id
     assetTrackShipmentsPge.txt_ShipmentId(wdriver).sendKeys(VerifyShipping);
     Syn_Click(assetTrackShipmentsPge.btn_SelectValues(wdriver,"searchShipmentID"));
     logger.log(LogStatus.PASS,"enter Shipment Id  ","Shipment Id is entered ");
     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
     
//Switch to the Tab Search window
    switchToWindow("Tab Search");
    WebimplicitWait(wdriver);
    String verifyError=assetTrackShipmentsPge.msg_NoMatches(wdriver).getText().trim();
    Assert.assertEquals("No matches Found", verifyError);
    logger.log(LogStatus.PASS,"Error message","Verified the Error message : "+verifyError);
        }       

//Verify that the Shipment is saved
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   


@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void ShipmentCase_Numbers(Method m,String username,String password,String PONumber) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Verify the 4 tabs are displayed

         Boolean AssetDisplay=assetTrackAssetsPge.btn_Assets(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+AssetDisplay);
         Boolean ShipmentDisplay=assetTrackAssetsPge.btn_Shipments(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Shipments Tab","Shipment Tab is displayed :"+ShipmentDisplay);
         Boolean MaintainDisplay=assetTrackAssetsPge.btn_Maintain(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is displayed :"+MaintainDisplay);
         Boolean NeedHelpDisplay=assetTrackAssetsPge.btn_NeedHelp(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Help Tab","Need Help Tab is displayed :"+NeedHelpDisplay);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
 //Click on Asset Module tab
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
 //Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
        logger.log(LogStatus.PASS,"Search Asset Link Tab","Enter Asset Link Tab is clicked ");
        
  
  //Verify that the Find Purchase order field is displayed      
        String verifyTitle=assetTrackAssetsPge.tit_FindPurchaseOrder(wdriver).getText();
        Assert.assertEquals("Find Purchase Order", verifyTitle);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyTitle);
        
        
  //Enter a valid PO Number
        assetTrackAssetsPge.txt_POnumber(wdriver).sendKeys(PONumber);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        
  //Click on the Find PO button
        Syn_Click(assetTrackAssetsPge.btn_FindPO(wdriver));
        logger.log(LogStatus.PASS,"Find PO button","Find PO button is clicked ");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
//Click on the View Fixed Assets button
        Syn_Click(assetTrackAssetsPge.lnk_ViewFixedAssets(wdriver));
        logger.log(LogStatus.PASS,"View Fixed Assets link","View Fixed Assets link is clicked ");
        
 //Select Tracking Number from the table       
        AssetTableDataSelect("WE0181133U",10,"click");
        
//Click on the View history button
        Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
        logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        String verifyAssetShippedMessage=assetTrackAssetsPge.txt_AssetShipped(wdriver).getText();
       // verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
        
        assertTrue(verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment"));
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAssetShippedMessage);
       
  
//Case to verify mm/dd/yyyy Time(hh:mm)- asset shipped as  Part of Shipment- <ID> Case Number-<No.>

        }
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   

    
@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
public void ShipmentModule_ViewAsset_Positive_Flow(Method m,String username,String password) throws Exception
{
    try
    {   
     
     logger.startTest(m.getName());
     System.out.println("method name"+(m.getName()));
     TestReporter.logStep("Start test execution of " + m.getName());
     TestReporter.logStep("Launch Asset Tracker ");
     
//Step1:Login to the Application
     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
     WebimplicitWait(wdriver);
     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
     Assert.assertEquals("Welcome, Tester1", verifyLogin);
     
//Verifying that the Login is successful
    
    logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
    Thread.sleep(1000);
     
//Click on the Shipments tab
    Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
    logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
     
//Click on the Search Shipment link
     Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
    logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
    
 
//Click on the Show Latest Shipment button
    Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
    logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked "); 
    Thread.sleep(3000);
    
    Boolean assetTable = wdriver.findElement(By.xpath("//table[@id='search']")).isDisplayed();
    logger.log(LogStatus.PASS,"Search Results page","Search Results page is displayed :"+assetTable);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.btn_ModifySearch(wdriver));
    logger.log(LogStatus.PASS,"Modify Search button ","Modify Search button is clicked "); 
    Thread.sleep(3000);
    String ShipmentNumber="11273";
    assetTrackShipmentsPge.txt_ShipmentId(wdriver).sendKeys(ShipmentNumber);
    Syn_Click(assetTrackShipmentsPge.SearchShipment_ShipmentNo_Selectvalues(wdriver));
    logger.log(LogStatus.PASS,"enter Shipment Id  ","Shipment Id is entered ");
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.SearchShipments_SearchforShipmentsButton(wdriver));
    logger.log(LogStatus.PASS,"Search for Shipments","Search for Shipments is clicked");
    Thread.sleep(3000);
    
    Boolean Page=assetTrackShipmentsPge.WayBill_ManifestDetailsPage(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"WayBill Manifest details","WayBill Manifest details are displayed :"+Page);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean updateShipment=assetTrackShipmentsPge.btn_UpdateShipment(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"update Shipment button","update Shipment button is displayed :"+updateShipment);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean delete=assetTrackShipmentsPge.btn_DeleteShipment(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Delete shipment button","Delete shipment button are displayed :"+delete);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean CopyShipment=assetTrackShipmentsPge.btn_CopyShipment(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"copy Shipment button","copy Shipment button is displayed :"+updateShipment);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean Exportmanifest=assetTrackShipmentsPge.bt_Exportmanifest(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Export Manifest button","Export Manifest button is displayed :"+Exportmanifest);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean Previous=assetTrackShipmentsPge.bt_Previous(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Previous button","Previous button is displayed :"+Previous);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    String actShipmentNumber=assetTrackShipmentsPge. WayBillPage_ShipmentNumber(wdriver).getText().trim();
    Assert.assertEquals(actShipmentNumber, ShipmentNumber);
    logger.log(LogStatus.PASS,"Verification Successfull","Verified the Shipment Number : "+actShipmentNumber);
    
    Syn_Click(assetTrackShipmentsPge.WayBillDetails_collapseButton(wdriver));
    logger.log(LogStatus.PASS,"collapse button","collapse button is clicked");
    Thread.sleep(1000);
    
    Boolean Expand=assetTrackShipmentsPge.WayBillDetails_ExpandButton(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"WayBill Manifest details","WayBill Manifest details are collapsed :"+Expand);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.WayBillDetails_ExpandButton(wdriver));
    logger.log(LogStatus.PASS,"WayBill Details collapse button","WayBill Details collapse button is clicked");
    Thread.sleep(1000);
    
    Boolean collapse=assetTrackShipmentsPge.WayBillDetails_collapseButton(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"WayBill Manifest details","WayBill Manifest details are displayed :"+collapse);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.CaseDetails_ExpandButton(wdriver));
    logger.log(LogStatus.PASS,"case Details Expand button","case Details Expand button is clicked");
    Thread.sleep(1000);
    
    Boolean Case2details=assetTrackShipmentsPge.CaseDetails_caseNumber2(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Case 2 details","Case 2 details are displayed :"+Case2details);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    String Casecontents=assetTrackShipmentsPge.Casedetails_CaseContents(wdriver).getText().trim();
   //need to check
    assertTrue(Casecontents.contains("**NOTICE** test hazmat asset"));
    logger.log(LogStatus.PASS,"Verification Successfull","Verified HAZMAT label is displayed as notice");
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.CaseDetails_CollapseButton(wdriver));
    logger.log(LogStatus.PASS,"Case Details collapse button","Case Details collapse button is clicked");
    Thread.sleep(1000);
    
    Boolean CaseExpand=assetTrackShipmentsPge.CaseDetails_ExpandButton(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Case 2 details","Case 2 details are collapsed :"+CaseExpand);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    
    Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
    logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
     
//Click on the Search Shipment link
     Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
    logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
    logger.log(LogStatus.PASS,"Update Shipment Link ","Update Shipment is clicked ");
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean Edit=assetTrackShipmentsPge.WayBillPage_EditAddress(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Shipment details screen","Shipment details screen is editable :"+Edit);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean addcase=assetTrackShipmentsPge.WayBillPage_AddCase(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"add case button","add case button is displayed :"+addcase);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean Finish=assetTrackShipmentsPge.WayBillPage_Finish(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Finish button","Finish button is displayed :"+Finish);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Boolean Save=assetTrackShipmentsPge.WayBillPage_Save(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Save button","Save button is displayed :"+Save);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.WayBillPage_AddCase(wdriver));
    logger.log(LogStatus.PASS,"Add Case","Add Case is clicked ");
    Thread.sleep(3000);
    
    Boolean CaseDetailsPage=assetTrackShipmentsPge.CaseDetailsScreen(wdriver).isDisplayed();
    logger.log(LogStatus.PASS,"Case Details Screen","Case Details Screen is displayed :"+CaseDetailsPage);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.CaseDetails_Cancelbutton(wdriver));
    logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked ");
    Thread.sleep(3000);
    
    Syn_Click(assetTrackShipmentsPge.WayBillPage_Save(wdriver));
    logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
    Thread.sleep(3000);
    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    
    Syn_Click(assetTrackShipmentsPge.WayBillPage_Finish(wdriver));
    logger.log(LogStatus.PASS,"Finish button","Finish button is clicked ");
    Thread.sleep(3000);
    
    Alert alert1= wdriver.switchTo().alert();
    alert1.accept();  
    
    String verifyAlertMessage= wdriver.switchTo().alert().getText();
    assertTrue(verifyAlertMessage.contains("Are you sure you want to finish the shipment?"));
    logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);

//Click on the cancel button in the alert
   Alert alert= wdriver.switchTo().alert();
   alert.accept();
   
   Boolean updateShipment1=assetTrackShipmentsPge.btn_UpdateShipment(wdriver).isDisplayed();
   logger.log(LogStatus.PASS,"update shipment details","shipment details are updated :"+updateShipment1);
   objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    }       

//Verify that the Shipment is saved
    catch (Exception | AssertionError e) {
     System.out.println(e);
     logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
    }
}   

 
    
    
	
}
