package com.nbcu.assetTracker.web;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.lang.reflect.Method;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Web_AssetTracker_AssetModule extends Commonstudio
{
    PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    ExtentReports logger = ExtentReports.get(Web_AssetTracker_AssetModule.class);
    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
    AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    //@Test(enabled = true)
    public void AlertMessageTruncated(Method m,String username,String password,String quantity,String quantity1,String trackingNo) throws Exception
    {
        try
        {   
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Assets button in the Assets page
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
//Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
        logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
         
//Perform a blank search of the Asset 
         Syn_Click(assetTrackAssetsPge.btn_SavedSearch(wdriver));
         logger.log(LogStatus.PASS,"Saved Search button","Saved Search button is clicked ");
         WebimplicitWait(wdriver);
         
         switchToWindow("viewSearchCriteriaListAction");
         Syn_Click(assetTrackAssetsPge.btn_SavedSearchOk(wdriver));
         
         explicitlywaitAlert_Web();
        String verifyAlertMessage= wdriver.switchTo().alert().getText();
        Assert.assertEquals("Please select one saved report.", verifyAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);
     
        }
        catch (Exception | AssertionError e) {
         System.out.println(e);
      
         
        }
    }   
    
    
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Asset_Module_Search_Asset_FANumber(Method m,String username,String password,String FixedAssetNumber) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verify that the login is successful
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Assets button in the Assets page
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
//Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub menus should get displayed 
         
         Boolean verifyEnterAssetTab=assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyEnterAssetTab);
         Boolean verifySearchAssetTab=assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Shipment Tab is displayed :"+verifySearchAssetTab);
         Boolean verifyScanInTab=assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Shipment Tab is displayed :"+verifyScanInTab);
         Boolean verifyScanOutTab=assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Shipment Tab is displayed :"+verifyScanOutTab);
         
 //Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
        logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
        
//Verify that the Scan out link is displayed     
        Boolean VerifyFixedAssetField=assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Assets Tab","Shipment Tab is displayed :"+VerifyFixedAssetField);   
        
//Entering the FA Number
        assetTrackAssetsPge.txt_FixedAssetNuumber(wdriver).sendKeys(FixedAssetNumber);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);       
        
 //Click on the Select Values button     
        Syn_Click(assetTrackAssetsPge.btn_SelectValues(wdriver,"fixedAssetNumber"));
        logger.log(LogStatus.PASS,"enter Shipment Id  ","Shipment Id is entered ");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 
//Click on the Search for Assets button
         Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
         logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
         WebimplicitWait(wdriver);
         
//Verify that the Asset Details screen is displayed
         String verifyTitle=assetTrackAssetsPge.lbl_AssetDetails(wdriver).getText().trim();
         Assert.assertEquals("Asset Details", verifyTitle);
         logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyTitle);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
//Verify that the Fixed Asset Field is displayed
         String verifyFieldAssetNo=assetTrackAssetsPge.txt_verify_FieldAsset(wdriver).getText().trim();
         Assert.assertEquals(FixedAssetNumber, verifyFieldAssetNo);
         logger.log(LogStatus.PASS,"Field Asset Number field"," Field Asset Number field is displayed with the entered Number: "+verifyFieldAssetNo);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
        }
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void FirstCostFieldValidation(Method m,String username,String password) throws Exception
    {
        try
        {   
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is successful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Assets button in the Assets page
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
 //Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
        logger.log(LogStatus.PASS,"Enter Asset Link Tab","Enter Asset Link Tab is clicked ");
         
//Perform a blank search of the Asset 
         Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
         logger.log(LogStatus.PASS,"Enter Without PO button","Enter Without PO button is clicked ");
         WebimplicitWait(wdriver);
         
 //verify that the Enter Details screen is displayed
         String verifyMessage=assetTrackAssetsPge.tit_AssetDetails(wdriver).getText();
         Assert.assertEquals("The Quantity of Copy Asset cannot be more than Twenty.", verifyMessage);
         logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyMessage);
         String tempFirstCostVal="1000000051545484";
         int tempFirstCostVal_Length=tempFirstCostVal.length();
         assetTrackAssetsPge.txt_FirstCost(wdriver).sendKeys(tempFirstCostVal);
         
         
//verify that the Max length to be entered in the First cost field is 16. 
         String verifyMaxlength=assetTrackAssetsPge.txt_FirstCost(wdriver).getAttribute("maxlength");
         Assert.assertEquals(tempFirstCostVal_Length, verifyMaxlength.toString());
         logger.log(LogStatus.PASS,"Verify Maximum Length"," Maximum Length of First Cost : "+verifyMaxlength);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
        }
        catch (Exception | AssertionError e) {
            System.out.println(e);
            //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
            logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
            TestReporter.logFailure("Error Message:"+e.getMessage());
            objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
        }
         
        }
     
    
 //Demo/////////////////////////////////////////////////////   
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void CopyAsset_WithoutPO_Web(Method m,String username,String password,String quantity,String quantity1,String trackingNo) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Assets button in the Assets page
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
 //Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
        logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
         
//Perform a blank search of the Asset 
         Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
         logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
         WebimplicitWait(wdriver);
         
         
//Code to select data from the table
         AssetTableDataSelect("10835T",10,"click");
        
//Click on the Copy Asset button
         Syn_Click(assetTrackAssetsPge.btn_CopyAsset(wdriver));
          logger.log(LogStatus.PASS,"Copy Asset button ","Copy Asset button is clicked");
         
//Entering a value greater than or equal to 99
         assetTrackAssetsPge.txt_CopyAsset(wdriver).sendKeys(quantity);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
//Click on the Create button 
         Syn_Click(assetTrackAssetsPge.btn_CreateAsset(wdriver));
         WebimplicitWait(wdriver);
         logger.log(LogStatus.PASS,"Create button","Create button is clicked ");
 
//Verifying that the error message is displayed on entering the value greater than 20
         String verifyMessage=assetTrackAssetsPge.msg_CopyAsset(wdriver).getText();
        Assert.assertEquals("The Quantity of Copy Asset cannot be more than Twenty.", verifyMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyMessage);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
//Enter the value again in the text box(Lesser than 20)
        assetTrackAssetsPge.txt_CopyAsset(wdriver).sendKeys(quantity1);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
     
//Click on the Create button 
        Syn_Click(assetTrackAssetsPge.btn_CreateAsset(wdriver));
        WebimplicitWait(wdriver);
        logger.log(LogStatus.PASS,"Create button","Create button is clicked ");
        
        
//Enter the Tracking Number
        int RandomValue;
        RandomValue=getRandomNumberInRange(1000,20000);
        String RandomValueTracking;
        RandomValueTracking=RandomValue+"T";
        assetTrackAssetsPge.txt_TrackingItemNo(wdriver).sendKeys(RandomValueTracking);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
      
//Click on the Save button 
        
      Syn_Click(assetTrackAssetsPge.btn_ItemSave(wdriver));
      logger.log(LogStatus.PASS,"Save button ","Save button is clicked ");
          
//Verify that the Confirmation Message for the Number of copied Assets is displayed
      String verifyConfirmationMsg=assetTrackAssetsPge.msg_SaveItemDetails(wdriver).getAttribute("outerText").trim();
      Assert.assertEquals(quantity1+ " copied asset has been added to the database.", verifyConfirmationMsg);
      logger.log(LogStatus.PASS,"Asset Added"," copied asset has been added to the database: "+verifyConfirmationMsg);
      objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
        
 //Verification
      //Click on the Assets button in the Assets page
        Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
        
//Click on the Search Asset link
       Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
       logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       Thread.sleep(20000);
       
       assetTrackAssetsPge.txt_trackingNo(wdriver).sendKeys(RandomValueTracking);
       Syn_Click(assetTrackAssetsPge.btn_SelectValues(wdriver,"trackingNumber"));
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
 //Click on Search for assets
       Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
       logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
       WebimplicitWait(wdriver);
       
       String verifyTrackingNo=assetTrackAssetsPge.txt_verify_trackingNo(wdriver).getText().trim();
       Assert.assertEquals(RandomValueTracking, verifyTrackingNo);
       logger.log(LogStatus.PASS,"Asset Copied"," copied asset has been added successfully to the database: "+verifyTrackingNo);
       objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_verify_trackingNo(wdriver));
       
       
        }
        catch (Exception | AssertionError e) {
            System.out.println(e);
            //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
            logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
            TestReporter.logFailure("Error Message:"+e.getMessage());
            objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
        }
    }   
    
    
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void CopyAsset_WithPO_Web(Method m,String username,String password,String quantity,String quantity1,String trackingNo,String SerialNumber) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Assets button in the Assets page
         
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
 //Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
        logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
         
//Enter a PO number 
        
        
        assetTrackAssetsPge.txt_POnumber(wdriver).sendKeys("3123456789");
        Syn_Click(assetTrackAssetsPge.btn_SelectValues(wdriver,"purchaseOrderNumber"));
         WebimplicitWait(wdriver);
         logger.log(LogStatus.PASS,"Set PO number","PO number is entered : 312456789");
         
         
        
         Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
         logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
         WebimplicitWait(wdriver);
         
         
         
          //Code to select the value from the table
         AssetTableDataSelect("1212",10,"click");
        
       //Click on the Copy Asset button
         Syn_Click(assetTrackAssetsPge.btn_CopyAsset(wdriver));
          logger.log(LogStatus.PASS,"Copy Asset button ","Copy Asset button is clicked");
         
//Entering a value greater than or equal to 99
         assetTrackAssetsPge.txt_CopyAsset(wdriver).sendKeys(quantity);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
//Click on the Create button 
         Syn_Click(assetTrackAssetsPge.btn_CreateAsset(wdriver));
      WebimplicitWait(wdriver);
       logger.log(LogStatus.PASS,"Create button","Create button is clicked ");
 
//Verifying that the error message is displayed on entering the value greater than 20
         String verifyMessage=assetTrackAssetsPge.msg_CopyAsset(wdriver).getText();
        Assert.assertEquals("The Quantity of Copy Asset cannot be more than Twenty.", verifyMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyMessage);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
//Enter the value again in the text box(Lesser than 20)
        assetTrackAssetsPge.txt_CopyAsset(wdriver).sendKeys(quantity1);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
     
//Click on the Create button 
        Syn_Click(assetTrackAssetsPge.btn_CreateAsset(wdriver));
        WebimplicitWait(wdriver);
        logger.log(LogStatus.PASS,"Create button","Create button is clicked ");
        
        
//Enter the Tracking Number
        
        int RandomValue;
        RandomValue=getRandomNumberInRange(1000,20000);
        String RandomValueTracking;
        RandomValueTracking=RandomValue+"T";
        assetTrackAssetsPge.txt_TrackingItemNo(wdriver).sendKeys(RandomValueTracking);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
      
//Click on the Save button 
      Syn_Click(assetTrackAssetsPge.btn_ItemSave(wdriver));
         logger.log(LogStatus.PASS,"Save button ","Save button is clicked ");
          
//Verify that the Confirmation Message for the Number of copied Assets is displayed
      String verifyConfirmationMsg=assetTrackAssetsPge.msg_SaveItemDetails(wdriver).getAttribute("outerText").trim();
        Assert.assertEquals("1 copied asset has been added to the database.", verifyConfirmationMsg);
        logger.log(LogStatus.PASS,"Asset Added"," copied asset has been added to the database: "+verifyConfirmationMsg);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
        
 //Verification
        
      //Click on the Assets button in the Assets page
        Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
        
//Click on the Search Asset link
        Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
       logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
        
       assetTrackAssetsPge.txt_trackingNo(wdriver).sendKeys(RandomValueTracking);
       Syn_Click(assetTrackAssetsPge.btn_SelectValues(wdriver,"trackingNumber"));
       
 //Click on Search for assets
       Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
       logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
       WebimplicitWait(wdriver);
       
       String verifyTrackingNo=assetTrackAssetsPge.txt_verify_trackingNo(wdriver).getText().trim();
       Assert.assertEquals(RandomValueTracking, verifyTrackingNo);
       logger.log(LogStatus.PASS,"Asset Copied"," copied asset has been added successfully to the database: "+verifyTrackingNo);
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
       
      // trackingNumber
       
        }
        catch (Exception | AssertionError e) {
            System.out.println(e);
            //logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
            logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
            TestReporter.logFailure("Error Message:"+e.getMessage());
            objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
        
        }
    }   
    

    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void UpdateAsset_NegetiveFlow(Method m,String username,String password) throws Exception
    {
    try
    {  

    logger.startTest(m.getName());
    System.out.println("method name"+(m.getName()));
    TestReporter.logStep("Start test execution of " + m.getName());
    TestReporter.logStep("Launch Asset Tracker ");

    assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
    WebimplicitWait(wdriver);
    String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
    Assert.assertEquals("Welcome, Tester1", verifyLogin);

    //Verifying that the Login is successful

    logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
    Thread.sleep(1000);

    //Click on the Assets button in the Assets page
            Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
            logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
           
    //Click on the Search Asset link
            Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
           logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
           objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
           Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
           logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
           WebimplicitWait(wdriver);
           Syn_Click(assetTrackAssetsPge.chkbox_selectAsset(wdriver));
           logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
           WebimplicitWait(wdriver);
           Syn_Click(assetTrackAssetsPge.btn_GlobalUpdate(wdriver));
           logger.log(LogStatus.PASS,"Global Update button","Global Update button is clicked ");
           WebimplicitWait(wdriver);
           
           Boolean assestDetailsPage=assetTrackAssetsPge.lbl_AssetDetails(wdriver).isDisplayed();
      logger.log(LogStatus.PASS,"Asset details page","Asset details page is displayed :"+assestDetailsPage);
      objCommStudio.getScreenshoteachStepWeb(wdriver, true);
     
     
      Boolean savebutton=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton);
     
      Boolean cancelbutton=assetTrackAssetsPge.btn_Cancel(wdriver).isDisplayed();
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton);
      //add scroll down
     
     
      /*Syn_Click(assetTrackAssetsPge.btn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set STATUS","Status is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      */
    /*  //set current location
      Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set current location","current location is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      
      //current sub location
      Syn_Click(assetTrackAssetsPge.btn_currentsublocation(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set current sub location","current sub location is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      
      //permanent location
      Syn_Click(assetTrackAssetsPge.btn_permanentlocation(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set permanent location","permanent location is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      
    //permanent sub location
      Syn_Click(assetTrackAssetsPge.btn_permanentsublocation(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set permanent location","permanent location is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      
      //set model
      Syn_Click(assetTrackAssetsPge.btn_model(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_statusSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set permanent location","permanent location is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      
      //enter invalid first cost
      assetTrackAssetsPge.txt_firstcost(wdriver).sendKeys("@");
      
      
*/      //click on save changes
      //enter invalid data for first cost
      assetTrackAssetsPge.txt_firstcost(wdriver).sendKeys("@");
      Boolean savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      Robot r = new  Robot();
    
      explicitlywaitAlert_Web();
      String verifyAlertMessage= wdriver.switchTo().alert().getText();
      wdriver.switchTo().alert().accept();
      logger.log(LogStatus.PASS,"alert accept should be clicked",verifyAlertMessage);
      String validationmessage = assetTrackAssetsPge.Lbl_FirstCostValidationMsg(wdriver).getText();
      Assert.assertEquals("First Cost is not a valid number.", validationmessage);
      
    /*  //enter valid data for first cost
      assetTrackAssetsPge.txt_firstcost(wdriver).sendKeys("11");
       savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
       r = new  Robot();
      r.keyPress(KeyEvent.VK_ENTER);
      r.keyRelease(KeyEvent.VK_ENTER);
      logger.log(LogStatus.PASS,"alert accept should be clicked","alert accept is clicked");

      */
      
   /*   //set country of origin
      Syn_Click(assetTrackAssetsPge.btn_countryOfOrigin(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      switchToWindow("Tab Search");
      WebimplicitWait(wdriver);
      Syn_Click(assetTrackAssetsPge.radiobtn_countryoforiginSelection(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"Set country of origin","country of origin is Set Successfully ");
      switchToWindow("Asset Tracker v2.2.1");
      */
    //enter invalid data for height
      assetTrackAssetsPge.txt_DimensionsHeight(wdriver).sendKeys("@");
      savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
 
      
      
      

      String validationmessageHeight = assetTrackAssetsPge.Lbl_DimensionHeightValidationMsg(wdriver).getText();
      Assert.assertEquals("Height is not a valid number.", validationmessage);
      
      
      //enter valid data for height
     /* assetTrackAssetsPge.txt_DimensionsHeight(wdriver).sendKeys("11");
      savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
       r = new  Robot();
      r.keyPress(KeyEvent.VK_ENTER);
      r.keyRelease(KeyEvent.VK_ENTER);
      logger.log(LogStatus.PASS,"alert accept should be clicked","alert accept is clicked");
      */
      
      
      assetTrackAssetsPge.txt_DimensionsWeight(wdriver).sendKeys("@");
      savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
       r = new  Robot();
      r.keyPress(KeyEvent.VK_ENTER);
      r.keyRelease(KeyEvent.VK_ENTER);
      logger.log(LogStatus.PASS,"alert accept should be clicked","alert accept is clicked");

      String validationmessageWeight = assetTrackAssetsPge.Lbl_DimensionWeightValidationMsg(wdriver).getText();
      Assert.assertEquals("Weight is not a valid number.", validationmessageWeight);
      
    /*  //enter valid data for weight
      assetTrackAssetsPge.txt_DimensionsWeight(wdriver).sendKeys("11");
      savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
       r = new  Robot();
      r.keyPress(KeyEvent.VK_ENTER);
      r.keyRelease(KeyEvent.VK_ENTER);
      logger.log(LogStatus.PASS,"alert accept should be clicked","alert accept is clicked");

      */
      
      //add code for comments
      
      
      savebutton1=assetTrackAssetsPge.btn_SaveChanges(wdriver).isDisplayed();
      Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      logger.log(LogStatus.PASS,"save button","save button is displayed :"+savebutton1);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
      WebimplicitWait(wdriver);
       r = new  Robot();
      r.keyPress(KeyEvent.VK_ENTER);
      r.keyRelease(KeyEvent.VK_ENTER);
      logger.log(LogStatus.PASS,"alert accept should be clicked","alert accept is clicked");
      
    }
    catch (Exception | AssertionError e) {
    System.out.println(e);
   
    logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
    TestReporter.logFailure("Error Message:"+e.getMessage());
    objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
    }
    }
    
    
    
    /////////19-11-2019------------////
    
    
    
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void Asset_Module_Insert_Asset_No_PO_SAP_SRM_Asset(Method m,String username,String password,String firstcost,String SerialNumber,String PickManufacturer,String PickType) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(10000);
         
//Click on the Assets button in the Assets page
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
//Click on the EnterAsset link	
         Syn_Click(assetTrackAssetsPge.btn_EnterAsset(wdriver));
		logger.log(LogStatus.PASS, "EnterAsset should be clicked", "EnterAsset is clicked");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);

//Verify that the Find Purchase Order screen is displayed	 
		String verifyFindPOTitle= assetTrackAssetsPge.tit_FindPurchaseOrder(wdriver).getText();
		Assert.assertEquals("Find Purchase Order", verifyFindPOTitle);
	    logger.log(LogStatus.PASS,"Find PO Number Title","Find PO Number Title is displayed : "+verifyFindPOTitle);	
		    
	//Click on Enter Without PO#
		 Syn_Click(assetTrackAssetsPge.btn_EnterWithoutPO(wdriver));
		 logger.log(LogStatus.PASS, "Enter Without PO# should be clicked", "Enter Without PO# is clicked");
		// objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 Thread.sleep(10000);
		 
//Click on the SAP radio button
		 Syn_Click(assetTrackAssetsPge.rdo_SAP(wdriver));
		 logger.log(LogStatus.PASS, "SAP/SRM radio button ", "SAP/SRM radio button is clicked");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 
 //Step6:Verify section on "Enter Asset" page for SAP/SRM selection.
		 //Verify that the Finace Details,PO Details, Asset details tabs are displayed
		 Boolean verifyAssetTab=assetTrackAssetsPge.lbl_AssetDetails(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyAssetTab);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.lbl_AssetDetails(wdriver));
         
         Boolean verifyPOTab=assetTrackAssetsPge.lbl_PurchaseOrderDetails(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Purchase Order Details","Purchase Order Details Tab :"+verifyPOTab);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.lbl_PurchaseOrderDetails(wdriver));
         
         Boolean verifyFinaceTab=assetTrackAssetsPge.lbl_FinanceDetailsr(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Finance Details Tab","Finance Details Tab is displayed :"+verifyFinaceTab);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.lbl_FinanceDetailsr(wdriver));
         
 //Verify the different fields under Purchase Details Tab
         //LeftPanel
         Boolean verifyPOfield=assetTrackAssetsPge.txt_POnumber(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Purchase Order field","Purchase Order field is displayed :"+verifyPOfield);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_POnumber(wdriver));
         
         Boolean verifyeBuyRequistion=assetTrackAssetsPge.txt_ebuyRequisition(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"EBuy Requisition field","EBuy Requisition field is displayed :"+verifyeBuyRequistion);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ebuyRequisition(wdriver));
         
         Boolean verifyCA_Account=assetTrackAssetsPge.txt_CA_Account(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"CA Number field","CA Number field is displayed :"+verifyCA_Account);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_CA_Account(wdriver));
         
         //Right Panel
         Boolean verifyVendorName=assetTrackAssetsPge.txt_VendorName(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Vendor Name field","Vendor Name fieldb is displayed :"+verifyVendorName);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_VendorName(wdriver));
         
         Boolean verifyProjectNumber=assetTrackAssetsPge.txt_ProjectNumber(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Project Number field","Project Number field is displayed :"+verifyProjectNumber);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ProjectNumber(wdriver));
         
         Boolean verifyFANumber=assetTrackAssetsPge.txt_FANumber(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Fixed Asset Number field","Fixed Asset Number field :"+verifyFANumber);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_FANumber(wdriver));
         
 //Verify different fields under Finance Details Tab
         Boolean verifyBusinessUnit=assetTrackAssetsPge.txt_CostObject(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Business Unit field","Business Unit field is displayed :"+verifyBusinessUnit);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_CostObject(wdriver));
         
         Boolean verifyDepartment=assetTrackAssetsPge.txt_GLAccount(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Department field","Department field is displayed :"+verifyDepartment);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_GLAccount(wdriver));
         
         Boolean verifyFirstCost=assetTrackAssetsPge.txt_ProfitCenter(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"First Cost field","First Cost field :"+verifyFirstCost);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ProfitCenter(wdriver));
      
         
         Boolean verifyWarrantyDetails=assetTrackAssetsPge.txt_WarrantyDetails(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Warranty Details field","Warranty Details is displayed :"+verifyWarrantyDetails);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_WarrantyDetails(wdriver));
         
     
         
         
//Verify different fields under Asset Details Tab 
         Boolean verifyTrackingItemNo=assetTrackAssetsPge.txt_TrackingItemNo(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Tracking Item No field","Tracking Item No field is displayed :"+verifyTrackingItemNo);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_TrackingItemNo(wdriver));
         
         Boolean verifyStatusName=assetTrackAssetsPge.txt_StatusName(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Status Name field","Status Name field is displayed :"+verifyStatusName);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_StatusName(wdriver));
         
         Boolean verifyDivisonName=assetTrackAssetsPge.txt_DivisonName(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Divison Name field","Divison Name field :"+verifyDivisonName);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_DivisonName(wdriver));
         
         Boolean verifyCountryOfOrigin=assetTrackAssetsPge.txt_CountryOfOrigin(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Country Of Origin field","Country Of Origin is displayed :"+verifyCountryOfOrigin);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_CountryOfOrigin(wdriver));
         
         Boolean verifyModelName=assetTrackAssetsPge.txt_ModelName(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Model Name field","Model Name is displayed :"+verifyModelName);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ModelName(wdriver));
         
         Boolean verifyCurrentSubLocation=assetTrackAssetsPge.txt_CurrentSubLocation(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Current Sub Location field","Current Sub Location field is displayed :"+verifyCurrentSubLocation);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_CurrentSubLocation(wdriver));
         
         Boolean verifyPermanentLocation=assetTrackAssetsPge.txt_PermanentLocation(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Permanent Location field","Permanent Location field is displayed :"+verifyPermanentLocation);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_PermanentLocation(wdriver));
         
  //Enter the valid input Serial# field in Asset Details.
         //ASR # 3746947 
         assetTrackAssetsPge.txt_SerialNumber(wdriver).sendKeys(SerialNumber);
         logger.log(LogStatus.PASS, "Enter the Serial Number", "Serial Number is entered");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 
//verify that the Max length to be entered in the Serial Number field is 40. 		 
         String tempSerialNumber="1000000051545484100000005154548412345678";
         int tempSerialNumber_Length=tempSerialNumber.length();
         assetTrackAssetsPge.txt_SerialNumber(wdriver).sendKeys(tempSerialNumber);
         assetTrackAssetsPge.txt_SerialNumber(wdriver).clear();
         String verifyMaxlength=assetTrackAssetsPge.txt_SerialNumber(wdriver).getAttribute("maxlength");
        // Assert.assertEquals(tempSerialNumber_Length, verifyMaxlength.toString());
         //logger.log(LogStatus.PASS,"Verify Maximum Length"," Maximum Length of Serial Number: "+verifyMaxlength);
         //objCommStudio.getScreenshoteachStepWeb(wdriver, true);     
         
// Verify specific fields for "SAP/SRM" functionality.
       //Verify different fields under Finance Details Tab
         Boolean verifyCostObject=assetTrackAssetsPge.txt_CostObject(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Cost Object field","Cost Object field is displayed :"+verifyCostObject);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_CostObject(wdriver));
         
         Boolean verifyGLAccount=assetTrackAssetsPge.txt_GLAccount(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"G/L Account Number field","G/L Account Number field is displayed :"+verifyGLAccount);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_GLAccount(wdriver));
         
         Boolean verifyProfitCenter=assetTrackAssetsPge.txt_ProfitCenter(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Profit Center field","Profit Center field :"+verifyProfitCenter);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ProfitCenter(wdriver));
         
 //Verify that the Previous and the Save button is displayed
         Boolean verifyPreviousButton=assetTrackAssetsPge.btn_Previous(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Previous Button","Previous Button is displayed :"+verifyPreviousButton);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.btn_Previous(wdriver));
         
         Boolean verifyAddAssetButton=assetTrackAssetsPge.btn_addAsset(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Add Asset Button","Add Asset Button is displayed :"+verifyAddAssetButton);
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.btn_addAsset(wdriver));
         
 //(//input[@value='Add New'])[2]
         Syn_Click(assetTrackAssetsPge.btn_AddNewModel(wdriver));
		 logger.log(LogStatus.PASS, "Add New Button", "Add New Button is clicked");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 Thread.sleep(10000);
		 switchToWindow("Add a New Model");
		 Thread.sleep(10000);
		 int RandomValue;
         RandomValue=getRandomNumberInRange(1000,20000);
         String RandomModelName;
         RandomModelName=RandomValue+"M";
                 
        String verifyPickManufactureChecked =assetTrackAssetsPge.rdo_PickUpManufacturer(wdriver).getAttribute("checked");
         logger.log(LogStatus.PASS,"PickUp Manufacturer radio button","PickUp Manufacturer radio button is checked :"+verifyPickManufactureChecked);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         String verifyPickUpType=assetTrackAssetsPge.rdo_PickUpType(wdriver).getAttribute("checked");
         logger.log(LogStatus.PASS,"PickUp Type radio button","PickUp Type radio button is checked :"+verifyPickUpType);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         String verifyNewManufacturerDisabled=assetTrackAssetsPge.txt_ModelManufacturer(wdriver).getAttribute("disabled");
         logger.log(LogStatus.PASS,"New Manufacturer field","Manufacturer field is disabled:"+verifyNewManufacturerDisabled);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         String verifyNewTypeDisabled=assetTrackAssetsPge.txt_ModelNewType(wdriver).getAttribute("disabled");
         logger.log(LogStatus.PASS,"Manufacturer field","Manufacturer field is disabled:"+verifyNewTypeDisabled);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         
       //font[@class='message'][text()='Manufacturer must be specified.']
         assetTrackMaintainPage.txt_NewModelName(wdriver).sendKeys(RandomModelName);
         logger.log(LogStatus.PASS,"Enter the Model Name ","Model Name is entered ");
         objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.txt_NewModelName(wdriver));
    
         //Click on Save button
         Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
		 logger.log(LogStatus.PASS, "Save Button", "Save Button is clicked");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	
  
     
		 WebimplicitWait(wdriver);
		 Thread.sleep(20000);
         assetTrackMaintainPage.txt_PickUpManufacturer(wdriver).sendKeys(PickManufacturer);
         Syn_Click(assetTrackMaintainPage.btn_SelectfromNewWindow(wdriver,"Pick Manufacturer"));
         logger.log(LogStatus.PASS,"Pick up type","Pick up type is selected ");
         
         String verifyNewManufacturerEnabled=assetTrackAssetsPge.txt_ModelManufacturer(wdriver).getAttribute("enabled");
         logger.log(LogStatus.PASS,"New Manufacturer field","Manufacturer field is disabled:"+verifyNewManufacturerEnabled);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         assetTrackMaintainPage.txt_PickType(wdriver).sendKeys(PickType);
         WebimplicitWait(wdriver);
         WebimplicitWait(wdriver);
         Thread.sleep(20000);
 //Select the Pick Up Type       
         Syn_Click(assetTrackMaintainPage.btn_SelectPickType(wdriver));
         logger.log(LogStatus.PASS,"Enter the Pick Type ","Pick Type is entered ");
 
//Select the Model Weight
         assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys("NA");
         logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
         
 //Select the Model Length   
         assetTrackAssetsPge.txt_Modellength(wdriver).sendKeys("12");
         logger.log(LogStatus.PASS,"Enter the Model length ","Model length is entered ");

 //Click on Save button
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
     	WebDriverWait wait = new WebDriverWait(wdriver,100);
		
		wait.until(ExpectedConditions.visibilityOf(assetTrackAssetsPge.msg_Error_Dynamic(wdriver,"Weight is not a valid number.")));
		String verifyMessage=assetTrackAssetsPge.msg_Error_Dynamic(wdriver,"Weight is not a valid number.").getText().trim();
         Assert.assertEquals("Weight is not a valid number.", verifyMessage);
         logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyMessage);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
         assetTrackMaintainPage.txt_ModelWeight(wdriver).clear();
         assetTrackMaintainPage.txt_ModelWeight(wdriver).sendKeys("12");
         logger.log(LogStatus.PASS,"Enter the Model Weight ","Model Weight is entered ");
         
         Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
         logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
         objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
         
         Thread.sleep(10000);
         switchToWindow("Asset Tracker v2.2.1");
		 Thread.sleep(20000);
         
//Entering mandatory fields for creating Asset
		
	//Selecting vendor value
		 
		 
	
		 JavascriptExecutor jse = (JavascriptExecutor)wdriver;
		 jse.executeScript("arguments[0].value='291 DIGITAL LLC';", assetTrackAssetsPge.txt_VendorName(wdriver));

		// assetTrackAssetsPge.txt_VendorName(wdriver).sendKeys("291 DIGITAL LLC");
		 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Vendor"));
		Thread.sleep(5000);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 
		 
	//	 assetTrackAssetsPge.txt_FirstCost(wdriver).sendKeys(tempSerialNumber);
		 JavascriptExecutor jsee = (JavascriptExecutor)wdriver;
		 jsee.executeScript("arguments[0].value='1000';", assetTrackAssetsPge.txt_FirstCost(wdriver));
		 logger.log(LogStatus.PASS, "First cost should be entered", "First cost is entered");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 
		int RandomValue1;
		RandomValue1=getRandomNumberInRange(1000,20000);
        String RandomValueTracking;
        RandomValueTracking=RandomValue1+"T";
        assetTrackAssetsPge.trackingno(wdriver).sendKeys(RandomValueTracking);

	
	//selecting cost object
		 Syn_Clickupd((assetTrackAssetsPge.costObject(wdriver)),wdriver);
		Thread.sleep(5000);
		logger.log(LogStatus.PASS, "Costobject should be entered", "Costobject is entered");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	//selecting model
		 Syn_Clickupd((assetTrackAssetsPge.model(wdriver)),wdriver);
		 Thread.sleep(25000);
		switchToWindowupd("Tab Search",wdriver);
		Syn_Clickupd((assetTrackAssetsPge.selValueWindow(wdriver)),wdriver);	

		logger.log(LogStatus.PASS, "Model should be selected", "Model is selected");
		switchToWindowupd("Asset Tracker v2.2.1",wdriver);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 
	
//selecting status
		 
		 JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
		 jse1.executeScript("arguments[0].value='WARRANTY REPLACEMENT';", assetTrackAssetsPge.txt_StatusName(wdriver));
		 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Status"));
		Thread.sleep(5000);
		logger.log(LogStatus.PASS, "Status should be selected", "Status is selected");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);

//selecting country of origin
		 
		 JavascriptExecutor jse2 = (JavascriptExecutor)wdriver;
		 jse2.executeScript("arguments[0].value='ARUBA';", assetTrackAssetsPge.txt_CountryOfOrigin(wdriver));
		 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Country of Origin"));
		Thread.sleep(5000);
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		logger.log(LogStatus.PASS, "Country of origin should be selected", "country of origin is selected");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	
	//selecting current-sub-location
		 Thread.sleep(25000);
		 JavascriptExecutor jse3 = (JavascriptExecutor)wdriver;
		 jse3.executeScript("arguments[0].value='1A RK 34';", assetTrackAssetsPge.txt_CurrentSubLocation(wdriver));
		 Syn_Click(assetTrackAssetsPge.btn_SelectfromNewWindow(wdriver," Current Sub-Location"));
		Thread.sleep(5000);
		logger.log(LogStatus.PASS, "Current sublocation should be selected", "current sub location is selected");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		

//Click on Add Asset
		 Thread.sleep(15000);
		 Syn_Click(assetTrackAssetsPge.btn_addAsset(wdriver));
		Thread.sleep(5000);
		
		assetTrackAssetsPge.confirmation(wdriver).isDisplayed();
		logger.log(LogStatus.PASS, "Asset added confirmation should be displayed", "Asset added confirmation is displayed");
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
  	}
        catch (Exception | AssertionError e) {
            System.out.println(e);
            logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
            TestReporter.logFailure("Error Message:"+e.getMessage());
            objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
        
        }
    }   

}

    
    