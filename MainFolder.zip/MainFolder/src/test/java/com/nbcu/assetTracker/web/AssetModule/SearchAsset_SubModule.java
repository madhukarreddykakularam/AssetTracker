package com.nbcu.assetTracker.web.AssetModule;

import static org.testng.Assert.assertTrue;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_ShipmentsPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.webdriven.commands.SelectWindow;

public class SearchAsset_SubModule extends Commonstudio
{

	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(SearchAsset_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_ShipmentsPage assetTrackShipmentsPge=new AssetTrack_ShipmentsPage();

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void ShipmentCase_Copy_PositiveFlow(Method m,String username,String password,String quantity,String trackingNo) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Shipments tab
			Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
			logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");

			//Click on the Search Shipment link
			Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
			logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");


			//Click on the Show Latest Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
			logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked "); 

			//Click on any record from the table      
			AssetTableDataSelect("11210",7,"click");


			//Click on the Copy Shipment button for the selected record
			Syn_Click(assetTrackShipmentsPge.btn_CopyShipment(wdriver));
			logger.log(LogStatus.PASS,"Copy Shipment button ","Copy Shipment button is clicked "); 
			WebimplicitWait(wdriver);

			switchToWindow("Confirm");

			//Save the Shipment Number selected for the Verification
			String VerifyCaseCopyMessage=assetTrackShipmentsPge. msg_CopyShipmentCase(wdriver).getText().trim();
			Assert.assertEquals("Would you like to copy the Cases as well?", VerifyCaseCopyMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+VerifyCaseCopyMessage);

			//Verify Yes, No , Cancel button exists
			Boolean verifyYesButton=assetTrackShipmentsPge.btn_CopyShipmentCaseYes(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyYesButton);
			Boolean verifyNoButton=assetTrackShipmentsPge.btn_CopyShipmentCaseNo(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyNoButton);
			Boolean verifyCancelButton=assetTrackShipmentsPge.btn_CopyShipmentCaseCancel(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifyCancelButton);


			//Click on the Yes button in the Confirmation window
			Syn_Click(assetTrackShipmentsPge.btn_CopyShipmentCaseYes(wdriver));
			logger.log(LogStatus.PASS,"Yes button ","Yes button is clicked in the confirmation window"); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			WebimplicitWait(wdriver);
			switchToWindow("Asset Tracker v2.2.1");


			//Click on the Finish Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_ShipmentFinish(wdriver));
			logger.log(LogStatus.PASS,"Finish button ","Finish button is clicked "); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
			explicitlywaitAlert_Web();

			String verifyAlertMessage= wdriver.switchTo().alert().getText();
			Assert.assertEquals("Clicking Finish updates the location of all the assets in this shipment.Are you sure you want to finish the shipment?", verifyAlertMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);

			//Click on the cancel button in the alert
			Alert alert= wdriver.switchTo().alert();
			alert.accept();

			//Click on Update Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
			logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked"); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on Copy Case button
			Syn_Click(assetTrackShipmentsPge.btn_CopyCase(wdriver));
			logger.log(LogStatus.PASS,"Copy Case button ","Copy Case buttonn is clicked"); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
			explicitlywaitAlert_Web();

			String verifyCopyCaseAlertMessage= wdriver.switchTo().alert().getText();
			Assert.assertEquals("The changes made to the shipment will be saved", verifyAlertMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyCopyCaseAlertMessage);

			//Click on the cancel button in the alert
			Alert alert1= wdriver.switchTo().alert();
			alert1.accept();   

			//Entering a value greater than or equal to 99
			assetTrackShipmentsPge.txt_CopyQuantity(wdriver).sendKeys(quantity);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the Create button 
			Syn_Click(assetTrackShipmentsPge.btn_CopyCreate(wdriver));
			WebimplicitWait(wdriver);
			logger.log(LogStatus.PASS,"Create button","Create button is clicked ");

			//Enter the tracking No       
			assetTrackShipmentsPge.txt_ShipmentTracking(wdriver).sendKeys(trackingNo);//1196076551
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Click on the Save  button 
			Syn_Click(assetTrackShipmentsPge.btn_SaveCopyShipment(wdriver));
			WebimplicitWait(wdriver);
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");


			//Click on Finish in the Wayfill Manifest page
			//Click on the Finish Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_ShipmentFinish(wdriver));
			logger.log(LogStatus.PASS,"Finish button ","Finish button is clicked "); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
			explicitlywaitAlert_Web();

			String verifyFinishAlert= wdriver.switchTo().alert().getText();
			Assert.assertEquals("Clicking Finish updates the location of all the assets in this shipment.Are you sure you want to finish the shipment?", verifyAlertMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyFinishAlert);

			//Click on the ok button in the alert
			Alert alert2= wdriver.switchTo().alert();
			alert2.accept();   
		}       

		//Verify that the Shipment is saved
		catch (Exception | AssertionError e) {
			System.out.println(e);
			logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
		}
	}   


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Shipment_Module_Search_Shipment_Search_Tracking_no_Ipad(Method m,String username,String password,String TrackingNumber) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Shipments tab
			Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
			logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");

			//Click on the Search Shipment link
			Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
			logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");

			//Click on the Show Latest Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
			logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked ");

			//Verify that the different buttons are present in the Show Shipments screen
			Boolean verifModifySearchbtn=assetTrackShipmentsPge.btn_ModifySearch(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Modify Search button","Modify Search button is displayed :"+verifModifySearchbtn);

			Boolean verifyCancelButton=assetTrackShipmentsPge.btn_GlobalUpdate(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Global Update button","Global Update button is displayed :"+verifyCancelButton);

			Boolean verifyNewHTSCodeField=assetTrackShipmentsPge.btn_SortResults(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Sort Results","Sort Results button is displayed :"+verifyNewHTSCodeField);

			Boolean verifyChangeLayout=assetTrackShipmentsPge.btn_ChangeLayout(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Change Layout button","Change Layout button is displayed :"+verifyChangeLayout);

			//Click on View button 
			//Click on any record from the table      
			// AssetTableDataSelect("11296",7,"click");
			Syn_Click(assetTrackShipmentsPge.btn_View(wdriver));
			logger.log(LogStatus.PASS,"View button ","View button is clicked "); 


			//Click on the Update Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
			logger.log(LogStatus.PASS,"Update Shipment Link ","Update Shipment is clicked "); 


			// while (true)
			// {
			//if (assetTrackShipmentsPge.btn_RemoveCase(wdriver).isDisplayed())
			// {
			//	Syn_Click(assetTrackShipmentsPge.btn_RemoveCase(wdriver));
			//	explicitlywaitAlert_Web();
			//    Alert alert= wdriver.switchTo().alert();
			//    alert.accept();	
			//} 
			//else
			// {
			// 	WebimplicitWait(wdriver); 
			// }
			// }

			//Click on the Add Case button
			Syn_Click(assetTrackShipmentsPge.btn_AddCase(wdriver));
			logger.log(LogStatus.PASS,"Add Case button ","Add Case button is clicked ");
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackShipmentsPge.btn_AddCase(wdriver));
			int RandomValue;
			RandomValue=getRandomNumberInRange(100,200);
			String RandomCaseNum;
			RandomCaseNum=RandomValue+"12";
			WebimplicitWait(wdriver); 
			Thread.sleep(2000);
			assetTrackShipmentsPge.txt_CaseNumber(wdriver).clear();
			assetTrackShipmentsPge.txt_CaseNumber(wdriver).sendKeys(RandomCaseNum);

			//Click on the Add Units button
			Syn_Click(assetTrackShipmentsPge.btn_AddUnits(wdriver));
			logger.log(LogStatus.PASS,"Add Units button ","Add Units button is clicked ");

			//Enter the Tracking Number    
			assetTrackShipmentsPge.txt_AddCaseTrackingNum(wdriver).sendKeys(TrackingNumber);
			logger.log(LogStatus.PASS,"Tracking Number ","Tracking Number is entered ");
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackShipmentsPge.txt_AddCaseTrackingNum(wdriver));

			//Click on the Add Case button

			Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
			logger.log(LogStatus.PASS,"Add Item button ","Add Item button is clicked ");

			//Click on the Continue button
			Syn_Click(assetTrackShipmentsPge. btn_AddCaseContinue(wdriver));
			logger.log(LogStatus.PASS,"Continue button ","Continue button is clicked ");

			//Click on the Save button
			Syn_Click(assetTrackShipmentsPge. btn_AddCaseSave(wdriver));
			logger.log(LogStatus.PASS,"Save button ","Save button is clicked ");

			//Expand the Case details
			WebimplicitWait(wdriver); 
			Thread.sleep(3000);
			Syn_Click(assetTrackShipmentsPge.btn_CaseDetailsExpand(wdriver,RandomCaseNum));
			logger.log(LogStatus.PASS,"Case Details Expand ","Case Details is Expanded ");       

			//Verify that the added asset details are present
			String verifyCaseDetails=assetTrackShipmentsPge.txt_CaseDetails(wdriver,TrackingNumber).getAttribute("innerText");        
			logger.log(LogStatus.PASS,"Tracking Details","Current Location field is displayed :"+verifyCaseDetails);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackShipmentsPge.txt_CaseDetails(wdriver,TrackingNumber));
			WebimplicitWait(wdriver); 
			Thread.sleep(3000);
			Syn_Click(assetTrackShipmentsPge.btn_RemoveCase(wdriver,RandomCaseNum));
			logger.log(LogStatus.PASS,"Remove Case button ","Remove Case button is clicked");  
			explicitlywaitAlert_Web();
			Alert alert= wdriver.switchTo().alert();
			alert.accept();
			WebimplicitWait(wdriver); 
			Thread.sleep(3000);

		}       

		//Verify that the Shipment is saved
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}   



	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void ShipmentCase_Delete_PositiveFlow(Method m,String username,String password) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Click on the Shipments tab
			Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
			logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");

			//Click on the Search Shipment link
			Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
			logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");

			//Click on the Show Latest Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
			logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked ");      

			//Click on the View button for any record
			Syn_Click(assetTrackShipmentsPge.btn_View(wdriver));
			logger.log(LogStatus.PASS,"View button ","View button is clicked "); 

			//Save the Shipment Number selected for the Verification
			String VerifyShipping=assetTrackShipmentsPge.txt_Verify_ShipmentNo(wdriver).getText().trim();

			//Click on the Delete Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_DeleteShipment(wdriver));
			logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked "); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
			explicitlywaitAlert_Web();

			String verifyAlertMessage= wdriver.switchTo().alert().getText();
			Assert.assertEquals("Are you sure  you want to Delete?", verifyAlertMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);

			//Click on the cancel button in the alert

			Alert alert= wdriver.switchTo().alert();
			alert.dismiss();

			//Click on the Delete Shipment button
			Syn_Click(assetTrackShipmentsPge.btn_DeleteShipment(wdriver));
			logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked"); 
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the Ok button in the alert
			explicitlywaitAlert_Web();
			alert.accept();

			//Confirmation page is displayed
			String verifyConfirmationPage=assetTrackShipmentsPge.tit_Confirmation_Page(wdriver).getText();
			Assert.assertEquals("Confirmation", verifyConfirmationPage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the Confirmation message : "+verifyConfirmationPage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Verifying that the Confirmation message is displayed after deleting the Shipment
			String verifyConfirmationMessage=assetTrackShipmentsPge.msg_ConfirmDeleteShipment(wdriver).getText();
			Assert.assertEquals("Shipment has been deleted sucessfully.", verifyConfirmationMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the Confirmation message : "+verifyConfirmationMessage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Click on the Search Shipment buton
			Syn_Click(assetTrackShipmentsPge.btn_SearchShipmentAction(wdriver));
			logger.log(LogStatus.PASS,"Search Shipment button","Search Shipment button is clicked ");


			//Enter the Deleted Shipment Id
			assetTrackShipmentsPge.txt_ShipmentId(wdriver).sendKeys(VerifyShipping);
			Syn_Click(assetTrackShipmentsPge.btn_SelectValues(wdriver,"searchShipmentID"));
			logger.log(LogStatus.PASS,"enter Shipment Id  ","Shipment Id is entered ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Switch to the Tab Search window
			switchToWindow("Tab Search");
			WebimplicitWait(wdriver);
			String verifyError=assetTrackShipmentsPge.msg_NoMatches(wdriver).getText().trim();
			Assert.assertEquals("No matches Found", verifyError);
			logger.log(LogStatus.PASS,"Error message","Verified the Error message : "+verifyError);
		}       

		//Verify that the Shipment is saved
		catch (Exception | AssertionError e) {
			System.out.println(e);
			logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
		}
	}   


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void ShipmentCase_Numbers(Method m,String username,String password,String PONumber) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			//Verify the 4 tabs are displayed

			Boolean AssetDisplay=assetTrackAssetsPge.btn_Assets(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+AssetDisplay);
			Boolean ShipmentDisplay=assetTrackAssetsPge.btn_Shipments(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Shipments Tab","Shipment Tab is displayed :"+ShipmentDisplay);
			Boolean MaintainDisplay=assetTrackAssetsPge.btn_Maintain(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is displayed :"+MaintainDisplay);
			Boolean NeedHelpDisplay=assetTrackAssetsPge.btn_NeedHelp(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Help Tab","Need Help Tab is displayed :"+NeedHelpDisplay);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on Asset Module tab
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

			//Click on the Search Asset link
			Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Enter Asset Link Tab is clicked ");


			//Verify that the Find Purchase order field is displayed      
			String verifyTitle=assetTrackAssetsPge.tit_FindPurchaseOrder(wdriver).getText();
			Assert.assertEquals("Find Purchase Order", verifyTitle);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyTitle);


			//Enter a valid PO Number
			assetTrackAssetsPge.txt_POnumber(wdriver).sendKeys(PONumber);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Click on the Find PO button
			Syn_Click(assetTrackAssetsPge.btn_FindPO(wdriver));
			logger.log(LogStatus.PASS,"Find PO button","Find PO button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the View Fixed Assets button
			Syn_Click(assetTrackAssetsPge.lnk_ViewFixedAssets(wdriver));
			logger.log(LogStatus.PASS,"View Fixed Assets link","View Fixed Assets link is clicked ");

			//Select Tracking Number from the table       
			AssetTableDataSelect("WE0181133U",10,"click");

			//Click on the View history button
			Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
			logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			String verifyAssetShippedMessage=assetTrackAssetsPge.txt_AssetShipped(wdriver).getText();
			// verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
			assertTrue(verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment"));
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAssetShippedMessage);


			//Case to verify mm/dd/yyyy Time(hh:mm)- asset shipped as  Part of Shipment- <ID> Case Number-<No.>

		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
		}
	}   

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Perform_Asset_Global_Update_for_Existing_Assets_in_the_system(Method m,String username,String password) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);


			//Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

			//Click on the Search Asset link
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Perform a blank search of the Asset 
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			//Check on the first checkbox in the Search Assets page 
			Syn_Click(assetTrackAssetsPge.chk_Asset1(wdriver));
			logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Click on the Global Update button
			Syn_Click(assetTrackAssetsPge.btn_GlobalUpdate(wdriver));
			logger.log(LogStatus.PASS,"Global Update button","Global Update button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Without entering any values click on the Save button
			Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
			logger.log(LogStatus.PASS,"Save Changes button","Save Changes button is clicked ");
			WebimplicitWait(wdriver);

			explicitlywaitAlert_Web(); 
			String verifyAlertMessage= wdriver.switchTo().alert().getText();
			Assert.assertEquals("Please enter at least one field.", verifyAlertMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);

			//Click OK on the Alert message     
			Alert alert= wdriver.switchTo().alert();
			alert.accept();   

			//Enter any value in any of the field  
			int RandomValue;
			RandomValue=getRandomNumberInRange(1000,20000);
			String RandomUpdatedValue;
			RandomUpdatedValue=RandomValue+"PO";
			assetTrackAssetsPge.txt_ServiceTag(wdriver).sendKeys(RandomUpdatedValue);
			logger.log(LogStatus.PASS,"Service Tag value","Service Tag value is Entered : "+RandomUpdatedValue);


			//Click on the Save Changes button
			Syn_Click(assetTrackAssetsPge.btn_SaveChanges(wdriver));
			logger.log(LogStatus.PASS,"Save Changes button","Save Changes button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);	

			//Verify the Confirmation message in the Alert	    
			explicitlywaitAlert_Web(); 
			String verifyConfirmationMessage= wdriver.switchTo().alert().getText();
			Assert.assertEquals("Are you sure you want to update this Asset?", verifyConfirmationMessage);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyConfirmationMessage);

			//Click OK on the Alert message     
			Alert alert1= wdriver.switchTo().alert();
			alert1.accept(); 

			//Verify that the Confirmation page is displayed
			String verifyConfirmationTitle= assetTrackAssetsPge.tit_Confirmation_Page(wdriver).getText();
			Assert.assertEquals("Confirmation", verifyConfirmationTitle);
			logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyConfirmationTitle);

			//Validation step to traverse till View History button
			//Click on the Back to Search Results button
			Syn_Click(assetTrackAssetsPge.btn_BackToSearchResults(wdriver));
			logger.log(LogStatus.PASS,"Back to Search Results button","Back to Search Results button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);	

			//Click on View Asset    
			Syn_Click(assetTrackAssetsPge.btn_ViewAsset(wdriver));
			logger.log(LogStatus.PASS,"Back to Search Results button","Back to Search Results button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);	
			WebimplicitWait(wdriver);

			//Click on View Asset    
			Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
			logger.log(LogStatus.PASS,"View History button","View History button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);	
			WebimplicitWait(wdriver);   
			Thread.sleep(2000);

			//Verify that the history is Updated.
			String verifyConfirmationText= assetTrackAssetsPge.txt_VerifyViewHistoryText(wdriver,RandomUpdatedValue).getText().trim();
			Assert.assertEquals(RandomUpdatedValue, verifyConfirmationText);
			logger.log(LogStatus.PASS,"History is updated with the Updated Value for the Asset","History is updated with the Updated Value for the Asset as : "+verifyConfirmationText);

		}       
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	} 
	
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_Couple_Asset_Positive_flow(Method m, String username, String password, String Child,
	String Parent) throws Exception {
	try {

	logger.startTest(m.getName());
	System.out.println("method name" + (m.getName()));
	TestReporter.logStep("Start test execution of " + m.getName());
	TestReporter.logStep("Launch Asset Tracker ");

// Step1:Login to the Application

	assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
	WebimplicitWait(wdriver);
	String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
	Assert.assertEquals("Welcome, Tester1", verifyLogin);

// Verify that the login is successful
	Thread.sleep(5000);
	logger.log(LogStatus.PASS, "Login is suucessful",
	"Login is succesful with the login Message " + verifyLogin);

// Click on the Assets button in the Assets page
	Thread.sleep(8000);
	WebimplicitWait(wdriver);
	Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
	logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

// Click on the Search Asset link
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
	logger.log(LogStatus.PASS, "Search Asset link Tab", "Search Asset link Tab is clicked ");

	// Decoupling Parent tracking number
	// write on the tracking number Asset link
	Thread.sleep(5000);
	assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Child);
	logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");

	// Click on the select values button link
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
	logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

	// Click on the Search for Asset link
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
	logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

	// Click on the Search for Asset link
	Thread.sleep(5000);
	/*
	* JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
	* jse1.executeScript("scroll(0, 250);");
	*/
	Boolean Standalonepage = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Stand alone page",
	"Stand alone asset details page is displayed :" + Standalonepage);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Click on the Update Details for Asset link
	Thread.sleep(5000);
	/* jse1.executeScript("scroll(0, -250);"); */
	Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
	logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

	//Verify Consumable asset
	Boolean VerifyConsumable=assetTrackAssetsPge.VerifyConsumable(wdriver).isSelected();
	if(VerifyConsumable==true)
	{
	//Do nothing
	}
	else
	{
	Syn_Click(assetTrackAssetsPge.VerifyConsumable(wdriver));
	}

	// Verify add child button and add parent button displayed or not
	Thread.sleep(5000);
	JavascriptExecutor jse = (JavascriptExecutor) wdriver;
	jse.executeScript("scroll(0, 400);");
	Boolean Btn_AddParent = assetTrackAssetsPge.Btn_AddParent(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "add parent button", "add parent button is displayed :" + Btn_AddParent);
	Boolean Btn_AddChild = assetTrackAssetsPge.Btn_AddChild(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "add child button", "add child button is displayed :" + Btn_AddChild);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Click Add Parent Button
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_AddParent(wdriver));
	logger.log(LogStatus.PASS, "Add Parent Button Tab", "Add Parent Button is clicked ");

	// Accept the popup Button
	WebDriverWait wait = new WebDriverWait(wdriver, 30);
	wait.until(ExpectedConditions.alertIsPresent());
	Alert alert = wdriver.switchTo().alert();
	Thread.sleep(1000);
	alert.getText();
	// alert handling
	logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
	Thread.sleep(1000);
	alert.accept();
	logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

	// Add parent Tracking number
	Thread.sleep(5000);
	Boolean VerifyParentTracking = assetTrackAssetsPge.VerifyParentTracking(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "parent Tracking number Page",
	"parent Tracking number Page is displayed :" + VerifyParentTracking);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	assetTrackAssetsPge.Txt_ParentTracking(wdriver).sendKeys(Parent);
	logger.log(LogStatus.PASS, "Add Parent Tracking number", "Add Parent Tracking number is entered");

	// Click on save button
	Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
	logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");

	// Confirmation message
	Thread.sleep(5000);
	String Txt_message = assetTrackAssetsPge.Txt_message(wdriver).getText().trim();
	Assert.assertEquals(Txt_message, "You have successfully added a parent asset.");
	logger.log(LogStatus.PASS, "Confirmation message", "Confirmation message is displayed:" + Txt_message);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Back to edit asset button is clicked:
	Syn_Click(assetTrackAssetsPge.Btn_Edit(wdriver));
	logger.log(LogStatus.PASS, "Back to edit asset button is clicked:",
	"Back to edit asset button is clicked:");

	// Edit asset page is displayed
	Boolean Edit_assetpage = assetTrackAssetsPge.Edit_assetpage(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Edit asset page is displayed",
	"Edit asset page is displayed :" + Edit_assetpage);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Click Decouple button
	Thread.sleep(5000);
	JavascriptExecutor jse8 = (JavascriptExecutor) wdriver;
	jse8.executeScript("scroll(0, 400);");
	Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
	Thread.sleep(5000);
	// alert handling
	WebDriverWait wait1 = new WebDriverWait(wdriver, 30);
	wait1.until(ExpectedConditions.alertIsPresent());
	Thread.sleep(2000);
	Alert alert3 = wdriver.switchTo().alert();
	Thread.sleep(2000);
	alert3.accept();
	Thread.sleep(2000);
	logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Checkbox(wdriver));
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));

	// Click Cancel Button
	Thread.sleep(5000);
////////////////////////////	Syn_Click(assetTrackAssetsPge.Btn_Cancel(wdriver));
	logger.log(LogStatus.PASS, "Cancel Button is clicked:", "Cancel Button is clicked:");
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_previous(wdriver));
	logger.log(LogStatus.PASS, "Previous Button is clicked:", "Previous Button is clicked:");

	// Decoupling child tracking number
	// write on the tracking number Asset link
	Thread.sleep(5000);
	assetTrackAssetsPge.txt_trackingNumber(wdriver).clear();
	assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Parent);
	logger.log(LogStatus.PASS, "Valid parent tracking number is entered",
	"Valid parent tracking number is entered");

	// Click on the select values button link
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
	logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

	// Click on the Search for Asset link
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
	logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

	// Click on the Search for Asset link
	Thread.sleep(5000);
	/*
	* JavascriptExecutor jse5 = (JavascriptExecutor)wdriver;
	* jse5.executeScript("scroll(0, 250);");
	*/
	Boolean ParentStandalonepage = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Stand alone page",
	"Stand alone asset details page is displayed :" + ParentStandalonepage);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Click on the Update Details for Asset link
	Thread.sleep(5000);
	/* jse5.executeScript("scroll(0, -250);"); */
	Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
	logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

	// Verify add child button and add parent button displayed or not
	Thread.sleep(5000);
	JavascriptExecutor jse2 = (JavascriptExecutor) wdriver;
	jse2.executeScript("scroll(0, 400);");
	Boolean Btn_AddParent1 = assetTrackAssetsPge.Btn_AddParent(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "add parent button", "add parent button is displayed :" + Btn_AddParent1);
	Boolean Btn_AddChild1 = assetTrackAssetsPge.Btn_AddChild(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "add child button", "add child button is displayed :" + Btn_AddChild1);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Click Add Child Button
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_AddChild(wdriver));
	logger.log(LogStatus.PASS, "Add Child Button Tab", "Add Child Button is clicked ");

	// Accept the popup Button
	WebDriverWait wait2 = new WebDriverWait(wdriver, 30);
	wait2.until(ExpectedConditions.alertIsPresent());
	Alert alert1 = wdriver.switchTo().alert();
	Thread.sleep(1000);
	alert1.getText();
	// alert handling
	logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert1.getText());
	Thread.sleep(1000);
	alert1.accept();
	logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

	// Add Child Tracking number
	Thread.sleep(5000);
	Boolean VerifyChildTracking = assetTrackAssetsPge.VerifyChildTracking(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Child Tracking number Page",
	"Child Tracking number Page is displayed :" + VerifyChildTracking);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	assetTrackAssetsPge.Txt_ChildTracking(wdriver).sendKeys(Child);
	logger.log(LogStatus.PASS, "Add Child Tracking number", "Add Child Tracking number is entered");

	// Click on save button
	Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
	logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");

	// Confirmation message
	Thread.sleep(5000);
	String Txt_message1 = assetTrackAssetsPge.Txt_message1(wdriver).getText().trim();
	Assert.assertEquals(Txt_message1, "You have successfully added a child asset.");
	logger.log(LogStatus.PASS, "Confirmation message", "Confirmation message is displayed");
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Back to edit asset button is clicked:
	Syn_Click(assetTrackAssetsPge.Btn_Edit(wdriver));
	logger.log(LogStatus.PASS, "Back to edit asset button is clicked:",
	"Back to edit asset button is clicked:");

	// Edit asset page is displayed
	Boolean Edit_assetpage1 = assetTrackAssetsPge.Edit_assetpage(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Edit asset page is displayed",
	"Edit asset page is displayed :" + Edit_assetpage1);
	JavascriptExecutor jse4 = (JavascriptExecutor) wdriver;
	jse4.executeScript("scroll(0, 400);");
	Boolean Child_assetpage = assetTrackAssetsPge.Child_assetpage(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Child asset page is displayed",
	"Child asset page is displayed :" + Child_assetpage);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Click Decouple button
	Thread.sleep(5000);
	Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
	logger.log(LogStatus.PASS, "Decouple button is clicked", "Decouple button is clicked");
	WebDriverWait wait4 = new WebDriverWait(wdriver, 30);
	wait4.until(ExpectedConditions.alertIsPresent());
	Alert alert2 = wdriver.switchTo().alert();
	Thread.sleep(2000);
	alert2.getText();
	// alert handling
	logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert2.getText());
	Thread.sleep(2000);
	alert2.accept();
	Thread.sleep(2000);
	logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");
	Thread.sleep(5000);
	// Checkbox is selected
	Thread.sleep(2000);
/////	Boolean Verify_scanin = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
/////	logger.log(LogStatus.PASS, "Tracking Number is displayed","Tracking Number is displayed :" + Verify_scanin);
	Boolean Verify_ItemDetails = assetTrackAssetsPge.Verify_ItemDetails(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Item Details page is displayed",
	"Item Details page is displayed :" + Verify_ItemDetails);

	Syn_Click(assetTrackAssetsPge.Checkbox(wdriver));
	logger.log(LogStatus.PASS, " Checkbox is selected", " Checkbox Button is clicked");
	Thread.sleep(2000);
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	// Decouple button is clicked
	Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
	logger.log(LogStatus.PASS, "Decouple button is clicked", "Decouple button is clicked");
	Thread.sleep(5000);
	// Save changes button is clicked
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	Syn_Click(assetTrackAssetsPge.Btn_saveChanges(wdriver));
	logger.log(LogStatus.PASS, "Save button is clicked", "Save button is clicked");
	JavascriptExecutor jse6 = (JavascriptExecutor) wdriver;
	jse6.executeScript("scroll(0, 400);");
	Boolean ParentStandalonepage1 = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
	logger.log(LogStatus.PASS, "Stand alone page",
	"Stand alone asset details page is displayed :" + ParentStandalonepage1);
	logger.log(LogStatus.PASS, " asset becomes a standalone asset", " asset becomes a standalone asset");
	objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	} catch (Exception | AssertionError e) {
	logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
	TestReporter.logFailure("Error Message:" + e.getMessage());
	objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
	}

	}

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_Decouple_Consumable_Asset(Method m, String username, String password, String Child,
			String Parent) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Search Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS, "Search Asset link Tab", "Search Asset link Tab is clicked ");

			// Decoupling Parent tracking number
			// write on the tracking number Asset link
			Thread.sleep(5000);
			assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Child);
			logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");

			// Click on the select values button link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
			logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			/*
			 * JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
			 * jse1.executeScript("scroll(0, 250);");
			 */
			Boolean Standalonepage = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + Standalonepage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click on the Update Details for Asset link
			Thread.sleep(5000);
			/* jse1.executeScript("scroll(0, -250);"); */
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

			//Verify Consumable asset
			Boolean VerifyConsumable=assetTrackAssetsPge.VerifyConsumable(wdriver).isSelected();
			if(VerifyConsumable==true)
			{
				//Do nothing
			}
			else
			{
				Syn_Click(assetTrackAssetsPge.VerifyConsumable(wdriver));
			}
			
			// Verify add child button and add parent button displayed or not
			Thread.sleep(5000);
			JavascriptExecutor jse = (JavascriptExecutor) wdriver;
			jse.executeScript("scroll(0, 400);");
			Boolean Btn_AddParent = assetTrackAssetsPge.Btn_AddParent(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add parent button", "add parent button is displayed :" + Btn_AddParent);
			Boolean Btn_AddChild = assetTrackAssetsPge.Btn_AddChild(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add child button", "add child button is displayed :" + Btn_AddChild);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Add Parent Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_AddParent(wdriver));
			logger.log(LogStatus.PASS, "Add Parent Button Tab", "Add Parent Button is clicked ");

			// Accept the popup Button
			WebDriverWait wait = new WebDriverWait(wdriver, 50);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = wdriver.switchTo().alert();
			Thread.sleep(1000);
			alert.getText();
			// alert handling
			logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
			Thread.sleep(1000);
			alert.accept();
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

			// Add parent Tracking number
			Thread.sleep(5000);
			Boolean VerifyParentTracking = assetTrackAssetsPge.VerifyParentTracking(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "parent Tracking number Page",
					"parent Tracking number Page is displayed :" + VerifyParentTracking);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			assetTrackAssetsPge.Txt_ParentTracking(wdriver).sendKeys(Parent);
			logger.log(LogStatus.PASS, "Add Parent Tracking number", "Add Parent Tracking number is entered");

			// Click on save button
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");

			// Confirmation message
			Thread.sleep(5000);
			String Txt_message = assetTrackAssetsPge.Txt_message(wdriver).getText().trim();
			Assert.assertEquals(Txt_message, "You have successfully added a parent asset.");
			logger.log(LogStatus.PASS, "Confirmation message", "Confirmation message is displayed:" + Txt_message);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Back to edit asset button is clicked:
			Syn_Click(assetTrackAssetsPge.Btn_Edit(wdriver));
			logger.log(LogStatus.PASS, "Back to edit asset button is clicked:",
					"Back to edit asset button is clicked:");

			// Edit asset page is displayed
			Boolean Edit_assetpage = assetTrackAssetsPge.Edit_assetpage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Edit asset page is displayed",
					"Edit asset page is displayed :" + Edit_assetpage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Decouple button
			Thread.sleep(5000);
			JavascriptExecutor jse8 = (JavascriptExecutor) wdriver;
			jse8.executeScript("scroll(0, 400);");
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			Thread.sleep(5000);
			// alert handling
			WebDriverWait wait1 = new WebDriverWait(wdriver, 50);
			wait1.until(ExpectedConditions.alertIsPresent());
			Thread.sleep(2000);
			Alert alert3 = wdriver.switchTo().alert();
			Thread.sleep(2000);
			alert3.accept();
			Thread.sleep(2000);
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Checkbox(wdriver));
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));

			// Click Cancel Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_Cancel(wdriver));
			logger.log(LogStatus.PASS, "Cancel Button is clicked:", "Cancel Button is clicked:");
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_previous(wdriver));
			logger.log(LogStatus.PASS, "Previous Button is clicked:", "Previous Button is clicked:");

			// Decoupling child tracking number
			// write on the tracking number Asset link
			Thread.sleep(5000);
			assetTrackAssetsPge.txt_trackingNumber(wdriver).clear();
			assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Parent);
			logger.log(LogStatus.PASS, "Valid parent tracking number is entered",
					"Valid parent tracking number is entered");

			// Click on the select values button link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
			logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			/*
			 * JavascriptExecutor jse5 = (JavascriptExecutor)wdriver;
			 * jse5.executeScript("scroll(0, 250);");
			 */
			Boolean ParentStandalonepage = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + ParentStandalonepage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click on the Update Details for Asset link
			Thread.sleep(5000);
			/* jse5.executeScript("scroll(0, -250);"); */
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

			// Verify add child button and add parent button displayed or not
			Thread.sleep(5000);
			JavascriptExecutor jse2 = (JavascriptExecutor) wdriver;
			jse2.executeScript("scroll(0, 400);");
			Boolean Btn_AddParent1 = assetTrackAssetsPge.Btn_AddParent(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add parent button", "add parent button is displayed :" + Btn_AddParent1);
			Boolean Btn_AddChild1 = assetTrackAssetsPge.Btn_AddChild(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add child button", "add child button is displayed :" + Btn_AddChild1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Add Child Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_AddChild(wdriver));
			logger.log(LogStatus.PASS, "Add Child Button Tab", "Add Child Button is clicked ");

			// Accept the popup Button
			WebDriverWait wait2 = new WebDriverWait(wdriver, 50);
			wait2.until(ExpectedConditions.alertIsPresent());
			Alert alert1 = wdriver.switchTo().alert();
			Thread.sleep(1000);
			alert1.getText();
			// alert handling
			logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert1.getText());
			Thread.sleep(1000);
			alert1.accept();
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

			// Add Child Tracking number
			Thread.sleep(5000);
			Boolean VerifyChildTracking = assetTrackAssetsPge.VerifyChildTracking(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Child Tracking number Page",
					"Child Tracking number Page is displayed :" + VerifyChildTracking);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			assetTrackAssetsPge.Txt_ChildTracking(wdriver).sendKeys(Child);
			logger.log(LogStatus.PASS, "Add Child Tracking number", "Add Child Tracking number is entered");

			// Click on save button
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");

			// Confirmation message
			Thread.sleep(5000);
			String Txt_message1 = assetTrackAssetsPge.Txt_message1(wdriver).getText().trim();
			Assert.assertEquals(Txt_message1, "You have successfully added a child asset.");
			logger.log(LogStatus.PASS, "Confirmation message", "Confirmation message is displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Back to edit asset button is clicked:
			Syn_Click(assetTrackAssetsPge.Btn_Edit(wdriver));
			logger.log(LogStatus.PASS, "Back to edit asset button is clicked:",
					"Back to edit asset button is clicked:");

			// Edit asset page is displayed
			Boolean Edit_assetpage1 = assetTrackAssetsPge.Edit_assetpage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Edit asset page is displayed",
					"Edit asset page is displayed :" + Edit_assetpage1);
			JavascriptExecutor jse4 = (JavascriptExecutor) wdriver;
			jse4.executeScript("scroll(0, 400);");
			Boolean Child_assetpage = assetTrackAssetsPge.Child_assetpage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Child asset page is displayed",
					"Child asset page is displayed :" + Child_assetpage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Decouple button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked", "Decouple button is clicked");
			WebDriverWait wait4 = new WebDriverWait(wdriver, 50);
			wait4.until(ExpectedConditions.alertIsPresent());
			Alert alert2 = wdriver.switchTo().alert();
			Thread.sleep(2000);
			alert2.getText();
			// alert handling
			logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert2.getText());
			Thread.sleep(2000);
			alert2.accept();
			Thread.sleep(2000);
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");
			Thread.sleep(5000);
			// Checkbox is selected
			Thread.sleep(2000);
			Boolean Verify_scanin = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Tracking Number is displayed",
					"Tracking Number is displayed :" + Verify_scanin);
			Boolean Verify_ItemDetails = assetTrackAssetsPge.Verify_ItemDetails(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Item Details page is displayed",
					"Item Details page is displayed :" + Verify_ItemDetails);

			Syn_Click(assetTrackAssetsPge.Checkbox(wdriver));
			logger.log(LogStatus.PASS, " Checkbox is selected", " Checkbox Button is clicked");
			Thread.sleep(2000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Decouple button is clicked
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked", "Decouple button is clicked");
			Thread.sleep(5000);
			// Save changes button is clicked
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Syn_Click(assetTrackAssetsPge.Btn_saveChanges(wdriver));
			logger.log(LogStatus.PASS, "Save button is clicked", "Save button is clicked");
			JavascriptExecutor jse6 = (JavascriptExecutor) wdriver;
			jse6.executeScript("scroll(0, 400);");
			Boolean ParentStandalonepage1 = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + ParentStandalonepage1);
			logger.log(LogStatus.PASS, "	asset becomes a standalone asset", "	asset becomes a standalone asset");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_Decouple_Asset_Positive_flow(Method m, String username, String password, String Child,
			String Parent) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Search Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS, "Search Asset link Tab", "Search Asset link Tab is clicked ");

			// Decoupling Parent tracking number
			// write on the tracking number Asset link
			Thread.sleep(5000);
			assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Child);
			logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");

			// Click on the select values button link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
			logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Thread.sleep(2000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				// do nothing
			} else {
				  JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
				  jse1.executeScript("scroll(0, 250);");	 
			}
			Boolean Standalonepage = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + Standalonepage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click on the Update Details for Asset link
			Thread.sleep(5000);
			/* jse1.executeScript("scroll(0, -250);"); */
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

			// Verify add child button and add parent button displayed or not
			Thread.sleep(5000);
			JavascriptExecutor jse = (JavascriptExecutor) wdriver;
			jse.executeScript("scroll(0, 400);");
			Boolean Btn_AddParent = assetTrackAssetsPge.Btn_AddParent(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add parent button", "add parent button is displayed :" + Btn_AddParent);
			Boolean Btn_AddChild = assetTrackAssetsPge.Btn_AddChild(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add child button", "add child button is displayed :" + Btn_AddChild);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Add Parent Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_AddParent(wdriver));
			logger.log(LogStatus.PASS, "Add Parent Button Tab", "Add Parent Button is clicked ");

			// Accept the popup Button
			WebDriverWait wait = new WebDriverWait(wdriver, 50);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = wdriver.switchTo().alert();
			Thread.sleep(1000);
			alert.getText();
			// alert handling
			logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
			Thread.sleep(1000);
			alert.accept();
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

			// Add parent Tracking number
			Thread.sleep(5000);
			Boolean VerifyParentTracking = assetTrackAssetsPge.VerifyParentTracking(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "parent Tracking number Page",
					"parent Tracking number Page is displayed :" + VerifyParentTracking);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			assetTrackAssetsPge.Txt_ParentTracking(wdriver).sendKeys(Parent);
			logger.log(LogStatus.PASS, "Add Parent Tracking number", "Add Parent Tracking number is entered");

			// Click on save button
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");

			// Confirmation message
			Thread.sleep(5000);
			String Txt_message = assetTrackAssetsPge.Txt_message(wdriver).getText().trim();
			Assert.assertEquals(Txt_message, "You have successfully added a parent asset.");
			logger.log(LogStatus.PASS, "Confirmation message", "Confirmation message is displayed:" + Txt_message);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Back to edit asset button is clicked:
			Syn_Click(assetTrackAssetsPge.Btn_Edit(wdriver));
			logger.log(LogStatus.PASS, "Back to edit asset button is clicked:",
					"Back to edit asset button is clicked:");

			// Edit asset page is displayed
			Boolean Edit_assetpage = assetTrackAssetsPge.Edit_assetpage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Edit asset page is displayed",
					"Edit asset page is displayed :" + Edit_assetpage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Decouple button
			Thread.sleep(5000);
			JavascriptExecutor jse8 = (JavascriptExecutor) wdriver;
			jse8.executeScript("scroll(0, 400);");
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked:", "Decouple button is clicked");
			Thread.sleep(5000);
			// alert handling
			WebDriverWait wait1 = new WebDriverWait(wdriver, 50);
			wait1.until(ExpectedConditions.alertIsPresent());
			Thread.sleep(2000);
			Alert alert3 = wdriver.switchTo().alert();
			Thread.sleep(2000);
			alert3.accept();
			Thread.sleep(2000);
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");
			Thread.sleep(5000);
			//Checkbox is selected
			Syn_Click(assetTrackAssetsPge.Checkbox(wdriver));
			logger.log(LogStatus.PASS, " Checkbox is selected", " Checkbox is selected");
			Thread.sleep(5000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked:", "Decouple button is clicked");
			
			// Click Cancel Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_Cancel(wdriver));
			logger.log(LogStatus.PASS, "Cancel Button is clicked:", "Cancel Button is clicked:");
			Thread.sleep(5000);
			JavascriptExecutor jse6 = (JavascriptExecutor) wdriver;
			jse6.executeScript("scroll(0, 400);");
			Boolean ParentStandalonepage1 = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + ParentStandalonepage1);
			logger.log(LogStatus.PASS, "Asset Page is displayed", "Asset Page is displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Clicks Update Details 
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

			//Check By Default the Locations are there
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
			js.executeScript("scroll(0, 600);");
			String Currentlocation=assetTrackAssetsPge.txt_currentlocation(wdriver).getAttribute("value");
			if(Currentlocation.isEmpty())
			{
			Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
			Thread.sleep(20000); 
			switchToWindow("Tab Search"); 
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(20000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Current Location is selected","Current Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Current Location is Present By Default","Current Location is Present By Default");	
			}
			
			// enter Sublocation
			String CurrentSublocation=assetTrackAssetsPge.txt_CurrentSubLocationAsset(wdriver).getAttribute("value");
			if(CurrentSublocation.isEmpty())
			{
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_SublocationId(wdriver));
				Thread.sleep(10000); 
				switchToWindow("Tab Search"); 
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
			
				logger.log(LogStatus.PASS, "Current Sub Location is selected","Current Sub Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Current Sub Location is Present By Default","Current Sub Location is Present By Default");	
			}
			
			String PermanentLocation=assetTrackAssetsPge.txt_permanentSublocationID(wdriver).getAttribute("value");
			if(PermanentLocation.isEmpty())
			{
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_PermanentLocation(wdriver));
				Thread.sleep(10000); 
				switchToWindow("Tab Search"); 
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
			
				logger.log(LogStatus.PASS, "Permanent Location is selected","Permanent Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Permanent Location is Present By Default","Permanent Location is Present By Default");	
			}
			
			String PermanentSubLocation=assetTrackAssetsPge.txt_PermanentLocation(wdriver).getAttribute("value");
			if(PermanentSubLocation.isEmpty())
			{
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_permanentSublocationID(wdriver));
				Thread.sleep(10000); 
				switchToWindow("Tab Search"); 
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
			
				logger.log(LogStatus.PASS, "Permanent sub Location is selected","Permanent sub Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Permanent sub Location is Present By Default","Permanent sub Location is Present By Default");	
			}
			
			
			//Save Changes Button is clicked
			JavascriptExecutor jse9 = (JavascriptExecutor) wdriver;
			jse9.executeScript("scroll(0, -600);");
			Syn_Click(assetTrackAssetsPge.Btn_saveChanges(wdriver));
			logger.log(LogStatus.PASS, "Save button is clicked", "Save button is clicked");
			logger.log(LogStatus.PASS, "Changes are saved", "Changes are saved");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_Decouple_Asset_Negative_flow(Method m, String username, String password, String Child, String Parent) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Search Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS, "Search Asset link Tab", "Search Asset link Tab is clicked ");

			// Decoupling Parent tracking number
			// write on the tracking number Asset link
			Thread.sleep(5000);
			assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Child);
			logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");

			// Click on the select values button link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
			 String title= wdriver.getTitle();
			  if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
			    {
			    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			    WebimplicitWait(wdriver);
			    switchToWindow("Asset Tracker v2.2.1");  
			    }
			logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Thread.sleep(2000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				// do nothing
			} else {
				  JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
				  jse1.executeScript("scroll(0, 250);");	 
			}
			Boolean Standalonepage = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + Standalonepage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click on the Update Details for Asset link
			Thread.sleep(5000);
			/* jse1.executeScript("scroll(0, -250);"); */
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

			// Verify add child button and add parent button displayed or not
			Thread.sleep(5000);
			JavascriptExecutor jse = (JavascriptExecutor) wdriver;
			jse.executeScript("scroll(0, 400);");
			Boolean Btn_AddParent = assetTrackAssetsPge.Btn_AddParent(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add parent button", "add parent button is displayed :" + Btn_AddParent);
			Boolean Btn_AddChild = assetTrackAssetsPge.Btn_AddChild(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "add child button", "add child button is displayed :" + Btn_AddChild);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Add Parent Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_AddParent(wdriver));
			logger.log(LogStatus.PASS, "Add Parent Button Tab", "Add Parent Button is clicked ");

			// Accept the popup Button
			WebDriverWait wait = new WebDriverWait(wdriver, 50);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = wdriver.switchTo().alert();
			Thread.sleep(1000);
			alert.getText();
			// alert handling
			logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
			Thread.sleep(1000);
			alert.accept();
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

			// Add parent Tracking number
			Thread.sleep(5000);
			Boolean VerifyParentTracking = assetTrackAssetsPge.VerifyParentTracking(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "parent Tracking number Page",
					"parent Tracking number Page is displayed :" + VerifyParentTracking);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Give Invalid tracking number
			assetTrackAssetsPge.Txt_ParentTracking(wdriver).sendKeys("@#$%^&*!");
			logger.log(LogStatus.PASS, "Invalid tracking Number is Entered", "Invalid tracking Number is Entered");
			// Click on save button
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");
			//Validation Message
			String ValidMsg=assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			String Concatenate="Tracking Number (@#$%^&*!) cannot be found in the system.";
			Assert.assertEquals(ValidMsg, Concatenate);
			logger.log(LogStatus.PASS, "Invalid tracking Number is Entered", "Validation Message displayed :"+ValidMsg);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Enter Valid Tracking Number
			assetTrackAssetsPge.Txt_ParentTracking(wdriver).clear();
			assetTrackAssetsPge.Txt_ParentTracking(wdriver).sendKeys(Parent);
			logger.log(LogStatus.PASS, "Add Parent Tracking number", "Add Parent Tracking number is entered");

			// Click on save button
			Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS, "save button is clicked", "save button is clicked");

			// Confirmation message
			Thread.sleep(5000);
			String Txt_message = assetTrackAssetsPge.Txt_message(wdriver).getText().trim();
			Assert.assertEquals(Txt_message, "You have successfully added a parent asset.");
			logger.log(LogStatus.PASS, "Confirmation message", "Confirmation message is displayed:" + Txt_message);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Back to edit asset button is clicked:
			Syn_Click(assetTrackAssetsPge.Btn_Edit(wdriver));
			logger.log(LogStatus.PASS, "Back to edit asset button is clicked:",
					"Back to edit asset button is clicked:");

			// Edit asset page is displayed
			Boolean Edit_assetpage = assetTrackAssetsPge.Edit_assetpage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Edit asset page is displayed",
					"Edit asset page is displayed :" + Edit_assetpage);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Decouple button
			Thread.sleep(5000);
			JavascriptExecutor jse8 = (JavascriptExecutor) wdriver;
			jse8.executeScript("scroll(0, 400);");
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked:", "Decouple button is clicked");
			Thread.sleep(5000);
			// alert handling
			WebDriverWait wait1 = new WebDriverWait(wdriver, 50);
			wait1.until(ExpectedConditions.alertIsPresent());
			Thread.sleep(2000);
			Alert alert3 = wdriver.switchTo().alert();
			Thread.sleep(2000);
			alert3.accept();
			Thread.sleep(2000);
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");
			Thread.sleep(5000);
			//Checkbox is selected
			Syn_Click(assetTrackAssetsPge.Checkbox(wdriver));
			logger.log(LogStatus.PASS, " Checkbox is selected", " Checkbox is selected");
			Thread.sleep(5000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked:", "Decouple button is clicked");
			
			// Click Cancel Button
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_Cancel(wdriver));
			logger.log(LogStatus.PASS, "Cancel Button is clicked:", "Cancel Button is clicked:");
			Thread.sleep(5000);
			JavascriptExecutor jse6 = (JavascriptExecutor) wdriver;
			jse6.executeScript("scroll(0, 400);");
			Boolean ParentStandalonepage1 = assetTrackAssetsPge.Standalonepage(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Stand alone page",
					"Stand alone asset details page is displayed :" + ParentStandalonepage1);
			logger.log(LogStatus.PASS, "Asset Page is displayed", "Asset Page is displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Clicks Update Details 
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");

			//Check By Default the Locations are there
			JavascriptExecutor js = (JavascriptExecutor) wdriver;
			js.executeScript("scroll(0, 600);");
			String Currentlocation=assetTrackAssetsPge.txt_currentlocation(wdriver).getAttribute("value");
			if(Currentlocation.isEmpty())
			{
			Syn_Click(assetTrackAssetsPge.btn_currentlocation(wdriver));
			Thread.sleep(20000); 
			switchToWindow("Tab Search"); 
			Thread.sleep(15000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(20000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Current Location is selected","Current Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Current Location is Present By Default","Current Location is Present By Default");	
			}
			
			// enter Sublocation
			String CurrentSublocation=assetTrackAssetsPge.txt_CurrentSubLocationAsset(wdriver).getAttribute("value");
			if(CurrentSublocation.isEmpty())
			{
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_SublocationId(wdriver));
				Thread.sleep(10000); 
				switchToWindow("Tab Search"); 
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
			
				logger.log(LogStatus.PASS, "Current Sub Location is selected","Current Sub Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Current Sub Location is Present By Default","Current Sub Location is Present By Default");	
			}
			
			String PermanentLocation=assetTrackAssetsPge.txt_permanentSublocationID(wdriver).getAttribute("value");
			if(PermanentLocation.isEmpty())
			{
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_PermanentLocation(wdriver));
				Thread.sleep(10000); 
				switchToWindow("Tab Search"); 
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
			
				logger.log(LogStatus.PASS, "Permanent Location is selected","Permanent Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Permanent Location is Present By Default","Permanent Location is Present By Default");	
			}
			
			String PermanentSubLocation=assetTrackAssetsPge.txt_PermanentLocation(wdriver).getAttribute("value");
			if(PermanentSubLocation.isEmpty())
			{
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.btn_permanentSublocationID(wdriver));
				Thread.sleep(10000); 
				switchToWindow("Tab Search"); 
				Thread.sleep(10000);
				Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver)); 
				Thread.sleep(10000);
				switchToWindow("Asset Tracker v2.2.1");
			
				logger.log(LogStatus.PASS, "Permanent sub Location is selected","Permanent sub Location is selected");
			}
			else
			{
				logger.log(LogStatus.PASS, "Permanent sub Location is Present By Default","Permanent sub Location is Present By Default");	
			}
			
			//Save Changes Button is clicked
			JavascriptExecutor jse9 = (JavascriptExecutor) wdriver;
			jse9.executeScript("scroll(0, -600);");
			Syn_Click(assetTrackAssetsPge.Btn_saveChanges(wdriver));
			logger.log(LogStatus.PASS, "Save button is clicked", "Save button is clicked");
			
			//Clicks Update Details 
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");
			
			//Enter Invalid Changes in location	
			Thread.sleep(5000);
			JavascriptExecutor jse0 = (JavascriptExecutor) wdriver;
			jse0.executeScript("scroll(0, 600);");
			assetTrackAssetsPge.txt_currentlocation(wdriver).clear();
			assetTrackAssetsPge.txt_currentlocation(wdriver).sendKeys("@#$%^");
			logger.log(LogStatus.PASS, "Invalid data in Current Location is entered","Invalid data in Current Location is entered");
			assetTrackAssetsPge.txt_CurrentSubLocationAsset(wdriver).sendKeys("@#$%^");
			logger.log(LogStatus.PASS, "Invalid data in Current Sub Location is entered","Invalid data in Current Sub Location is entered");
			assetTrackAssetsPge.txt_permanentSublocationID(wdriver).clear();
			logger.log(LogStatus.PASS, "Invalid data in Permanent Location is entered","Invalid data in Permanent Location is entered");
			
			//Save Changes Button is clicked
			JavascriptExecutor jse91 = (JavascriptExecutor) wdriver;
			jse91.executeScript("scroll(0, -600);");
			Syn_Click(assetTrackAssetsPge.Btn_saveChanges(wdriver));
			logger.log(LogStatus.PASS, "Save button is clicked", "Save button is clicked");
			
			//Validation Message Is printed
			Thread.sleep(2000);
			String ValidMsg1=assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			if(ValidMsg1.equalsIgnoreCase("Select Current location only from the pop-up.") || ValidMsg1.equalsIgnoreCase("Select Current sub location only from the pop-up."))
			{
			logger.log(LogStatus.PASS, "Validation Message displayed", "Validation Message displayed :"+ValidMsg1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			}


		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_Decouple_Asset_Overal_flow(Method m, String username, String password, String Child) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");
			
			// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
			// menus should get displayed
			Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
			Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
			Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
			Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

			// Click on the Search Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS, "Search Asset link Tab", "Search Asset link Tab is clicked ");
			
			//Search asset page is displayed with blank fields and Other tabs
			Thread.sleep(2000);
			Boolean VerifyAsset = assetTrackAssetsPge.VerifyAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Asset page Tab is displayed :" + VerifyAsset);
			Boolean Btn_Clear = assetTrackAssetsPge.Btn_Clear(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Clear Tab", "Clear Tab is displayed :" + Btn_Clear);
			Boolean Btn_SaveSearch = assetTrackAssetsPge.Btn_SaveSearch(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Saved search Tab", "Saved search Tab is displayed :" + Btn_SaveSearch);
			Boolean btn_SearchForAssets = assetTrackAssetsPge.btn_SearchForAssets(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "search for assets Tab", "search for assets Tab is displayed :" + btn_SearchForAssets);
			String txt_trackingNumber = assetTrackAssetsPge.txt_trackingNumber(wdriver).getAttribute("value");
			if(txt_trackingNumber.isEmpty())
			{
			logger.log(LogStatus.PASS, "trackingNumber Tab", "trackingNumber Tab is displayed blank :" + txt_trackingNumber);
			}
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			// write on the tracking number Asset link
			Thread.sleep(5000);
			assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Child);
			logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");

			// Click on the select values button link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
			 String title= wdriver.getTitle();
			  if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
			    {
			    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			    WebimplicitWait(wdriver);
			    switchToWindow("Asset Tracker v2.2.1");  
			    }
			logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");
		
			
			// Click on the Search for Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Thread.sleep(2000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				// do nothing
			} else {
				  JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
				  jse1.executeScript("scroll(0, 250);");	 
			}
			Boolean VerifyParentChild = assetTrackAssetsPge.VerifyParentChild(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Parent child page",
					"Parent child page details page is displayed :" + VerifyParentChild);
			
			//click on the View asset
			Thread.sleep(2000);
			Syn_Click(assetTrackAssetsPge.Btn_ViewAsset(wdriver));
			logger.log(LogStatus.PASS, "View asset link Tab", "View asset link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click on the Update Details for Asset link
			Thread.sleep(5000);
			/* jse1.executeScript("scroll(0, -250);"); */
			Syn_Click(assetTrackAssetsPge.Btn_updateDetails(wdriver));
			logger.log(LogStatus.PASS, " Update Details Tab", " Update Details Tab is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Decouple button
			Thread.sleep(5000);
			JavascriptExecutor jse8 = (JavascriptExecutor) wdriver;
			jse8.executeScript("scroll(0, 400);");
			Boolean VerifyDecouple=assetTrackAssetsPge.Btn_Decouple(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Decouple button is Present:", "Decouple button is Present :" +VerifyDecouple);
			Syn_Click(assetTrackAssetsPge.Btn_Decouple(wdriver));
			logger.log(LogStatus.PASS, "Decouple button is clicked:", "Decouple button is clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);
			
			// Accept the popup Button
			WebDriverWait wait = new WebDriverWait(wdriver, 50);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = wdriver.switchTo().alert();
			Thread.sleep(1000);
			alert.getText();
			// alert handling
			logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
			Thread.sleep(1000);
			alert.accept();
			logger.log(LogStatus.PASS, " Alert is accepted", " OK Button is clicked");

			// Decouple Screen
			Thread.sleep(2000);
			Boolean Verify_scanin = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Tracking Number is displayed",
								"Tracking Number is displayed :" + Verify_scanin);
			Boolean Verify_ItemDetails = assetTrackAssetsPge.Verify_ItemDetails(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Item Details page is displayed",
								"Item Details page is displayed :" + Verify_ItemDetails);

			Boolean Decouplescreen=assetTrackAssetsPge.Checkbox(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, " Decouple screen is displayed", " Decouple screen is displayed :"+Decouplescreen);
			Boolean VerifyDecouple1=assetTrackAssetsPge.Btn_Decouple(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Decouple button is Present:", "Decouple button is Present :" +VerifyDecouple1);
			Thread.sleep(2000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}


	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Shipment_Module_View_Asset_Print_Page(Method m, String username, String password, String Child) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			Thread.sleep(5000);
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);

			// Click on the Assets button in the Assets page
			Thread.sleep(8000);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");
			
			// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
			// menus should get displayed
			Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
			Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
			Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
			Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

			// Click on the Search Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS, "Search Asset link Tab", "Search Asset link Tab is clicked ");
			
			//Search asset page is displayed with blank fields and Other tabs
			Thread.sleep(2000);
			Boolean VerifyAsset = assetTrackAssetsPge.VerifyAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Asset page Tab is displayed :" + VerifyAsset);
			Boolean Btn_Clear = assetTrackAssetsPge.Btn_Clear(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Clear Tab", "Clear Tab is displayed :" + Btn_Clear);
			Boolean Btn_SaveSearch = assetTrackAssetsPge.Btn_SaveSearch(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Saved search Tab", "Saved search Tab is displayed :" + Btn_SaveSearch);
			Boolean btn_SearchForAssets = assetTrackAssetsPge.btn_SearchForAssets(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "search for assets Tab", "search for assets Tab is displayed :" + btn_SearchForAssets);
			String txt_trackingNumber = assetTrackAssetsPge.txt_trackingNumber(wdriver).getAttribute("value");
			if(txt_trackingNumber.isEmpty())
			{
			logger.log(LogStatus.PASS, "trackingNumber Tab", "trackingNumber Tab is displayed blank :" + txt_trackingNumber);
			}
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			// write on the tracking number Asset link
			Thread.sleep(5000);
			assetTrackAssetsPge.txt_trackingNumber(wdriver).sendKeys(Child);
			logger.log(LogStatus.PASS, "Valid tracking number is entered", "Valid tracking number is entered");

			// Click on the select values button link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.Btn_tracking(wdriver));
			 String title= wdriver.getTitle();
			  if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
			    {
			    assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			    WebimplicitWait(wdriver);
			    switchToWindow("Asset Tracker v2.2.1");  
			    }
			logger.log(LogStatus.PASS, "select values button", "select values button is Clicked");
		
			
			// Click on the Search for Asset link
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset link Tab", "Search for Asset link Tab is clicked ");

			// Click on the Search for Asset link
			Thread.sleep(5000);
			Thread.sleep(2000);
			if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
				// do nothing
			} else {
				  JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
				  jse1.executeScript("scroll(0, 250);");	 
			}
			Boolean VerifyParentChild = assetTrackAssetsPge.VerifyParentChild(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Parent child page",
					"Parent child page details page is displayed :" + VerifyParentChild);
			
			//click on the View asset
			Thread.sleep(2000);
			Syn_Click(assetTrackAssetsPge.Btn_ViewAsset(wdriver));
			logger.log(LogStatus.PASS, "View asset link Tab", "View asset link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Verify the View asset button is present or not.
			Thread.sleep(2000);
			 JavascriptExecutor jse1 = (JavascriptExecutor)wdriver;
			  jse1.executeScript("scroll(0, 250);");
			Boolean ViewBtn=assetTrackAssetsPge.Btn_ViewAsset(wdriver).isDisplayed();
			Boolean Flag=true;
			Assert.assertEquals(ViewBtn, Flag);
			logger.log(LogStatus.PASS, "View asset btn Tab", "View asset btn Tab is displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Click printable page button
			 jse1.executeScript("scroll(0, -250);");
			 Syn_Click(assetTrackAssetsPge.Btn_print(wdriver));
			logger.log(LogStatus.PASS, "printable page button Tab", "printable page button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			//Asset details printable page is displayed
			Thread.sleep(5000);
			    switchToWindow("Asset Tracker (Printable)");  
			    Set<String> handles = wdriver.getWindowHandles();

			      System.out.println("no of windows" +handles.size());

			
			    String title1= wdriver.getTitle();
			    Thread.sleep(5000);
			    wdriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			    logger.log(LogStatus.PASS, "printable page", "printable page  is displayed ");
			    	logger.log(LogStatus.PASS, " No Button is present on the window", "No Button is present on the window"); 
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			    
		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}

	//Prabha//
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Maintain_ChangedLayout_For_SearchAssetPage(Method m,String username,String password) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			Thread.sleep(5000);
			//Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
			Thread.sleep(10000);
			//Click on the Search Asset link
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			Thread.sleep(5000);
			//Perform a blank search of the Asset 
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(10000);
		
			Syn_Click(assetTrackAssetsPge.btn_ChangeLayout(wdriver));
			logger.log(LogStatus.PASS,"Change Layout Button","Clicked on change layout button ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);
			
		
		   switchToWindow("Change Layout");
		
		  if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
          {
			Thread.sleep(5000);
			
			
			//select[@name='availCols']
			 Select SelectAction=new Select(assetTrackAssetsPge.btn_selectAvailableColumns(wdriver));
			  for(int i=1;i<=2;i++)
			  {
				  Syn_Click(assetTrackAssetsPge.btn_selectAvailableColumns(wdriver));
				SelectAction.selectByIndex(i);
				 // dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),i);

	             Syn_Click(assetTrackAssetsPge.btn_addArrow(wdriver));
		     	logger.log(LogStatus.PASS,"Add the fields button","Value should be added	 ");
			     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
					   
			     Thread.sleep(5000);
			 }
          }
          else
          {
        	   Thread.sleep(3000);
   		    java.util.List<WebElement> listOfElements = wdriver.findElements(By.xpath("(//td[@class='dataCenter']//option)"));
   		    System.out.print(listOfElements+"listOfElements");
   		    
   		 for(int i=1;i<= 2 ;i++)
		    {
		    	String xPathWithVariable = "(//td[@class='dataCenter']//option)" + "[" + i + "]";
		        String value = wdriver.findElement(By.xpath(xPathWithVariable)).getText();
		        System.out.print(value+"Value");
		    	
		    	
		    	wdriver.findElement(By.xpath(xPathWithVariable)).click();
		    	
		     Syn_Click(assetTrackAssetsPge.btn_addArrow(wdriver));
		logger.log(LogStatus.PASS,"Add the fields button","Value should be added	 ");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
				   
		    	
		    }
   		   
          }
		
		
		 //  Syn_Click_RunTime(assetTrackAssetsPge.btn_SortSave(wdriver),"JavaScriptClick");
		    Syn_Click(assetTrackAssetsPge.btn_SortSave(wdriver));
			logger.log(LogStatus.PASS,"Save Button","Clicked on save button ");
			//objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			Thread.sleep(15000);
			switchToWindow("Asset Tracker v2.2.1");
			 
			Thread.sleep(10000);
			
			  Boolean verifyYesButton=assetTrackAssetsPge.txt_OriginalHeader(wdriver).isDisplayed();
		     logger.log(LogStatus.PASS,"Tabs are added to the header :"+verifyYesButton);
		     
	
			 
			Syn_Click(assetTrackAssetsPge.btn_selectAsset(wdriver));
			logger.log(LogStatus.PASS,"Click on Asset","Select any asset ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			Syn_Click_RunTime(assetTrackAssetsPge.btn_viewAsset(wdriver),"JavaScriptClick");
			logger.log(LogStatus.PASS,"Click on View asset for selected asset");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);


			Boolean verifyYesButton2=assetTrackAssetsPge.txt_viewAssetscreen(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"View Asset Screen","View asset screen should be displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(3000);

			Syn_Click_RunTime(assetTrackAssetsPge.btn_previous(wdriver),"JavaScriptClick");
			logger.log(LogStatus.PASS,"previous","Previous pageshould be displayed");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(3000);
			
			
			 
			Syn_Click_RunTime(assetTrackAssetsPge.btn_Next(wdriver),"JavaScriptClick");
			logger.log(LogStatus.PASS,"Next","Clicked on next button");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			Boolean verifyYesButton1=assetTrackAssetsPge.txt_OriginalHeader(wdriver).isDisplayed();
		     logger.log(LogStatus.PASS,"Page Layout is maintained :"+verifyYesButton1);
			  
			Syn_Click_RunTime(assetTrackAssetsPge.btn_previous1(wdriver),"JavaScriptClick");
			logger.log(LogStatus.PASS,"Previous","Clicked on previous button");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			Boolean verifyYesButton3=assetTrackAssetsPge.txt_OriginalHeader(wdriver).isDisplayed();
		     logger.log(LogStatus.PASS,"Page Layout is maintained :"+verifyYesButton3);
		     
		     Syn_Click_RunTime(assetTrackAssetsPge.btn_printablepage(wdriver),"JavaScriptClick");
		     Syn_Click(assetTrackAssetsPge.btn_printablepage(wdriver));
				logger.log(LogStatus.PASS,"Printable","Clicked on Printable Page");
			     objCommStudio.getScreenshoteachStepWeb(wdriver, true);

              //switchToNewWindow("Search Results (Printable)");
			  
		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 		
			}
		}

	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void SavedSearchAsset_retainingvalues_whenother_assetsearched(Method m,String username,String password) throws Exception
	{
		try
		{   

			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			//Step1:Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			//Verifying that the Login is successful

			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

			Thread.sleep(5000);
			JavascriptExecutor myExecutor =((JavascriptExecutor)wdriver);
			
			//Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
			Thread.sleep(2000);
			//Click on the Search Asset link
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(2000);
			
			assetTrackAssetsPge.txt_Country(wdriver).sendKeys("AFGHANISTAN");
			
			
			Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
			Thread.sleep(3000);
			//Perform a blank search of the Asset 
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
			WebimplicitWait(wdriver);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);
			Syn_Click(assetTrackAssetsPge.btn_SaveSearch(wdriver));
			logger.log(LogStatus.PASS,"Save search Button","Clicked on Save search button ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			
			Thread.sleep(5000);
			
			Set <String> availableWindows=wdriver.getWindowHandles();
			String Parent = wdriver.getWindowHandle();
			availableWindows.remove(Parent);
			for (String windowId : availableWindows) 
			{
			wdriver.switchTo().window(windowId);
			}
			Thread.sleep(3000);
			Random rand =new Random();
			int num=rand.nextInt(((9999 - 1000) + 1) + 1000);
			String searchName ="Test"+num;
			assetTrackAssetsPge.SaveSearch_SearchName(wdriver).sendKeys(searchName);
			
			//myExecutor.executeScript("document.getElementsByName('savedSrchCriteriaName')[0].value='"+searchName+"'");
			Thread.sleep(3000);
            
            Syn_Click(assetTrackAssetsPge.btn_AddChildSAVE(wdriver));
			logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
			Thread.sleep(5000);
            switchToWindow("Asset Tracker v2.2.1");
            Thread.sleep(5000);
			String Expectedmsg= "Search Criteria has been saved.";
            String SuccessMsg= assetTrackAssetsPge.ScanOut_SuccessMessage(wdriver).getText().trim();
            Assert.assertEquals(SuccessMsg, Expectedmsg);
            logger.log(LogStatus.PASS,"Success message","Success message is displayed as "+SuccessMsg);
            objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            
          //Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
			Thread.sleep(3000);
			//Click on the Search Asset link
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			Syn_Click(assetTrackAssetsPge.btn_SavedSearch(wdriver));
			logger.log(LogStatus.PASS,"Save search Button","Clicked on Save search button ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);
			Set <String> availableWindows1=wdriver.getWindowHandles();
			
			String Parent1 = wdriver.getWindowHandle();
			availableWindows1.remove(Parent1);
			for (String windowId1 : availableWindows1) 
			{
				
			wdriver.switchTo().window(windowId1);
			}
			Thread.sleep(5000);
			selValueWindow(wdriver);
			Syn_Click(assetTrackAssetsPge.btn_SavedSearchOk(wdriver));
			logger.log(LogStatus.PASS,"Ok button","ok button in saved search is clicked ");
			
			Thread.sleep(5000);
            switchToWindow("Asset Tracker v2.2.1");
            Thread.sleep(5000);
            myExecutor.executeScript("document.getElementsByName('countryOfOriginName')[0].value='AFGHANISTAN'");
			//assetTrackAssetsPge.txt_Country(wdriver).sendKeys("AFGHANISTAN");
			Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(4000);
			Syn_Click(assetTrackAssetsPge.btn_SavedSearch(wdriver));
			logger.log(LogStatus.PASS,"Saved Search button","Saved Search button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(4000);
			Set <String> availableWindows11=wdriver.getWindowHandles();
			String Parent11 = wdriver.getWindowHandle();
			availableWindows11.remove(Parent11);
			for (String windowId : availableWindows11) 
			{
			wdriver.switchTo().window(windowId);
			}
			
			wdriver.findElement(By.xpath("(//*[@type='radio'])[2]")).click();
			Syn_Click(assetTrackAssetsPge.btn_SavedSearchOk(wdriver));
			logger.log(LogStatus.PASS,"Ok button","ok button in saved search is clicked ");
			//objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(4000);
			switchToWindow("Asset Tracker v2.2.1");
            Thread.sleep(5000);
			
            Syn_Click(assetTrackAssetsPge.btnCountryOriginId(wdriver));
            Thread.sleep(5000);
            Set <String> available=wdriver.getWindowHandles();
            if((available.size())>1){
            	logger.log(LogStatus.PASS,"Previously searched values","Previously searched values are not displayed");
    			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
            } 
            else
            {
            	logger.log(LogStatus.FAIL,"Previously searched values","Previously searched values are not displayed");
    			
            }
            
			  
		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 		
			}
		}
	
}
