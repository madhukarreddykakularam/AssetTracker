package com.nbcu.assetTracker.web.AssetModule;

import java.lang.reflect.Method;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ScanIn_SubModule extends Commonstudio
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(ScanIn_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Validation_for_Scan_In_CONTINUE_BUTTON(Method m,String username,String password) throws Exception
	{
		try
		{      
			logger.startTest(m.getName());
			System.out.println("method name"+(m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

	//Set up: Login to the Application
			assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
			WebimplicitWait(wdriver);
			String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

	//Verifying that the Login is successful
			logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
			Thread.sleep(1000);

	//Click on the Assets button in the Assets page
	        Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
	        logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
	  
	      //Click on the Scan In link in the Assets page
	        Syn_Click(assetTrackAssetsPge.lnk_ScanInAsset(wdriver));
	        logger.log(LogStatus.PASS,"Scan In link","Scan In link is clicked ");       
	        
	 //Verify that the Scan In page is displayed
	  		String VerifyScanInTitle=assetTrackAssetsPge.tit_AssetTitle(wdriver,"Scan In").getText();
	  		Assert.assertEquals("Scan In", VerifyScanInTitle);
	  		objCommStudio.getScreenshoteachStepWeb(wdriver, true);	
	  		
	 //Verify that the Current Location , Sub Location ,Continue, Support# details are displayed.
	  		Boolean verifyCurrentLocation=assetTrackAssetsPge.txt_ScanInCurrentLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Current Location","Current Location field is displayed :"+verifyCurrentLocation);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ScanInCurrentLocation(wdriver));
			
			Boolean verifyCurrentSubLocation=assetTrackAssetsPge.txt_ScanInCurrentSubLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Current Sub Location field is displayed","Current Sub Location field is displayed :"+verifyCurrentSubLocation);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_ScanInCurrentSubLocation(wdriver));
	  		
			Boolean verifyContinueButton=assetTrackAssetsPge.btn_ScanInContinue(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Continue button","Continue button is displayed :"+verifyContinueButton);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.btn_ScanInContinue(wdriver));
			
			Boolean verifySupportCentral=assetTrackAssetsPge.txt_SupportCentral(wdriver).isDisplayed();
			logger.log(LogStatus.PASS,"Support Central button","Support Central button is displayed :"+verifySupportCentral);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.txt_SupportCentral(wdriver));
			
	//Verify that the Perform inventory checkbox is checked		
			String verifyPerformInvChecked=assetTrackAssetsPge.chk_ScanInPerformInventory(wdriver).getAttribute("checked");
			Assert.assertEquals("true", verifyPerformInvChecked);
			logger.log(LogStatus.PASS,"Perform inventory Checkbox","Perform inventory Checkbox is checked :"+verifySupportCentral);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.chk_ScanInPerformInventory(wdriver));
			
	//Click on continue without entering any fields
			assetTrackAssetsPge.txt_ScanInCurrentLocation(wdriver).clear();
			assetTrackAssetsPge.txt_ScanInCurrentSubLocation(wdriver).clear();
			Syn_Click(assetTrackAssetsPge.btn_ScanInContinue(wdriver));
	        logger.log(LogStatus.PASS,"Continue button","Continue button is clicked ");
	        
	//Verify the Error messages are displayed
	        Boolean verifyCurrentLocationError=assetTrackAssetsPge.msg_ErrorMessages(wdriver,"Current Location must be specified.").isDisplayed();
			logger.log(LogStatus.PASS,"Current Location","Current Location field is displayed :"+verifyCurrentLocationError);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.msg_ErrorMessages(wdriver,"Current Location must be specified."));
			
			Boolean verifyCurrentSubLocationError=assetTrackAssetsPge.msg_ErrorMessages(wdriver,"Current Sub-Location must be specified.").isDisplayed();
			logger.log(LogStatus.PASS,"Current Location","Current Location field is displayed :"+verifyCurrentSubLocationError);
			objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackAssetsPge.msg_ErrorMessages(wdriver,"Current Location must be specified."));
	        	
			
		}
		catch (Exception | AssertionError e) {
			System.out.println(e);
			//logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
		}
	}
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void FATS_PCR_SCAN_IN_OUT_InventoryCheckbox(Method m, String username, String password) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);
			Thread.sleep(1000);

			// Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
			// menus should get displayed
			Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
			Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
			Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
			Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

			// Click on the Scan in Asset link
			Syn_Click(assetTrackAssetsPge.lnk_ScanintAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan in Asset Link Tab", "Scan in Asset Link Tab is clicked ");

			// Verify that location, Sublocation, Inventory; ppmc should get displayed
			Boolean VerifyPPMC = assetTrackAssetsPge.VerifyPPMC(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan in Tab", "PPMC Tab is displayed :" + VerifyPPMC);
			Boolean VerifyLocation = assetTrackAssetsPge.VerifyLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation);
			String VerifyLocation1 = assetTrackAssetsPge.VerifyLocation(wdriver).getText().trim();
			String Name = "* Current Location";
			Assert.assertEquals(VerifyLocation1, Name);
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation1);
			Boolean Verify_SubLocation = assetTrackAssetsPge.Verify_SubLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Verify_SubLocation Tab", "SubLocation Tab is displayed :" + Verify_SubLocation);
			String VerifySubLocation1 = assetTrackAssetsPge.Verify_SubLocation(wdriver).getText().trim();
			String Name1 = "* Current Sub-Location";
			Assert.assertEquals(VerifySubLocation1, Name1);
			logger.log(LogStatus.PASS, "Sub Location Tab", "SubLocation Tab is displayed :" + VerifySubLocation1);
			Boolean VerifyInventory = assetTrackAssetsPge.VerifyInventory(wdriver).isSelected();
			Boolean Flag = true;
			Assert.assertEquals(VerifyInventory, Flag);
			logger.log(LogStatus.PASS, "VerifyInventory Tab", "Inventory Tab is selected :" + VerifyInventory);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			assetTrackAssetsPge.txt_location(wdriver).clear();
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Continue Tab is clicked Without entering any data", "Continue Tab is clicked");

			// Validation message
			String ValidMsg1 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			Assert.assertEquals(ValidMsg1,
					"Current Location must be specified.\n" + "Current Sub-Location must be specified.");
			logger.log(LogStatus.PASS, "ValidMsg Tab", "Valid Msg  is displayed :" + ValidMsg1);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void Asset_Module_ScanIn_Positive_flow(Method m, String username, String password) throws Exception {
		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			// Step1:Login to the Application

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verify that the login is successful
			logger.log(LogStatus.PASS, "Login is suucessful",
					"Login is succesful with the login Message " + verifyLogin);
			Thread.sleep(1000);

			// Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
			// menus should get displayed
			Boolean verifyEnterAssetTab = assetTrackAssetsPge.lnk_EnterAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is displayed :" + verifyEnterAssetTab);
			Boolean verifySearchAssetTab = assetTrackAssetsPge.lnk_SeacrhAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifySearchAssetTab);
			Boolean verifyScanInTab = assetTrackAssetsPge.lnk_ScanInAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanInTab);
			Boolean verifyScanOutTab = assetTrackAssetsPge.lnk_ScanOutAsset(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Assets Tab", "Shipment Tab is displayed :" + verifyScanOutTab);

			// Click on the Search Asset link
			Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
			logger.log(LogStatus.PASS, "Search Asset Link Tab", "Search Asset Link Tab is clicked ");

			// Click on the Search for Asset tab
			Thread.sleep(2000);
			Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
			logger.log(LogStatus.PASS, "Search for Asset Tab", "Search for Asset Tab is clicked ");

			String Tracking = assetTrackAssetsPge.txt_Tracking(wdriver).getText().trim();

			// Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Scan in Asset link
			Syn_Click(assetTrackAssetsPge.lnk_ScanintAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan in Asset Link Tab", "Scan in Asset Link Tab is clicked ");

			// Verify that Enter Asset, Search Asset, Scan In Asset; Scan Out Asset sub
			// menus should get displayed
			Boolean VerifyPPMC = assetTrackAssetsPge.VerifyPPMC(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan in Tab", "PPMC Tab is displayed :" + VerifyPPMC);
			Boolean VerifyLocation = assetTrackAssetsPge.VerifyLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Location Tab", "Location Tab is displayed :" + VerifyLocation);
			Boolean Verify_SubLocation = assetTrackAssetsPge.Verify_SubLocation(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Verify_SubLocation Tab", "SubLocation Tab is displayed :" + Verify_SubLocation);
			Boolean VerifyInventory = assetTrackAssetsPge.VerifyInventory(wdriver).isSelected();
			Boolean Flag = true;
			Assert.assertEquals(VerifyInventory, Flag);
			logger.log(LogStatus.PASS, "VerifyInventory Tab", "Inventory Tab is displayed :" + VerifyInventory);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			assetTrackAssetsPge.txt_location(wdriver).clear();

			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));

			// Verify Error Message
			String ErrorMsg = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			if (ErrorMsg.equalsIgnoreCase("Current Location must be specified.")
					|| ErrorMsg.equalsIgnoreCase("Current Sub-Location must be specified.")) {
				logger.log(LogStatus.PASS, "ErrorMsg Tab", "Error Msg  is displayed :" + ErrorMsg);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			}

			String RandomValue;
			RandomValue = RandomStringUtils.randomAlphabetic(5);
			String RandomName;
			RandomName = RandomValue.toUpperCase();

			// Click Location new button and click save
			Syn_Click(assetTrackAssetsPge.Location_Newbtn(wdriver));
			switchToWindow("maintainMaintainCurrentLocations");
			Thread.sleep(1000);
			assetTrackAssetsPge.NewLocation_txt(wdriver).sendKeys(RandomName);
			Syn_Click(assetTrackAssetsPge.Btn_save(wdriver));
			Thread.sleep(7000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Location Tab", "Location is entered");
			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));

			// Verify Error Message
			String ErrorMsg1 = assetTrackAssetsPge.msg_CopyAsset(wdriver).getText().trim();
			if (ErrorMsg1.equalsIgnoreCase("Current Location must be specified.")
					|| ErrorMsg1.equalsIgnoreCase("Current Sub-Location must be specified.")) {
				logger.log(LogStatus.PASS, "ErrorMsg Tab", "Error Msg  is displayed :" + ErrorMsg1);
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			}

			// Click Sub location new button and click save
			Thread.sleep(1000);
			Syn_Click(assetTrackAssetsPge.SubLocation_Newbtn(wdriver));
			switchToWindow("maintainMaintainCurrentSubLocations");
			Thread.sleep(7000);
			WebimplicitWait(wdriver);
			// Syn_Click(assetTrackAssetsPge.NewSubLocation_txt(wdriver));
			// assetTrackAssetsPge.NewSubLocation_txt(wdriver).click();
			JavascriptExecutor jse = (JavascriptExecutor) wdriver;
			jse.executeScript("arguments[0].value='qweer';", assetTrackAssetsPge.NewSubLocation_txt(wdriver));
			// assetTrackAssetsPge.NewSubLocation_txt(wdriver).sendKeys("APEK");
			Thread.sleep(1000);
			Syn_Click(assetTrackAssetsPge.Btn_save(wdriver));
			Thread.sleep(7000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Sub Location Tab", "Sub Location is entered");

			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));

			Thread.sleep(1000);
			Boolean Verify_scanin = assetTrackAssetsPge.Verify_scanin(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Scan in Tab", "Scan Tab is displayed :" + Verify_scanin);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click on the Assets button in the Assets page
			Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");

			// Click on the Scan in Asset link
			Syn_Click(assetTrackAssetsPge.lnk_ScanintAsset(wdriver));
			logger.log(LogStatus.PASS, "Scan in Asset Link Tab", "Scan in Asset Link Tab is clicked ");

			// Click location new button and click save
			assetTrackAssetsPge.txt_location(wdriver).clear();
			Thread.sleep(2000);
			Syn_Click(assetTrackAssetsPge.btn_location(wdriver));
			Thread.sleep(5000);
			switchToWindow("Tab Search");
			Thread.sleep(1000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(10000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, " Location Tab", " Location is entered");

			// Click Sub location new button and click save
			Syn_Click(assetTrackAssetsPge.btn_sublocation(wdriver));
			Thread.sleep(2000);
			switchToWindow("Tab Search");
			Thread.sleep(1000);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			Thread.sleep(4000);
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Sub Location Tab", "Sub Location is entered");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Continue Button
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));

			// add Tracking number and press continue
			Thread.sleep(1000);
			// assetTrackAssetsPge.Tracking_txt(wdriver).sendKeys(Tracking);
			JavascriptExecutor jse1 = (JavascriptExecutor) wdriver;
			jse1.executeScript("arguments[0].value='1';", assetTrackAssetsPge.Tracking_txt(wdriver));
			Thread.sleep(1000);
			Syn_Click(assetTrackAssetsPge.btnAdd(wdriver));
			Syn_Click(assetTrackAssetsPge.Btn_Continue(wdriver));
			logger.log(LogStatus.PASS, "Tracking number", "Tracking number is entered");
			Thread.sleep(1000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Verify the status , division and Serial Number
			Boolean VerifySerial = assetTrackAssetsPge.VerifySerial(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "VerifySerial in Tab", "Serial Tab is displayed :" + VerifySerial);
			Boolean VerifyDivision = assetTrackAssetsPge.VerifyDivision(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "Division Tab", "Division Tab is displayed :" + VerifyDivision);
			Boolean Verify_status = assetTrackAssetsPge.Verify_status(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "status Tab", "status Tab is displayed :" + Verify_status);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			// Click Confirm Button
			Syn_Click(assetTrackAssetsPge.Btn_confirm(wdriver));
			logger.log(LogStatus.PASS, "Confirm Tab", "Confirm Tab is Clicked ");

			Syn_Click(assetTrackAssetsPge.Btn_Home(wdriver));
			logger.log(LogStatus.PASS, "Home Tab", "Home Tab is Clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		} catch (Exception | AssertionError e) {
			logger.log(LogStatus.FAIL, "Error Message:" + e.getMessage());
			TestReporter.logFailure("Error Message:" + e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}

}
