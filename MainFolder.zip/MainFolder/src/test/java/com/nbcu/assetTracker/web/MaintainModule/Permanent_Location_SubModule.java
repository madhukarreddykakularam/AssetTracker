package com.nbcu.assetTracker.web.MaintainModule;
//package com.nbcu.assetTracker.web;
import java.lang.reflect.Method;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_MaintainPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Permanent_Location_SubModule extends Commonstudio 
{
	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(Permanent_Location_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_MaintainPage assetTrackMaintainPage=new AssetTrack_MaintainPage();

	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void Permanent_Location_EndToEnd(Method m,String username,String password,String Action) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Set up: Firstly create a Division .
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	     logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	     Thread.sleep(1000);
	     
	//Click on the Maintain button in the Assets page
	     Syn_Click(assetTrackMaintainPage.btn_Maintain(wdriver));
	     logger.log(LogStatus.PASS,"Maintain Tab","Maintain Tab is clicked ");
	        
	//Click on the  permanent locations link
	     Syn_Click(assetTrackMaintainPage.lnk_Maintain(wdriver,"Permanent Locations"));
	    		 
	     logger.log(LogStatus.PASS,"Permanent locations Tab","Permanent locations Tab is clicked ");
	     Thread.sleep(1000);
	     
	   //Verify that the Maintain My Preferences page is displayed
		String VerifyPrefernceTitle=assetTrackMaintainPage.tit_Mantainlinks(wdriver,"Maintain Permanent Locations").getText();
		Assert.assertEquals("Maintain Permanent Locations", VerifyPrefernceTitle);
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
		 Boolean verifySaveButton=assetTrackMaintainPage.btn_SaveModel(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+verifySaveButton);
         Boolean verifyCancelButton=assetTrackMaintainPage.btn_CancelMaintain(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Cancel Button Tab is displayed :"+verifyCancelButton);
		
			
		if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
		{
			dropDownSelectJavaScript(assetTrackMaintainPage.drpdownAction(wdriver),Action);
		}
		else
		{
			Thread.sleep(3000);	
			Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
			SelectAction.selectByVisibleText(Action);
			WebimplicitWait(wdriver);
		}	
		Select SelectAction=new Select(assetTrackMaintainPage.drpdownAction(wdriver));
		
//Verify that the ADD Action is selected
		WebElement option = SelectAction.getFirstSelectedOption();
		String SelectedAction = option.getText().trim();
		Assert.assertEquals(SelectedAction, "ADD");
		logger.log(LogStatus.PASS,"ADD Action  ","ADD Action is selected ");
		//System.out.println(defaultItem );
			
//User enters New Location and Clicks on Save button.	
		int RandomValue;
		RandomValue=getRandomNumberInRange(1000,20000);
		String RandomLocation;
		RandomLocation=RandomValue+"PO";
		assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys(RandomLocation);
		Syn_Click(assetTrackMaintainPage.btn_SaveModel(wdriver));
		Thread.sleep(10000);
			
//System should save the new location in database and repopulate the parent page with newly added location.
		//Verify the Confirmation Message is populated
		//Verify that the value is entered  
		String VerifyConfirmationMsg=assetTrackMaintainPage.msg_Confirmation(wdriver).getText().trim();
		String Concatenate= "Permanent Location "+"'"+RandomLocation+"'"+ " has been added.";
		Assert.assertEquals(Concatenate, VerifyConfirmationMsg);
		objCommStudio.getScreenshoteachStepWebHighlight(wdriver, true,assetTrackMaintainPage.msg_Confirmation(wdriver));
		Thread.sleep(1000);
		
		String verifyPermLocationPopulated=assetTrackMaintainPage.txt_currentLocation(wdriver).getAttribute("value");
		Assert.assertEquals(verifyPermLocationPopulated, RandomLocation);
		logger.log(LogStatus.PASS,"Permanent Location Added ","Permanent Location Added in the parent window as : " +verifyPermLocationPopulated);
		Thread.sleep(1000);
		
//User enters New Location and Clicks on Cancel button.
		assetTrackMaintainPage.txt_newLocation(wdriver).sendKeys(RandomLocation);
		Syn_Click(assetTrackMaintainPage.btn_CancelMaintain(wdriver));
		WebimplicitWait(wdriver);
	
//Verify that the main screen is displayed after clicking on the Cancel button,without saving the data
		Thread.sleep(1000);
		String verifyMainWindow=assetTrackAssetsPge.title_Login(wdriver).getText();
		Assert.assertEquals("Welcome, Tester1", verifyMainWindow);
		logger.log(LogStatus.PASS,"Main window","Main window is displayed "+verifyMainWindow);
		Thread.sleep(1000);		
			
			
	    }
	    catch (Exception | AssertionError e) {
	     System.out.println(e);
	     logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
		 TestReporter.logFailure("Error Message:"+e.getMessage());
		  objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true); 
	    }
}   

}
