package com.nbcu.assetTracker.web.ShipMentModule;

import static org.testng.Assert.assertTrue;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_ShipmentsPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class EnterShipment_Submodule extends Commonstudio{

	PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    ExtentReports logger = ExtentReports.get(SearchShipment_Submodule.class);
    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
    AssetTrack_ShipmentsPage assetTrackShipmentsPge=new AssetTrack_ShipmentsPage();
    
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void ShipmentModule_Insert_Shipment_NewShipment(Method m,String username,String password) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Step1:Login to the Application
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	    logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	    Thread.sleep(1000);
	     
	//Click on the Shipments tab
	 // Click on the Shipments tab
	   /* Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
		logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");

		//Click on the Search Asset link
		Syn_Click(assetTrackAssetsPge.lnk_SeacrhAsset(wdriver));
		logger.log(LogStatus.PASS,"Search Asset Link Tab","Search Asset Link Tab is clicked ");
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		//Perform a blank search of the Asset 
		Syn_Click(assetTrackAssetsPge.btn_SearchForAssets(wdriver));
		logger.log(LogStatus.PASS,"Search For Assets button","Search For Assets button is clicked ");
		WebimplicitWait(wdriver);
		Thread.sleep(3000);*/
		//List<WebElement> trackingnumbers=wdriver.findElements(By.xpath("//tr/td[@class='dataCenter'][2]"));
		
	    Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
	    logger.log(LogStatus.PASS, "Shipments Tab", "Shipments Tab is clicked ");
	    Thread.sleep(3000);
	    // Click on Enter shipment
	    Syn_Click(assetTrackShipmentsPge.lnk_EnterShipment(wdriver));
	    logger.log(LogStatus.PASS,"Enter shipment button","Enter shipment button is clicked ");
	    // Shipment page
	    Thread.sleep(1000);
	    Boolean verifyYesButton = assetTrackShipmentsPge.txt_ShipmentPage(wdriver).isDisplayed();
	    logger.log(LogStatus.PASS, "Shipment Page should be displayed" + verifyYesButton);

	    // Edit Address button corresponding to ship from
	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditAddress(wdriver));
	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	    Thread.sleep(5000);
	    switchToWindow("Ship From: Address Info");
	    Thread.sleep(5000);

	    assetTrackShipmentsPge.txt_searchsitefrom(wdriver).sendKeys("1A");
	    Syn_Click(assetTrackShipmentsPge.btn_searchsitefromtab(wdriver));
	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	    
	    Thread.sleep(5000);

	    assetTrackShipmentsPge.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	    Syn_Click(assetTrackShipmentsPge.btn_searchattn(wdriver));
	    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
	    Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    Thread.sleep(5000);
	    switchToWindow("Ship From: Address Info");
	    Thread.sleep(5000);
	    // click on save
	    WebElement country= wdriver.findElement(By.xpath("//select[@name='country']"));
	    Select selectcntry=new Select(country);
	    selectcntry.selectByVisibleText("UNITED KINGDOM");
	    /*dropDownSelectJavaScript(country, "UNITED KINGDOM");
	    Thread.sleep(4000);
	    dropDownSelectJavaScript(country, "UNITED KINGDOM");
	    */
	    Thread.sleep(4000);
	    Syn_Click(assetTrackShipmentsPge.txt_faxNo(wdriver));
	    Thread.sleep(2000);
	    
	    boolean state=assetTrackShipmentsPge.Addressinfo_StateDisabled(wdriver).isDisplayed();
	    logger.log(LogStatus.PASS,"State field","State field is disabled:"+state);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    	
	    WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    Select selectdd=new Select(Province);
	    String DefaultValue=selectdd.getFirstSelectedOption().getText();
	    Assert.assertEquals(DefaultValue, "SELECT A PROVINCE");
    		logger.log(LogStatus.PASS,"Province default Value","Province default Value :"+DefaultValue);
    	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    	dropDownSelectJavaScript(Province, "AVON");
	    Thread.sleep(4000);
	    String Faxno=assetTrackShipmentsPge.txt_faxNo(wdriver).getText();
	    
	    
	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	    logger.log(LogStatus.PASS,"save button","save  button is clicked ");
	    
	    Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(10000);
	    // Edit Address button corresponding to Shipto
	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditTo(wdriver));
	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	    
	    Thread.sleep(5000);
	    switchToWindow("Consigned To: Address Info");
	    Thread.sleep(5000);

	    JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
	       myExecutor.executeScript("document.getElementsByName('locationName')[0].value='1A'");
	    Thread.sleep(5000);

	    //assetTrackShipmentsPge.txt_searchsitefrom(wdriver).sendKeys("1A");
	    Syn_Click(assetTrackShipmentsPge.btn_searchsitefromtab(wdriver));
	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	    Thread.sleep(5000);
	    //assetTrackShipmentsPge.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	     myExecutor.executeScript("document.getElementsByName('attention')[0].value=' ABC, ABC'");
	    Syn_Click(assetTrackShipmentsPge.btn_searchattn(wdriver));
	    logger.log(LogStatus.PASS,"ATTN","ATTN is clicked ");
	    Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    Thread.sleep(5000);
	    switchToWindow("Consigned To: Address Info");
	    Thread.sleep(5000);
	    // click on save
	    WebElement country1= wdriver.findElement(By.xpath("//select[@name='country']"));
	    Select selectcntry1=new Select(country1);
	    selectcntry1.selectByVisibleText("UNITED KINGDOM");
	    /*dropDownSelectJavaScript(country1, "UNITED KINGDOM");
	    Thread.sleep(3000);
	    dropDownSelectJavaScript(country1, "UNITED KINGDOM");*/
	    Thread.sleep(3000);
	    Syn_Click(assetTrackShipmentsPge.txt_faxNo(wdriver));
	    Thread.sleep(2000);
	    
	    boolean state1=assetTrackShipmentsPge.Addressinfo_StateDisabled(wdriver).isDisplayed();
	    logger.log(LogStatus.PASS,"State field","State field is disabled:"+state1);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    //WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    //Select selectdd=new Select(Province);
        WebElement Province1= wdriver.findElement(By.xpath("//select[@name='province']"));
	    Select selectdd1=new Select(Province1);
	    String DefaultValue1=selectdd1.getFirstSelectedOption().getText();
	    Assert.assertEquals(DefaultValue1, "SELECT A PROVINCE");
    	logger.log(LogStatus.PASS,"Province default Value","Province default Value :"+DefaultValue1);
    	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    	selectdd1.selectByVisibleText("AVON");
    	//dropDownSelectJavaScript(Province, "AVON");
	    Thread.sleep(4000);
	    
	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	    logger.log(LogStatus.PASS, "Click on save button  ");
	    Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
	    Boolean requestedBy=assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Requested By field","Requested By field is displayed :"+requestedBy);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver));
        myExecutor.executeScript("document.getElementsByName('requestedBy')[0].value='Test'");
        //assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver).sendKeys("Test");
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_RequestedByLookUp(wdriver));
        Thread.sleep(10000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    Thread.sleep(5000);
	    
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
        
	    Boolean TotalWeight=assetTrackShipmentsPge.WaybillManifestPage_TotalWeight(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Total Weight By field","Total Weight By field is displayed :"+TotalWeight);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Boolean TotalValue=assetTrackShipmentsPge.WaybillManifestPage_TotalValue(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Total Value field","Total Value field is displayed :"+TotalValue);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
        Boolean ShipmentApprover=assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is displayed :"+ShipmentApprover);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver));
        Thread.sleep(2000);
        Boolean ShipmentApproverChecked=assetTrackShipmentsPge.WaybillPage_ShipmentApproverCheckBox_Checked(wdriver).isDisplayed();
        Assert.assertTrue(ShipmentApproverChecked);
        logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is checked :"+ShipmentApproverChecked);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver));
        Thread.sleep(2000);
        Boolean ShipmentApproverUnChecked=assetTrackShipmentsPge.WaybillPage_ShipmentApproverCheckBox_UnChecked(wdriver).isDisplayed();
        Assert.assertTrue(ShipmentApproverUnChecked);
        
        logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is Unchecked :"+ShipmentApproverUnChecked);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        String Shipfrom=assetTrackShipmentsPge.WaybillPage_FromLocation(wdriver).getText();
        assertTrue(Shipfrom.contains("FAX:"+Faxno));
        logger.log(LogStatus.PASS,"Verification Successfull","Verified Fax number is displayed in ship from text");
	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    Thread.sleep(1000);
        
	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditAddress(wdriver));
	    logger.log(LogStatus.PASS, "Click on Edit Address button corresponding to ship from ");
	    Thread.sleep(5000);
	    switchToWindow("Ship From: Address Info");
	    Thread.sleep(4000);
	    logger.log(LogStatus.PASS,"Address Info","Address Info is displayed");
	    myExecutor.executeScript("document.getElementsByName('city')[0].value='Test'");
	    //assetTrackShipmentsPge.txt_City(wdriver).sendKeys("Test");
	    Thread.sleep(1000);
	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	    logger.log(LogStatus.PASS, "Click on save button");
	    Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(4000);
	    
	    Boolean DateRequested=assetTrackShipmentsPge.WayBillPage_DateRequested(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"DateRequested","DateRequested is displayed :"+DateRequested);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	  
        Boolean ShipDate=assetTrackShipmentsPge.WayBillPage_ShipDate(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"ShipDate field","ShipDate field is displayed :"+ShipDate);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean DeliveryRequired=assetTrackShipmentsPge.WayBillPage_DeliveryRequired(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"DeliveryRequired field","DeliveryRequired field is displayed :"+DeliveryRequired);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean ExpectedReturnDate=assetTrackShipmentsPge.WayBillPage_ExpectedReturnDate(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Expected Return Date field","Expected Return Date field is displayed :"+ExpectedReturnDate);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        assetTrackShipmentsPge.txt_currentlocation(wdriver).clear();
        Thread.sleep(3000);
        //WebElement loc = wdriver.findElementByXPath("(//div[@class='tabImage'])[1]");
        Thread.sleep(3000);
       // myExecutor.executeScript("arguments[0].click();", loc);
        Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentLocationLookUp(wdriver));
        
        Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
        Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtab(wdriver));
	    logger.log(LogStatus.PASS, "Selected current sub location  ");

	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtabsearch(wdriver));
	    Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    logger.log(LogStatus.PASS,"Current sublocation field","Current sublocation field is entered");
        Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
	    
	    assetTrackShipmentsPge.txt_courier(wdriver).sendKeys("123");
	    assetTrackShipmentsPge.txt_waybillinfo(wdriver).sendKeys("1234");

	    WebElement element4 = wdriver.findElementByXPath("//input[@name='shipDate']");
	    selectDateJavScriptExe("25/12/2017", element4);

	    WebElement element5 = wdriver.findElementByXPath("//input[@name='expectedReturnDate']");
	    selectDateJavScriptExe("25/12/2019", element5);
	    
	    Syn_Click(assetTrackShipmentsPge.WayBillPage_AddCaseButton(wdriver));
	    logger.log(LogStatus.PASS, "Add Case button");

	    Boolean caseDetailsPage=assetTrackShipmentsPge.CaseDetailsPage(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Case Details page","Case Details page is displayed :"+caseDetailsPage);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean CaseTrackingNumber=assetTrackShipmentsPge.CaseDetailsPage_CaseTrackingNo(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Case Tracking Number field","Case Tracking Number is displayed :"+CaseTrackingNumber);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Syn_Click(assetTrackShipmentsPge.btn_AddUnits(wdriver));
	   // logger.log(LogStatus.PASS, "Add units button");
	    logger.log(LogStatus.PASS,"Add units button","Add Assests to shipments page is clicked ");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       /* String Trackingno1="0987654321";
		String Trackingno2="10099T";
		String Trackingno3="1012836";
		String Trackingno4="10132895";
		*/
        Thread.sleep(5000);
        myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10132895'");
       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	    Thread.sleep(2000);
	    myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10204T'");
	   // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno2);
        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	    Thread.sleep(2000);
	    myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='1012836'");
	   // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno3);
        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	    Thread.sleep(2000);
	    myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10204T1'");
	  //  assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno4);
        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	    Thread.sleep(4000);
	    /*for(int i=0;i<4;i++){
	    String Number=trackingnumbers.get(i).getText();
	    Thread.sleep(2000);
	    assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Number);
    	//assetTrackShipmentsPge.AddAssets_TrackingNumber(wdriver).sendKeys(Number);
	    Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	    Thread.sleep(2000);
	    }*/
	    Syn_Click(assetTrackShipmentsPge.btn_AddCaseContinue(wdriver));
	    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
	    Thread.sleep(3000);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
        Thread.sleep(3000);
        logger.log(LogStatus.PASS,"Save button","Save is clicked");
        WebDriverWait wait = new WebDriverWait(wdriver, 50);
        /*wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = wdriver.switchTo().alert();
        Thread.sleep(1000);
        alert.getText();
        // alert handling
        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
        Thread.sleep(1000);
        alert.accept();*/

        /*Alert alert1= wdriver.switchTo().alert();
        alert1.accept();*/
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
        Syn_Click(assetTrackShipmentsPge.btn_entershipment_finish(wdriver));
        logger.log(LogStatus.PASS,"Finish button","Finish is clicked");
        Thread.sleep(3000);
        
        //WebDriverWait wait = new WebDriverWait(wdriver, 50);
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert1 = wdriver.switchTo().alert();
        Thread.sleep(1000);
        alert1.getText();
        // alert handling
        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert1.getText());
        Thread.sleep(1000);
        alert1.accept();
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
       
		String ShipmentNumber=assetTrackShipmentsPge.WayBillPage_ShipmentNumber(wdriver).getText();
        String ProFormaInvoice=assetTrackShipmentsPge.WayBillPage_ProFormaInvoice(wdriver).getText();
        Assert.assertEquals(ShipmentNumber, ProFormaInvoice);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified Shipment Id and Pro-Forma Invoices are same");
	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    Thread.sleep(4000);
	    
        Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
        logger.log(LogStatus.PASS,"Update Shipment button","Update Shipment is clicked");
        Thread.sleep(5000);
        
        Syn_Click(assetTrackShipmentsPge.CaseDetails_ExpandButton1(wdriver));
        logger.log(LogStatus.PASS,"Expand button","Expand button is clicked");
	    
        Boolean EditItems=assetTrackShipmentsPge.CaseDetails_EditItems(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"EditItems button","EditItems is displayed :"+EditItems);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	  
        Boolean RemoveItems=assetTrackShipmentsPge.CaseDetails_RemoveItems(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"RemoveItems button","RemoveItems button is displayed :"+RemoveItems);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Syn_Click(assetTrackShipmentsPge.btn_entershipment_finish(wdriver));
        logger.log(LogStatus.PASS,"Finish button","Finish is clicked");
        Thread.sleep(3000);
        wait.until(ExpectedConditions.alertIsPresent());
        Alert alert11 = wdriver.switchTo().alert();
        Thread.sleep(1000);
        alert11.getText();
        // alert handling
        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert11.getText());
        Thread.sleep(1000);
        alert11.accept();
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
       
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		logger.log(LogStatus.PASS,"Waybill / Manifest Details page","Waybill / Manifest Details page is clicked");
        
	    }       

	//Verify that the Shipment is saved
	    catch (Exception | AssertionError e) {
	     System.out.println(e);
	     logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
	    }
	}   
	
	
	
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void ShipmentModule_ShipAsset_PositiveFlow(Method m,String username,String password) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Step1:Login to the Application
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	    logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	    Thread.sleep(1000);
	     
	    Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
	    logger.log(LogStatus.PASS, "Shipments Tab", "Shipments Tab is clicked ");
	    Thread.sleep(3000);
	    // Click on Enter shipment
	    Syn_Click(assetTrackShipmentsPge.lnk_EnterShipment(wdriver));
	    logger.log(LogStatus.PASS,"Enter shipment button","Enter shipment button is clicked ");
	    // Shipment page
	    Thread.sleep(1000);
	    Boolean verifyYesButton = assetTrackShipmentsPge.txt_ShipmentPage(wdriver).isDisplayed();
	    logger.log(LogStatus.PASS, "Shipment Page should be displayed" + verifyYesButton);

	    // Edit Address button corresponding to ship from
	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditAddress(wdriver));
	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	    Thread.sleep(5000);
	    switchToWindow("Ship From: Address Info");
	    Thread.sleep(5000);

	    assetTrackShipmentsPge.txt_searchsitefrom(wdriver).sendKeys("1A");
	    Syn_Click(assetTrackShipmentsPge.btn_searchsitefromtab(wdriver));
	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	    
	    Thread.sleep(5000);

	    assetTrackShipmentsPge.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	    Syn_Click(assetTrackShipmentsPge.btn_searchattn(wdriver));
	    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
	    Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    Thread.sleep(5000);
	    switchToWindow("Ship From: Address Info");
	    Thread.sleep(5000);
	    logger.log(LogStatus.PASS,"ATTN	field","ATTN field is entered");
	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    // click on save
	    
	    WebElement country= wdriver.findElement(By.xpath("//select[@name='country']"));
	    Select selectcntry=new Select(country);
	    selectcntry.selectByVisibleText("UNITED KINGDOM");
	    /*dropDownSelectJavaScript(country, "UNITED KINGDOM");
	    Thread.sleep(4000);
	    dropDownSelectJavaScript(country, "UNITED KINGDOM");
	    */
	    Thread.sleep(4000);
	    Syn_Click(assetTrackShipmentsPge.txt_faxNo(wdriver));
	    Thread.sleep(2000);
	    
	    boolean state=assetTrackShipmentsPge.Addressinfo_StateDisabled(wdriver).isDisplayed();
	    logger.log(LogStatus.PASS,"State field","State field is disabled:"+state);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    	
	    WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    Select selectdd=new Select(Province);
	    String DefaultValue=selectdd.getFirstSelectedOption().getText();
	    Assert.assertEquals(DefaultValue, "SELECT A PROVINCE");
    		logger.log(LogStatus.PASS,"Province default Value","Province default Value :"+DefaultValue);
    	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    	dropDownSelectJavaScript(Province, "AVON");
	    Thread.sleep(4000);
	    String Faxno=assetTrackShipmentsPge.txt_faxNo(wdriver).getText();
	    
	    
	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	    logger.log(LogStatus.PASS,"save button","save  button is clicked ");
	    
	    Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(10000);
	    // Edit Address button corresponding to Shipto
	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditTo(wdriver));
	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	    
	    Thread.sleep(5000);
	    switchToWindow("Consigned To: Address Info");
	    Thread.sleep(5000);

	    JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
	       myExecutor.executeScript("document.getElementsByName('locationName')[0].value='1A'");
	    Thread.sleep(5000);

	    //assetTrackShipmentsPge.txt_searchsitefrom(wdriver).sendKeys("1A");
	    Syn_Click(assetTrackShipmentsPge.btn_searchsitefromtab(wdriver));
	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	    Thread.sleep(5000);
	    //assetTrackShipmentsPge.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	     myExecutor.executeScript("document.getElementsByName('attention')[0].value=' ABC, ABC'");
	    Syn_Click(assetTrackShipmentsPge.btn_searchattn(wdriver));
	    logger.log(LogStatus.PASS,"ATTN","ATTN is clicked ");
	    Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    Thread.sleep(5000);
	    switchToWindow("Consigned To: Address Info");
	    Thread.sleep(5000);
	    // click on save
	    WebElement country1= wdriver.findElement(By.xpath("//select[@name='country']"));
	    Select selectcntry1=new Select(country1);
	    selectcntry1.selectByVisibleText("UNITED KINGDOM");
	    /*dropDownSelectJavaScript(country1, "UNITED KINGDOM");
	    Thread.sleep(3000);
	    dropDownSelectJavaScript(country1, "UNITED KINGDOM");*/
	    Thread.sleep(3000);
	    Syn_Click(assetTrackShipmentsPge.txt_faxNo(wdriver));
	    Thread.sleep(2000);
	    
	    boolean state1=assetTrackShipmentsPge.Addressinfo_StateDisabled(wdriver).isDisplayed();
	    logger.log(LogStatus.PASS,"State field","State field is disabled:"+state1);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    //WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	    //Select selectdd=new Select(Province);
        WebElement Province1= wdriver.findElement(By.xpath("//select[@name='province']"));
	    Select selectdd1=new Select(Province1);
	    String DefaultValue1=selectdd1.getFirstSelectedOption().getText();
	    Assert.assertEquals(DefaultValue1, "SELECT A PROVINCE");
    	logger.log(LogStatus.PASS,"Province default Value","Province default Value :"+DefaultValue1);
    	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
    	selectdd1.selectByVisibleText("AVON");
    	//dropDownSelectJavaScript(Province, "AVON");
	    Thread.sleep(4000);
	    
	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	    logger.log(LogStatus.PASS, "Click on save button  ");
	    Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
	    Boolean requestedBy=assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Requested By field","Requested By field is displayed :"+requestedBy);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver));
        myExecutor.executeScript("document.getElementsByName('requestedBy')[0].value='Test'");
        //assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver).sendKeys("Test");
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_RequestedByLookUp(wdriver));
        Thread.sleep(10000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    Thread.sleep(5000);
	    
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
        
	    Boolean TotalWeight=assetTrackShipmentsPge.WaybillManifestPage_TotalWeight(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Total Weight By field","Total Weight By field is displayed :"+TotalWeight);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Boolean TotalValue=assetTrackShipmentsPge.WaybillManifestPage_TotalValue(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Total Value field","Total Value field is displayed :"+TotalValue);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
        Boolean ShipmentApprover=assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is displayed :"+ShipmentApprover);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver));
        Thread.sleep(2000);
        Boolean ShipmentApproverChecked=assetTrackShipmentsPge.WaybillPage_ShipmentApproverCheckBox_Checked(wdriver).isDisplayed();
        Assert.assertTrue(ShipmentApproverChecked);
        logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is checked :"+ShipmentApproverChecked);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver));
        Thread.sleep(2000);
        Boolean ShipmentApproverUnChecked=assetTrackShipmentsPge.WaybillPage_ShipmentApproverCheckBox_UnChecked(wdriver).isDisplayed();
        Assert.assertTrue(ShipmentApproverUnChecked);
        
        logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is Unchecked :"+ShipmentApproverUnChecked);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        String Shipfrom=assetTrackShipmentsPge.WaybillPage_FromLocation(wdriver).getText();
        assertTrue(Shipfrom.contains("FAX:"+Faxno));
        logger.log(LogStatus.PASS,"Verification Successfull","Verified Fax number is displayed in ship from text");
	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    Thread.sleep(1000);
        
	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditAddress(wdriver));
	    logger.log(LogStatus.PASS, "Click on Edit Address button corresponding to ship from ");
	    Thread.sleep(5000);
	    switchToWindow("Ship From: Address Info");
	    Thread.sleep(4000);
	    logger.log(LogStatus.PASS,"Address Info","Address Info is displayed");
	    myExecutor.executeScript("document.getElementsByName('city')[0].value='Test'");
	    //assetTrackShipmentsPge.txt_City(wdriver).sendKeys("Test");
	    Thread.sleep(1000);
	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	    logger.log(LogStatus.PASS, "Click on save button");
	    Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(4000);
	    
	    Boolean DateRequested=assetTrackShipmentsPge.WayBillPage_DateRequested(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"DateRequested","DateRequested is displayed :"+DateRequested);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	  
        Boolean ShipDate=assetTrackShipmentsPge.WayBillPage_ShipDate(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"ShipDate field","ShipDate field is displayed :"+ShipDate);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean DeliveryRequired=assetTrackShipmentsPge.WayBillPage_DeliveryRequired(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"DeliveryRequired field","DeliveryRequired field is displayed :"+DeliveryRequired);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean ExpectedReturnDate=assetTrackShipmentsPge.WayBillPage_ExpectedReturnDate(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Expected Return Date field","Expected Return Date field is displayed :"+ExpectedReturnDate);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
        assetTrackShipmentsPge.txt_currentlocation(wdriver).clear();
        Thread.sleep(3000);
        //WebElement loc = wdriver.findElementByXPath("(//div[@class='tabImage'])[1]");
        Thread.sleep(3000);
       // myExecutor.executeScript("arguments[0].click();", loc);
        Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentLocationLookUp(wdriver));
        
        Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
        Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtab(wdriver));
	    logger.log(LogStatus.PASS, "Selected current sub location  ");

	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtabsearch(wdriver));
	    Thread.sleep(5000);
	    switchToWindow("Tab Search");
	    Thread.sleep(5000);
	    selValueWindow(wdriver);
	    logger.log(LogStatus.PASS,"Current sublocation field","Current sublocation field is entered");
        Thread.sleep(5000);
	    switchToWindow("Asset Tracker v2.2.1");
	    Thread.sleep(5000);
	    
	    //assetTrackShipmentsPge.txt_courier(wdriver).sendKeys("123");
	    myExecutor.executeScript("document.getElementsByName('courier')[0].value='123'");
	   //assetTrackShipmentsPge.txt_waybillinfo(wdriver).sendKeys("1234");
	    myExecutor.executeScript("document.getElementsByName('waybillInfo')[0].value='1234'");
	    
	    logger.log(LogStatus.PASS,"Courier and Fax number","Courier and Fax number details are entered");
	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    WebElement element4 = wdriver.findElementByXPath("//input[@name='shipDate']");
	    selectDateJavScriptExe("27/12/2017", element4);
	    WebElement dateRequested = wdriver.findElementByXPath("//input[@name='dateRequested']");
	    selectDateJavScriptExe("27/12/2017", dateRequested);
	    WebElement deliveryRequiredBy = wdriver.findElementByXPath("//input[@name='deliveryRequiredBy']");
	    selectDateJavScriptExe("27/12/2017", deliveryRequiredBy);
	    WebElement element5 = wdriver.findElementByXPath("//input[@name='expectedReturnDate']");
	    selectDateJavScriptExe("27/12/2019", element5);
	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	    
	    
	    myExecutor.executeScript("document.getElementsByName('assignment')[0].value='1234'");Thread.sleep(3000);
	    Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
        logger.log(LogStatus.PASS,"Save button","Save is clicked");
        WebDriverWait wait = new WebDriverWait(wdriver, 50);
        /*wait.until(ExpectedConditions.alertIsPresent());
        Alert alert = wdriver.switchTo().alert();
        Thread.sleep(1000);
        alert.getText();
        // alert handling
        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
        Thread.sleep(1000);
        alert.accept();*/

        /*Alert alert1= wdriver.switchTo().alert();
        alert1.accept();*/
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
			logger.log(LogStatus.PASS,"Save","Entered Values are saved");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        Thread.sleep(3000);
		
		Syn_Click(assetTrackShipmentsPge.WayBillPage_AddCaseButton(wdriver));
		    logger.log(LogStatus.PASS, "Add Case button");
		    Thread.sleep(3000);
		    myExecutor.executeScript("document.getElementsByName('weightLB')[0].value='12'");
		    
	    Syn_Click(assetTrackShipmentsPge.btn_AddUnits(wdriver));
		   // logger.log(LogStatus.PASS, "Add units button");
		    logger.log(LogStatus.PASS,"Add units button","Add Assests to shipments page is clicked ");
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	       /* String Trackingno1="0987654321";
			String Trackingno2="10099T";
			String Trackingno3="1012836";
			String Trackingno4="10132895";
			*/
	        Thread.sleep(5000);
	        myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10413T'");
	       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
	        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
		    Thread.sleep(2000);
		    
		    Syn_Click(assetTrackShipmentsPge.btn_AddCaseContinue(wdriver));
		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
		    Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		
	        Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
	        logger.log(LogStatus.PASS,"Save button","Save is clicked");
	        //WebDriverWait wait1 = new WebDriverWait(wdriver, 50);
	        /*wait1.until(ExpectedConditions.alertIsPresent());
	        Alert alert = wdriver.switchTo().alert();
	        Thread.sleep(1000);
	        alert.getText();
	        // alert handling
	        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
	        Thread.sleep(1000);
	        alert.accept();*/

	        /*Alert alert1= wdriver.switchTo().alert();
	        alert1.accept();*/
	        WebimplicitWait(wdriver); 
			Thread.sleep(3000);
		
			Syn_Click(assetTrackShipmentsPge.CaseDetails_EditItems(wdriver));
	        logger.log(LogStatus.PASS,"Edit Items","Edit Items is clicked");
	        Thread.sleep(3000);
			
	        Syn_Click(assetTrackShipmentsPge.EditItems_Override_CVCheckBox(wdriver));
	        logger.log(LogStatus.PASS,"CheckBox","CheckBox is selected");
	        Thread.sleep(3000);
	        assetTrackShipmentsPge.EditItems_CountryOfOrigin(wdriver).clear();
	        Thread.sleep(2000);
	        
	        Syn_Click(assetTrackShipmentsPge.EditItems_CountryOfOrigin_LookUp(wdriver));
	        logger.log(LogStatus.PASS,"Country of Origin Lookup","Country of Origin Lookup is clicked");
	        Thread.sleep(5000);
		    switchToWindow("Tab Search");
		    Thread.sleep(5000);
		    selValueWindow(wdriver);
		    logger.log(LogStatus.PASS,"Country of Origin","Country of Origin is Selected");
	        Thread.sleep(5000);
		    switchToWindow("Asset Tracker v2.2.1");
		    Thread.sleep(5000);
		    logger.log(LogStatus.PASS,"Country of Origin","Country of Origin is Updated");
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	       
	        Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
	        logger.log(LogStatus.PASS,"Save button","Save is clicked");
	        Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		       
	        Syn_Click(assetTrackShipmentsPge.CaseDetails_RemoveItems(wdriver));
	        logger.log(LogStatus.PASS,"Remove button","Remove button is clicked");
	        Thread.sleep(3000);
	        
	        WebDriverWait wait11 = new WebDriverWait(wdriver, 50);
	        wait11.until(ExpectedConditions.alertIsPresent());
	        Alert alert1 = wdriver.switchTo().alert();
	        Thread.sleep(1000);
	        alert1.getText();
	        // alert handling
	        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert1.getText());
	        Thread.sleep(1000);
	        alert1.dismiss();

	        /*Alert alert1= wdriver.switchTo().alert();
	        alert1.accept();*/
	        WebimplicitWait(wdriver); 
			Thread.sleep(3000);
			
			Boolean verifyYesButton1 = assetTrackShipmentsPge.txt_ShipmentPage(wdriver).isDisplayed();
		    logger.log(LogStatus.PASS, "Shipment Page should be displayed" + verifyYesButton1);
		    Syn_Click(assetTrackShipmentsPge.CaseDetails_RemoveItems(wdriver));
	        logger.log(LogStatus.PASS,"Remove button","Remove button is clicked");
	        Thread.sleep(3000);
	        WebDriverWait wait2 = new WebDriverWait(wdriver, 50);
		    wait2.until(ExpectedConditions.alertIsPresent());
	        Alert alert11 = wdriver.switchTo().alert();
	        Thread.sleep(1000);
	        alert11.getText();
	        // alert handling
	        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert11.getText());
	        Thread.sleep(1000);
	        alert11.accept();

	        /*Alert alert1= wdriver.switchTo().alert();
	        alert1.accept();*/
	        WebimplicitWait(wdriver); 
			Thread.sleep(3000);
		    try{
			Boolean RemoveButton = assetTrackShipmentsPge.CaseDetails_RemoveItems(wdriver).isDisplayed();
		    }
		    catch(Exception e){
		    	logger.log(LogStatus.PASS,"Case","Case is removed");
		    }
		    Thread.sleep(3000);
	        
	        Syn_Click(assetTrackShipmentsPge.WayBillPage_AddCaseButton(wdriver));
		    logger.log(LogStatus.PASS, "Add Case button");
		    Thread.sleep(3000);
		    Boolean caseDetailsPage=assetTrackShipmentsPge.CaseDetailsPage(wdriver).isDisplayed();
	        logger.log(LogStatus.PASS,"Case Details page","Case Details page is displayed :"+caseDetailsPage);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
	        String txt_CaseNumber =assetTrackShipmentsPge.caseDetails_CaseNumber(wdriver).getAttribute("value");
	        Assert.assertEquals(txt_CaseNumber, "1");
	        logger.log(LogStatus.PASS,"Case Number","Case Number is displayed as "+txt_CaseNumber);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
	        Syn_Click(assetTrackShipmentsPge.CaseDetails_Cancelbutton(wdriver));
		    logger.log(LogStatus.PASS,"Cancel button","Cancel button is clicked");
	        Thread.sleep(3000);
	        Boolean verifyYesButton11 = assetTrackShipmentsPge.txt_ShipmentPage(wdriver).isDisplayed();
		    logger.log(LogStatus.PASS, "Shipment Page should be displayed" + verifyYesButton11);
		    
		    Syn_Click(assetTrackShipmentsPge.WayBillPage_AddCaseButton(wdriver));
		    logger.log(LogStatus.PASS, "Add Case button");
		    Thread.sleep(3000);
		    myExecutor.executeScript("document.getElementsByName('weightLB')[0].value='12'");
		    
		    Syn_Click(assetTrackShipmentsPge.btn_AddUnits(wdriver));
		   // logger.log(LogStatus.PASS, "Add units button");
		    logger.log(LogStatus.PASS,"Add units button","Add Assests to shipments page is clicked ");
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	       /* String Trackingno1="0987654321";
			String Trackingno2="10099T";
			String Trackingno3="1012836";
			String Trackingno4="10132895";
			*/
	        Thread.sleep(5000);
	        myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10834T'");
	       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
	        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
		    Thread.sleep(2000);
		    
		    Syn_Click(assetTrackShipmentsPge.btn_AddCaseContinue(wdriver));
		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
		    Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	       
	        Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
	        logger.log(LogStatus.PASS,"Save button","Save is clicked");
	        //WebDriverWait wait = new WebDriverWait(wdriver, 50);
	           
        Syn_Click(assetTrackShipmentsPge.btn_entershipment_finish(wdriver));
        logger.log(LogStatus.PASS,"Finish button","Finish is clicked");
        Thread.sleep(3000);
        
        WebDriverWait wait3 = new WebDriverWait(wdriver, 50);
        wait3.until(ExpectedConditions.alertIsPresent());
        Alert alert12 = wdriver.switchTo().alert();
        Thread.sleep(3000);
        alert12.getText();
        // alert handling
        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert12.getText());
        Thread.sleep(4000);
        alert12.accept();
        WebimplicitWait(wdriver); 
		Thread.sleep(3000);
       try{
		Boolean Finishbut = assetTrackShipmentsPge.btn_entershipment_finish(wdriver).isDisplayed();
       }
       catch(Exception e){
		logger.log(LogStatus.PASS,"Shipment details","Shipment details are updated");
       }
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean LatUpdatedOn = assetTrackShipmentsPge.WayBill_LatUpdatedOn(wdriver).isDisplayed();
		Assert.assertTrue(LatUpdatedOn);
		logger.log(LogStatus.PASS,"Last Updated On details","Last Updated On details are displayed");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        Boolean LatUpdatedBy = assetTrackShipmentsPge.WayBill_LatUpdatedBy(wdriver).isDisplayed();
		Assert.assertTrue(LatUpdatedBy);
		logger.log(LogStatus.PASS,"Last Updated By details","Last Updated By details are displayed");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		
		
        
	    }       

	//Verify that the Shipment is saved
	    catch (Exception | AssertionError e) {
	     System.out.println(e);
	     logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
	    }
	}
	
	
	
	
	
	@Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
	public void ShipmentModule_ShipAssetAlternateFlow(Method m,String username,String password) throws Exception
	{
	    try
	    {   
	     
	     logger.startTest(m.getName());
	     System.out.println("method name"+(m.getName()));
	     TestReporter.logStep("Start test execution of " + m.getName());
	     TestReporter.logStep("Launch Asset Tracker ");
	     
	//Step1:Login to the Application
	     assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
	     WebimplicitWait(wdriver);
	     String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
	     Assert.assertEquals("Welcome, Tester1", verifyLogin);
	     
	//Verifying that the Login is successful
	    
	    logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
	    Thread.sleep(1000);
	 	     
	 	    Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
	 	    logger.log(LogStatus.PASS, "Shipments Tab", "Shipments Tab is clicked ");
	 	    Thread.sleep(3000);
	 	    // Click on Enter shipment
	 	    Syn_Click(assetTrackShipmentsPge.lnk_EnterShipment(wdriver));
	 	    logger.log(LogStatus.PASS,"Enter shipment button","Enter shipment button is clicked ");
	 	    // Shipment page
	 	    Thread.sleep(1000);
	 	    Boolean verifyYesButton = assetTrackShipmentsPge.txt_ShipmentPage(wdriver).isDisplayed();
	 	    logger.log(LogStatus.PASS, "Shipment Page should be displayed" + verifyYesButton);
	 	    
	 	    
	 	    
	 	    // Edit Address button corresponding to ship from
	 	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditAddress(wdriver));
	 	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Ship From: Address Info");
	 	    Thread.sleep(5000);
	 	  
	 	    assetTrackShipmentsPge.txt_searchsitefrom(wdriver).sendKeys("1A");
	 	    Syn_Click(assetTrackShipmentsPge.btn_searchsitefromtab(wdriver));
	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	 	    
	 	    Thread.sleep(5000);

	 	    assetTrackShipmentsPge.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	 	    Syn_Click(assetTrackShipmentsPge.btn_searchattn(wdriver));
	 	    logger.log(LogStatus.PASS, "Click on  tab search for  ATTN  ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    Thread.sleep(5000);
	 	    switchToWindow("Ship From: Address Info");
	 	    Thread.sleep(5000);
	 	    logger.log(LogStatus.PASS,"ATTN	field","ATTN field is entered");
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    // click on save
	 	    
	 	    WebElement country= wdriver.findElement(By.xpath("//select[@name='country']"));
	 	    Select selectcntry=new Select(country);
	 	    selectcntry.selectByVisibleText("UNITED KINGDOM");
	 	    /*dropDownSelectJavaScript(country, "UNITED KINGDOM");
	 	    Thread.sleep(4000);
	 	    dropDownSelectJavaScript(country, "UNITED KINGDOM");
	 	    */
	 	    Thread.sleep(4000);
	 	    Syn_Click(assetTrackShipmentsPge.txt_faxNo(wdriver));
	 	    Thread.sleep(2000);
	 	    
	 	    boolean state=assetTrackShipmentsPge.Addressinfo_StateDisabled(wdriver).isDisplayed();
	 	    logger.log(LogStatus.PASS,"State field","State field is disabled:"+state);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    	
	 	    WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	 	    Select selectdd=new Select(Province);
	 	    String DefaultValue=selectdd.getFirstSelectedOption().getText();
	 	    Assert.assertEquals(DefaultValue, "SELECT A PROVINCE");
	     		logger.log(LogStatus.PASS,"Province default Value","Province default Value :"+DefaultValue);
	     	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     	dropDownSelectJavaScript(Province, "AVON");
	 	    Thread.sleep(4000);
	 	    String Faxno=assetTrackShipmentsPge.txt_faxNo(wdriver).getText();
	 	    
	 	    
	 	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	 	    logger.log(LogStatus.PASS,"save button","save  button is clicked ");
	 	    
	 	    Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(10000);
	 	    // Edit Address button corresponding to Shipto
	 	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditTo(wdriver));
	 	    logger.log(LogStatus.PASS,"Ship to edit address button","Ship to edit address button is clicked ");
	 	    
	 	    Thread.sleep(5000);
	 	    switchToWindow("Consigned To: Address Info");
	 	    Thread.sleep(5000);

	 	    JavascriptExecutor myExecutor = ((JavascriptExecutor) wdriver);
	 	       myExecutor.executeScript("document.getElementsByName('locationName')[0].value='1A'");
	 	    Thread.sleep(5000);

	 	    //assetTrackShipmentsPge.txt_searchsitefrom(wdriver).sendKeys("1A");
	 	    Syn_Click(assetTrackShipmentsPge.btn_searchsitefromtab(wdriver));
	 	    logger.log(LogStatus.PASS,"searchsite name","searchsite name is clicked ");
	 	    Thread.sleep(5000);
	 	    //assetTrackShipmentsPge.txt_searchattn(wdriver).sendKeys(" ABC, ABC");
	 	     myExecutor.executeScript("document.getElementsByName('attention')[0].value=' ABC, ABC'");
	 	    Syn_Click(assetTrackShipmentsPge.btn_searchattn(wdriver));
	 	    logger.log(LogStatus.PASS,"ATTN","ATTN is clicked ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    Thread.sleep(5000);
	 	    switchToWindow("Consigned To: Address Info");
	 	    Thread.sleep(5000);
	 	    // click on save
	 	    WebElement country1= wdriver.findElement(By.xpath("//select[@name='country']"));
	 	    Select selectcntry1=new Select(country1);
	 	    selectcntry1.selectByVisibleText("UNITED KINGDOM");
	 	    /*dropDownSelectJavaScript(country1, "UNITED KINGDOM");
	 	    Thread.sleep(3000);
	 	    dropDownSelectJavaScript(country1, "UNITED KINGDOM");*/
	 	    Thread.sleep(3000);
	 	    Syn_Click(assetTrackShipmentsPge.txt_faxNo(wdriver));
	 	    Thread.sleep(2000);
	 	    
	 	    boolean state1=assetTrackShipmentsPge.Addressinfo_StateDisabled(wdriver).isDisplayed();
	 	    logger.log(LogStatus.PASS,"State field","State field is disabled:"+state1);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    //WebElement Province= wdriver.findElement(By.xpath("//select[@name='province']"));
	 	    //Select selectdd=new Select(Province);
	         WebElement Province1= wdriver.findElement(By.xpath("//select[@name='province']"));
	 	    Select selectdd1=new Select(Province1);
	 	    String DefaultValue1=selectdd1.getFirstSelectedOption().getText();
	 	    Assert.assertEquals(DefaultValue1, "SELECT A PROVINCE");
	     	logger.log(LogStatus.PASS,"Province default Value","Province default Value :"+DefaultValue1);
	     	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     	selectdd1.selectByVisibleText("AVON");
	     	//dropDownSelectJavaScript(Province, "AVON");
	 	    Thread.sleep(4000);
	 	    
	 	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	 	    logger.log(LogStatus.PASS, "Click on save button  ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    Boolean requestedBy=assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"Requested By field","Requested By field is displayed :"+requestedBy);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver));
	         myExecutor.executeScript("document.getElementsByName('requestedBy')[0].value='Test'");
	         //assetTrackShipmentsPge.WaybillManifestPage_RequestedBy(wdriver).sendKeys("Test");
	         Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_RequestedByLookUp(wdriver));
	         Thread.sleep(10000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    Thread.sleep(5000);
	 	    
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	         
	 	    Boolean TotalWeight=assetTrackShipmentsPge.WaybillManifestPage_TotalWeight(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"Total Weight By field","Total Weight By field is displayed :"+TotalWeight);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    
	         Boolean TotalValue=assetTrackShipmentsPge.WaybillManifestPage_TotalValue(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"Total Value field","Total Value field is displayed :"+TotalValue);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	        
	         Boolean ShipmentApprover=assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is displayed :"+ShipmentApprover);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    
	         Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver));
	         Thread.sleep(2000);
	         Boolean ShipmentApproverChecked=assetTrackShipmentsPge.WaybillPage_ShipmentApproverCheckBox_Checked(wdriver).isDisplayed();
	         Assert.assertTrue(ShipmentApproverChecked);
	         logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is checked :"+ShipmentApproverChecked);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    
	         Syn_Click(assetTrackShipmentsPge.WaybillManifestPage_ShipmentApproverCheckBox(wdriver));
	         Thread.sleep(2000);
	         Boolean ShipmentApproverUnChecked=assetTrackShipmentsPge.WaybillPage_ShipmentApproverCheckBox_UnChecked(wdriver).isDisplayed();
	         Assert.assertTrue(ShipmentApproverUnChecked);
	         
	         logger.log(LogStatus.PASS,"Shipment approved by NBC Legal/JPMC Vastera checkbox","Shipment approved by NBC Legal/JPMC Vastera checkbox is Unchecked :"+ShipmentApproverUnChecked);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    
	         String Shipfrom=assetTrackShipmentsPge.WaybillPage_FromLocation(wdriver).getText();
	         assertTrue(Shipfrom.contains("FAX:"+Faxno));
	         logger.log(LogStatus.PASS,"Verification Successfull","Verified Fax number is displayed in ship from text");
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    Thread.sleep(1000);
	         
	 	    Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditAddress(wdriver));
	 	    logger.log(LogStatus.PASS, "Click on Edit Address button corresponding to ship from ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Ship From: Address Info");
	 	    Thread.sleep(4000);
	 	    logger.log(LogStatus.PASS,"Address Info","Address Info is displayed");
	 	    myExecutor.executeScript("document.getElementsByName('city')[0].value='Test'");
	 	    //assetTrackShipmentsPge.txt_City(wdriver).sendKeys("Test");
	 	    Thread.sleep(1000);
	 	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	 	    logger.log(LogStatus.PASS, "Click on save button");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(4000);
	 	    
	 	    Boolean DateRequested=assetTrackShipmentsPge.WayBillPage_DateRequested(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"DateRequested","DateRequested is displayed :"+DateRequested);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	  
	         Boolean ShipDate=assetTrackShipmentsPge.WayBillPage_ShipDate(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"ShipDate field","ShipDate field is displayed :"+ShipDate);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
	         Boolean DeliveryRequired=assetTrackShipmentsPge.WayBillPage_DeliveryRequired(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"DeliveryRequired field","DeliveryRequired field is displayed :"+DeliveryRequired);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
	         Boolean ExpectedReturnDate=assetTrackShipmentsPge.WayBillPage_ExpectedReturnDate(wdriver).isDisplayed();
	         logger.log(LogStatus.PASS,"Expected Return Date field","Expected Return Date field is displayed :"+ExpectedReturnDate);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    
	         assetTrackShipmentsPge.txt_currentlocation(wdriver).clear();
	         Thread.sleep(3000);
	         //WebElement loc = wdriver.findElementByXPath("(//div[@class='tabImage'])[1]");
	         Thread.sleep(3000);
	        // myExecutor.executeScript("arguments[0].click();", loc);
	         Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentLocationLookUp(wdriver));
	         
	         Thread.sleep(5000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Current location field","Current location field is entered");
	         Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtab(wdriver));
	 	    logger.log(LogStatus.PASS, "Selected current sub location  ");

	 	    Syn_Click(assetTrackShipmentsPge.btn_currentsublocationtabsearch(wdriver));
	 	    Thread.sleep(5000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Current sublocation field","Current sublocation field is entered");
	         Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	 	    //assetTrackShipmentsPge.txt_courier(wdriver).sendKeys("123");
	 	    myExecutor.executeScript("document.getElementsByName('courier')[0].value='123'");
	 	   //assetTrackShipmentsPge.txt_waybillinfo(wdriver).sendKeys("1234");
	 	    myExecutor.executeScript("document.getElementsByName('waybillInfo')[0].value='1234'");
	 	    
	 	    logger.log(LogStatus.PASS,"Courier and Fax number","Courier and Fax number details are entered");
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    WebElement element4 = wdriver.findElementByXPath("//input[@name='shipDate']");
	 	    selectDateJavScriptExe("27/12/2017", element4);
	 	    WebElement dateRequested = wdriver.findElementByXPath("//input[@name='dateRequested']");
	 	    selectDateJavScriptExe("27/12/2017", dateRequested);
	 	    WebElement deliveryRequiredBy = wdriver.findElementByXPath("//input[@name='deliveryRequiredBy']");
	 	    selectDateJavScriptExe("27/12/2017", deliveryRequiredBy);
	 	    WebElement element5 = wdriver.findElementByXPath("//input[@name='expectedReturnDate']");
	 	    selectDateJavScriptExe("27/12/2019", element5);
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    
	 	    
	 	    myExecutor.executeScript("document.getElementsByName('assignment')[0].value='1234'");Thread.sleep(3000);
	 	    Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
	         logger.log(LogStatus.PASS,"Save button","Save is clicked");
	         WebDriverWait wait = new WebDriverWait(wdriver, 50);
	         /*wait.until(ExpectedConditions.alertIsPresent());
	         Alert alert = wdriver.switchTo().alert();
	         Thread.sleep(1000);
	         alert.getText();
	         // alert handling
	         logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert.getText());
	         Thread.sleep(1000);
	         alert.accept();*/

	         /*Alert alert1= wdriver.switchTo().alert();
	         alert1.accept();*/
	         WebimplicitWait(wdriver); 
 			Thread.sleep(3000);
	 			logger.log(LogStatus.PASS,"Save","Entered Values are saved");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         Thread.sleep(3000);
	 		
	        Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentLocation_Addnew(wdriver));
		    logger.log(LogStatus.PASS, "Add New button");
		    Thread.sleep(4000);
	       
		   Set<String> availableWindows = wdriver.getWindowHandles();
			//System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
			if (availableWindows.size() >= 1) {
				try {
					for (String windowId : availableWindows) {
						
						System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
						String win=wdriver.switchTo().window(windowId).getTitle();
						System.out.println(win);
							//return true;
							//return true;
						  //break;
					}
				} catch (NoSuchWindowException e) {
					
					//logger.handleError("No child window is available to switch ", e);
				}
       
			}
	         
			Thread.sleep(3000);
			myExecutor.executeScript("document.getElementsByName('newLocationName')[0].value='TEST'");
			
			Syn_Click(assetTrackShipmentsPge.btn_AddCaseSave(wdriver));
 		    logger.log(LogStatus.PASS, "Save button");
 		    Thread.sleep(3000);
 		    
 		    String message=assetTrackShipmentsPge.Maintain_CurrentLocation_Message(wdriver).getText();
 		    Assert.assertTrue(message.contains("already exists."));
 		    logger.log(LogStatus.PASS,"Verification Successfull","Verified Message is displayed:"+message);
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    Thread.sleep(1000);
 		    
	 	    myExecutor.executeScript("document.getElementsByName('newLocationName')[0].value='!@#$'");
	 	  	Syn_Click(assetTrackShipmentsPge.btn_AddCaseSave(wdriver));
		    logger.log(LogStatus.PASS, "Save button");
		    Thread.sleep(3000);
		    String Errormessage=assetTrackShipmentsPge.Maintain_CurrentLocation_Message(wdriver).getText();
		    Assert.assertTrue(Errormessage.equals("Enter a valid New Location."));
		    logger.log(LogStatus.PASS,"Verification For junk Characters","Verified Error Message is displayed:"+Errormessage);
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    Thread.sleep(1000);
 		    
	 	    Syn_Click(assetTrackShipmentsPge.Maintain_CurrentLocation_Cancel(wdriver));
		    logger.log(LogStatus.PASS, "Cancel button");
		    Thread.sleep(3000);
	 	   
		    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	 	    
	 	   Syn_Click(assetTrackShipmentsPge.WayBillPage_CurrentSubLocation_Addnew(wdriver));
		    logger.log(LogStatus.PASS, "Add New button");
		    Thread.sleep(4000);
	       
		   Set<String> availableWindows1 = wdriver.getWindowHandles();
			//System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
			if (availableWindows1.size() >= 1) {
				try {
					for (String windowId : availableWindows1) {
						
						System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
						String win=wdriver.switchTo().window(windowId).getTitle();
						System.out.println(win);
							//return true;
							//return true;
						  //break;
					}
				} catch (NoSuchWindowException e) {
					
					//logger.handleError("No child window is available to switch ", e);
				}
      
			}
	         
			Thread.sleep(3000);
			assetTrackShipmentsPge.WayBillPage_CurrentLocation_NewLocation(wdriver).clear();
	        Thread.sleep(2000);
			myExecutor.executeScript("document.getElementsByName('newLocationName')[0].value='TEST'");
			
			Syn_Click(assetTrackShipmentsPge.btn_AddCaseSave(wdriver));
		    logger.log(LogStatus.PASS, "Save button");
		    Thread.sleep(3000);
		    //String Expectedmsg="SubLocation "+"TEST"+" already exists.";
		    String message1=assetTrackShipmentsPge.Maintain_CurrentLocation_Message(wdriver).getText();
		    Assert.assertTrue(message1.contains("already exists."));
		    logger.log(LogStatus.PASS,"Verification Successfull","Verified Message is displayed:"+message1);
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    Thread.sleep(1000);
		    
	 	    myExecutor.executeScript("document.getElementsByName('newLocationName')[0].value='!@#$'");
	 	  	Syn_Click(assetTrackShipmentsPge.btn_AddCaseSave(wdriver));
		    logger.log(LogStatus.PASS, "Save button");
		    Thread.sleep(3000);
		    String Errormessage1=assetTrackShipmentsPge.Maintain_CurrentLocation_Message(wdriver).getText();
		    Assert.assertTrue(Errormessage1.equals("Enter a valid New Sub-Location."));
		    logger.log(LogStatus.PASS,"Verification For junk Characters","Verified Error Message is displayed:"+Errormessage1);
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    Thread.sleep(1000);
		    
	 	    Syn_Click(assetTrackShipmentsPge.Maintain_CurrentLocation_Cancel(wdriver));
		    logger.log(LogStatus.PASS, "Cancel button");
		    Thread.sleep(3000);
	 	   	
		    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	 	    myExecutor.executeScript("document.getElementsByName('packedBy')[0].value='ABC'");
	 	    Thread.sleep(3000);
	 	    Syn_Click(assetTrackShipmentsPge.WayBillPage_PackedByLookUp(wdriver));
		    logger.log(LogStatus.PASS, "Lookup button");
	 	   	Thread.sleep(5000);
	 	    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Packed By field","Packed By field field is entered");
	        Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	     
	 	   myExecutor.executeScript("document.getElementsByName('comments')[0].value='Testing'");
	 	    Thread.sleep(3000);
	 	 
	 	    Syn_Click(assetTrackShipmentsPge.WayBillPage_PeopleSoftEbuy(wdriver));
		    logger.log(LogStatus.PASS, "PeopleSoft/Ebuy Radio button");
		    Thread.sleep(2000);
	 	    
		    Syn_Click(assetTrackShipmentsPge.WayBillPage_BussinessUnitLookUp(wdriver));
		    logger.log(LogStatus.PASS, "Bussiness unit LookUp");
		    Thread.sleep(5000);
		    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Bussiness Unit field","Bussiness Unit field is entered");
	        Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	 	   Syn_Click(assetTrackShipmentsPge.WayBillPage_DepartmentLookUp(wdriver));
		    logger.log(LogStatus.PASS, "Department LookUp");
		    Thread.sleep(5000);
		    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Department field","Department field is entered");
	        Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	 	   Syn_Click(assetTrackShipmentsPge.WayBillPage_AccountIDLookUp(wdriver));
		    logger.log(LogStatus.PASS, "Account ID LookUp");
		    Thread.sleep(5000);
		    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Account ID field","Account ID field is entered");
	        Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	 	   Syn_Click(assetTrackShipmentsPge.WayBillPage_ShowCodeLookUp(wdriver));
		    logger.log(LogStatus.PASS, "Show Code LookUp");
		    Thread.sleep(5000);
		    switchToWindow("Tab Search");
	 	    Thread.sleep(5000);
	 	    selValueWindow(wdriver);
	 	    logger.log(LogStatus.PASS,"Show Code field","Show Code field is entered");
	        Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
		    
	 	   Syn_Click(assetTrackShipmentsPge.btn_ShipfromeditTo(wdriver));
	 	    logger.log(LogStatus.PASS,"Shipfrom edit address button","Shipfrom edit address button is clicked ");
	 	    
	 	    Thread.sleep(5000);
	 	    switchToWindow("Consigned To: Address Info");
	 	    Thread.sleep(5000);

	 	   
	 	   
	 	    WebElement country11= wdriver.findElement(By.xpath("//select[@name='country']"));
	 	    Select selectcntry11=new Select(country11);
	 	    selectcntry11.selectByVisibleText("SYRIA");
	 	    /*dropDownSelectJavaScript(country1, "UNITED KINGDOM");
	 	    Thread.sleep(3000);
	 	    dropDownSelectJavaScript(country1, "UNITED KINGDOM");*/
	 	    Thread.sleep(3000);
	 	    
	     	//dropDownSelectJavaScript(Province, "AVON");
	 	    
	 	  	Alert alertCountry = wdriver.switchTo().alert();
	        Thread.sleep(1000);
	        String CountryMsg= alertCountry.getText();
	        Assert.assertEquals(CountryMsg, "Shipping to this country requires special notification, please contact NBC Legal at 212-664-3305 for further assistance.");
	        // alert handling
	        logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alertCountry.getText());
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	     	
	        Thread.sleep(1000);
	        alertCountry.accept();
	        Thread.sleep(4000);
	        
	        WebElement Province11= wdriver.findElement(By.xpath("//select[@name='province']"));
	 	    Select selectdd11=new Select(Province11);
	 	    selectdd11.selectByVisibleText("DARA");
	 	    
	 	    Syn_Click(assetTrackShipmentsPge.btn_shipfromsave(wdriver));
	 	    logger.log(LogStatus.PASS, "Click on save button  ");
	 	    Thread.sleep(5000);
	 	    switchToWindow("Asset Tracker v2.2.1");
	 	    Thread.sleep(5000);
	 	    
	         
	 		Syn_Click(assetTrackShipmentsPge.WayBillPage_AddCaseButton(wdriver));
 		    logger.log(LogStatus.PASS, "Add Case button");
 		    Thread.sleep(3000);
 		    myExecutor.executeScript("document.getElementsByName('weightLB')[0].value='12'");
 		    myExecutor.executeScript("document.getElementsByName('length')[0].value='10'");
 		    myExecutor.executeScript("document.getElementsByName('width')[0].value='10'");
 		    myExecutor.executeScript("document.getElementsByName('height')[0].value='10'");
 		   objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 		 //input[@name='length']
 		    Syn_Click(assetTrackShipmentsPge.btn_AddUnits(wdriver));
 		   // logger.log(LogStatus.PASS, "Add units button");
 		    logger.log(LogStatus.PASS,"Add units button","Add Assests to shipments page is clicked ");
 	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 	       /* String Trackingno1="0987654321";
 			String Trackingno2="10099T";
 			String Trackingno3="1012836";
 			String Trackingno4="10132895";
 			*/
 	        Thread.sleep(5000);
 	        myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10413T'");
 	       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
 	        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
 		    Thread.sleep(2000);
 		    
 		    Syn_Click(assetTrackShipmentsPge.btn_AddCaseContinue(wdriver));
 		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
 		    Thread.sleep(3000);
 	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 		
 	       Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
 	        logger.log(LogStatus.PASS,"Add Item button","Add Item clicked");
 	       Thread.sleep(3000);
 	       
 	       Boolean TrackNo=assetTrackShipmentsPge.txt_AddCaseTrackingNum(wdriver).isDisplayed();
 	       logger.log(LogStatus.PASS,"Tracking Number field","Tracking Number field is displayed :"+TrackNo);
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         Thread.sleep(3000);
	        Syn_Click(assetTrackShipmentsPge.AddAsset_To_Shipment_Cancel(wdriver));
	        logger.log(LogStatus.PASS,"Cancel button","Cancel clicked");
	        Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 	 		      
 	       	Syn_Click(assetTrackShipmentsPge.EditItems_Remove(wdriver));
	        logger.log(LogStatus.PASS,"Remove button","Remove clicked");
	        Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 		
 	       try{
	        Boolean TrackNo1=assetTrackShipmentsPge.EditItems_Remove(wdriver).isDisplayed();
 	       } 
 	       catch(Exception e)
 	       {
 	    	   logger.log(LogStatus.PASS,"Row for the Edit Items Case 1 is removed","Row for the Edit Items Case 1 is removed");
		         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			            
 	       }
		         
		       
 	       
 	      Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	        logger.log(LogStatus.PASS,"Add Item button","Add Item clicked");
	       Thread.sleep(3000);
 	       
	       myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10413T'");
 	       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
 	       Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
 		   Thread.sleep(2000);
 		   logger.log(LogStatus.PASS,"Tracking Number","User is able to add tracking number");
 		   objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	  
	     
	     Syn_Click(assetTrackShipmentsPge.AddAsset_To_Shipment_Cancel(wdriver));
	        logger.log(LogStatus.PASS,"Cancel button","Cancel clicked");
	        Thread.sleep(3000);
 		    
 	       
	        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	        logger.log(LogStatus.PASS,"Add Item button","Add Item clicked");
	       Thread.sleep(3000);
 	       
	       myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='asdafgh'");
 	       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
 	       Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
 		   Thread.sleep(2000);
 		   logger.log(LogStatus.PASS,"Tracking Number","User is able to add tracking number");
 		   objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	  
 		   Syn_Click(assetTrackShipmentsPge.btn_AddCaseContinue(wdriver));
		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
		    Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	       
	        String Errormsg=assetTrackShipmentsPge.Maintain_CurrentLocation_Message(wdriver).getText();
		    Assert.assertTrue(Errormsg.equals("Tracking Number (ASDAFGH) cannot be found in the system."));
		    logger.log(LogStatus.PASS,"Verification For invalid input","Verified Error Message is displayed:"+Errormsg);
	 	    objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	 	    Thread.sleep(1000);
		    
	 	    Syn_Click(assetTrackShipmentsPge.AddAsset_To_Shipment_Cancel(wdriver));
	        logger.log(LogStatus.PASS,"Cancel button","Cancel clicked");
	        Thread.sleep(3000);
	        
	        Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
	        logger.log(LogStatus.PASS,"Add Item button","Add Item clicked");
	       Thread.sleep(3000);
 	       
	       myExecutor.executeScript("document.getElementsByName('trackingNum')[0].value='10688T1 '");
 	       // assetTrackAssetsPge.txt_ScanInTrackingNum(wdriver).sendKeys(Trackingno1);
 	       Syn_Click(assetTrackShipmentsPge.btn_AddCaseAddItem(wdriver));
 		   Thread.sleep(2000);
 		   logger.log(LogStatus.PASS,"Tracking Number","User is able to add tracking number");
 		   objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	  
 		   Syn_Click(assetTrackShipmentsPge.btn_AddCaseContinue(wdriver));
		    logger.log(LogStatus.PASS,"Continue button","Continue is clicked");
		    Thread.sleep(3000);
	        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
           
 	        Syn_Click(assetTrackShipmentsPge.edititemssave(wdriver));
 	        logger.log(LogStatus.PASS,"Save button","Save is clicked");
	 	        
 	            
	         Syn_Click(assetTrackShipmentsPge.btn_entershipment_finish(wdriver));
	         logger.log(LogStatus.PASS,"Finish button","Finish is clicked");
	         Thread.sleep(3000);
	         
	         WebDriverWait wait3 = new WebDriverWait(wdriver, 50);
	         wait3.until(ExpectedConditions.alertIsPresent());
	         Alert alert12 = wdriver.switchTo().alert();
	         Thread.sleep(3000);
	         alert12.getText();
	         // alert handling
	         logger.log(LogStatus.PASS, "Alert Message", "Alert Message is displayed :" + alert12.getText());
	         Thread.sleep(4000);
	         alert12.accept();
	         WebimplicitWait(wdriver); 
	 		Thread.sleep(3000);
	        try{
	 		Boolean Finishbut = assetTrackShipmentsPge.btn_entershipment_finish(wdriver).isDisplayed();
	        }
	        catch(Exception e){
	 		logger.log(LogStatus.PASS,"Shipment details","Shipment details are updated");
	        }
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
	         /*Boolean LatUpdatedOn = assetTrackShipmentsPge.WayBill_LatUpdatedOn(wdriver).isDisplayed();
	 		Assert.assertTrue(LatUpdatedOn);
	 		logger.log(LogStatus.PASS,"Last Updated On details","Last Updated On details are displayed");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	         
	         Boolean LatUpdatedBy = assetTrackShipmentsPge.WayBill_LatUpdatedBy(wdriver).isDisplayed();
	 		Assert.assertTrue(LatUpdatedBy);
	 		logger.log(LogStatus.PASS,"Last Updated By details","Last Updated By details are displayed");
	         objCommStudio.getScreenshoteachStepWeb(wdriver, true);*/
	
	    }       

		//Verify that the Shipment is saved
		    catch (Exception | AssertionError e) {
		     System.out.println(e);
		     logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
		    }
		} 
}
