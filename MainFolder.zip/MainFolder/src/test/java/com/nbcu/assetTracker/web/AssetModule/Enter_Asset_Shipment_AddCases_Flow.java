package com.nbcu.assetTracker.web.AssetModule;

import java.lang.reflect.Method;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_ShipmentsPage;
import com.Nbcu.AssetTracker.Web.AddAsset.EnterAssetModules;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Enter_Asset_Shipment_AddCases_Flow extends Commonstudio {

	PropertyFileReader prop = new PropertyFileReader();
	Commonstudio objCommStudio = new Commonstudio();
	ExtentReports logger = ExtentReports.get(SearchAsset_SubModule.class);
	AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
	AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
	AssetTrack_ShipmentsPage shipmentpage=new AssetTrack_ShipmentsPage();	
	EnterAssetModules addasset=new EnterAssetModules();

	@Test(enabled = true, dataProvider = "AssetTrack_SheetData", dataProviderClass = ParaMethod.class)
	public void AssetModule_ConsumableAsset_ParentAssetTracking(Method m, String username, String password,String firstcost,String Addchild,String Shipfrom_Sitename,String Shipfrom_Zipcode,String consignedto_sitename,String datefieldVal,String fromAddress,String toaddress
			) throws Exception {


		try {

			logger.startTest(m.getName());
			System.out.println("method name" + (m.getName()));
			TestReporter.logStep("Start test execution of " + m.getName());
			TestReporter.logStep("Launch Asset Tracker ");

			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			String verifyLogin = assetTrackAssetsPge.title_Login(wdriver).getText();
			Assert.assertEquals("Welcome, Tester1", verifyLogin);

			// Verifying that the Login is successful
			logger.log(LogStatus.PASS, "Login is suucessful","Login is succesful with the login Message " + verifyLogin);
			Thread.sleep(3000);

			//Click on the Assets button in the Assets page
			/*Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
			logger.log(LogStatus.PASS, "Assets Tab", "Assets Tab is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(2000);

			//Adding Asset
			addasset.Asset_AddAsset(wdriver,username,password,firstcost);*/

		/*	//click on view asset
			Syn_Click(assetTrackAssetsPge.btn_ViewAsset(wdriver));
			logger.log(LogStatus.PASS, "View Asset button should be clicked", "View Asset button  is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);

			//Click Update details button on Asset Detials page	 
			Syn_Click(assetTrackAssetsPge.btn_AssetDet_UpdateDetails(wdriver));
			logger.log(LogStatus.PASS, "Update Details button should be clicked", "Update Details button  is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(5000);

		//Click AddChild button	
			Syn_Click(assetTrackAssetsPge.btn_AddChild(wdriver));
			logger.log(LogStatus.PASS, "AddChild button should be clicked", "Addchild button  is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			explicitlywaitAlert_Web();
			//alert click ok	 
			Alert alert=wdriver.switchTo().alert();
			alert.accept();
			logger.log(LogStatus.PASS, "Click OK on the alert dialog", "Clicked OK on the alert dialog");

			//Entering Child Tracking Number   
			Syn_Click(assetTrackAssetsPge.txt_ChildTracNo(wdriver));
			assetTrackAssetsPge.txt_ChildTracNo(wdriver).sendKeys(Addchild);
			logger.log(LogStatus.PASS, "Child Tracking Number should be added", "Child Tracking Number is added");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//click on save in addchild screen   
			Syn_Click(assetTrackAssetsPge.btn_AddChildSAVE(wdriver));
			logger.log(LogStatus.PASS, "Save button should be clicked", "Save button should be clicked");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//verifying child added       
			assetTrackAssetsPge.confrm_AddedChildsucc(wdriver).isDisplayed();
			logger.log(LogStatus.PASS, "child asset should be added successfully", "child asset is added successfully ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);    */

			//click on link shipment 
			Syn_Click(shipmentpage.lnk_Shipment(wdriver));
			logger.log(LogStatus.PASS, "Shipment link should be clicked successfully", "Shipment link should be clicked successfully ");

			//click on Enter shipment
			Syn_Click(shipmentpage.lnk_EnterShipment(wdriver));
			logger.log(LogStatus.PASS, "Enter Shipment link should be clicked successfully", "Enter Shipment link should be clicked successfully ");
			Thread.sleep(5000);

			//Entering shipment details
			//select ship date 
			WebElement element1=wdriver.findElementByXPath("//*[@name='shipDate']");
			selectDateJavScriptExe(datefieldVal,element1);
			logger.log(LogStatus.PASS, "Shipment date  is entered", "Shipment date  is entered ");

			//Commented//

			//Entering ship from address
			Syn_Click(shipmentpage.btn_shipfromEditAddress(wdriver));
			logger.log(LogStatus.PASS, "Click on the Edit Shipment button", "Click on the Edit Shipment button ");
			Thread.sleep(10000);

			switchToWindow("Ship From: Address Info");
			Thread.sleep(5000);
			String title= wdriver.getTitle();
			if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
			{
				assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
				WebimplicitWait(wdriver);
				//Syn_Clickupd((shipmentpage.selValueWindow(wdriver)),wdriver);; //select vendor 1st option
				shipmentpage.txt_editadd_Sitename(wdriver).sendKeys(Shipfrom_Sitename);
			}
			else
			{
				Thread.sleep(5000);
				Syn_Click(shipmentpage.txt_editadd_Sitename(wdriver));
				shipmentpage.txt_editadd_Sitename(wdriver).sendKeys(Shipfrom_Sitename);
				logger.log(LogStatus.PASS, "Enter the Site Name ", "Enter the Site Name:" +Shipfrom_Sitename);
			}
			Syn_Click(shipmentpage.editadd_Attn(wdriver));
			logger.log(LogStatus.PASS, "Click on the ATTN edit box ", "Clicked on the ATTN edit box");
			Thread.sleep(40000);
			switchToWindow("Tab Search");
			Thread.sleep(60000);
			wdriver.findElement(By.xpath("//input[@value='1141521']")).click();
			//Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			
			Thread.sleep(50000);
			logger.log(LogStatus.PASS, "Select ATTN Value from the window ", "Selected ATTN Value from the window ");
			switchToWindow("Ship From: Address Info");
			logger.log(LogStatus.PASS, "Select the value from the ATTN list ", "Selected the value from the ATTN list ");
			Syn_Click(shipmentpage.txt_editadd_Zipcode(wdriver));
			shipmentpage.txt_editadd_Zipcode(wdriver).sendKeys(Shipfrom_Zipcode);
			logger.log(LogStatus.PASS, "Zipcode ", "Zipcode is entered ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

//Selecting state  
//   Syn_Click(shipmentpage.btn_editadd_Save(wdriver));
			WebElement element=wdriver.findElementByXPath("//*[@name='state']");
			Select sele=new Select(element);
			sele.selectByIndex(2);
			logger.log(LogStatus.PASS, "Select State from the list", "Selected State from the list");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			
//Click on Save button
			Syn_Click(shipmentpage.btn_editadd_Save(wdriver));
			switchToWindow("Asset Tracker v2.2.1");
			logger.log(LogStatus.PASS, "Switch back to the main window", "Switched back to the main window");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

//Entering consigned to address details
			Syn_Click(shipmentpage.btn_consignedtoEditAddress(wdriver));
			logger.log(LogStatus.PASS, "Consigned to Ship button_Edit", "Consigned to Ship button_Edit button is clicked");
			Thread.sleep(10000);
			switchToWindow("Consigned To: Address Info");
			logger.log(LogStatus.PASS, "Switch to the Consigned To: window ", "Switched to the Consigned To: window ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(4000);

//Enter the Consigned to Site Name
			Syn_Click(shipmentpage.txt_editadd_Sitename(wdriver));
			JavascriptExecutor jse = (JavascriptExecutor)wdriver;
			jse.executeScript("arguments[0].value='consignedto_sitename';", shipmentpage.txt_editadd_Sitename(wdriver));
			shipmentpage.txt_editadd_Sitename(wdriver).sendKeys(consignedto_sitename);
			logger.log(LogStatus.PASS, "Enter the Site Name ", "Enter the Site Name:" +consignedto_sitename);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

//Click on the ATTN Search button		        
			Syn_Click(shipmentpage.editadd_Attn(wdriver));
			Thread.sleep(45000);
			switchToWindow("Tab Search");
			Thread.sleep(30000);
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(30000);
			//Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
			wdriver.findElement(By.xpath("//input[@value='1141521']")).click();
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			logger.log(LogStatus.PASS, "ATTN  ", "ATTN is selected from the list" );
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			Thread.sleep(2000);
			switchToWindow("Consigned To: Address Info");

//Selecting state  
			WebElement elemen=wdriver.findElementByXPath("//*[@name='state']");
			Select sel=new Select(elemen);
			sel.selectByIndex(2);
			logger.log(LogStatus.PASS, "State Name  ", "State Name is selected from the dropdown" );
			Syn_Click(shipmentpage.txt_editadd_Zipcode(wdriver));
			shipmentpage.txt_editadd_Zipcode(wdriver).sendKeys(Shipfrom_Zipcode); 
			logger.log(LogStatus.PASS, "Zipcode_Consigned shipment", "Zipcode is selected for the consigned shipment" );
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
//Click on the Save button    
			Syn_Click(shipmentpage.btn_editadd_Save(wdriver));
			logger.log(LogStatus.PASS, "Save button", "Save button is clicked" );
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);
			switchToWindow("Asset Tracker v2.2.1");  

//Click on the Current Sublocation Select button
			Syn_Click(shipmentpage.currentSubLocation(wdriver));
			Thread.sleep(5000);
			switchToWindow("Tab Search");
			String title3= wdriver.getTitle();
			if(title3.equalsIgnoreCase("NBCUniversal SSO Login"))
			{
				assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
				WebimplicitWait(wdriver);
				Syn_Clickupd((shipmentpage.selValueWindow(wdriver)),wdriver);; //select vendor 1st option
			}
			else
				//Select the value from the new pop up					
				Syn_Clickupd((shipmentpage.selValueWindow(wdriver)),wdriver); //select vendor 1st option
			logger.log(LogStatus.PASS, "Current Sub Location ", "Current Sub Location is selected from the pop up" );
			objCommStudio.getScreenshoteachStepWeb(wdriver, true);

			//Switch to the 			
			switchToWindow("Asset Tracker v2.2.1");
			Thread.sleep(2000);

			Syn_Click(shipmentpage.checkbox_noreturndate(wdriver));
			Syn_Click(shipmentpage.waybill_save(wdriver));

			//Click finish button	   
			Syn_Click(shipmentpage.waybill_save(wdriver));
			String shipmentNo=shipmentpage.shipmentno(wdriver).getText();
			if(shipmentNo!=null)
			{
				logger.log(LogStatus.PASS, "Shipment should be  saved successfully", "Shipment is saved successfully ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true);  
			}
			else
			{
				logger.log(LogStatus.FAIL, "Shipment should be  saved successfully", "Shipment is not saved successfully ");
			}
			//click on addcase	   
			Syn_Click(shipmentpage.addcase(wdriver));

			//Click on addunits
			Syn_Click(shipmentpage.addunits(wdriver));
			logger.log(LogStatus.PASS, "Add Units button", "Add Units button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			Syn_Click(shipmentpage.addassttoshipment_trackingno(wdriver));
			shipmentpage.addassttoshipment_trackingno(wdriver).sendKeys("1");      //parenttracking no


			Syn_Click(shipmentpage.addassttoshipment_additem(wdriver));
			logger.log(LogStatus.PASS, "Shipment Add Item button", "Shipment Add Item button is clicked ");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			Syn_Click(shipmentpage.addassttoshipment_continue(wdriver));
			logger.log(LogStatus.PASS, "Shipment Continue button", "Shipment Continue button is clicked ");
			boolean bool=shipmentpage.edititemscase(wdriver).isDisplayed();
			if(bool==true)  
			{
				logger.log(LogStatus.PASS, "Edit items screen should be displayed successfully", "Edit items screen is displayed successfully ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
			}
			else
			{
				logger.log(LogStatus.FAIL, "Edit items screen should be displayed successfully", "Edit items screen is not displayed successfully ");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			}
			//click on save on edit itemscase screen
			Syn_Click(shipmentpage.edititemssave(wdriver));
			boolean boo=shipmentpage.waybillOrManifestDetails(wdriver).isDisplayed();
			if(boo==true)  
			{
				logger.log(LogStatus.PASS, "WayBill or Manifest details screen should be displayed successfully", "WayBill or Manifest details screen is displayed successfully");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
			}
			else
			{
				logger.log(LogStatus.FAIL, "WayBill or Manifest details screen should be displayed successfully", "WayBill or Manifest details screen is not displayed successfully");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			}
			//click on copy case button		
			Syn_Click(shipmentpage.waybillOrManifestDet_copycase(wdriver));

			//alert click ok	 
			Alert alert1=wdriver.switchTo().alert();
			alert1.accept();
			Thread.sleep(5000);

			wdriver.findElementByXPath("//*[text()='Copy Case']").isDisplayed();
			logger.log(LogStatus.PASS, "Copy case  screen should be displayed successfully", "Copy case screen is displayed successfully");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			Syn_Click(shipmentpage.copycase_Quantity(wdriver));
			shipmentpage.copycase_Quantity(wdriver).sendKeys("2");
			objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			Syn_Click(shipmentpage.copycase_Btn_Create(wdriver));
			List<WebElement> elements=wdriver.findElementsByClassName("txtStandard");
			int size=elements.size();
			for(int i=1;i<=size-1;i++)
			{
				int j=106;
				String tracno="AUTO"+j+"";
				wdriver.findElementByXPath("(//*[@class='txtStandard'])["+i+"]").sendKeys(tracno);
				j++;
			}
			//click save
			Syn_Click(shipmentpage.edititemssave(wdriver));

			boolean boo1=shipmentpage.waybillOrManifestDetails(wdriver).isDisplayed();
			if(boo1==true)  
			{
				logger.log(LogStatus.PASS, "WayBill or Manifest details screen should be displayed successfully", "WayBill or Manifest details screen is displayed successfully");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
			}
			else
			{
				logger.log(LogStatus.FAIL, "WayBill or Manifest details screen should be displayed successfully", "WayBill or Manifest details screen is not displayed successfully");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			}

			Syn_Click(shipmentpage.edititemssave(wdriver));

			boolean boo2=shipmentpage.waybillOrManifestDetails(wdriver).isDisplayed();
			if(boo2==true)  
			{
				logger.log(LogStatus.PASS, "WayBill or Manifest details screen should be displayed successfully", "WayBill or Manifest details screen is displayed successfully");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 
			}
			else
			{
				logger.log(LogStatus.FAIL, "WayBill or Manifest details screen should be displayed successfully", "WayBill or Manifest details screen is not displayed successfully");
				objCommStudio.getScreenshoteachStepWeb(wdriver, true); 

			}
		} 
		catch (Exception | AssertionError e) {
			System.out.println(e);

			logger.log(LogStatus.FAIL,"Error Message:"+e.getMessage());
			TestReporter.logFailure("Error Message:"+e.getMessage());
			objCommStudio.getScreenshotFailedWeb(wdriver, "Error Msg", true);
		}

	}


}
