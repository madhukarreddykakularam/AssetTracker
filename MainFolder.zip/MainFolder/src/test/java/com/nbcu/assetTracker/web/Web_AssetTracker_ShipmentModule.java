package com.nbcu.assetTracker.web;
import static org.testng.Assert.assertTrue;

import java.lang.reflect.Method;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_ShipmentsPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Web_AssetTracker_ShipmentModule extends Commonstudio
{
    PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    ExtentReports logger = ExtentReports.get(Web_AssetTracker_ShipmentModule.class);
    AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
    AssetTrack_AssetsPage assetTrackAssetsPge=new  AssetTrack_AssetsPage();
    AssetTrack_ShipmentsPage assetTrackShipmentsPge=new AssetTrack_ShipmentsPage();
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void ShipmentCase_Numbers(Method m,String username,String password,String PONumber) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Verify the 4 tabs are displayed

         Boolean AssetDisplay=assetTrackAssetsPge.btn_Assets(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is displayed :"+AssetDisplay);
         Boolean ShipmentDisplay=assetTrackAssetsPge.btn_Shipments(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Shipment Tab is displayed :"+ShipmentDisplay);
         Boolean MaintainDisplay=assetTrackAssetsPge.btn_Maintain(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Maintain Tab is displayed :"+MaintainDisplay);
         Boolean NeedHelpDisplay=assetTrackAssetsPge.btn_NeedHelp(wdriver).isDisplayed();
         logger.log(LogStatus.PASS,"Assets Tab","Need Help Tab is displayed :"+NeedHelpDisplay);
         objCommStudio.getScreenshoteachStepWeb(wdriver, true);
         
 //Click on Asset Module tab
         Syn_Click(assetTrackAssetsPge.btn_Assets(wdriver));
         logger.log(LogStatus.PASS,"Assets Tab","Assets Tab is clicked ");
         
 //Click on the Search Asset link
         Syn_Click(assetTrackAssetsPge.lnk_EnterAsset(wdriver));
        logger.log(LogStatus.PASS,"Search Asset Link Tab","Enter Asset Link Tab is clicked ");
        
  
  //Verify that the Find Purchase order field is displayed      
        String verifyTitle=assetTrackAssetsPge.tit_FindPurchaseOrder(wdriver).getText();
        Assert.assertEquals("Find Purchase Order", verifyTitle);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyTitle);
        
        
  //Enter a valid PO Number
        assetTrackAssetsPge.txt_POnumber(wdriver).sendKeys(PONumber);
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        
  //Click on the Find PO button
        Syn_Click(assetTrackAssetsPge.btn_FindPO(wdriver));
        logger.log(LogStatus.PASS,"Find PO button","Find PO button is clicked ");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
//Click on the View Fixed Assets button
        Syn_Click(assetTrackAssetsPge.lnk_ViewFixedAssets(wdriver));
        logger.log(LogStatus.PASS,"View Fixed Assets link","View Fixed Assets link is clicked ");
        
 //Select Tracking Number from the table       
        AssetTableDataSelect("WE0181133U",10,"click");
        
//Click on the View history button
        Syn_Click(assetTrackAssetsPge.btn_ViewHistory(wdriver));
        logger.log(LogStatus.PASS,"View History button","View History button is clicked and the User is naviagated to the detailed history page ");
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
        String verifyAssetShippedMessage=assetTrackAssetsPge.txt_AssetShipped(wdriver).getText();
       // verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment");
        assertTrue(verifyAssetShippedMessage.contains("Asset Shipped as part of Shipment"));
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAssetShippedMessage);
       


        }
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   
    
    
    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void ShipmentCase_Delete_PositiveFlow(Method m,String username,String password) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
         logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
         Thread.sleep(1000);
         
//Click on the Shipments tab
         Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
         logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
         
 //Click on the Search Shipment link
         Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
        logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
        
//Click on the Show Latest Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
       logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked ");      
        
//Click on the View button for any record
       Syn_Click(assetTrackShipmentsPge.btn_View(wdriver));
       logger.log(LogStatus.PASS,"View button ","View button is clicked "); 

//Save the Shipment Number selected for the Verification
       String VerifyShipping=assetTrackShipmentsPge.txt_Verify_ShipmentNo(wdriver).getText().trim();
       
//Click on the Delete Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_DeleteShipment(wdriver));
       logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked "); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
       explicitlywaitAlert_Web();
  
       String verifyAlertMessage= wdriver.switchTo().alert().getText();
       Assert.assertEquals("Are you sure  you want to Delete?", verifyAlertMessage);
       logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);
    
//Click on the cancel button in the alert
       
       Alert alert= wdriver.switchTo().alert();
       alert.dismiss();

 //Click on the Delete Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_DeleteShipment(wdriver));
       logger.log(LogStatus.PASS,"Delete Shipment button ","Delete Shipment button is clicked"); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);

   //Click on the Ok button in the alert
       explicitlywaitAlert_Web();
       alert.accept();
       
       //Confirmation page is displayed
       String verifyConfirmationPage=assetTrackShipmentsPge.tit_Confirmation_Page(wdriver).getText();
       Assert.assertEquals("Confirmation", verifyConfirmationPage);
       logger.log(LogStatus.PASS,"Verification Successfull","Verified the Confirmation message : "+verifyConfirmationPage);
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        
       
     //Verifying that the Confirmation message is displayed after deleting the Shipment
       String verifyConfirmationMessage=assetTrackShipmentsPge.msg_ConfirmDeleteShipment(wdriver).getText();
      Assert.assertEquals("Shipment has been deleted sucessfully.", verifyConfirmationMessage);
      logger.log(LogStatus.PASS,"Verification Successfull","Verified the Confirmation message : "+verifyConfirmationMessage);
      objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
       
//Click on the Search Shipment buton
      Syn_Click(assetTrackShipmentsPge.btn_SearchShipmentAction(wdriver));
      logger.log(LogStatus.PASS,"Search Shipment button","Search Shipment button is clicked ");
      
  
 //Enter the Deleted Shipment Id
     assetTrackShipmentsPge.txt_ShipmentId(wdriver).sendKeys(VerifyShipping);
     Syn_Click(assetTrackShipmentsPge.btn_SelectValues(wdriver,"searchShipmentID"));
     logger.log(LogStatus.PASS,"enter Shipment Id  ","Shipment Id is entered ");
     objCommStudio.getScreenshoteachStepWeb(wdriver, true);
     
//Switch to the Tab Search window
    switchToWindow("Tab Search");
    WebimplicitWait(wdriver);
    String verifyError=assetTrackShipmentsPge.msg_NoMatches(wdriver).getText().trim();
    Assert.assertEquals("No matches Found", verifyError);
    logger.log(LogStatus.PASS,"Error message","Verified the Error message : "+verifyError);
        }
        
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   
   
    

    @Test(enabled = true, dataProvider = "AssetTrack_SheetData",dataProviderClass = ParaMethod.class)
    public void ShipmentCase_Copy_PositiveFlow(Method m,String username,String password,String quantity,String trackingNo) throws Exception
    {
        try
        {   
         
         logger.startTest(m.getName());
         System.out.println("method name"+(m.getName()));
         TestReporter.logStep("Start test execution of " + m.getName());
         TestReporter.logStep("Launch Asset Tracker ");
         
//Step1:Login to the Application
         assetTrackLoginModPge.AssetTrack_Login(wdriver,username,password);
         WebimplicitWait(wdriver);
         String verifyLogin=assetTrackAssetsPge.title_Login(wdriver).getText();
         Assert.assertEquals("Welcome, Tester1", verifyLogin);
         
//Verifying that the Login is successful
        
        logger.log(LogStatus.PASS,"Login is suucessful","Login is succesful with the login Message "+verifyLogin);
        Thread.sleep(1000);
         
//Click on the Shipments tab
        Syn_Click(assetTrackAssetsPge.btn_Shipments(wdriver));
        logger.log(LogStatus.PASS,"Shipments Tab","Shipments Tab is clicked ");
         
 //Click on the Search Shipment link
         Syn_Click(assetTrackShipmentsPge.lnk_SearchShipment(wdriver));
        logger.log(LogStatus.PASS,"Search Shipment Link ","Search Shipment is clicked ");
        
     
//Click on the Show Latest Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShowLatestShipment(wdriver));
        logger.log(LogStatus.PASS,"Show Latest Shipment button ","Show Latest Shipment button is clicked "); 
        
 //Click on any record from the table      
        AssetTableDataSelect("11259",7,"click");
        
        
//Click on the Copy Shipment button for the selected record
        //Syn_Click(assetTrackShipmentsPge.btn_CopyShipment(wdriver));
        String newurl="https://assettrackerqa.inbcu.com/fats/shipFACopyCaseConfirm?shipmentID=11259";
        ((JavascriptExecutor) wdriver).executeScript("window.open(arguments[0])", newurl);
        //Syn_Click_RunTime(assetTrackShipmentsPge.btn_CopyShipment(wdriver),"JavaScriptClick");
        logger.log(LogStatus.PASS,"Copy Shipment button ","Copy Shipment button is clicked "); 
        WebimplicitWait(wdriver);
    
        switchToWindow("Confirm");
 
//Save the Shipment Number selected for the Verification
        String VerifyCaseCopyMessage=assetTrackShipmentsPge.msg_CopyShipmentCase(wdriver).getText().trim();
        Assert.assertEquals("Would you like to copy the Cases as well?", VerifyCaseCopyMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+VerifyCaseCopyMessage);
               
//Verify Yes, No , Cancel button exists
        Boolean verifyYesButton=assetTrackShipmentsPge.btn_CopyShipmentCaseYes(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Yes Btn","Yes Button is displayed :"+verifyYesButton);
        Boolean verifyNoButton=assetTrackShipmentsPge.btn_CopyShipmentCaseNo(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"No Btn","No Button is displayed :"+verifyNoButton);
        Boolean verifyCancelButton=assetTrackShipmentsPge.btn_CopyShipmentCaseCancel(wdriver).isDisplayed();
        logger.log(LogStatus.PASS,"Cancel Btn","Cancel button is displayed :"+verifyCancelButton);
        
        
//Click on the Yes button in the Confirmation window
        Syn_Click(assetTrackShipmentsPge.btn_CopyShipmentCaseYes(wdriver));
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        logger.log(LogStatus.PASS,"Yes button ","Yes button is clicked in the confirmation window"); 
        
        switchToWindow("Asset Tracker v2.2.1");
        
        WebimplicitWait(wdriver);
        //switchToWindow("Asset Tracker v2.2.1");
        
  
//Click on the Finish Shipment button
        Syn_Click(assetTrackShipmentsPge.btn_ShipmentFinish(wdriver));
        logger.log(LogStatus.PASS,"Finish button ","Finish button is clicked "); 
        objCommStudio.getScreenshoteachStepWeb(wdriver, true);
 
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
        explicitlywaitAlert_Web();
  
        String verifyAlertMessage= wdriver.switchTo().alert().getText();
        
        assertTrue(verifyAlertMessage.contains("Clicking Finish updates the location of all the assets in this shipment"));
        //Assert.assertEquals("Clicking Finish updates the location of all the assets in this shipment.Are you sure you want to finish the shipment?", verifyAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyAlertMessage);
    
//Click on the cancel button in the alert
       Alert alert= wdriver.switchTo().alert();
       alert.accept();
       
 //Click on Update Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_UpdateShipment(wdriver));
       logger.log(LogStatus.PASS,"Update Shipment button ","Update Shipment button is clicked"); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
 //Click on Copy Case button
       Syn_Click(assetTrackShipmentsPge.btn_CopyCase(wdriver));
       logger.log(LogStatus.PASS,"Copy Case button ","Copy Case buttonn is clicked"); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
        explicitlywaitAlert_Web();
    	  
        String verifyCopyCaseAlertMessage= wdriver.switchTo().alert().getText();
        Assert.assertEquals("The changes made to the shipment will be saved",verifyCopyCaseAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyCopyCaseAlertMessage);
    	    
    	//Click on the cancel button in the alert
       Alert alert1= wdriver.switchTo().alert();
       alert1.accept();   
       
     //Entering a value greater than or equal to 99
       assetTrackShipmentsPge.txt_CopyQuantity(wdriver).sendKeys(quantity);
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
//Click on the Create button 
       Syn_Click(assetTrackShipmentsPge.btn_CopyCreate(wdriver));
       WebimplicitWait(wdriver);
       logger.log(LogStatus.PASS,"Create button","Create button is clicked ");
       
//Enter the tracking No       
       assetTrackShipmentsPge.txt_ShipmentTracking(wdriver).sendKeys(trackingNo);//1196076551
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);
       
       
//Click on the Save  button 
       Syn_Click(assetTrackShipmentsPge.btn_SaveCopyShipment(wdriver));
       WebimplicitWait(wdriver);
       logger.log(LogStatus.PASS,"Save button","Save button is clicked ");
       
       Thread.sleep(1000);
 //Click on Finish in the Waybill Manifest page
     //Click on the Finish Shipment button
       Syn_Click(assetTrackShipmentsPge.btn_ShipmentFinish(wdriver));
       logger.log(LogStatus.PASS,"Finish button ","Finish button is clicked "); 
       objCommStudio.getScreenshoteachStepWeb(wdriver, true);

      
//Alert box is displayed with Are you sure you want to Delete? and the Ok and cancel buttons are displayed   
        explicitlywaitAlert_Web();
    	  
        String verifyFinishAlert= wdriver.switchTo().alert().getText();
        assertTrue(verifyFinishAlert.contains("Clicking Finish updates the location of all the assets in this shipment"));
        //Assert.assertEquals("Clicking Finish updates the location of all the assets in this shipment.Are you sure you want to finish the shipment?", verifyAlertMessage);
        logger.log(LogStatus.PASS,"Verification Successfull","Verified the error message : "+verifyFinishAlert);
    	    	    
 //Click on the ok button in the alert
       Alert alert2= wdriver.switchTo().alert();
       alert2.accept();   
        }       

//Verify that the Shipment is saved
        catch (Exception | AssertionError e) {
         System.out.println(e);
         logger.log(LogStatus.FAIL,"Asset Added"," copied asset has not added to the database");
        }
    }   
}
 