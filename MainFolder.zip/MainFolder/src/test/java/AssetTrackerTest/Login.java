package AssetTrackerTest;

import java.lang.reflect.Method;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import com.Nbcu.mobile.dataprovider.ParaMethod;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
//import com.mgm.mobile.or.ExceptionLocators;
//import com.mgm.mobile.or.MlifeLocator;
//import com.mgm.mobile.or.MyStayLocator;
//import com.mgm.mobile.ui.android.common.AndroidMGMmodules;
//import com.mgm.mobile.ui.android.mlife.common.AndroidMlifeModules;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;



public class Login extends Commonstudio {
    PropertyFileReader prop = new PropertyFileReader();
    ExtentReports logger = ExtentReports.get(Login.class);
   
    //ExceptionLocators objExcLoc = new ExceptionLocators();
   
   

    /*
     * Script: Update address of mlife user and verify updated details
     * Flow: Login -> Update address -> Verify
     * Created:
     * Modified On:22-Apr-2019
     * Modified By: JyothiE
     * Modified deails:Added assertions,camelcase coding conventions
     * Precondition: Active mlife account
     * Details Need to Pass from Excel: Test case name,email,password,address
     * Excel: AndroidSuiteTestData.xlsx
*/		 
    @Test(enabled = true)
    public void _25691_UpdateAddressOfMLifeUserAndVerify() throws Exception
    {
        try
        {
        	wdriver.get("https://assettrackerqa.inbcu.com");
        	//Thread.sleep(100)
        	//wdriver.findElement(By.cssSelector("[name='q']")).sendKeys("Arsenal FC");
        	//wdriver.findElement(By.cssSelector("[name='q']")).sendKeys(Keys.ENTER);
        	
            //Start test execution by loading all the desired capabilities
        	//TestReporter.logStep("Start test execution of " + m.getName());
        /*	
        	logger.startTest(m.getName());
            implicitWait(driver);
            
      
            TestReporter.logStep("Login");
            objAndroidMlifeMod.mob_VerifyLoginButtontoClick(driver);
            
            //Enter login details and verify biometric alert
            TestReporter.logStep("Enter login details and verify biometric alert");
            objAndroidMlifeMod.mob_EnterLoginDetails(driver, email, Password);
            
            //Update address of mlife user
            TestReporter.logStep("Update address of mlife user");
            objAndroidMlifeMod.mob_UpdateProfileDetails(driver, address);
            
            //Verify updated address details
            TestReporter.logStep("Verify Updated address details");
            objAndroidMlifeMod.mob_VeifyUpdatedProfileDetails(driver, address);
            
            //Logout
            TestReporter.logStep("Logout");
            objAndroidMlifeMod.mob_SwipeToLogout(driver);
           
            //End the test exection
            TestReporter.logStep("End the test execution of " + m.getName());
            logger.endTest();
            
           */ 
        } catch (Exception | AssertionError e) {
        	System.out.println(e);
          // objExcLoc.ExceptionHandling(wdriver, (java.lang.Exception) e);
        }
    }

    /*
     * Script: Send recovery email on click of forgot password link
     * Flow: Login -> forgort password link -> Enter email -> verify success messgae
     * Created:
     * Modified On:21-Apr-2019
     * Modified By: JyothiE
     * Modified deails:Added assertions,camelcase coding conventions
     * Precondition: Active mlife account
     * Details Need to Pass from Excel: Test case name,email
     * Excel: AndroidSuiteTestData.xlsx
*/		
    /*@Test(enabled = true, dataProvider = "MLifeAd", dataProviderClass = ParaMethod.class)
    public void _25695_VerifyForgotPasswordLink(Method m, String email) throws Exception 
    {
        try
        {
            //Start test execution by loading all the desired capabilities
        	TestReporter.logStep("Start test case execution of " + m.getName());
        	logger.startTest(m.getName());
            implicitWait(driver);
            
            //Verify for logged in user,if, then logout and click on login
            TestReporter.logStep("Verify for logged in user,if, then logout and click on login");
            objAndroidMlifeMod.mob_VerifyLoginButtontoClick(driver);
            
            //Click on forgot password link and enter email address for recovery mail
            TestReporter.logStep("Click on forgot password link and enter email address for recovery mail");
            objAndroidMlifeMod.mob_ClickForgotPasswordEnterEmail(driver, email);
            
            //Verify success message
            TestReporter.logStep("Verify success message");
            objAndroidMlifeMod.mob_VerifySuccessForForgotPassowrd(driver);
            
            //End test execution
            TestReporter.logStep("End the test execution of " + m.getName());
            logger.endTest();
        } catch (Exception | AssertionError e) {
            objExcLoc.ExceptionHandling(driver, (java.lang.Exception) e);
        }
    }*/

}

/*  ///////////Code Dump///////////////////////
 * @Test(enabled = true)
    public void NotificationsOnLaunch() throws Exception {
        {
            logger.startTest("Launch App and Verify Promo Video & Notifications");
            implicitWait(driver);
            objAndroidMgmMod.mob_ClickNotifications(driver);
            logger.endTest();
        }
    }

    // Verfiying Login and Logout with valid Credentials

    @Test(enabled = true, dataProvider = "MLifeAd", dataProviderClass = ParaMethod.class)
    public void LoginLogoutWithValidCredentials(Method m, String email, String password) throws Exception {
        try
        {
            logger.startTest(m.getName());
            implicitWait(driver);
            TestReporter.logStep("Login");
            objAndroidMlifeMod.mob_VerifyLoginButtontoClick(driver);
            TestReporter.logScreenshot(driver, "Login details");
            objAndroidMlifeMod.mob_EnterLoginDetails(driver, email, password);
           
            //Added by Jyothi on  21st jan
            TestReporter.logStep("Verifying terms of use Alert");
           objAndroidMlifeMod.mob_TermsOfUseAlert(driver);
            TestReporter.logStep("Logout");
            objAndroidMlifeMod.mob_SwipeToLogout(driver);
            logger.log(LogStatus.PASS, ":User LoggedIN Successfully");
            logger.endTest();
        } catch (Exception | AssertionError e) {
            objExcLoc.ExceptionHandling(driver, (java.lang.Exception) e);
        }
    }
*/
