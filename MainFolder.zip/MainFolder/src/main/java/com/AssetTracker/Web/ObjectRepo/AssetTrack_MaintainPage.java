package com.AssetTracker.Web.ObjectRepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.dvnext.mobile.utils.PropertyFileReader;

public class AssetTrack_MaintainPage 
{
	public WebElement element;
	PropertyFileReader prop = new PropertyFileReader();

	public WebElement btn_Maintain(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@src='/fats/images/Maintain.gif']"));
        return element;

    }
	
	public WebElement lnk_Models(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Models')]"));
        return element;

    }
	
	public WebElement lnk_Manufacturers(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Manufacturers')]"));
        return element;

    }
	public WebElement lnk_Maintain(RemoteWebDriver wdriver,String linkValue)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'"+linkValue+"')]"));
		
        return element;

    }
	//lnk_Vendors
	
	public WebElement lnk_Divsions(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Divisions')]"));
        return element;

    }
	public WebElement drpdownAction(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//select[@name='actionCode']"));
        return element;

    }
	public WebElement drpdownManufacturer(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//select[@id='companyID']"));
        return element;

    }
	
	public WebElement txt_PickUpManufacturer(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='manufacturerName']"));
        return element;

    }
	public WebElement btn_SelectfromNewWindow(RemoteWebDriver wdriver,String selectValue)
	{
      
		element = wdriver.findElement(By.xpath(".//td[contains(text(),'"+selectValue+"')]//parent::tr//img[@src='/fats/images/Tab.gif']"));
        return element;

    }
	
	public WebElement txt_modelName(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='newFixedAssetModelName']"));
        return element;

    }
	
	public WebElement txt_ModelWeight(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='fixedAssetModelWeight']"));
        return element;

    }
	
	public WebElement btn_SaveModel(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='Save']"));
        return element;

    }
	
	public WebElement txt_PickType(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='fixedAssetTypeName']"));
        return element;

    }
	
	public WebElement txt_NewModelName(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='newFixedAssetModelName']"));
        return element;

    }
	
	public WebElement txt_PickNewType(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='newFixedAssetTypeName']"));
        return element;

    }
	
	public WebElement txt_HTSCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='htsCode']"));
        return element;

    }
	
	public WebElement txt_ECCNCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='fixedAssetECCNCode']"));
        return element;

    }
	
	public WebElement txt_ModelName(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='fixedAssetModelName']"));
        return element;

    }
	
	public WebElement msg_Confirmation(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//font[@class='confirmation']"));
		return element;

    }
	
	public WebElement msg_ConfirmationdDynamic(RemoteWebDriver wdriver,String msgTxt)
	{
      
		//element = wdriver.findElement(By.xpath("//font[@class='confirmation']"));
		element = wdriver.findElement(By.xpath("//font[@class='confirmation'][contains(text(),'"+msgTxt+"')]"));
		return element;

    }
	
	
	public WebElement msg_ConfirmationdDynamic_Add_Delete(RemoteWebDriver wdriver,String msgTxt, String Action)
	{
      
		//element = wdriver.findElement(By.xpath("//font[@class='confirmation']"));
		
		element = wdriver.findElement(By.xpath("//font[@class='confirmation'][contains(text(),'"+msgTxt+"')and contains(text(),'"+Action+"')]"));
		return element;

    }
	
	
	
	public WebElement lnk_MyPreferences(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'My Preferences')]"));
        return element;

    }
	
	public WebElement txt_Divison_Prefernces(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='divisionName']"));
        return element;

    }
	
	public WebElement tit_MyPreferences(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//td[@class='headerLeft'][text()='Maintain My Preferences']"));
        return element;

    }
	public WebElement tit_MantainManufacturers(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//td[@class='headerLeft'][text()='Maintain Manufacturers']"));
        return element;

    }
	public WebElement tit_Mantainlinks(RemoteWebDriver wdriver,String title)
	{
      
		element = wdriver.findElement(By.xpath("//td[@class='headerLeft'][text()='"+title+"']"));
        return element;

    }
	//td[@class='headerLeft'][text()='Maintain Statuses']
	
	
	public WebElement btn_SavePreferences(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@name='Save']"));
        return element;

    }
	
	public WebElement btn_CancelMaintain(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Cancel']"));
        return element;

    }
	
	//input[@value='Cancel']
	
	public WebElement txt_NewDivision(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='newDivision']"));
        return element;

    }
	
	public WebElement txt_NewSiteName(RemoteWebDriver wdriver)
	{
     element = wdriver.findElement(By.xpath("//input[@name='siteName']"));
        return element;
	}
	
	
	
	
	public WebElement btn_SelectPickType(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@id='fixedAssetTypeName']/../../div)[2]/a"));
        return element;

    }
	//txt_Newmanufacturer
	public WebElement txt_NewName(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='companyName']"));
        return element;

    }
	
	
	public WebElement drpdown_Division(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//select[@id='divisionID']"));
        return element;

    }
	
	public WebElement msg_Error(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//font[@class='message']"));
        return element;

    }
	public WebElement msg_Error_Dynamic(RemoteWebDriver wdriver,String msgTxt)
	{
		
		element = wdriver.findElement(By.xpath("//font[@class='message'][text()='"+msgTxt+"']"));
		
        return element;
        //Weight is not a valid number.
    }
	

	
	public WebElement txt_PrefDefaultCurrentLocation(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='currentLocationName']"));
        return element;

    }
	public WebElement txt_PrefDefaultPermanentLocation(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='permanentLocationName']"));
        return element;

    }
	
	public WebElement txt_PrefDefaultPermSubLocation(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='permanentSublocationName']"));
        return element;

    }
			
	public WebElement msg_NoMatches(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//center"));
        return element;

    }
	
	public WebElement drpdown_Status(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//select[@id='statusID']"));
        return element;

    }
	
	public WebElement txt_NewStatusName(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='statusName']"));
        return element;

    }
	
	
	public WebElement txt_SiteZipCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='zip']"));
        return element;

    }
	
	
	
	
	public WebElement drpdownSiteState(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//select[@name='state']"));
        return element;

    }
	public WebElement btn_AddNewHTSCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='htc']"));
        return element;

    }
	public WebElement btn_AddNewECCCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='exp']"));
        return element;

    }
	
	
	
	
	public WebElement txt_NewHTSCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='newHTSCode']"));
        return element;

    }
	
	public WebElement txt_NewECCCode(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='newECCNCode']"));
        return element;

    }
	
	public WebElement txt_Newmanufacturer(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='companyName']"));
        return element;

    }
	
	public WebElement btn_SaveManufacturer(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='save']"));
        return element;

    }
	
	
	public WebElement Validation_Message(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[contains(text(),'New Manufacturer must be specified')]"));
        return element;

    }
	
				
	public WebElement Updated_Message(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[contains(text(),'has been updated')]"));
        return element;

    }

	public WebElement FontColor(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//font[text()='*']"));
        return element;

    }

	public WebElement drpdown_Vendor(RemoteWebDriver wdriver) {
		element = wdriver.findElement(By.xpath("//select[@name='actionCode']"));
        return element;
	}

	
	public WebElement ADD_Message(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[contains(text(),'has been added')]"));
        return element;

    }
	public WebElement Action_Message(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//font[@class='message']"));
        return element;

    }
	
			public WebElement Manufactureradio(RemoteWebDriver wdriver)
			{
		      
				//element = wdriver.findElement(By.xpath("//*[contains(text(),'Pick')]//input"));
				element = wdriver.findElement(By.xpath("(//input[@name='newManufacturer'])[1]"));
				
		        return element;

		    }
			public WebElement Validmesg(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//*[contains(text(),'Select Manufacturer only from the pop-up.')]"));
		        return element;

		    }
			
			public WebElement Validmesg1(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//*[contains(text(),'Select Export Classification Code only from the pop-up.')]"));
		        return element;

		    }
			
			public WebElement ValidDimensions(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//*[contains(text(),'Length is not a valid number.')]"));
		        return element;

		    }
			public WebElement Text_Dimensions_len(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='fixedAssetModelLength']"));
		        return element;

		    }
			public WebElement Text_Dimensions_widt(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='fixedAssetModelWidth']"));
		        return element;

		    }
			
			public WebElement Text_Dimensions_height(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='fixedAssetModelHeight']"));
		        return element;

		    }
	
			public WebElement btn_newmodel(RemoteWebDriver wdriver)
			{
		      
				//element = wdriver.findElement(By.xpath("//*[contains(text(),'New Model')]//input"));
				//input[@name='newModel']
				element = wdriver.findElement(By.xpath("(//input[@name='newModel'])[2]"));
		        return element;

		    }
						
			public WebElement btn_division(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@id='divisionName']/../../div/a"));
		        return element;

		    }
			
			public WebElement txt_currentlocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='currentLocationName']"));
		        return element;

		    }
			
			public WebElement btn_currentlocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='currentLocationName']/../../div/a"));
		        return element;

		    }
			
			public WebElement btn_currentlocation_Sub(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='locationID']/../div/div[2]/a/img"));
		        return element;

		    }
			
			public WebElement txt_permanentlocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='permanentLocationName']"));
		        return element;

		    }
			
			public WebElement btn_permanentlocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='permanentLocationName']/../../div/a"));
		        return element;

		    }
			
			public WebElement txt_permanentsublocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@id='permanentSublocationName']"));
		        return element;

		    }
			
			public WebElement btn_permanentsublocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='permanentSublocationName']/../../div/a"));
		        return element;

		    }
			
			public WebElement txt_costObjectNumber(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@id='costObjectNumber']"));
		        return element;

		    }
			
			public WebElement btn_costObjectNumber(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@id='costObjectNumber']/../../../div/div/a"));
		        return element;

		    }
			
			public WebElement txt_accountNumber(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@id='accountNumber']"));
		        return element;

		    }
			
			public WebElement btn_accountNumber(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='accountNumber']/../../div/a"));
		        return element;

		    }
			
			public WebElement radio_weigt1(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@value='LB']"));
		        return element;

		    }
			
			public WebElement radio_weigt2(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@value='KG']"));
		        return element;

		    }
			
			public WebElement drp_currencyCode(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//select[@name='currencyCode']"));
		        return element;

		    }
		
			public WebElement selValueWindow(RemoteWebDriver wdriver) {
				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[1]"));
		        return element;
			}
			public WebElement selValueWindow1(RemoteWebDriver wdriver) {
				element = wdriver.findElement(By.xpath("(//input[@name='dialog'])[1]"));
		        return element;
			}
		
			public WebElement verifylocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Select')]	"));
		        return element;

		    }
			
			public WebElement txt_newLocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='newLocationName']"));
		        return element;

		    }
			
			public WebElement txt_currentLocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='locationName']"));
		        return element;

		    }
			public WebElement Btn_Cancel(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='Cancel']"));
		        return element;

		    }
			
			public WebElement btn_SelectPickManufacture(RemoteWebDriver wdriver)

		       {
		          element = wdriver.findElement(By.xpath("(//input[@id='manufacturerName']/../../div)[2]/a"));
		          return element;

		       }
			
			public WebElement lnk_currentlocations(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Current Locations')]"));
		        return element;

		    }
			public WebElement lnk_currentsublocations(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Current Sublocations')]"));
		        return element;

		    }
			
			
			//////26_Nov//////
			
			
			public WebElement txt_SubLocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='subLocationName']"));
		        return element;

		    }
			
			//////27_Nov
			public WebElement rdoKGMeasurement(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='weightMeasurementType' and @value='KG']"));
		        return element;

		    }
			
			//03/12/2019
			public WebElement lnk_SiteNames(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Site Names')]"));
		        return element;

		    }
			
			public WebElement lnk_Vendors(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Vendors')]"));
		        return element;

		    }
			
			public WebElement lnk_Types(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Types')]"));
		        return element;

		    }
			public WebElement lnk_Statuses(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Statuses')]"));
		        return element;

		    }
			public WebElement lnk_WorkerDivAssocs(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Worker-Div Assocs')]"));
		        return element;

		    }
			
			public WebElement lnk_PermanentLocations(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//a[contains(text(),'Permanent Locations')]"));
		        return element;

		    }
			
			public WebElement btn_PickupManufacturer(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='manufacturerID']/../div/div[2]/a/img"));
		        return element;

		    }	
			
			public WebElement drpDivisionName(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//select[@id='departmentOption']"));
		        return element;

		    }
			public WebElement txt_newWorkerName(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='newWorkerName']"));
		        return element;

		    }
			
			public WebElement btn_FindName(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@value='Find Name']"));
		        return element;

		    }
			
			public WebElement sel_ValueWorker(RemoteWebDriver wdriver) {
				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[3]"));
		        return element;
			}
			
			public WebElement btn_selectAvailableColumns(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("//select[@name='availCols']"));
		        return element;

		    }
			public WebElement btn_ChangeLayout(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("//input[@value='Change Layout']"));
		        return element;

		    }

			public WebElement btn_addArrow(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("(//td[@class='dataCenter']/img)[2]"));
		        return element;

		    }
			public WebElement btn_printablepage(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("(//input[@value='Printable Page'])"));
		        return element;

		    }
			public WebElement btn_Next(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("//input[@value='Next >>']"));
		        return element;

		    }
			public WebElement btn_previousp(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("(//input[@value='<< Previous']"));
		        return element;

		    }
			public int  btn_tabcount(RemoteWebDriver wdriver)
			{
				int size = wdriver.findElements(By.xpath("(//td[@class='headerButtons']/input")).size();

				return size;

		    }
			public WebElement  txt_OriginalHeader(RemoteWebDriver wdriver)
			{
				element = wdriver.findElement(By.xpath("//tr[@id='original_header']"));
		        return element;

		    }

			  public WebElement  PickUp_Manufacture_PopupButton(RemoteWebDriver wdriver)

			    {

			                   // element = wdriver.findElement(By.xpath("(//div[@class='tabImage'])[1]"));
			                    element = wdriver.findElement(By.xpath("//input[@name='manufacturerID']/../div/div[2]/a/img"));

			                    return element;
			    }

			   

			    public WebElement  PickUp_Type_PopupButton(RemoteWebDriver wdriver)

			    {

			                    element = wdriver.findElement(By.xpath("//input[@name='fixedAssetTypeID']/../div/div[2]/a/img"));

			                    return element;
			    }

			    public WebElement  New_Manufacturer_RadioButton(RemoteWebDriver wdriver)

			    {
			   
			                    //element = wdriver.findElement(By.xpath("//td[contains(text(),'Or, New Manufacturer')]/input[@name='newManufacturer']"));
			                    element = wdriver.findElement(By.xpath("//td[contains(text(),'Or, New Manufacturer')]/input[@name='newManufacturer']"));

			                    return element;
			    }

			   

			    public WebElement  PickUpManufacturer_RadioButton(RemoteWebDriver wdriver)

			    {

			                    element = wdriver.findElement(By.xpath("//td[contains(text(),'Pick Manufacturer')]/input[@name='newManufacturer']"));

			                    return element;
			    }
			    
			    public WebElement lnk_EnterShipment(RemoteWebDriver wdriver)
				{
					element = wdriver.findElement(By.xpath("//*[text()='Enter Shipment']"));
					return element;
				}
			    
			    public WebElement btn_ShipfromeditAddress(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("(//input[@value='Edit Address'])[1]"));
				        return element;

				}
			    
			    public WebElement txt_searchsitefrom(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@id='locationName']"));
				        return element;

				}
			    
			    public WebElement btn_searchsitefromtab(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("(//div[@class='tabImage']/a)[1]"));
				        return element;
				}
			    public WebElement txt_searchattn(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@id='attention']"));
				        return element;
				}
				public WebElement btn_searchattn(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("(//div[@class='tabImage']/a)[2]"));
				        return element;
				}
				
				public WebElement ShipFrom_City(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='city']"));
				        return element;
				}
				
				public WebElement ShipFrom_CityFrom(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='cityFrom']"));
				        return element;
				}
				
				public WebElement btn_ShipfromeditTo(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("(//input[@value='Edit Address'])[2]"));
				        return element;
				}
				
				public WebElement ShipFrom_CityTo(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='cityTo']"));
				        return element;
				}
				
				public WebElement Maintain_SiteNames_Address1(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='address1']"));
				        return element;
				}
				
				public WebElement WayBillPage_ShipmentID(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='shipmentID']"));
				        return element;
				}
				
				public WebElement WayBillPage_ShipmentIDNo(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Shipment Number ')]/../td[2]/input"));
				        return element;
				}
				
				public WebElement WayBillPage_Shipfrom_Address1(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='address1From']"));
				        return element;
				}
				
				public WebElement WayBillPage_ShipTo_Address1(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='address1To']"));
				        return element;
				}
				
				public WebElement SearchShipment_ShipmentID(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='searchShipmentID']"));
				        return element;
				}
				
				public WebElement SearchShipment_ShipmentIDlookup(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='searchShipmentID']/following-sibling::input"));
				        return element;
				}
				
				public WebElement SearchShipment_SearchForShipments(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@type='submit']"));
				        return element;
				}
				
				public WebElement SearchShipment_ShipFromDetails(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Ship From')]/../td[@class='dataLeft']"));
				        return element;
				}
				
				public WebElement SearchShipment_ShipToDetails(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Consigned To')]/../td[@class='dataLeft']"));
				        return element;
				}
				
}





