package com.AssetTracker.Web.ObjectRepo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.dvnext.mobile.utils.PropertyFileReader;

public class AssetTrack_AssetsPage 
{
	public WebElement element;
	PropertyFileReader prop = new PropertyFileReader();
	
	
	
	public WebElement btn_Assets(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@src='/fats/images/Asset.gif']"));
        return element;

    }
	
	
	public WebElement btn_Shipments(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@src='/fats/images/Shipments.gif']"));
        return element;

    }
	
	public WebElement btn_Maintain(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@src='/fats/images/Maintain.gif']"));
        return element;

    }
	
	public WebElement btn_NeedHelp(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@src='/fats/images/Help.gif']"));
        return element;

    }
	public WebElement lnk_SeacrhAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Search Asset')]"));
        return element;

    }
	
	public WebElement lnk_ScanInAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Scan In Asset')]"));
        return element;

    }
	
	public WebElement lnk_ScanOutAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Scan Out Asset')]"));
        return element;

    }
	public WebElement btn_FindPO(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='Find PO #']"));
        return element;

    }
	
	
	public WebElement lnk_EnterAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Enter Asset')]"));
        return element;

    }
	
	public WebElement btn_EnterWithoutPO(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='Enter Without PO #']"));
        return element;

    }
	
	
	
	//input[@value='Enter Without PO #']
	
	public WebElement btn_SearchForAssets(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@value='Search For Assets'])[1]"));
        return element;

    }
	
	
	public WebElement btn_SortResults(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@value='Sort Results']"));
        return element;

    }
	
	
	public WebElement btn_CopyAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='Copy Asset']"));
        return element;

    }
	
	
	public WebElement rdo_Sort1Desc(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='sortBy1'][@value=' DESC']"));
        return element;

    }
	
	
	public WebElement btn_SortSave(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='Save']"));
        return element;

    }
	
	
	public WebElement btn_ViewAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@value='View Asset'])[1]"));
        return element;

    }
	

	
	public WebElement txt_CopyAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='copyQuantity']"));
        return element;

    }
	
	
	
	public WebElement btn_CreateAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='Create']"));
        return element;

    }
	
	public WebElement msg_CopyAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//font[@class='message']"));
        return element;

    }
	
	public WebElement title_Login(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//a[@class='welcomename']"));
        return element;

    }
	
	public WebElement txt_TrackingItemNo(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='trackingNumber']"));
        return element;

    }
	
	public WebElement btn_ItemSave(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='Save']"));
        return element;

    }
	
	public WebElement msg_SaveItemDetails(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[contains(text(),'asset has been added to the database')]"));
        return element;

    }
	
	
	public WebElement tit_AssetDetails(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//font[@class='message']"));
        return element;

    }
	
	public WebElement lbl_AssetDetails(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Asset Details')]"));
        return element;

    }
	
	public WebElement txt_FirstCost(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='firstCost']"));
        return element;

    }
	
	
	public WebElement btn_SavedSearch(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@value='Saved Search'])[1]"));
        return element;

    }
	
	
	public WebElement btn_SavedSearchOk(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='submitButton'][@value='Ok']"));
        return element;

    }
	public WebElement txt_trackingNo(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='trackingNumber']"));
        return element;

    }
	
	public WebElement btn_SelectValues(RemoteWebDriver wdriver,String selectVal)
	{
		element = wdriver.findElement(By.xpath("//input[@name='"+selectVal+"']/following-sibling::input"));
		
        return element;

    }
	
	public WebElement txt_POnumber(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='purchaseOrderNumber']"));
        return element;

    }
	
	public WebElement txt_verify_trackingNo(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[(text()='Tracking #')]/following-sibling::td"));
        return element;

    }
	public WebElement tit_FindPurchaseOrder(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//td[text()='Find Purchase Order']"));
        return element;

    }
	
	public WebElement lnk_ViewFixedAssets(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//a[text()='View Fixed Assets '])[1]"));
        return element;

    }
	
	public WebElement btn_ViewHistory(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@value='View History']"));
        return element;

    }
	public WebElement txt_AssetShipped(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[contains(text(),'Asset Shipped as part of Shipment')]"));
        return element;

    }
	public WebElement txt_FixedAssetNuumber(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='fixedAssetNumber']"));
        return element;

    }
	
	public WebElement txt_verify_FieldAsset(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[(text()='Fixed Asset #')]/following-sibling::td"));
        return element;

    }
	
	public WebElement btn_AddLineItem(RemoteWebDriver wdriver,int instance)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@value='Add Line Item'])["+instance+"]"));
        return element;

    }
	public WebElement btn_LineItem(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//img[@src='/fats/images/TabLineItem.gif']"));
        return element;

    }
	
	public WebElement btn_AssetLineItem(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//img[@src='/fats/images/TabAsset.gif']"));
        return element;

    }
	
	public WebElement btn_Clear(RemoteWebDriver wdriver,String selectText)
	{
      
		element = wdriver.findElement(By.xpath("//*[text()='"+selectText+"']/following-sibling::td/input[@value='Clear']"));
        return element;

    }
	
	public WebElement tit_AssetTitle(RemoteWebDriver wdriver,String title)
	{
      
		element = wdriver.findElement(By.xpath("//td[@class='headerLeft'][text()='"+title+"']"));
        return element;

    }
	public WebElement txt_ScanInCurrentLocation(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='locationName']"));
        return element;

    }
	public WebElement txt_ScanInCurrentSubLocation(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='sublocationName']"));
        return element;

    }
	public WebElement btn_ScanInContinue(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='continueButton']"));
        return element;

    }
	public WebElement txt_SupportCentral(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@id='supportCentral']"));
        return element;

    }
	public WebElement chk_ScanInPerformInventory(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//input[@name='performInventoryCheck']"));
        return element;

    }
	public WebElement msg_ErrorMessages(RemoteWebDriver wdriver,String RequiredText)
	{
      
		element = wdriver.findElement(By.xpath("//font[@id='errorMsg'][text()='"+RequiredText+"']"));
        return element;

    }
	
	public WebElement txt_VerifyViewHistoryText(RemoteWebDriver wdriver,String RandomUpdatedValue)
	{
      
		element = wdriver.findElement(By.xpath("//*[contains(text(),'"+RandomUpdatedValue+"')]"));
        return element;

    }
	public WebElement chk_Asset1(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@name='fixedAssetID'])[1]"));
        return element;

    }
	
	public WebElement btn_GlobalUpdate(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@value='Global Update'])[1]"));
        return element;

    }
	public WebElement txt_ServiceTag(RemoteWebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("(//input[@name='serviceTag'])[1]"));
        return element;

    }
	public WebElement btn_SaveChanges(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Save Changes']"));
        return element;

    }
	

	public WebElement tit_Confirmation_Page(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//td[text()='Confirmation']"));
        return element;

    }
	
	public WebElement btn_BackToSearchResults(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Back to Search Results']"));
        return element;

    }
	

	//Satish////

//Enter Asset elements


	
	public WebElement selectVendor(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//*[@src='/fats/images/Tab.gif'])[1]"));
		return element;
	}
	
	
	public WebElement firstCost(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[@name='firstCost']"));
		return element;
	}
	
	public WebElement trackingno(RemoteWebDriver wdriver)
	{

		element = wdriver.findElement(By.xpath("//*[@name='trackingNumber']"));
		return element;
	}
	
	public WebElement costObject(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//*[text()=' Cost Object #'])[2]/following::img[1]"));
		return element;
	}
	
	public WebElement model(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//*[text()=' Model']/following::img)[1]"));
		return element;
	}
	
	public WebElement status(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[text()=' Status']/following::img[1]"));
		return element;
	}
	
	public WebElement countryOfOrigin(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[text()=' Country of Origin']/following::img[1]"));
		return element;
	}
	
	public WebElement currentSubLocation(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[text()=' Current Sub-Location']/following::img[1]"));
		return element;
	}
	
	public WebElement btn_addAsset(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[@name='submitButton']"));
		return element;
	}
	
	public WebElement confirmation(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[text()='Confirmation']"));
		return element;
	}
	
	public WebElement btn_EnterAsset(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[text()='Enter Asset']"));
		return element;
	}

	

	//MISSING ELEMENTS 



	public WebElement btn_AssetDet_UpdateDetails(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//*[@value='Update Details']"));
			return element;
		}

	public WebElement btn_AddChild(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//*[@value='Add Child']"));
			return element;
		}
		
		public WebElement txt_ChildTracNo(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//*[@name='childTrackingNumber']"));
			return element;
		}
		
		public WebElement btn_AddChildSAVE(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//*[@value='Save']"));
			return element;
		}
		
		public WebElement confrm_AddedChildsucc(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("(//*[text()='Confirmation']/following::tr/td)[1]"));
			return element;
		}
		
		
		public WebElement txt_firstcost(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='firstCost']"));
	        return element;

	    }
		public WebElement btn_Cancel(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@value='Cancel']"));
		        return element;

		    }

		public WebElement chkbox_selectAsset(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@type='checkbox'])[3]"));
		        return element;

		    }
		
		public WebElement Lbl_FirstCostValidationMsg(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//font[contains(text(),'First Cost is not a valid number.')]"));
		        return element;

		    }

		public WebElement btn_countryOfOrigin(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//td[contains(text(),'Country of Origin')]//parent::tr//img[@src='/fats/images/Tab.gif'])[1]"));
		        return element;

		    }
		public WebElement radiobtn_countryoforiginSelection(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@type='radio'])[1]"));
		        return element;

		    }
		public WebElement txt_DimensionsHeight(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='height']"));
	        return element;

	    }
		
		public WebElement Lbl_DimensionHeightValidationMsg(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//font[contains(text(),'Height is not a valid number.')]"));
		        return element;

		    }
		
		public WebElement txt_DimensionsWeight(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='weight']"));
	        return element;

	    }
		
		public WebElement Lbl_DimensionWeightValidationMsg(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//font[contains(text(),'Height is not a valid number.')]"));
		        return element;

		    }
		
		

		
		///////////////////NEw=19/11/2019////////////////////////////////
		
		public WebElement rdo_SAP(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='POSystem' and @value='SRM']"));
	        return element;

	    }
		public WebElement rdo_Ebuy(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='POSystem' and @value='EBUY']"));
	        return element;

	    }
		
		
		public WebElement lbl_PurchaseOrderDetails(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Purchase Order Details')]"));
	        return element;

	    }
		
		public WebElement lbl_FinanceDetailsr(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Finance Details')]"));
	        return element;

	    }
		
		public WebElement txt_ebuyRequisition(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='requisition']"));
	        return element;

	    }
		public WebElement txt_CA_Account(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='capitalAsset']"));
	        return element;

	    }
		public WebElement txt_VendorName(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='vendorName']"));
	        return element;

	    }
		public WebElement txt_ProjectNumber(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='projectNumber']"));
	        return element;

	    }
		public WebElement txt_FANumber(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='fixedAssetNumber']"));
	        return element;

	    }
		public WebElement txt_BusinessUnit(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='bu']"));
	        return element;

	    }
		public WebElement txt_Department(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='department']"));
	        return element;

	    }
		public WebElement txt_WarrantyDetails(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='warrantyDetails']"));
	        return element;

	    }
		public WebElement txt_AccountCode(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='accountCode']"));
	        return element;

	    }
		public WebElement txt_ProductionCode(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='productionCode']"));
	        return element;

	    }
		public WebElement txt_StatusName(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='statusName']"));
	        return element;

	    }
		public WebElement txt_DivisonName(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='divisionName']"));
	        return element;

	    }
		public WebElement txt_CountryOfOrigin(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='countryOfOriginName']"));
	        return element;

	    }
		
		public WebElement txt_ModelName(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='fixedAssetModelName']"));
	        return element;

	    }
		
		public WebElement txt_CurrentLocation(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='currentLocationName']"));
	        return element;

	    }
		
		public WebElement txt_CurrentSubLocation(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='currentSubLocationName']"));
	        return element;

	    }
		
		public WebElement txt_CurrentSubLocationAsset(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='currentSublocationName']"));
	        return element;

	    }
		
	
		public WebElement txt_SerialNumber(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='serialNumber']"));
	        return element;

	    }
		public WebElement txt_CostObject(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='costObjectNumber0']"));
	        return element;

	    }
		
		public WebElement txt_ProfitCenter(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='profitCenterNumber0']"));
	        return element;

	    }
		public WebElement txt_GLAccount(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@id='accountNumber0']"));
	        return element;

	    }
		public WebElement btn_Previous(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@value='Previous']"));
	        return element;

	    }
		public WebElement btn_AddNewModel(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("(//input[@value='Add New'])[2]"));
	        return element;

	    }
		public WebElement rdo_PickUpManufacturer(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='newManufacturer']"));
	        return element;

	    }
		
		public WebElement rdo_PickUpType(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='newType']"));
			return element;

	    }
		public WebElement txt_ModelManufacturer(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='newManufacturerName']"));
	        return element;

	    }
		public WebElement txt_ModelNewType(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='newFixedAssetTypeName']"));
	        return element;

	    }
		
		public WebElement msg_(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='newFixedAssetTypeName']"));
	        return element;

	    }
		
		//font[@class='message'][text()='Manufacturer must be specified.']
		
		public WebElement txt_Modellength(RemoteWebDriver wdriver)
		{
	      
			element = wdriver.findElement(By.xpath("//input[@name='fixedAssetModelLength']"));
	        return element;

	    }
		
		public WebElement btn_SelectfromNewWindow(RemoteWebDriver wdriver,String selectValue)
		{
	      
			element = wdriver.findElement(By.xpath(".//td[contains(text(),'"+selectValue+"')]//parent::tr//img[@src='/fats/images/Tab.gif']"));
	        return element;

	    }
		
		public WebElement msg_Error_Dynamic(RemoteWebDriver wdriver,String msgTxt)
		{
			
			element = wdriver.findElement(By.xpath("//font[@class='message'][text()='"+msgTxt+"']"));
			
	        return element;
	        //Weight is not a valid number.
	    }
		
		
		//Satarupa
		
			public WebElement btn_Addnew_Contact(RemoteWebDriver wdriver)
			{
		      
				//element = wdriver.findElement(By.xpath("(//input[@type='button'])[3]"));
				element = wdriver.findElement(By.xpath("//input[@name='personResponsibleID']/../div[2]/input"));
				
		        return element;

		    }
			

			public WebElement txt_Firstname(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@id='firstName']"));
		        return element;

		    }
			
			public WebElement txt_lastname(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='lastName']"));
		        return element;

		    }
			
			public WebElement txt_emailid(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='emailID']"));
		        return element;

		    }
			
			public WebElement txt_phone(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='phoneNumber']"));
		        return element;

		    }
			
			public WebElement txt_Address(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='address1']"));
		        return element;

		    }
			
			public WebElement drp_state(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//select[@name='stateName']"));
		        return element;

		    }
			
			public WebElement txt_city(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='city']"));
		        return element;

		    }
			
			public WebElement drp_country(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//select[@name='country']"));
		        return element;

		    }
			public WebElement txt_Zip(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='zip']"));
		        return element;

		    }
			
			public WebElement btn_contact(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='personResponsibleID']/..//a/img"));
		        return element;

		    }
			
			public WebElement btn_Save(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='Save']"));
		        return element;

		    }
			
			public WebElement txt_contactname(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='personResponsible']"));
		        return element;

		    }


			public WebElement selValueWindow(RemoteWebDriver wdriver) {
				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[1]"));
		        return element;
			}
			public WebElement selValue1Window(RemoteWebDriver wdriver) {
				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[3]"));
		        return element;
			}
			public WebElement logoutwin(RemoteWebDriver wdriver) {
				element = wdriver.findElement(By.xpath("//*[@id='masterdiv']/table/tbody/tr[2]/td[1]/a/img"));
		        return element;
			}
			
			public WebElement txt_Tracking(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("(//td[@class='dataCenter']/../td[2])[1]"));
		        return element;

		    }
			
			public WebElement VerifyPPMC(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Support Central # / PPMC #')]"));
		        return element;

		    }
			public WebElement VerifyLocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//td[contains(text(),' Current Location')]"));
		        return element;

		    }
			public WebElement Verify_SubLocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Sub-Location')]"));
		        return element;

		    }
			public WebElement Btn_Continue(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@value='Continue']"));
		        return element;

		    }
			public WebElement Btn_Cancel(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@value='Cancel']"));
		        return element;

		    }
			
			public WebElement Location_Newbtn(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("(//input[@value='Add New'])[1]"));
		        return element;

		    }
			public WebElement SubLocation_Newbtn(RemoteWebDriver wdriver)
			{
		      
				//element = wdriver.findElement(By.xpath("(//input[@value='Add New'])[2]"));
				element = wdriver.findElement(By.xpath("(//div[@class='tabButton'])[2]"));
				
		        return element;

		    }
			public WebElement txt_location(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='locationName']"));
		        return element;

		    }

			public WebElement txt_sublocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='sublocationName']"));
		        return element;

		    }
			
			public WebElement Btn_Date(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@class='txtDate']/../a/img"));
		        return element;

		    }
			
			public WebElement CurrentDate(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//font[@color='RED']"));
		        return element;

		    }
			
			public WebElement Verify_scanin(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Tracking #')]"));
		        return element;

		    }
			
			public WebElement btn_location(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='locationID']/..//a/img"));
		        return element;

		    }
			public WebElement btn_sublocation(RemoteWebDriver wdriver)
			{
		      
				element = wdriver.findElement(By.xpath("//input[@name='sublocationID']/..//a/img"));
		        return element;

		    }

			public WebElement VerifyInventory(RemoteWebDriver wdriver) {
				
				element = wdriver.findElement(By.xpath("//input[@name='performInventoryCheck']"));
				return element;
			}
			public WebElement Verify_status(RemoteWebDriver wdriver) {
				
				element = wdriver.findElement(By.xpath("//div[contains(text(),'Status')]"));
				return element;
			}
			public WebElement NewLocation_txt(RemoteWebDriver wdriver) {
				
				element = wdriver.findElement(By.xpath("//input[@name='newLocationName']"));
				return element;
			}
			public WebElement NewSubLocation_txt(RemoteWebDriver wdriver) {
				
				//element = wdriver.findElement(By.xpath("//input[@type='text']"));
				element = wdriver.findElement(By.xpath("//input[@name='newLocationName']"));
				return element;
			}
			
					public WebElement Tracking_txt(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//input[@id='trackingNum']"));
					return element;
					}
					public WebElement btnAdd(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//input[@value='Add Item']"));
					return element;
					}
					public WebElement VerifySerial(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//div[contains(text(),'Serial #')]"));
					return element;
					}
					public WebElement VerifyDivision(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//div[contains(text(),'Division')]"));
					return element;
					}
				public WebElement Btn_confirm(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//input[@value='Confirm']"));
					return element;
					}
				public WebElement Btn_Home(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//input[@id='homeButton']"));
					return element;
					}
			
				public WebElement Btn_save(RemoteWebDriver wdriver) {
						
						element = wdriver.findElement(By.xpath("//input[@value='Save']"));
						return element;
						}
			
				public WebElement VerifyContactName(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//td[contains(text(),' Contact Name')]"));
					return element;
					}
				
				public WebElement VerifyExpReturndate(RemoteWebDriver wdriver) {
					
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Expected Return Date')]"));
					return element;
					}
				
				public WebElement txt_ExpReturndate(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@class='txtDate']"));
					return element;
					}
			
				public WebElement VerifyObjectType(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Scan Out Cost Object Type')]"));
					return element;
					}
				public WebElement VerifyDrpObjectType(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Scan Out Cost Object #')]"));
					return element;
					}
				public WebElement VerifyBudjetCode(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Scan Out Project Budget Code')]"));
					return element;
					}
				
				public WebElement Enterassetdetailspge(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Asset Details')]"));
					return element;
					}
				
				public WebElement BtnVendor(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='vendorID']/../div/div[2]/a"));
					return element;
					}
			
				public WebElement Btn_PoSystem(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='SRM']"));
					return element;
					}
				//
				public WebElement Btn_costobject(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='fixedAssetFinanceActionForms0costObjectID']/../div/div[2]/a"));
					return element;
					}
				public WebElement txt_costobject(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@id='costObjectNumber0']"));
					return element;
					}
				
				public WebElement Txt_FirstCost(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='firstCost']"));
					return element;
					}
				
				public WebElement btnGlaccount(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='fixedAssetFinanceActionForms0GLAccountID']/../div/div[2]/a"));
					return element;
					}
				
				public WebElement txtGlaccount(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@id='accountNumber0']"));
					return element;
					}
				
				public WebElement btnStatusId(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='statusID']/../div/div[2]/a"));
					return element;
					}
				
				public WebElement btnCountryOriginId(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='countryOfOriginID']/../div/div[2]/a"));
					return element;
					}
				
				public WebElement btn_Model(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='fixedAssetModelID']/../div/div[2]/a"));
					return element;
					}
				
				public WebElement btn_SublocationId(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='currentSublocationID']/../div/div[2]/a"));
					return element;
					}
				
				public WebElement txt_division(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//input[@id='divisionName']"));
			        return element;

			    }
				
				public WebElement btn_division(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//input[@id='divisionName']/../../div/a"));
			        return element;

			    }
			
				public WebElement txt_currentsublocation(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//input[@name='currentSublocationName']"));
			        return element;

			    }
				
				public WebElement txt_currentlocation(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//input[@name='currentLocationName']"));
			        return element;

			    }
				
				public WebElement btn_currentlocation(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//input[@name='currentLocationName']/../../div/a"));
			        return element;

			    }		
				public WebElement btn_ADDAsset(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Add Asset']"));
					return element;
					}
				
				public WebElement BtnViewAsset(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='View Asset']"));
					return element;
					}
				
				public WebElement BtnCopyAsset(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Copy Asset']"));
					return element;
					}
				public WebElement BtnCreatenewAsset(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Create New Asset']"));
					return element;
					}
				public WebElement Getcount_ProfitCenter(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Profit Center')]"));
					return element;
					}
				
				public WebElement Getcount_Internal(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),' Internal Order ')]"));
					return element;
					}
				public WebElement Gettxt_Account(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'G/L Account')]/../td[2]"));
					return element;
					}
				public WebElement Getcount_Account(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'G/L Account')]"));
					return element;
					}
				public WebElement Gettxt_Cost(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'First Cost')]/../td[2]"));
					return element;
					}
				
				public WebElement btn_PermanentLocation(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='permanentLocationID']/../div/div[2]/a/img"));
					return element;
					}
				
				public WebElement txt_PermanentLocation(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='permanentSublocationName']"));
					return element;
					}
				
				public WebElement btn_permanentSublocationID(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='permanentSublocationID']/../div/div[2]/a"));
					return element;
					}
				public WebElement txt_permanentSublocationID(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='permanentLocationName']"));
					return element;
					}
				public WebElement txt_Country(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@id='countryOfOriginName']"));
					return element;
					}
				
				public WebElement txt_trackingNumber(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='trackingNumber']"));
					return element;
					}
				public WebElement Btn_tracking(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("(//input[@value='Select Values'])[1]"));
					return element;
					}
				
				public WebElement Standalonepage(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Stand Alone')]"));
					return element;
					}
				
				public WebElement Btn_updateDetails(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Update Details']"));
					return element;
					}
				
				public WebElement Btn_AddParent(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Add Parent']"));
					return element;
					}
				
				public WebElement Btn_AddChild(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Add Child']"));
					return element;
					}

				public WebElement Btn_Decouple(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Decouple']"));
					return element;
					}
				public WebElement Btn_Edit(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Back to Edit Asset']"));
					return element;
					}
				public WebElement Btn_previous(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='previous']"));
					return element;
					}
				public WebElement Txt_message(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'You have successfully added a parent asset')]"));
					return element;
					}
				public WebElement Txt_message1(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'You have successfully added a child asset')]"));
					return element;
					}
				public WebElement Txt_ParentTracking(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='parentTrackingNumber']"));
					return element;
					}
				public WebElement Txt_ChildTracking(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='childTrackingNumber']"));
					return element;
					}
				public WebElement Checkbox(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='checkall']"));
					return element;
					}
				
				public WebElement VerifyParentTracking(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Add Parent Asset')]"));
					return element;
					}
				public WebElement VerifyChildTracking(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Add Child Asset')]"));
					return element;
					}
				
				public WebElement Edit_assetpage(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Asset Details')]"));
					return element;
					}
				public WebElement Child_assetpage(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Parent - Child Relationships')]"));
					return element;
					}
				
				public WebElement Btn_saveChanges(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@value='Save Changes']"));
					return element;
					}
				
				public WebElement Verify_ItemDetails(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Item Details')]"));
					return element;
					}
				
				public WebElement VerifyConsumable(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='trackableFlag']"));
					return element;
					}
				public WebElement header_ScanOutAsset(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//td[text()='Scan Out']"));
			        return element;

			    }

				public WebElement lnk_ScanintAsset(RemoteWebDriver wdriver)
				{
			      
					element = wdriver.findElement(By.xpath("//a[contains(text(),'Scan In Asset')]"));
			        return element;

			    }
		//25_11///////////////////////		
				public WebElement txt_NetBookValue(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='netBookValue']"));
					
			        return element;
			        
			    }
				
				
				public WebElement txt_Length(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='length']"));
					
			        return element;
			      
			    }
				
				public WebElement txt_Width(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='width']"));
					
			        return element;
			      
			    }
				
				
				public WebElement txt_Height(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='height']"));
					
			        return element;
			      
			    }
				//new
				public WebElement Btn_Clear(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@value='Clear All']"));
					
			        return element;
			      
			    }
				
				public WebElement Btn_SaveSearch(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@value='Saved Search']"));
					
			        return element;
			      
			    }
				
				public WebElement VerifyAsset(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Search for Asset')]"));
					
			        return element;
			      
			    }
				
				public WebElement VerifyParentChild(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Parent - Child Relationships')]"));
					
			        return element;
			      
			    }
				
				public WebElement Btn_ViewAsset(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("(//input[@value='View Asset'])[1]"));
					
			        return element;
			      
			    }
				///////26////
				////////////////////////////////
				public WebElement btn_AddNewCurrentLocation(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("(//input[contains(@onclick,'currentLocationName')])[1]"));
					
			        return element;
			      
			    	
		
}
				
				public WebElement btn_AddNewCurSubLocation(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[contains(@onclick,'currentSubLocationName')]"));
					
			        return element;

				}
				
				//input[contains(@onclick,'permanentLocationName')]
				
				public WebElement btn_AddNewPermanentLocation(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("(//input[contains(@onclick,'permanentLocationName')])[1]"));
					
			        return element;

				}
				
				public WebElement btn_AddNewPermSubLocation(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[contains(@onclick,'permanentSubLocationName')]"));
					
			        return element;

				}
				
				public WebElement btn_SelFromNewWindowCostObject(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("(.//td[contains(text(),' Cost Object #')]//parent::tr//img[@src='/fats/images/Tab.gif'])[2]"));
					
			        return element;

				}
				
				public WebElement Btn_AddnewLocation(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='locationID']/../div[2]/input"));
					
			        return element;
			      
			    }
			
				public WebElement Btn_AddnewSubLocation(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='sublocationID']/../div[2]/input"));
					
			        return element;
			      
			    }
				
				public WebElement TrackingNumber(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='trackingNumbers']/.."));
					
			        return element;
			      
			    }
			
				public WebElement Btn_Remove(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@value='Remove Item']"));
					
			        return element;
			      
			    }
			
				//new
				public WebElement Btn_txt(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("(//input[@name='relationAmt']/../text())[4]"));
					
			        return element;
			      
			    }
				
				public WebElement Btn_print(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@name='printButton']"));
					
			        return element;
			      
			    }

			
				public WebElement Btn(RemoteWebDriver wdriver)
				{
					
					element = wdriver.findElement(By.xpath("//input[@type='button']"));
					
			        return element;
			      
			    }
				
				public WebElement btn_printablepage(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("(//input[@value='Printable Page'])"));
				        return element;

				    }
				
				public WebElement  txt_OriginalHeader(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//tr[@id='original_header']"));
				        return element;

				    }
				
				public WebElement btn_previous1(RemoteWebDriver wdriver)
				{
				     
				element = wdriver.findElement(By.xpath("//input[@value='<< Previous']"));
				        return element;

				    }
				
				public WebElement btn_Next(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@value='Next >>']"));
				        return element;

				    }
				
				
				
				public WebElement btn_previous(RemoteWebDriver wdriver)
				{
				     
				element = wdriver.findElement(By.xpath("//input[@value='Previous']"));
				        return element;

				    }
				
				
				public WebElement btn_selectAsset(RemoteWebDriver wdriver)
				{
				     
				element = wdriver.findElement(By.xpath("(//input[@name='fixedAssetID'])[1]"));
				        return element;

				    }
				public WebElement btn_viewAsset(RemoteWebDriver wdriver)
				{
				     
				element = wdriver.findElement(By.xpath("(//input[@value='View Asset'])[1]"));
				        return element;

				    }
				public WebElement txt_viewAssetscreen(RemoteWebDriver wdriver)
				{
				     
				element = wdriver.findElement(By.xpath("//td[contains(text(),'Asset Details ')]"));
				        return element;

				    }
				public WebElement btn_addArrow(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("(//td[@class='dataCenter']/img)[2]"));
				        return element;

				    }
				
				public WebElement btn_selectAvailableColumns(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//select[@name='availCols']"));
				        return element;

				    }
				
				public WebElement btn_ChangeLayout(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@value='Change Layout']"));
				        return element;

				    }
				
				public WebElement btn_ScanOutPageCurrentSubLocation(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("(//td[contains(text(),'Current Sub-Location')]//parent::tr//img[@src='/fats/images/Tab.gif'])[1]"));

				        return element;
				}
				
				public WebElement radiobtn_ScanOutCurrentSubLocationSelection(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[2]"));

				        return element;
				}
				public WebElement btn_ScanOutPageContactName(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("(//td[contains(text(),'Contact Name')]//parent::tr//img[@src='/fats/images/Tab.gif'])[1]"));

				        return element;
				}
				
				public WebElement radiobtn_ScanInCurrentSubLocationSelection(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[1]"));

				        return element;
				}
				
				
				public WebElement btn_ScanOutPageCalenderIcon(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("//img[@src='/fats/images/Calendar.gif']"));

				        return element;
				}
				
				public WebElement btn_ScanOutPageCalenderDate(RemoteWebDriver wdriver)

				{
					/*DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
				    
				    
				    Date date = new Date();
				    
				    
				    String date1= dateFormat.format(date);
				    String[] actDate = date1.split("/");
				    String tmrdate = actDate[1];
				    String dateplus1 = tmrdate;
				    int Date = Integer.parseInt(dateplus1);
				    
				    String Dateactual = Integer.toString(Date+1);*/
				//element = wdriver.findElement(By.xpath("//a[contains(text(),"+Dateactual+")]"));
					element = wdriver.findElement(By.xpath("//a[normalize-space()='18']"));

				        return element;
				}
				
				public WebElement btn_ScanInPageContinueButton(RemoteWebDriver wdriver)
				{

				element = wdriver.findElement(By.xpath("//input[@id='continueButton']"));

				        return element;
				}

				public WebElement txt_ScanInTrackingNum(RemoteWebDriver wdriver)
				{
				  
					element = wdriver.findElement(By.xpath("//input[@id='trackingNum']"));
				    return element;
				
				}
				
				public WebElement btn_ScanInPageAddTrackingNumContinueButton1(RemoteWebDriver wdriver)
				{

				element = wdriver.findElement(By.xpath("//input[@id='continueButton']"));

				        return element;
				}
				
				public WebElement btn_ScanInPageAddTrackingNumContinueButton(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("//input[@id='continue']"));

				        return element;
				}
				
				public WebElement btn_ScanInPrintablePagebtn(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("//input[@value='Printable Page']"));

				        return element;
				}
				
				public WebElement Lbl_PrintablePage_itemNum(RemoteWebDriver wdriver)
				{
				  
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Item Number')]"));
				    return element;

				}
				
				public WebElement EnterAssetPage_StatusTextBox(RemoteWebDriver wdriver)
				{
				  
					element = wdriver.findElement(By.xpath("//input[@name='statusName']"));
				    return element;

				}
				
				public WebElement btn_ScanOutPageCurrentLocation(RemoteWebDriver wdriver)

				{

					element = wdriver.findElement(By.xpath("(//td[contains(text(),' Current Location')]//parent::tr//img[@src='/fats/images/Tab.gif'])[1]"));

				    return element;
				}
				public WebElement radiobtn_ScanInCurrentLocationSelection(RemoteWebDriver wdriver)

				{

				element = wdriver.findElement(By.xpath("(//input[@type='radio'])[1]"));

			        return element;
			    }
				
				public WebElement CurrentLocation_Lookup(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='locationID']/../div/div/a/img"));
					return element;
				}
				
				public WebElement ContactName_Lookup(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='personResponsibleID']/../div/div/a/img"));
					return element;
				}
				
				public WebElement CurrentSubLocation_Lookup(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//input[@name='sublocationID']/../div/div/a/img"));
					return element;
				}
				
				public WebElement ChangeLayout_Status(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//option[@value='STATUS_NAME']"));
					return element;
				}
				
				public WebElement ChangeLayout_AddSelect(RemoteWebDriver wdriver) {
					element = wdriver.findElement(By.xpath("//img[@onclick='addSelect()']"));
					return element;
				}
				
				public WebElement ScanOut_AssetDetails_Status(RemoteWebDriver wdriver) 
				{
					element = wdriver.findElement(By.xpath("//textarea[@name='scanOutComments']/../following-sibling::td"));
					return element;
				}
				
				public WebElement ScanOut_TrackingNumber(RemoteWebDriver wdriver) 
				{
					element = wdriver.findElement(By.xpath("//input[@name='trackingNumbers']/.."));
					return element;
				}
				
				public WebElement ScanOut_SuccessMessage(RemoteWebDriver wdriver) 
				{
					element = wdriver.findElement(By.xpath("//td[@class='white']"));
					return element;
				}

				public WebElement Assets_SearchForAssets(RemoteWebDriver wdriver) 
				{
					element = wdriver.findElement(By.xpath("//input[@value='Search For Assets'][1]"));
					return element;
				}
				
				public WebElement Assets_SearchForAssets_ModifySearch(RemoteWebDriver wdriver) 
				{
					element = wdriver.findElement(By.xpath("//input[@value='Modify Search']"));
					return element;
				}
				
				public WebElement AssetDetails_ScanOutButton(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//input[@value='Scan Out']"));
			        return element;
				}
				
				public WebElement ScanOutPage_CurrentLocation(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//input[(@name='locationName')]"));
			        return element;
				}
				
				public WebElement Asset_ViewHistory(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("(//td[@class='headerLeftHist'])[1]"));
			        return element;
				}
				
				public WebElement ScanOut_ScanoutCostOjectNumber(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Scan Out Cost Object #')]/following-sibling::td"));
			        return element;
				}
				
				public WebElement PrintablePage_ScanoutCostOjectNumber(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Scan Out Cost Object #')]/following-sibling::td[1]"));
			        return element;
				}
				
				public WebElement ScanoutPage_ScanoutCostOjectNumber(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//input[@name='scanOutCostObjectCode']"));
			        return element;
				}
				
				public WebElement ScanoutPage_ScanoutCostOjectNumberLookUp(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//input[@name='scanOutCostObjectCode']/../../div/a/img"));
			        return element;
				}
				
				public WebElement ViewHistory_Scanout_CostObject(RemoteWebDriver wdriver)
				{ 
					element = wdriver.findElement(By.xpath("//td[contains(text(),'Scan out Internal Order:')]/../td[3]"));
			        return element;
				}
				
				public WebElement btn_SaveSearch(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@value='Save Search']"));
				        return element;
				}
				
				public WebElement SaveSearch_SearchName(RemoteWebDriver wdriver)
				{
				element = wdriver.findElement(By.xpath("//input[@name='savedSrchCriteriaName']"));
				        return element;
				}
				
				
}









			
				
				
				
				
				











