package com.AssetTracker.Web.ObjectRepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.dvnext.mobile.utils.PropertyFileReader;
//import com.mgm.mobile.constants.Constant;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

/* Description: Locators for all the elements in Home page
 * Created by: JyothiE
 * Created on: 04-May-19
 * Modified by:
 * Build No: 6.0 
 */

public class AssetTrack_LoginPage 
{
	public WebElement element;
	PropertyFileReader prop = new PropertyFileReader();
	
	
    //Terms of use alert
	
	public WebElement txt_Username(WebDriver wdriver)
	{
       /* if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
        {
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
            try {
                element = wdriver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'terms_of_use_continue')]"));
            } catch (Exception e) {
                element = wdriver.findElement(By.id("terms_of_use_continue"));
            }
        }
        */
		element = wdriver.findElement(By.xpath("//*[@id='username']"));
        return element;

    }
	
	public WebElement txt_Password(WebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//*[@id='password']"));
        return element;

    }
	
	public WebElement btn_SignIn(WebDriver wdriver)
	{
      
		element = wdriver.findElement(By.xpath("//button[contains(text(),'SIGN IN')]"));
        return element;

    }
	
	
	
	
	
	//***********************************************************************************
	public WebElement mBtn_Mob_TermsContinue(AppiumDriver<WebElement> driver)
	{
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
        {
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
            try {
                element = driver.findElement(By.xpath("//android.widget.Button[contains(@resource-id,'terms_of_use_continue')]"));
            } catch (Exception e) {
                element = driver.findElement(By.id("terms_of_use_continue"));
            }
        }
        return element;

    }
	
	//HOME tab
	
    public WebElement mBtn_Mob_HomeTab(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
        	try{
        		 element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='HOME']"));
        	}catch(Exception e)
        	{
        		element = driver.findElementByAccessibilityId("HOME");
        	}
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
            element = driver.findElement(By.id("action_my_stay"));
        }
        return element;
    }

   //Booked dining in itinerary
    
    public WebElement mElmnt_Mob_Mystay_RestaurantName(AppiumDriver<WebElement> driver, String RestaurantName)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
            element = driver.findElementByAccessibilityId("home-tab-dining-or-shows-reservations-list-type:restaurant-row:"+RestaurantName+"");
        }
        else if (prop.readPropFile("platform").equalsIgnoreCase("Android")) 
        {
            element = driver.findElement(By.xpath("//*[@text='" + RestaurantName + "']"));
        }
        return element;
    }
    public WebElement mElmnt_Mob_Mystay_Restaurant(AppiumDriver<WebElement> driver, String search)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
      try{
          element = driver.findElement(By.xpath("//XCUIElementTypeOther[@name='home-tab-dining-or-shows-reservations-list-type:restaurant-row:"+search+"']"));

      }  
        catch(Exception e){
            element = driver.findElementByAccessibilityId("home-tab-dining-or-shows-reservations-list-type:restaurant-row:"+search+"");
        }
        else if (prop.readPropFile("platform").equalsIgnoreCase("Android")) 
        {
            element = driver.findElement(By.xpath("//*[@text='" + search + "']"));
        }
        return element;
    }
    //Upcoming itinery in home page
    
    public WebElement mElmnt_Mob_Home_UpcomingItinerary(AppiumDriver<WebElement> driver) {
		 
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
        	
            element = driver.findElement(By.xpath("(//*[@type='XCUIElementTypeStaticText'])[1]"));
																  
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android")) {
																 
																																 
        }
        return element;
    }
    
    //Checkin CTA button
    
    public WebElement mBtn_Mob_Home_CheckInCTA(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
        	try{
        		element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='checkInCtaButton']"));
        		 
        	}catch(Exception e)
        	{
        		element = driver.findElementByAccessibilityId("checkInCtaButton");
        		  
        	}
             
            
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	try 
        	{
                element = driver.findElement(By.xpath("//android.widget.Button[@text='CHECK-IN']"));
            }
        	catch (Exception e)
            {
                element = driver.findElement(By.id("home_fragment_reservation_button"));
             }
        }
        return element;
    }
    
    //Checkin in top right corner
    public WebElement mBtn_Mob_Home_CheckIn(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
        	try{
    			element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='checkInBarButton']"));

        		}catch(Exception e)
        		{
        			 element = driver.findElementByAccessibilityId("checkInBarButton");

    			}
        	
          
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	try 
        	{
                element = driver.findElement(By.xpath("//android.widget.Button[@text='CHECK-IN']"));
            }
        	catch (Exception e)
            {
                element = driver.findElement(By.id("home_fragment_reservation_button"));
             }
        }
        return element;
    }
    
    //Checkin date - 6.0 - 14-May-19
    public WebElement checkinDate(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
              element = driver.findElementByAccessibilityId("dateTime");
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
    
    //View room key CTA
    public WebElement viewRoomKey(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {		try{
        				element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='viewRoomKeyCtaButton']"));

        			}catch(Exception e)
			        {
        				 element = driver.findElementByAccessibilityId("viewRoomKeyCtaButton");
			        }
             
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
        
      //Continue to checkout CTA
    public WebElement continueCheckout(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
        	try{
				element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='continueToCheckoutCtaButton']"));

			}catch(Exception e)
	        {
				 element = driver.findElementByAccessibilityId("continueToCheckoutCtaButton");
	        }
             
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
    
    public WebElement mBtn_Mob_Home_Login(AppiumDriver<WebElement> driver) {
		if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
			try {
				element = driver.findElement(By.xpath("(//XCUIElementTypeLink[@name='Log in'])[1]"));
				element.click();


			}catch(Exception e) {
				MobileElement el = (MobileElement) driver.findElement(MobileBy.xpath("(//XCUIElementTypeLink[@name='Log in'])[2]"));
				//((IOSDriver<WebElement>) driver).tap(1, el.getLocation().getX() + el.getSize().getWidth() - 5, el.getLocation().getY() + 5, 200);
			}
		} else if (prop.readPropFile("platform").equalsIgnoreCase("Android")) {
			try {
				MobileElement el = (MobileElement) driver.findElement(By.xpath("//android.widget.TextView[@text='Already an M life Rewards member? Log in']"));
				//((AndroidDriver<WebElement>) driver).tap(1, el.getLocation().getX() + el.getSize().getWidth() - 5, el.getLocation().getY() + 5, 200);

			} catch (Exception e1) {
				element = driver.findElement(By.id("home_fragment_not_logged_in_card_item_login_button"));
			}
		}
		return element;
	}
    
  //View reservation CTA
    public WebElement viewReservation(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {		try{
        	          element = driver.findElementByAccessibilityId("viewReservationCtaButton");
        			}catch(Exception e)
			        {
        				 element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name=\"viewReservationCtaButton\"]\n" + ""));
			        }
             
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
    
  //View All button when multipke dinings are available -- iOS-6.1.0 -- JyothiE
    public WebElement viewAll(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {		try{
        	          element = driver.findElementByAccessibilityId("viewAllButton");
        			}catch(Exception e)
			        {
        				 element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='viewAllButton']"));
			        }
             
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
    
    //Shows button in home page
    public WebElement showsButton(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
        	try{
        		 element = driver.findElementByAccessibilityId("showsButton");
			}catch(Exception e)
	        {
				element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='showsButton']"));	
	        }
             
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
    
  //nightlife button in home page
    public WebElement nightLifeButton(AppiumDriver<WebElement> driver)
    {
        if (prop.readPropFile("platform").equalsIgnoreCase("iOS"))
        {
        	try{
        		 element = driver.findElementByAccessibilityId("nightlifeButton");
			}catch(Exception e)
	        {
				element = driver.findElement(By.xpath("//XCUIElementTypeButton[@name='nightlifeButton']"));	
	        }
             
        } else if (prop.readPropFile("platform").equalsIgnoreCase("Android"))
        {
        	//TODO
        }
        return element;
    }
    }
    
	
