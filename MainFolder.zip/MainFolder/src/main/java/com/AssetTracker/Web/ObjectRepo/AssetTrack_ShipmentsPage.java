package com.AssetTracker.Web.ObjectRepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.dvnext.mobile.utils.PropertyFileReader;

public class AssetTrack_ShipmentsPage 
{
	public WebElement element;
	PropertyFileReader prop = new PropertyFileReader();
	
	
	public WebElement lnk_SearchShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//a[contains(text(),'Search Shipment')]"));
        return element;

    }
	
	public WebElement btn_ShowLatestShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Show Latest Shipments']"));
        return element;

    }
	
	public WebElement btn_View(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//input[@value='View'])[1]"));
        return element;

    }
	
	public WebElement txt_Verify_ShipmentNo(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[(text()='Shipment Number ')]/following-sibling::td"));
        return element;

    }
	
	public WebElement btn_DeleteShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//input[@name='Delete'])[1]"));
        return element;

    }

	public WebElement msg_ConfirmDeleteShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//*[contains(text(),'Shipment has been deleted sucessfully')]"));
        return element;

    }
	public WebElement txt_Action(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//td[text()='Action']"));
        return element;

    }
	public WebElement tit_Confirmation_Page(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//td[text()='Confirmation']"));
        return element;

    }
	
	public WebElement txt_ShipmentId(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@name='searchShipmentID']"));
        return element;

    }
	
	public WebElement btn_SelectValues(RemoteWebDriver wdriver,String selectVal)
	{
		element = wdriver.findElement(By.xpath("//input[@name='"+selectVal+"']/following-sibling::input"));
        return element;

    }
	
	public WebElement btn_SearchShipmentAction(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Search Shipment']"));
        return element;

    }
	public WebElement msg_NoMatches(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//center"));
        return element;

    }
	
	public WebElement btn_CopyShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//input[@value='Copy Shipment'])[1]"));
        return element;

    }
	
	public WebElement msg_CopyShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//table/tbody/tr/td[@class='color'])[1]"));
        return element;

    }
	
	public WebElement msg_CopyShipmentCase(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//td[@class='color'])[1]"));
        return element;

    }
	public WebElement btn_CopyShipmentCaseYes(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[contains(@onclick,'fnYes')]"));
        return element;

    }
	
	public WebElement btn_CopyShipmentCaseNo(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[contains(@onclick,'fnNo')]"));
        return element;

    }
	
	public WebElement btn_CopyShipmentCaseCancel(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[contains(@onclick,'fnCancel')]"));
        return element;

    }
	public WebElement btn_ShipmentFinish(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//input[@name='finish'])[1]"));
        return element;

    }
	public WebElement btn_UpdateShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//input[@value='Update Shipment'])[1]"));
        return element;

    }
	public WebElement btn_CopyCase(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("(//input[@value='Copy Case'])[1]"));
        return element;

    }
	public WebElement txt_CopyQuantity(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@name='copyQuantity']"));
        return element;

    }
	
	public WebElement btn_CopyCreate(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Create']"));
        return element;

    }
	public WebElement txt_ShipmentTracking(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@id='trackingnumber0']"));
        return element;

    }
	public WebElement btn_SaveCopyShipment(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@id='saveCopyButton']"));
        return element;

    }
	
	public WebElement btn_ModifySearch(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Modify Search']"));
        return element;

    }
	public WebElement btn_GlobalUpdate(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Global Update']"));
        return element;

    }
	public WebElement btn_SortResults(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Sort Results']"));
        return element;

    }
	public WebElement btn_ChangeLayout(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Change Layout']"));
        return element;

    }
	public WebElement btn_RemoveCase(RemoteWebDriver wdriver,String RandomCaseNum)
	{
		//element = wdriver.findElement(By.xpath("//input[@name='removeCase']"));
		element = wdriver.findElement(By.xpath("//*[contains(text(),'Case "+RandomCaseNum+"')]/following-sibling::td/input[@name='removeCase']"));
		
        return element;

    }
	public WebElement btn_AddCase(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Add Case']"));
        return element;

    }
	public WebElement btn_AddUnits(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Add Units']"));
        return element;

    }
	public WebElement txt_AddCaseTrackingNum(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@id='trackingNum']"));
        return element;

    }
	public WebElement btn_AddCaseAddItem(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Add Item']"));
        return element;

    }
	public WebElement btn_AddCaseContinue(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@id='continue']"));
        return element;

    }
	public WebElement btn_AddCaseSave(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@value='Save']"));
        return element;

    }
	
	public WebElement btn_CaseDetailsExpand(RemoteWebDriver wdriver,String RandomCaseNum)
	{
		//element = wdriver.findElement(By.xpath("//input[@value='+']"));
		element = wdriver.findElement(By.xpath("//*[contains(text(),'Case "+RandomCaseNum+"')]/input[@value='+']"));
		
        return element;

    }	
	public WebElement txt_CaseDetails(RemoteWebDriver wdriver,String TrackingNumber)
	{
		element = wdriver.findElement(By.xpath("//td[@class='dataLeft'][contains(text(),'"+TrackingNumber+"')]"));
        return element;

    }	
	public WebElement txt_CaseNumber(RemoteWebDriver wdriver)
	{
		element = wdriver.findElement(By.xpath("//input[@name='caseNumber']"));
        return element;

    }
	
	
	

	//Shipment module elements

		public WebElement lnk_Shipment(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@src='/fats/images/Shipments.gif']"));
			return element;
		}
		
		public WebElement lnk_EnterShipment(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()='Enter Shipment']"));
			return element;
		}
		public WebElement shipdate_cal(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()=' Ship Date']/following::img[1]"));
			return element;
		}
		
		public WebElement selectShipDate(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()='19']"));
			return element;
		}
		
		
		
		
		public WebElement checkbox_noreturndate(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@name='returnDateCheck']"));
			return element;
		}
		
		public WebElement waybill_save(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@name='submitButton'])[1]"));
			return element;
		}
		
		public WebElement shipmentno(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@name='shipmentID']"));
			return element;
		}
		
		public WebElement addcase(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@value='Add Case'])[1]"));
			return element;
		}
		
		public WebElement addunits(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@value='Add Units']"));
			return element;
		}
		
		public WebElement addassttoshipment_additem(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@value='Add Item']"));
			return element;
		}
		
		public WebElement addassttoshipment_continue(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@value='Continue']"));
			return element;
		}
		
		public WebElement edititemscase(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()='Edit Items: Case 1']"));
			return element;
		}
		
		public WebElement edititemssave(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@value='Save'])[1]"));
			return element;
		}
		
		public WebElement waybillOrManifestDetails(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()='Waybill / Manifest Details']"));
			return element;
		}
		
		public WebElement waybillOrManifestDet_copycase(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@value='Copy Case'])[1]"));
			return element;
		}
		
		public WebElement copycase_Quantity(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@name='copyQuantity']"));
			return element;
		}
		
		public WebElement copycase_Btn_Create(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@value='Create']"));
			return element;
		}
		
		public WebElement addassttoshipment_trackingno(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@name='trackingNum']"));
			return element;
		}
		
		public WebElement btn_entershipment_finish(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@value='Finish'])[2]"));
			return element;
		}
		
		public WebElement btn_shipfromEditAddress(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@value='Edit Address'])[1]"));
			return element;
		}
		
		public WebElement btn_consignedtoEditAddress(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//*[@value='Edit Address'])[2]"));
			return element;
		}
		
		public WebElement editadd_Attn(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()=' ATTN ']/following::img[1]"));
			return element;
		}
		
		public WebElement btn_editadd_Save(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@value='Save']"));
			return element;
		}
		
		public WebElement txt_editadd_Zipcode(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()='Zip Code']/following::input"));
			return element;
		}
		
		public WebElement txt_editadd_state(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[@name='state']"));
			return element;
		}
					
		
		public WebElement txt_editadd_Sitename(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()=' Site Name']/following::input[1]"));
			return element;
		}

		public WebElement currentSubLocation(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//*[text()=' Current Sub-Location']/following::img[1]"));
			return element;
		}
		

		public WebElement selValueWindow(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("(//*[@type='radio'])[1]"));
			return element;
		}
		
		public WebElement SearchShipment_ShipmentNo_Selectvalues(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//input[@name='searchShipmentID']/../input[@value='Select Values']"));
			return element;
		}
		
		public WebElement SearchShipments_SearchforShipmentsButton(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//input[@value='Search For Shipment']"));
			return element;
		}
		
		
		public WebElement WayBillPage_ShipmentNumber(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//td[contains(text(),'Shipment Number ')]/following-sibling::td"));
			return element;
		}
		
		public WebElement WayBill_ManifestDetailsPage(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//*[contains(text(),' Waybill')]"));
			return element;
		}
		
		public WebElement WayBillDetails_collapseButton(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//*[contains(text(),' Waybill')]/../td/input[@value='-']"));
			return element;
		}
		
		public WebElement WayBillDetails_ExpandButton(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//*[contains(text(),' Waybill')]/../td/input[@value='+']"));
			return element;
		}
		
		public WebElement CaseDetails_ExpandButton(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("(//input[@type='button' and @value='+'])[2]"));
			return element;
		}
		
		public WebElement CaseDetails_caseNumber2(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("//td[contains(text(),'Case Number')]/../td[contains(text(),'2')]"));
			return element;
		}
		
		public WebElement bt_Exportmanifest(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("(//input[@value='Export Manifest'])[1]"));
			return element;
		}
		
		public WebElement bt_Previous(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("(//input[@value='Previous'])[1]"));
			return element;
		}
		
		public WebElement Casedetails_CaseContents(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("(//td[contains(text(),'Case Contents')]/../td[@class='dataLeft'])[2]"));
			return element;
		}
	
		public WebElement CaseDetails_CollapseButton(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//input[@type='button' and @value='-'])[2]"));
			return element;
		}
		
		public WebElement WayBillPage_EditAddress(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//input[@value='Edit Address'])[1]"));
			return element;
		}
		
		public WebElement WayBillPage_Save(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Waybill')]/../td/input[@value='Save']"));
			return element;
		}
		public WebElement WayBillPage_Finish(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Waybill')]/../td/input[@value='Finish']"));
			return element;
		}
		
		public WebElement WayBillPage_AddCase(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Waybill')]/../td/input[@value='Add Case']"));
			return element;
		}
		
		public WebElement CaseDetailsScreen(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Case Details')]"));
			return element;
		}
		
		public WebElement CaseDetails_Cancelbutton(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("//input[@name='cancelButton']"));
			return element;
		}
		/*public WebElement lnk_EnterShipment(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//a[contains(text( ),'Enter Shipment')]"));
		        return element;

		    }*/

		public WebElement txt_ShipmentPage(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Waybill / Manifest Details')]"));
		        return element;

		    }
		public WebElement btn_ShipfromeditAddress(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@value='Edit Address'])[1]"));
		        return element;

		    }
		public WebElement btn_ShipfromeditTo(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@value='Edit Address'])[2]"));
		        return element;

		    }
		public WebElement btn_shipfromsave(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@value='Save']"));
		        return element;

		    }
		public WebElement txt_searchsitefrom(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@id='locationName']"));
		        return element;

		    }
		public WebElement btn_searchsitefromtab(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//div[@class='tabImage']/a)[1]"));
		        return element;

		    }
		public WebElement txt_searchattn(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@id='attention']"));
		        return element;
		}
		public WebElement btn_searchattn(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//div[@class='tabImage']/a)[2]"));
		        return element;

		    }
		public WebElement txt_currentlocation(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@id='currentLocationName']"));
		        return element;

		    }
		public WebElement btn_currentlocationtab(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//div[@class='tabImage'])[1]"));
		        return element;

		   }

		public WebElement txt_currentsublocation(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='currentSublocationName']"));
		        return element;

		    }
		public WebElement btn_currentsublocationtab(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//div[@class='tabImage'])[2]"));
		        return element;

		    }
		public WebElement btn_currentsublocationtabsearch(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='currentSublocationName']/following::a)[1]"));
		        return element;

		    }

		public WebElement txt_courier(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='courier']"));
		        return element;

		    }
		public WebElement txt_waybillinfo(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='waybillInfo']"));
		        return element;

		    }
		public WebElement btn_save(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='submitButton']"));
		        return element;
		}
		public WebElement Addressinfo_State(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//select[@name='state']"));
		        return element;

		 }
		
		public WebElement WaybillManifestPage_RequestedBy(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='requestedBy']"));
		        return element;
		}
		
		public WebElement WaybillManifestPage_RequestedByLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='requestedBy']/../../div/a"));
		        return element;
		}
		
		public WebElement WaybillManifestPage_TotalWeight(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Total Weight')]"));
		        return element;
		}
		
		public WebElement WaybillManifestPage_TotalValue(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Total Value')]"));
		        return element;
		}
		public WebElement WaybillManifestPage_ShipmentApproverCheckBox(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Shipment approved by NBC Legal/JPMC Vastera')]/../td/input"));
		        return element;
		}
		
		public WebElement WaybillPage_ShipmentApproverCheckBox_Checked(RemoteWebDriver wdriver)
		{
		//element = wdriver.findElement(By.xpath("//input[@name='shipmentLegalFlag' and @value='Y']"));
		element = wdriver.findElement(By.xpath("//input[@name='shipmentLegalFlag' and @value='Y']/../td[1]"));
		
		        return element;
		}
		
		public WebElement WaybillPage_ShipmentApproverCheckBox_UnChecked(RemoteWebDriver wdriver)
		{
		//element = wdriver.findElement(By.xpath("//input[@name='shipmentLegalFlag' and @value='N']"));
		element = wdriver.findElement(By.xpath("//input[@name='shipmentLegalFlag' and @value='N']/../td[1]"));
		        return element;
		}
		
		public WebElement WaybillPage_FromLocation(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//textarea[@name='fromLocationDesc']"));
		        return element;
		}
		
		public WebElement txt_faxNo(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='fax']"));
		        return element;
		}
		
		public WebElement txt_City(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='city']"));
		        return element;
		}
		
		public WebElement WayBillPage_DateRequested(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Date Requested')]"));
		        return element;
		}
		
		public WebElement WayBillPage_ShipDate(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Ship Date')]"));
		        return element;
		}
		
		public WebElement WayBillPage_DeliveryRequired(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Delivery Required By')]"));
		        return element;
		}
		
		public WebElement WayBillPage_ExpectedReturnDate(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Expected Return Date')]"));
		        return element;
		}
		public WebElement WayBillPage_AddCaseButton(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@value='Add Case'])[1]"));
		        return element;
		}
		
		public WebElement CaseDetailsPage(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Case #')]"));
		        return element;
		}
		
		public WebElement CaseDetailsPage_CaseTrackingNo(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Case Tracking #')]"));
		        return element;
		}
		
		public WebElement AddAssets_TrackingNumber(RemoteWebDriver wdriver)
		{
		  
			element = wdriver.findElement(By.xpath("//input[@id='trackingNum']"));
		    return element;
		}
		

		public WebElement WayBillPage_ProFormaInvoice(RemoteWebDriver wdriver)
		{
		  
			element = wdriver.findElement(By.xpath("//td[contains(text(),'Pro-Forma Invoice')]/following-sibling::td"));
		    return element;
		}
		
		public WebElement CaseDetails_ExpandButton1(RemoteWebDriver wdriver)
		{

			element = wdriver.findElement(By.xpath("(//input[@type='button' and @value='+'])[1]"));
			return element;
		}
		
		public WebElement CaseDetails_EditItems(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//input[@value='Edit Items'])[1]"));
			return element;
		}
		
		public WebElement CaseDetails_RemoveItems(RemoteWebDriver wdriver)
		{
			element = wdriver.findElement(By.xpath("(//input[@value='Remove Case'])[1]"));
			return element;
		}
		public WebElement Addressinfo_StateDisabled(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//select[@name='state' and @disabled='']"));
		        return element;

		 }
		
		public WebElement WayBillPage_CurrentLocationLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='currentLocationID']/following::a)[1]"));
		        return element;
		}
		
		public WebElement EditItems_Override_CVCheckBox(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='customsOverride'])[1]"));
		        return element;
		}
		
		public WebElement EditItems_CountryOfOrigin(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='countryNames_0'])[1]"));
		        return element;
		}
		
		public WebElement EditItems_CountryOfOrigin_LookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='countryNames_0'])[1]/../../td[2]/a/img"));
		        return element;
		}
		
		public WebElement WayBill_LatUpdatedOn(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Last Updated On')]"));
		        return element;
		}
		
		public WebElement WayBill_LatUpdatedBy(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Last Updated By')]"));
		        return element;
		}
		
		public WebElement caseDetails_CaseNumber(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[contains(text(),'Case #')]/../td/input"));
		        return element;
		}
		
		public WebElement WayBillPage_CurrentLocation_Addnew(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@id='currentLocationName']/../../div/input[@value='Add New']"));
		        return element;
		}
		

		public WebElement WayBillPage_CurrentLocation_NewLocation(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='newLocationName']"));
		        return element;
		}
	
		public WebElement Maintain_CurrentLocation_Message(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//font[@class='message']"));
		        return element;
		}
		
		public WebElement Maintain_CurrentLocation_Cancel(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='Cancel']"));
		        return element;
		}
		
		public WebElement WayBillPage_CurrentSubLocation_Addnew(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@id='currentSublocationName']/../../div/input[@value='Add New']"));
		        return element;
		}
			
		public WebElement WayBillPage_PackedByLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='packedBy']/following::a)[1]"));
		        return element;
		}
		
		public WebElement WayBillPage_CustomsPercentage(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='customsPercentage']"));
		        return element;
		}
		
		public WebElement WayBillPage_Comments(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//textarea[@name='comments']"));
		        return element;
		}
		
		public WebElement WayBillPage_PeopleSoftEbuy(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@name='POSystem' and @value='EBUY']"));
		        return element;
		}
		
		public WebElement WayBillPage_BussinessUnitLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='buID']/following::a)[1]"));
		        return element;
		}
		
		public WebElement WayBillPage_DepartmentLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='departmentID']/following::a)[1]"));
		        return element;
		}
	
		public WebElement WayBillPage_AccountIDLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='accountID']/following::a)[1]"));
		        return element;
		}
		
		public WebElement WayBillPage_ShowCodeLookUp(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@name='showCode']/following::a)[1]"));
		        return element;
		}
		
		public WebElement AddAsset_To_Shipment_Cancel(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//input[@value='Cancel']"));
		        return element;
		}
		
		public WebElement EditItems_CustomValuesDisabled(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[@id='customValuesEnabled0'and @style='display: none;']"));
		        return element;
		}
		
		public WebElement EditItems_Remove(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("(//input[@value='Remove'])[1]"));
		        return element;
		}
		
		public WebElement EditItems_Heading(RemoteWebDriver wdriver)
		{
		element = wdriver.findElement(By.xpath("//td[@class='headerLeft']"));
		        return element;
		}
		
		
	}


	