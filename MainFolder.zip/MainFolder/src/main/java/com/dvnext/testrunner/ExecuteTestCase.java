package com.dvnext.testrunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.testng.TestNG;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlInclude;
import org.testng.xml.XmlSuite;
import org.testng.xml.XmlTest;

import com.dvnext.excelutils.ExcelReader;
import com.dvnext.mobile.propertyreader.PropertyFileReader;

public class ExecuteTestCase {

    static Logger logger = Logger.getLogger(ExecuteTestCase.class);

    public static void main(String[] ar) {
        String platform;

        PropertyFileReader fileReader = new PropertyFileReader();
        // platform = fileReader.readPropFile("platform");
        // String suite = fileReader.readPropFile("testSuite").trim();
        String testSetPath = fileReader.readPropFile("tsFilePath").trim();
        System.out.println(testSetPath);
        String testSetSheetName = fileReader.readPropFile("tsSheetName").trim();
        System.out.println(testSetSheetName);
        TestNG myTestNG = new TestNG();
        String suite = "Sanity";
        String test = "API";
        String tcls = null;
        try {
            List<Map> rows = ExcelReader.read(testSetPath, testSetSheetName);
            System.out.println("Rows are::" + rows);

            XmlSuite mySuite = new XmlSuite();
            mySuite.setName(suite);
            List<XmlSuite> mySuites = new ArrayList<XmlSuite>();
            List<XmlTest> myTests = new ArrayList<XmlTest>();
            Map<String, String> testngParams = new HashMap<String, String>();
            XmlTest myTest = new XmlTest(mySuite);
            myTest.setName(test);

            List<XmlClass> myClasses = new ArrayList<XmlClass>();
            List<XmlInclude> xmlInclude = new ArrayList<XmlInclude>();
            for (Map map : rows)
            {

                if ((map.containsKey("TestClass") && map.containsKey("TestCaseName") && map.get("SelectYN").toString().equals("Y")))
                {
                    XmlClass cls = new XmlClass(map.get("TestClass").toString());
                    System.out.println(map.get("TestClass").toString());
                    myClasses.add(cls);
                    xmlInclude.add(new XmlInclude(map.get("TestCaseName").toString()));
                    System.out.println(map.get("TestCaseName").toString());
                    cls.setIncludedMethods(xmlInclude);
                }
            }
            myTest.setXmlClasses(myClasses);
            myTests.add(myTest);
            mySuite.setTests(myTests);
            mySuites.add(mySuite);
            myTestNG.setXmlSuites(mySuites);
            myTestNG.run();
        } catch (ClassNotFoundException e) {
            logger.error("ERROR: TestSuite: " + suite + "- Class not found..!!");
        } catch (Exception e) {
            logger.error("ERROR: Problem while reading test set" + testSetPath
                    + "..!!" + e.getMessage());
        }

    }
}
