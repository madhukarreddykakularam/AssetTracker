package com.dvnext.mobile.utils;

public class Xpaths {

}
