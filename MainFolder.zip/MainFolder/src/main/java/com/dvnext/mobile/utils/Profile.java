package com.dvnext.mobile.utils;

public class Profile
{
	public  String firstName = "";
	public  String lastName = "";
	public  String emailDomain = "";
	public  String phoneNumber = "";
	public String dobYear = "";
	public  String address = "";
	public  String zip = "";
	public  String state = "";
	public  String city = "";
	public  String country = "";
	public  String securityQuestion = "";
	
	
	public Profile() 
	{
		setFirstName(RandomDetails.getFirstName());
        setlastName(RandomDetails.getLastName());
        setPhoneNumber(RandomDetails.getPhoneNumber());
        setDOBYear(RandomDetails.getDOBYear());
        setAddress(RandomDetails.getAddress());
        setzipStateCityCountry(RandomDetails.getZIPStateCityCountry());
        
        setSecurityQuestion(RandomDetails.getSecurityQuestion());
	}
	private void setDOBYear(String dobYear) {
		this.dobYear = dobYear;
		
	}
	private void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
		
	}
	private void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	private void setzipStateCityCountry(String zipStateCity) {
		this.zip = zipStateCity.split(",")[0];
		this.city = zipStateCity.split(",")[1];
		this.state = zipStateCity.split(",")[2];
		this.country = zipStateCity.split(",")[3];
		
	}
	private void setAddress(String address) {
		this.address = address;
		
	}
	private void setEmailDomain(String emailDomain) {
		this.emailDomain = emailDomain;
		
	}
	private void setlastName(String lastName) 
	{
		this.lastName = lastName;
	}
	public void setFirstName(String firstName)
	{
		
		this.firstName = firstName;
	}
		
        
}
	

