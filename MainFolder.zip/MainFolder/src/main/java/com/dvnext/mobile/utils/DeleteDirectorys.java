package com.dvnext.mobile.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class DeleteDirectorys {
    final static String strRelPath = "./";
    
    
    
    

    public static boolean deleteDirectory() throws IOException { 
        String dir1 = strRelPath+"target/surefire-reports";
        FileUtils.deleteDirectory(new File(dir1));
        /*File dir = new File(dir1);
        if (dir.isDirectory()) { 
            File[] children = dir.listFiles(); 
            for (int i = 0; i < children.length; i++) { 
                boolean success = deleteDirectory(); 
                if (!success) { 
                    return false; 
                }
            }
        }*/
        // either file or an empty directory 
       // System.out.println("removing file or directory : " + dir1.getName()); 
        return true; 
    }
    public static void createDirectory(){ 
        File directory = new File(strRelPath+"target/surefire-reports"); 
        if (directory.exists()) { 
            System.out.println("Directory already exists ..."); } 
        else { 
            System.out.println("Directory not exists, creating now"); 
            boolean success = directory.mkdir(); 
            if (success) { 
                System.out.printf("Successfully created new directory : %s%n", directory); }
            else { 
                System.out.printf("Failed to create new directory: %s%n", directory); 
            } }
    }

    
    public static void main(String[] ar) throws Exception
    { 
        DeleteDirectorys gen = new DeleteDirectorys();
        gen.deleteDirectory();
    }

}
