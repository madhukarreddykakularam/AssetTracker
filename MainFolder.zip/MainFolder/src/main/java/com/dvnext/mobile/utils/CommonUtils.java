package com.dvnext.mobile.utils;

import java.util.List;

import org.apache.commons.lang3.time.StopWatch;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.dvnext.mobile.testreport.TestReporter;
///import com.nbcu.mobile.constants.Constant;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;


/*Class: CommonUtils 
 * Description: Contains static methods for general use Ex:Wait for elements visibility, clickable etc
 * Created By,On: Shashi, 15-May-19
 * Modified On:
 * Modified By: NA
 * Build No: 6.0
 * Modified deails: NA     
 * 
 */

public class CommonUtils {

	//xpaths for some elements

	public static String searchingMsgAfterSubmitClick_Xpath = "//XCUIElementTypeStaticText[@name='Searching...']";
	public static String loginDoneButton_Xpath = "//XCUIElementTypeButton[@name='loginButton']";
	public static String cardNumber_Xpath = "(//*[@type='XCUIElementTypeTextField'])[1]";
	public static String enhanceYourStay_Xpath =	"//XCUIElementTypeStaticText[@name='Enhance Your Stay']";
	public static String logOutButton_Xpath = "//XCUIElementTypeStaticText[@name='Log Out']";
	public static String saveButton_Xpath = "//XCUIElementTypeButton[@name='SAVE']";
	public static String confirmationTextField_Xpath = "//XCUIElementTypeTextField[@name='confirmationNumber']";
	public static String createAccountButton_Xpath=	"//XCUIElementTypeButton[@name='createAccountButton']";
	public static String addToReservationButton_Xpath="(//XCUIElementTypeButton)[2]";
	public static String cancelReservationButton_Xpath="//XCUIElementTypeButton[@name='cancelReservationButton']";
	public static String makeReservationButton_Xpath="//XCUIElementTypeButton[@name='makeOrUpdateReservationButton']";
	public static String activateAccountButton_Xpath="//XCUIElementTypeButton[@name='createAccountButton']";
	public static String currentReservation_Xpath ="//XCUIElementTypeStaticText[@name='Current Reservation']";
	public static String confirmBiometric_Xpath = "//XCUIElementTypeButton[@name='CONFIRM']";
	public static String roomChargeSummary_Xpath="//XCUIElementTypeOther[@name='Room Charge Summary']";
	public static String reviewSummaryAfterCheckOut_Xpath="//XCUIElementTypeButton[@name='reviewSummaryButton']";
	public static String continueToCheckIn_Xpath="//XCUIElementTypeButton[@name='continueToCheckInButton']";
	public static String continueToCheckIn_Accessibility="continueToCheckInButton";
	static PropertyFileReader prop = new PropertyFileReader();
	//waits until the element is visible 
	public static void waitForTheElementToBeVisible(AppiumDriver<WebElement> driver,long timeOut,WebElement webElement)
	{
		WebDriverWait wait = new WebDriverWait(driver, timeOut); 
		wait.until(ExpectedConditions.visibilityOf(webElement));

	}

	/*
	 * Wait for the element continuously whether it is in background or not within the given 
	 * timeOut and when found the element is displayed it returns true. 
	 * @author-shashi
	 * parameters-driver,timeOut,xpath for the element
	 * 
	 * 
	 */
	public static boolean waitForTheElementToBeVisibleUsingStopWatch(AppiumDriver<WebElement> driver,long timeOut,String xpath)
	{
		StopWatch stopwatch = new StopWatch();
		stopwatch.start();
		boolean isDisplayed=false;

		do {
			try{

				System.out.println("Waiting for the element to be visible");
				isDisplayed=driver.findElement(By.xpath(xpath)).isDisplayed();


			}catch(Exception e)
			{
				isDisplayed=false;
				System.out.println("signUp button :"+isDisplayed);
			}

		} while (!isDisplayed && stopwatch.getTime() < (timeOut));

		stopwatch.stop();

		return isDisplayed;

	}
	//waits until the element is  Clickable 
	public static void waitForTheElementToBeClickable(AppiumDriver<WebElement> driver,long timeOut,WebElement webElement)
	{
		WebDriverWait wait = new WebDriverWait(driver, timeOut); 
		wait.until(ExpectedConditions.elementToBeClickable(webElement));

	}
	public static void waitForHomeScreenToBeVisible(AppiumDriver<WebElement> driver) {
		// TODO Auto-generated method stub
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.or(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//XCUIElementTypeCell[@name='diningButton']")),
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//XCUIElementTypeCell[@name='showsButton']"))
				));

	}
	public static void waitForSignUpSuccess(AppiumDriver<WebElement> driver) {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.or(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//XCUIElementTypeCell[@name='diningButton']")),
				ExpectedConditions.visibilityOfElementLocated(By.xpath("(//XCUIElementTypeStaticText[@name='0 Tier Credits'])[1]")),
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//XCUIElementTypeCell[@name='showsButton']"))

				));

	}
	//waits until the element is invisible 
	public static void waitForInvisibilityOfElementLocated(AppiumDriver<WebElement> driver,long timeOut,String elementXpath)
	{
		WebDriverWait wait = new WebDriverWait(driver, timeOut); 
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath(elementXpath)));			

	}

	/*
	 * Use this method if want to go to home screen from any opened screen
	 * 
	 * @author-shashi
	 * parameters-driver
	 * 
	 * @Note- can be used if the next statement is mob_SwipeToLogout 
	 * 
	 */
	public static boolean goToHomeScreenUsingLoop(AppiumDriver<WebElement> driver) throws InterruptedException {
		// TODO Auto-generated method stub

		boolean isDisplayed=false;
		
		for(int i=1;i<6;i++)
		{
			
			try {  		
					//verify is it home screen
				if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) 
            	{
					isDisplayed= driver.findElement(By.xpath("//XCUIElementTypeButton[@name='HOME']")).isDisplayed();
            	}
				else if(prop.readPropFile("platform").equalsIgnoreCase("Android")) 
            	{
					isDisplayed = driver.findElement(By.id("home_tab")).isDisplayed();
            	}
					if(isDisplayed)
					{
						System.out.println("Reached Home screen in iteration:"+(i-1));	
						return isDisplayed;
					}

			}catch(Exception e)
			{
				//moving towards home screen
				driver.navigate().back();
				//wait for 1 sec
				Thread.sleep(1000);
				System.out.println("Going towards Home screen");	
				
			}
		}
		
		return isDisplayed;

	}



}
