package com.dvnext.xlreport;

import java.io.File;

import com.dvnext.engine.serviceClient.ServicesClient;
import com.dvnext.mobile.propertyreader.PropertyFileReader;

public class GenerateXLReport {
    final static String strRelPath = "./";
    static PropertyFileReader prop = new PropertyFileReader();

    public void generatexl() throws Exception {
        String dir = strRelPath + "Reports";
        File directory = new File(dir);
        directory.mkdirs();
        ExcelReportCreation.generateReport(String.valueOf(directory), "Report_Excel.xlsm");
        ExcelReportCreation.generateReport("Report_Excel" + ServicesClient.getCurrentTimeStamp() + ".xlsm");
    }

    public static void main(String[] ar) throws Exception
    {
        GenerateXLReport gen = new GenerateXLReport();
        gen.generatexl();
    }
}