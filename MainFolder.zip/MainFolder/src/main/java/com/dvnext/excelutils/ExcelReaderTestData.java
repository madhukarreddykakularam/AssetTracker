package com.dvnext.excelutils;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.dvnext.mobile.propertyreader.PropertyFileReader;

public class ExcelReaderTestData {
    int rowIndex = 0, columnIndex = 0;
    private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFCell Cell;

    // This method is to set the File path and to open the Excel file, Pass
    // Excel Path and Sheetname as Arguments to this method
    public ArrayList<ArrayList<String>> setExcelFile(String fileName, String sheetName, String getData) throws Exception {
        /*
         * final String strRelPath = ExcelReaderTestData.class.getProtectionDomain().getCodeSource().getLocation()
         * .getPath().split("bin")[0].replace("%20", " ");
         */
        final String strRelPath = "./";
        try {
            final PropertyFileReader prop = new PropertyFileReader();
            // Open the Excel file
            // final String fileName = prop.readPropFile("testdatafile");
            File file;
            // if (prop.readPropFile("framework").contains("external")) {
            // file = new File("../TestSet/Excel", fileName);
            // } else {
            file = new File(strRelPath + "TestInput", fileName);
            // }
            final FileInputStream ExcelFile = new FileInputStream(file);
            // Access the required test data sheet
            ExcelWBook = new XSSFWorkbook(ExcelFile);
            ExcelWSheet = ExcelWBook.getSheet(sheetName);
            /*
             * } catch (Exception e) {
             * throw (e);
             * }
             * }
             * 
             * 
             * 
             * public ArrayList<ArrayList<String>> getCellData(String getData,String fileName, String sheetName ) throws Exception {
             */
            ArrayList<ArrayList<String>> array = null;
            try {
                // setExcelFile(fileName, sheetName);
                int tcColID = 0;
                array = new ArrayList<ArrayList<String>>();
                // Get TestcasesID
                for (columnIndex = 0; columnIndex < ExcelWSheet.getRow(0).getPhysicalNumberOfCells(); columnIndex++) {
                    Cell = ExcelWSheet.getRow(0).getCell(columnIndex);
                    final String cellData = Cell.getStringCellValue();
                    if (cellData.contentEquals("TestCasesID")) {
                        tcColID = columnIndex;
                        break;
                    }
                }
                boolean tcflag = false;
                boolean flagloop = false;
                for (rowIndex = 0; rowIndex < ExcelWSheet.getPhysicalNumberOfRows(); rowIndex++) {
                    Cell = ExcelWSheet.getRow(rowIndex).getCell(tcColID);
                    final String getTCName = Cell.getStringCellValue();

                    if (getTCName.contains(getData) || tcflag == true) {
                        if (getTCName.contains(getData) || getTCName.isEmpty()) {
                            Cell = ExcelWSheet.getRow(rowIndex + 1).getCell(tcColID);
                            final String getrowcnt = Cell.getStringCellValue();
                            if (getrowcnt.isEmpty()) {
                                tcflag = true;
                                for (columnIndex = 0; columnIndex < ExcelWSheet.getRow(rowIndex)
                                		.getPhysicalNumberOfCells(); columnIndex++) {
                                	int lastcellnum=ExcelWSheet.getRow(rowIndex).getLastCellNum();
                                	System.out.println("last num"+lastcellnum);
                                    Cell = ExcelWSheet.getRow(0).getCell(columnIndex);
                                    final String getData1 = Cell.getStringCellValue();
                                    if (getData1.trim().contentEquals("Data1")) {
                                        Cell = ExcelWSheet.getRow(rowIndex + 1).getCell(columnIndex);
                                        final String DataExist = Cell.getStringCellValue();

                                        if (DataExist.isEmpty()) {
                                            flagloop = true;
                                            break;
                                        }
                                    }
                                }
                                if (flagloop == true) {
                                    break;
                                }
                            } else {
                                break;
                            }
                            final ArrayList<String> getObj = new ArrayList<String>();
                            boolean dataflag = false;
                            for (columnIndex = 0; columnIndex < ExcelWSheet.getRow(rowIndex)
                                    .getPhysicalNumberOfCells(); columnIndex++) {
                                Cell = ExcelWSheet.getRow(rowIndex).getCell(columnIndex);
                                if (dataflag == true) {
                                    Cell = ExcelWSheet.getRow(rowIndex + 1).getCell(columnIndex);
                                    int getType = Cell.getCellType();
                                    if (getType == 1) {
                                        String getValue = Cell.getStringCellValue();
                                        if (!getValue.isEmpty()) {
                                            getObj.add(getValue);
                                        }
                                    } else {
                                        String getValue = Cell.getRawValue();
                                        // int getIntValue = (int) getValue;

                                        getObj.add(getValue + "");
                                    }
                                }
                                Cell = ExcelWSheet.getRow(0).getCell(columnIndex);
                                final String getData1 = Cell.getStringCellValue();
                                if (getData1.trim().contentEquals("Data1")) {
                                    Cell = ExcelWSheet.getRow(rowIndex + 1).getCell(columnIndex);
                                    int getType = Cell.getCellType();
                                    if (getType == 1) {
                                        String getValue = Cell.getStringCellValue();
                                        getObj.add(getValue);
                                    } else {
                                        String getIntValue = Cell.getRawValue().toString();
                                        getObj.add(getIntValue + "");
                                    }
                                    dataflag = true;
                                }
                            }
                            array.add(getObj);
                        }

                    }
                }
                return array;
            } catch (Exception e) {
                return array;
            }
        } catch (Exception e) {
            throw (e);
        }
    }
}