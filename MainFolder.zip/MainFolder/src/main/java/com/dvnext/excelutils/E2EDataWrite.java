package com.dvnext.excelutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class E2EDataWrite {
	
	public static void writeData(String TestCaseID, String Parameter, String Value){
	
		try{
			Date ObjDate = new Date();
			SimpleDateFormat ObjDf = new SimpleDateFormat ("YYYY_MMM_dd");
						
			File file = new File(".//test-output//E2EData_"+ObjDf.format(ObjDate)+".xlsx");
			if (!file.exists()){
			FileOutputStream fos = new FileOutputStream (file);
			XSSFWorkbook XSSFWB = new XSSFWorkbook ();
			XSSFSheet XSSFSt = XSSFWB.createSheet("ResultData");
			XSSFSt.createRow(0).createCell(0).setCellValue("TestcaseID");
			XSSFWB.write(fos);
			XSSFWB.close();
			fos.close();
			}
			FileInputStream fis = new FileInputStream (file);
			XSSFWorkbook XSSFWB = new XSSFWorkbook (fis);
			XSSFSheet XSSFSt = XSSFWB.getSheet("ResultData");
			FileOutputStream fos = new FileOutputStream (file);
			boolean TCRowPresent = false;
			for (int i=1; i<=XSSFSt.getLastRowNum(); i++){
				if (XSSFSt.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(TestCaseID)){
					int LastCol = XSSFSt.getRow(i).getLastCellNum();
					XSSFSt.getRow(i).createCell(LastCol).setCellValue(Parameter+": "+Value);
					TCRowPresent = true;
					XSSFWB.write(fos);
					XSSFWB.close();
					fos.close();
					System.out.println("Output " + Parameter+": "+Value + " is saved in the excel");
					break;
				}
			}
			if (!TCRowPresent){
				int LastRowNum = XSSFSt.getLastRowNum();
				XSSFSt.createRow(LastRowNum+1).createCell(0).setCellValue(TestCaseID);
				XSSFSt.getRow(LastRowNum+1).createCell(1).setCellValue(Parameter+": "+Value);
				XSSFWB.write(fos);
				XSSFWB.close();
				System.out.println("Output " + Parameter+": "+Value + " is saved in the excel");
			}
	
			}
			catch (Exception e){
				e.printStackTrace();
			}
	}

}
