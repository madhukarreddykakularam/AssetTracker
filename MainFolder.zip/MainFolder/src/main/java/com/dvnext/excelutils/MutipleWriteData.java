package com.dvnext.excelutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class MutipleWriteData {
	public static String counts;
	public static Boolean flag = false;

	public static void WriteDataNewCreateRow(String Sheetname,
			String TestCaseID, String count, String Parameter, String Value) {

		int Number;
		int j;
		FileOutputStream fos;
		try {
			System.out.println("dasd");
			File file = new File(".//TestInput//iOSSuiteTestData.xlsx");
			FileInputStream fis1 = new FileInputStream(file);
			XSSFWorkbook XSSFWb = new XSSFWorkbook(fis1);

			Number = XSSFWb.getNumberOfSheets();
			// int arr[] =new int[3];
			for (j = 0; j < Number; j++) {
				if (XSSFWb.getSheetName(j).equalsIgnoreCase(Sheetname)) {
					XSSFWb.close();
					break;
				}
			}
			if (j == Number - 1) {
				System.out.println("Sheet present");

			}

			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook XSSFWB = new XSSFWorkbook(fis);
			XSSFSheet XSSFSt = XSSFWB.getSheet(Sheetname);
			FileOutputStream fos1 = new FileOutputStream(file);
			Cell c = null;
			for (int i = 1; i <= XSSFSt.getLastRowNum(); i++) {

				try {
					if (XSSFSt.getRow(i).getCell(0).getStringCellValue()
							.equalsIgnoreCase(TestCaseID)) {
						for (int k = 0; k < XSSFSt.getRow(i)
								.getPhysicalNumberOfCells(); k++) {
							String prsentCellValue = XSSFSt.getRow(i)
									.getCell(k).getStringCellValue();
							String psv = prsentCellValue.trim();
							String param = Parameter.trim();
							if (psv.equalsIgnoreCase(param)) {

								if (count.equalsIgnoreCase("1")) {
									XSSFSt.getRow(i + 1).createCell(k)
											.setCellValue(Value);
									System.out
											.println("entered value in the row previously created");
									break;
								} else if (count.equalsIgnoreCase("2")) {

									if (flag == true) {
										XSSFSt.getRow(i + 2).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									
									if ((XSSFSt.getRow(i + 2) != null) && (flag == false)) {
										try
										{
										c= XSSFSt.getRow(i+2).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
											if(c==null){
											XSSFSt.getRow(i + 2).createCell(k).setCellValue(Value);
										   System.out.println("entered value in the row previously created");
										   flag = true;
										   break;
										}
										else{
											XSSFSt.shiftRows(i + 2,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 2).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
										
										
											
									}
									if ((XSSFSt.getRow(i + 2) == null)) {
										Row row1 = XSSFSt.createRow(i + 2);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row newly created");
										flag = true;
										break;
									}

								}

								else if (count.equalsIgnoreCase("3")) {
									if (flag == true) {
										XSSFSt.getRow(i + 3).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 3) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+3).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 3).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 3,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 3).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 3) == null)) {
										Row row1 = XSSFSt.createRow(i + 3);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;
									}
								} else if (count.equalsIgnoreCase("4")) {
									if (flag == true) {
										XSSFSt.getRow(i + 4).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 4) != null) && (flag == false)) {
										{
											try
											{
											c= XSSFSt.getRow(i+4).getCell(0, Row.RETURN_BLANK_AS_NULL);
											}catch(Exception e){
												
											}
											if(c==null){
												XSSFSt.getRow(i + 4).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											else{
											XSSFSt.shiftRows(i + 4,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 4).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									}
									if ((XSSFSt.getRow(i + 4) == null)) {
										Row row1 = XSSFSt.createRow(i + 4);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;

									}
								} else if (count.equalsIgnoreCase("5")) {
									if (flag == true) {
										XSSFSt.getRow(i + 5).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 5) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+5).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 5).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											else{
											XSSFSt.shiftRows(i + 5,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 5).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 5) == null)) {
										Row row1 = XSSFSt.createRow(i + 5);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;

									}
								}

								else if (count.equalsIgnoreCase("6")) {
									if (flag == true) {
										XSSFSt.getRow(i + 6).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 6) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+6).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 6).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 6,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 6).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 6) == null)) {
										Row row1 = XSSFSt.createRow(i + 6);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;

									}
								}

								else if (count.equalsIgnoreCase("7")) {
									if (flag == true) {
										XSSFSt.getRow(i + 7).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 7) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+7).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 7).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 7,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 7).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 7) == null)) {
										Row row1 = XSSFSt.createRow(i + 7);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;

									}
								}

								else if (count.equalsIgnoreCase("8")) {
									if (flag == true) {
										XSSFSt.getRow(i + 8).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 8) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+8).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 8).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 8,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 8).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 8) == null)) {
										Row row1 = XSSFSt.createRow(i + 8);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;

									}
								}

								else if (count.equalsIgnoreCase("9")) {
									if (flag == true) {
										XSSFSt.getRow(i + 9).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 9) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+9).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 9).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 9,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 9).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 9) == null)) {
										Row row1 = XSSFSt.createRow(i + 9);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;
									}
								}

								else if (count.equalsIgnoreCase("10")) {
									if (flag == true) {
										XSSFSt.getRow(i + 10).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 10) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+10).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 10).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 10,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 10).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
										}
									
									}
									if ((XSSFSt.getRow(i + 10) == null)) {
										Row row1 = XSSFSt.createRow(i + 10);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;
									}
								}

								else if (count.equalsIgnoreCase("11")) {
									if (flag == true) {
										XSSFSt.getRow(i + 11).createCell(k)
												.setCellValue(Value);
										System.err
												.println("entered value in the row newly created");
										break;
									}
									if ((XSSFSt.getRow(i + 11) != null) && (flag == false)) {
										
										try
										{
										c= XSSFSt.getRow(i+11).getCell(0, Row.RETURN_BLANK_AS_NULL);
										}catch(Exception e){
											
										}
										if(c==null){
												XSSFSt.getRow(i + 11).createCell(k)
												.setCellValue(Value);
										System.out.println("entered value in the row previously created");
										flag = true;
										break;
										}
											
											else{
											XSSFSt.shiftRows(i + 11,
													XSSFSt.getLastRowNum(), 1);
											XSSFSt.createRow(i + 11).createCell(k)
													.setCellValue(Value);
											System.out
													.println("entered value in the row newly created");
											flag = true;
											break;
											
										}
									
									}
									if ((XSSFSt.getRow(i + 11) == null)) {
										Row row1 = XSSFSt.createRow(i + 11);
										Cell cell = row1.createCell(k);
										cell.setCellValue(Value);
										System.out
												.println("entered value in the row previously created");
										flag = true;
										break;
									}
								}
							}
						}
						break;
					}
				} catch (Exception e) {

				}

			}

			XSSFWB.write(fos1);
			XSSFWB.close();
			fos1.close();
			System.out.println("Output " + Parameter + ": " + Value
					+ " is saved in the excel");

		}

		catch (Exception e) {

			e.printStackTrace();
		}

	}

}
