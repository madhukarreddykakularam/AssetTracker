package com.dvnext.excelutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.dvnext.mobile.propertyreader.PropertyFileReader;

public class PreconditionTestDataLatest {

    public static void WriteDataNew(String Sheetname, String TestCaseID, String Parameter, String Value) {
        PropertyFileReader prop = new PropertyFileReader();
        int Number;
        int j;
        FileOutputStream fos;
        try {
            if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                File file = new File(".//TestInput//iOSSuiteTestData_1.xlsx");
                FileInputStream fis1 = new FileInputStream(file);
                XSSFWorkbook XSSFWb = new XSSFWorkbook(fis1);

                Number = XSSFWb.getNumberOfSheets();
                // int arr[] =new int[3];
                for (j = 0; j < Number; j++) {
                    if (XSSFWb.getSheetName(j).equalsIgnoreCase(Sheetname)) {
                        XSSFWb.close();
                        break;
                    }
                    if (j == Number - 1) {
                        System.out.println("Sheet not present");
                        /*
                         * fos = new FileOutputStream(file);
                         * XSSFSheet XSFSheet = XSSFWb.createSheet("WriteData");
                         * XSFSheet.createRow(1).createCell(0).setCellValue("TestCaseID");
                         * XSSFWb.write(fos);
                         * XSSFWb.close();
                         * fos.close();
                         * break;
                         */
                    }
                }

                FileInputStream fis = new FileInputStream(file);
                XSSFWorkbook XSSFWB = new XSSFWorkbook(fis);
                XSSFSheet XSSFSt = XSSFWB.getSheet(Sheetname);
                FileOutputStream fos1 = new FileOutputStream(file);
                boolean TCRowPresent = false;
                for (int i = 1; i <= XSSFSt.getLastRowNum(); i++) {

                    if (XSSFSt.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(TestCaseID)) {
                        for (int k = 0; k < XSSFSt.getRow(i).getPhysicalNumberOfCells(); k++) {// int LastCol = XSSFSt.getRow(i).getLastCellNum();
                            String prsentCellValue = XSSFSt.getRow(i).getCell(k).getStringCellValue();
                            String psv = prsentCellValue.trim();
                            String param = Parameter.trim();

                            if (psv.equalsIgnoreCase(param)) {

                                XSSFSt.getRow(i + 1).getCell(k).setCellValue(Value);
                                System.out.println("entered value in the row previously careted");
                                break;
                            }

                        }

                    }

                }
                TCRowPresent = true;
                XSSFWB.write(fos1);
                XSSFWB.close();
                fos1.close();
                System.out.println("Output " + Parameter + ": " + Value + " is saved in the excel");

            } else if (prop.readPropFile("platform").equalsIgnoreCase("Android")) {
                File file = new File(".//TestInput//AndroidSuiteTestData_1.xlsx");
                // File file = new File(".//TestInput//iOSSuiteTestData.xlsx");
                FileInputStream fis1 = new FileInputStream(file);
                XSSFWorkbook XSSFWb = new XSSFWorkbook(fis1);

                Number = XSSFWb.getNumberOfSheets();
                // int arr[] =new int[3];
                for (j = 0; j < Number; j++) {
                    if (XSSFWb.getSheetName(j).equalsIgnoreCase(Sheetname)) {
                        XSSFWb.close();
                        break;
                    }
                    if (j == Number - 1) {
                        System.out.println("Sheet not present");
                        /*
                         * fos = new FileOutputStream(file);
                         * XSSFSheet XSFSheet = XSSFWb.createSheet("WriteData");
                         * XSFSheet.createRow(1).createCell(0).setCellValue("TestCaseID");
                         * XSSFWb.write(fos);
                         * XSSFWb.close();
                         * fos.close();
                         * break;
                         */
                    }
                }

                FileInputStream fis = new FileInputStream(file);
                XSSFWorkbook XSSFWB = new XSSFWorkbook(fis);
                XSSFSheet XSSFSt = XSSFWB.getSheet(Sheetname);
                FileOutputStream fos1 = new FileOutputStream(file);
                boolean TCRowPresent = false;
                for (int i = 1; i <= XSSFSt.getLastRowNum(); i++) {

                    if (XSSFSt.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(TestCaseID)) {
                        for (int k = 0; k < XSSFSt.getRow(i).getPhysicalNumberOfCells(); k++) {// int LastCol = XSSFSt.getRow(i).getLastCellNum();
                            String prsentCellValue = XSSFSt.getRow(i).getCell(k).getStringCellValue();
                            String psv = prsentCellValue.trim();
                            String param = Parameter.trim();

                            if (psv.equalsIgnoreCase(param)) {

                                XSSFSt.getRow(i + 1).getCell(k).setCellValue(Value);
                                System.out.println("entered value in the row previously careted");
                                break;
                            }

                        }

                    }

                }
                TCRowPresent = true;
                XSSFWB.write(fos1);
                XSSFWB.close();
                fos1.close();
                System.out.println("Output " + Parameter + ": " + Value + " is saved in the excel");

            }

            else if (prop.readPropFile("platform").equalsIgnoreCase("API")) {
                File file = new File(".//TestInput//APISuiteTestData.xlsx");
                // File file = new File(".//TestInput//iOSSuiteTestData.xlsx");
                FileInputStream fis1 = new FileInputStream(file);
                XSSFWorkbook XSSFWb = new XSSFWorkbook(fis1);

                Number = XSSFWb.getNumberOfSheets();
                // int arr[] =new int[3];
                for (j = 0; j < Number; j++) {
                    if (XSSFWb.getSheetName(j).equalsIgnoreCase(Sheetname)) {
                        XSSFWb.close();
                        break;
                    }
                    if (j == Number - 1) {
                        System.out.println("Sheet not present");
                        /*
                         * fos = new FileOutputStream(file);
                         * XSSFSheet XSFSheet = XSSFWb.createSheet("WriteData");
                         * XSFSheet.createRow(1).createCell(0).setCellValue("TestCaseID");
                         * XSSFWb.write(fos);
                         * XSSFWb.close();
                         * fos.close();
                         * break;
                         */
                    }
                }

                FileInputStream fis = new FileInputStream(file);
                XSSFWorkbook XSSFWB = new XSSFWorkbook(fis);
                XSSFSheet XSSFSt = XSSFWB.getSheet(Sheetname);
                FileOutputStream fos1 = new FileOutputStream(file);
                boolean TCRowPresent = false;
                for (int i = 1; i <= XSSFSt.getLastRowNum(); i++) {

                    if (XSSFSt.getRow(i).getCell(0).getStringCellValue().equalsIgnoreCase(TestCaseID)) {
                        for (int k = 0; k < XSSFSt.getRow(i).getPhysicalNumberOfCells(); k++) {// int LastCol = XSSFSt.getRow(i).getLastCellNum();
                            String prsentCellValue = XSSFSt.getRow(i).getCell(k).getStringCellValue();
                            String psv = prsentCellValue.trim();
                            String param = Parameter.trim();

                            if (psv.equalsIgnoreCase(param)) {

                                XSSFSt.getRow(i + 1).getCell(k).setCellValue(Value);
                                System.out.println("entered value in the row previously careted");
                                break;
                            }

                        }

                    }

                }
                TCRowPresent = true;
                XSSFWB.write(fos1);
                XSSFWB.close();
                fos1.close();
                System.out.println("Output " + Parameter + ": " + Value + " is saved in the excel");

            }

        }
        /*
         * if (!TCRowPresent){
         * String val;
         * int LastRowNum = XSSFSt.getLastRowNum();
         * XSSFSt.createRow(LastRowNum+1).createCell(0).setCellValue(TestCaseID);
         *
         * XSSFSt.createRow(LastRowNum+2).createCell(0).setCellValue("'");
         *
         * XSSFSt.getRow(LastRowNum+1).createCell(1).setCellValue(Parameter);
         *
         * XSSFSt.getRow(LastRowNum+2).createCell(1).setCellValue(Value);
         *
         * XSSFWB.write(fos1);
         * XSSFWB.close();
         * System.out.println("Output " + Parameter+": "+Value + " is saved in the excel");
         *
         * }
         */

        catch (Exception e) {

            e.printStackTrace();
        }

    }
}
