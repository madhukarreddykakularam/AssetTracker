package com.dvnext.engine.studio;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileBrowserType;
import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.xml.sax.SAXException;

import com.dvnext.engine.serviceClient.ServicesClient;
import com.dvnext.excelutils.ObjectMap;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
//import com.nbcu.assetTracker.web.Web_AssetTrack_AddAsset;
import com.relevantcodes.extentreports.ExtentReports;



public class CommonstudioOld extends ServicesClient  {


    public RemoteWebDriver wdriver;
    public AppiumDriver<WebElement> driver;
    public AndroidDriver adriver;
    public static boolean isDisplayed;

    public ObjectMap objMap;
    public String runType;
    public String tool;
    public String platform;
    PropertyFileReader prop = new PropertyFileReader();
    public String workingDir = System.getProperty("user.dir");
    public final ExtentReports logger = ExtentReports.get(Commonstudio.class);
    static final String strRelPath = "./";
    public static String mobileServiceUrl;
    public static SSLContext sslcontext;
    public static HttpPost httpPost;
    public static HttpPost httpPostp;
    public static HttpGet httpGet;
    public static HttpDelete httpDelete;
    public static HttpClient client;
    public static HttpResponse httpResponse;
    public static String  KeyText ;
    public static String qrCodeApi;

    public static String emailAddress;

    public static StatusLine statusLine;
    public static String SNTToken;

    public static final long LOWWAIT = 3000;
    public static final long MEDIUMWAIT = 10000;
    public static final long LONGWAIT = 15000;
    public static final long HIGHWAIT = 22000;
    public static final String ANDROID = "Android";
    public static final String FORWARDSLASH = "/";
    public WebElement element;
    public String device;
    public static final String deviceConnectHost = "deviceconnect.inbcu.com";
    public static final String deviceConnectUserName = "RanaPratap.kurumeti@nbcuni.com";
    public static final String deviceConnectApiKey = "5eb782bf-eef7-4025-a805-937ae6251c70";
    private static final String serviceUrl = "http://" + deviceConnectHost + "/Appium";
    DesiredCapabilities capabilities = new DesiredCapabilities();
   
    @Parameters("DeviceID")
    //@Parameters({ "platform", "deviceID", "appUnderTest", "appType", "environment", "preconditionForPlatform" })
    @BeforeMethod
    public void setcaps(Method m, @Optional String deviceID) throws MalformedURLException, InterruptedException, KeyManagementException, NoSuchAlgorithmException {

        String testName = m.getName();
        runType = prop.readPropFile("runType");
        tool = prop.readPropFile("Tool");
        System.out.println(tool);
        if (prop.readPropFile("runLocation").contains("local")) {
        	 if (prop.readPropFile("runType").contains("mobile")) {
                 if (prop.readPropFile("Tool").contains("Studio")) {
                     if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                             //DesiredCapabilities caps = new DesiredCapabilities();
                             //caps.setBrowserName(MobileBrowserType.SAFARI);
                             //caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                             //driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), caps);
                             
                             DesiredCapabilities capabilities = new DesiredCapabilities();

                             // The name of a web browser to test on. Possible values are Safari or

                             // Chrome. If no device is specified, an

                             // appropriate iOS or Android device will be chosen automatically.
                             capabilities.setCapability("browserName", "Safari");
                             capabilities.setCapability("automationName", "XCUITest");
                             capabilities.setCapability("deviceConnectUsername", deviceConnectUserName);
                             capabilities.setCapability("deviceConnectApiKey", deviceConnectApiKey);
                             capabilities.setCapability("deviceConnectDevice", "60710e7a-ec87-4833-aeb7-4940773aa3c4");
                               capabilities.setCapability("orientation", "LANDSCAPE");
                             //capabilities.setCapability("webkitResponseTimeout", "999999");
                             //capabilities.setCapability("autoAcceptAlerts", "true");
                             //capabilities.setCapability("safariAllowPopups","true");
                             //capabilities.setCapability("safariOpenLinksInBackground","true");
                             //capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                             URL url = new URL(serviceUrl);
                             wdriver = new IOSDriver(url, capabilities);
                               
                         }

                         else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setBrowserName(MobileBrowserType.CHROMIUM);
                             driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), caps);
                         }

                     } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                             DesiredCapabilities dc = new DesiredCapabilities();

                             dc.setCapability(MobileCapabilityType.PLATFORM, "ios");
                             dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                             dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);

                             driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), dc);

                         } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);

                             capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.readPropFile("appPackage"));
                             capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.readPropFile("appActivity"));

                             driver = new NewAndroidDriver<WebElement>(new URL("http://localhost:4723/wd/hub"), capabilities);

                         }
                     }
                 }
                 else if (prop.readPropFile("Tool").contains("Appium")) {

                     if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setCapability("browserName", "safari");
                             caps.setCapability("version", "11.0");
                             caps.setCapability("platform", "iOS");
                             caps.setCapability("deviceName", "iPhone X");
                             caps.setCapability("platformName", "iOS");
                             caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                             driver = new NewIOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                         }
                         else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setCapability("browserName", "browser");
                             caps.setCapability("version", "6.0");
                             caps.setCapability("platform", "android");
                             caps.setCapability("deviceName", "Nexus S");
                             caps.setCapability("platformName", "android");
                             caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.APPIUM);
                             driver = new NewAndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                         }

                     } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setCapability("platformName", "iOS");
                             caps.setCapability("platformVersion", "11.3");
                             caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone");
                             caps.setCapability("automationName", "XCUITEST");
                             caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,300);
                             //caps.setCapability("autoWebview",true); 
                             caps.setCapability(MobileCapabilityType.UDID, prop.readPropFile("UDIDiOS"));
                             caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));

                             driver = new NewIOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

                         } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             if (prop.readPropFile("Parallel").equalsIgnoreCase("No")) {
                                 DesiredCapabilities capabilities = new DesiredCapabilities();

                                 //capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

                                 capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
                                 capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.readPropFile("UDID"));
                                 capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
                                 capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
                                 capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,300);
                                 capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
                                 capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
                                 capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

                                 try {
                                     driver = new NewAndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

                                 } catch (MalformedURLException e) {
                                     e.printStackTrace();
                                 }
                             } else if (prop.readPropFile("Parallel").equalsIgnoreCase("Yes")) {

                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device1"))) {
                                     device = prop.readPropFile("Devicename1");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL1")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device2"))) {
                                     device = prop.readPropFile("Devicename2");

                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL2")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device3"))) {
                                     device = prop.readPropFile("Devicename3");

                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL3")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device4"))) {
                                     device = prop.readPropFile("Devicename4");

                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL4")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device5"))) {
                                     device = prop.readPropFile("Devicename5");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL5")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device6"))) {
                                     device = prop.readPropFile("Devicename6");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL6")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device7"))) {
                                     device = prop.readPropFile("Devicename7");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL7")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device8"))) {
                                     device = prop.readPropFile("Devicename8");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL8")), capabilities);
                                 }

                                 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                             }
                         }
                     }
                 }
             }
             else if (prop.readPropFile("runType").equalsIgnoreCase("desktop")) {
                 if (prop.readPropFile("webBrowser").contains("chrome")) {
                     DesiredCapabilities caps = new DesiredCapabilities();
                     System.out.println("Chrome");
                     System.setProperty("webdriver.chrome.driver", strRelPath
                             + "Drivers/chromedriver.exe");
                     caps = DesiredCapabilities.chrome();
                     ChromeOptions options = new ChromeOptions();
                     caps.setCapability(ChromeOptions.CAPABILITY, options);
                     wdriver = new ChromeDriver();
                 } else if (prop.readPropFile("webBrowser").contains("safari")) {
                     DesiredCapabilities caps = new DesiredCapabilities();
                     caps.setBrowserName("safari");
                     caps.setCapability("Platform", "Mac");
                     wdriver = new SafariDriver();
                     System.out.println(caps + "    in safari setings");
                 
                     
                 } 
                 
                 else if (prop.readPropFile("webBrowser").contains("InternetExplorer")) {
                     System.setProperty("webdriver.ie.driver", strRelPath
                             + "Drivers/IEDriverServer.exe");
             		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
                    capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
                    capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
                    capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
                   capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                    capabilities.setJavascriptEnabled(true);
                    wdriver = new InternetExplorerDriver(capabilities);
                 } 
                 else if (prop.readPropFile("webBrowser").contains("firefox")) {
                     DesiredCapabilities caps = new DesiredCapabilities();
                     caps.setBrowserName("firefox");
                     caps.setCapability("Platform", "Mac");
                     wdriver = new FirefoxDriver();

                 }
             } else if (prop.readPropFile("runType").contains("api")) {
                 sslcontext = SSLContext.getInstance("TLSv1.2");
                 sslcontext.init(null, null, null);
                 try {
                     SSLConnectionSocketFactory socketFactory = new
                             SSLConnectionSocketFactory(sslcontext,
                                     SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                     client =
                             HttpClients.custom().setSSLSocketFactory(socketFactory).build();

                 } catch (Exception e) {
                     System.err.println("HttpsURLConnection Failed");
                     e.printStackTrace();
                 }

             }

        } else if (prop.readPropFile("runLocation").contains("jenkins")) {
            //setCapabilitiesFromXMLParameters(appUnderTest, appType, environment, platform, deviceID, preconditionForPlatform);
        }
    }

    @AfterSuite
    public void tearDown() throws Exception {
        logger.endTest();
    }

    @AfterMethod
    public void closeapp() {
    	//try {
        if (prop.readPropFile("runType").equalsIgnoreCase("mobile")) {
        	
            driver.quit();
        	
        }
        else if (prop.readPropFile("runType").equalsIgnoreCase("desktop")) {
            wdriver.quit();
        }
    /*	}catch(Exception e) {
    		e.printStackTrace();
    	}*/
    }

 
    @BeforeSuite
    public void ereport() throws ParserConfigurationException, IOException, SAXException {
        deleteDirectory();
        createDirectory();
        platform = prop.readPropFile("platform");
        System.out.println(platform);
        String dir = strRelPath + "Reports/EReports";
        File directory = new File(dir);
        directory.mkdirs();
        logger.init(directory + "/AssetTrackerReport" + platform + getCurrentTimeStamp() + ".html", true);
        logger.init(directory + "/AssetTrackerReport.html", true);
    }

    public void setcapsforParallel(String device) {

        capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
        capabilities.setCapability(MobileCapabilityType.UDID, device);
        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);

        capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
        capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
    }

    public void setcapsforNEWParallel(String platform, String deviceID, String systemPort) throws MalformedURLException {
        String[] platformInfo = platform.split(" ");

        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, platformInfo[0]);
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, platformInfo[1]);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android1");
        capabilities.setCapability(MobileCapabilityType.UDID, deviceID);

        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);

        capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
        capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));

    }

    public void setcapsWeb() {
        DesiredCapabilities caps = new DesiredCapabilities();
        System.out.println("Chrome");
        System.setProperty("webdriver.chrome.driver", strRelPath
                + "Drivers/chromedriver.exe");
        caps = DesiredCapabilities.chrome();
        ChromeOptions options = new ChromeOptions();
        caps.setCapability(ChromeOptions.CAPABILITY, options);
        wdriver = new ChromeDriver();
    }

    public void setCapabilitiesFromProperties(String deviceID) throws MalformedURLException, NoSuchAlgorithmException, KeyManagementException {
        if (prop.readPropFile("runType").contains("mobile")) {
            if (prop.readPropFile("Tool").contains("Studio")) {
                if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.SAFARI);
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                    else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.CHROMIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                        DesiredCapabilities dc = new DesiredCapabilities();

                        dc.setCapability(MobileCapabilityType.PLATFORM, "ios");
                        dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);

                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), dc);

                    } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);

                        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.readPropFile("appPackage"));
                        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.readPropFile("appActivity"));

                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), capabilities);

                    }
                }
            }
            else if (prop.readPropFile("Tool").contains("Appium")) {

                if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "safari");
                        caps.setCapability("version", "11.0");
                        caps.setCapability("platform", "iOS");
                        caps.setCapability("deviceName", "iPhone X");
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }
                    else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "browser");
                        caps.setCapability("version", "6.0");
                        caps.setCapability("platform", "android");
                        caps.setCapability("deviceName", "Nexus S");
                        caps.setCapability("platformName", "android");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.APPIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }

                } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability("platformVersion", "11.3");
                        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone");
                        caps.setCapability("automationName", "XCUITEST");
                        caps.setCapability(MobileCapabilityType.UDID, prop.readPropFile("UDIDiOS"));
                        caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                        caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.SAFARI);
                        caps.setCapability("startIWDP", true);
                          caps.setCapability("udid", "auto");
                       

                        driver = new NewIOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

                    } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        if (prop.readPropFile("Parallel").equalsIgnoreCase("No")) {
                            DesiredCapabilities capabilities = new DesiredCapabilities();

                            capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

                            capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
                            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.readPropFile("UDID"));
                            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
                            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
                            capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
                            capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
                            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

                            try {
                                driver = new NewAndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }
                        } else if (prop.readPropFile("Parallel").equalsIgnoreCase("Yes")) {

                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device1"))) {
                                device = prop.readPropFile("Devicename1");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL1")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device2"))) {
                                device = prop.readPropFile("Devicename2");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL2")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device3"))) {
                                device = prop.readPropFile("Devicename3");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL3")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device4"))) {
                                device = prop.readPropFile("Devicename4");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL4")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device5"))) {
                                device = prop.readPropFile("Devicename5");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL5")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device6"))) {
                                device = prop.readPropFile("Devicename6");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL6")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device7"))) {
                                device = prop.readPropFile("Devicename7");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL7")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device8"))) {
                                device = prop.readPropFile("Devicename8");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL8")), capabilities);
                            }

                            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                        }
                    }
                }
            }
        }
        else if (prop.readPropFile("runType").equalsIgnoreCase("desktop")) {
            if (prop.readPropFile("webBrowser").contains("chrome")) {
                DesiredCapabilities caps = new DesiredCapabilities();
                System.out.println("Chrome");
                System.setProperty("webdriver.chrome.driver", strRelPath
                        + "Drivers/chromedriver.exe");
                caps = DesiredCapabilities.chrome();
                ChromeOptions options = new ChromeOptions();
                caps.setCapability(ChromeOptions.CAPABILITY, options);
                wdriver = new ChromeDriver();
            } else if (prop.readPropFile("webBrowser").contains("safari")) {
                DesiredCapabilities caps = new DesiredCapabilities();
                caps.setBrowserName("safari");
                caps.setCapability("Platform", "Mac");
                wdriver = new SafariDriver();
                System.out.println(caps + "    in safari setings");
            } else if (prop.readPropFile("webBrowser").contains("firefox")) {
                DesiredCapabilities caps = new DesiredCapabilities();
                caps.setBrowserName("firefox");
                caps.setCapability("Platform", "Mac");
                wdriver = new FirefoxDriver();

            }
        } else if (prop.readPropFile("runType").contains("api")) {
            sslcontext = SSLContext.getInstance("TLSv1.2");
            sslcontext.init(null, null, null);
            try {
                SSLConnectionSocketFactory socketFactory = new
                        SSLConnectionSocketFactory(sslcontext,
                                SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                client =
                        HttpClients.custom().setSSLSocketFactory(socketFactory).build();

            } catch (Exception e) {
                System.err.println("HttpsURLConnection Failed");
                e.printStackTrace();
            }

        }

    }

    public void setCapabilitiesFromXMLParameters(String appUnderTest, String appType, String environment, String platform, String deviceID, String preconditionForPlatform) throws MalformedURLException, NoSuchAlgorithmException, KeyManagementException {
        if (appUnderTest.equalsIgnoreCase("Mobile")) {
            if (prop.readPropFile("Tool").contains("Studio")) {
                if (appType.equalsIgnoreCase("Web")) {
                    if (platform.equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.SAFARI);
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                    else if (platform.equalsIgnoreCase("Android")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.CHROMIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                } else if (appType.equalsIgnoreCase("Native")) {
                    if (platform.equalsIgnoreCase("iOS")) {

                        DesiredCapabilities dc = new DesiredCapabilities();

                        dc.setCapability(MobileCapabilityType.PLATFORM, "ios");
                        dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);

                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), dc);

                    } else if (platform.equalsIgnoreCase("Android")) {
                        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);

                        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.readPropFile("appPackage"));
                        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.readPropFile("appActivity"));

                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), capabilities);

                    }
                }
            }
            else if (prop.readPropFile("Tool").contains("Appium")) {

                if (appType.equalsIgnoreCase("Web")) {
                    if (platform.equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "safari");
                        caps.setCapability("version", "11.0");
                        caps.setCapability("platform", "iOS");
                        caps.setCapability("deviceName", "iPhone X");
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }
                    else if (platform.equalsIgnoreCase("Android")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "browser");
                        caps.setCapability("version", "6.0");
                        caps.setCapability("platform", "android");
                        caps.setCapability("deviceName", "Nexus S");
                        caps.setCapability("platformName", "android");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.APPIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }

                } else if (appType.equalsIgnoreCase("Native")) {
                    if (platform.equalsIgnoreCase("iOS")) {

                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability("platformVersion", "11.3");
                        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone");
                        caps.setCapability("automationName", "XCUITEST");
                        caps.setCapability(MobileCapabilityType.UDID, prop.readPropFile("UDIDiOS"));
                        caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));

                        driver = new NewIOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

                    } else if (platform.equalsIgnoreCase("Android")) {
                        if (prop.readPropFile("Parallel").equalsIgnoreCase("No")) {
                            DesiredCapabilities capabilities = new DesiredCapabilities();

                            capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

                            capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
                            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.readPropFile("UDID"));
                            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
                            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
                            capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
                            capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
                            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

                            try {
                                driver = new NewAndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }
                        } else if (prop.readPropFile("Parallel").equalsIgnoreCase("Yes")) {

                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device1"))) {
                                device = prop.readPropFile("Devicename1");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL1")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device2"))) {
                                device = prop.readPropFile("Devicename2");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL2")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device3"))) {
                                device = prop.readPropFile("Devicename3");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL3")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device4"))) {
                                device = prop.readPropFile("Devicename4");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL4")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device5"))) {
                                device = prop.readPropFile("Devicename5");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL5")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device6"))) {
                                device = prop.readPropFile("Devicename6");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL6")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device7"))) {
                                device = prop.readPropFile("Devicename7");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL7")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device8"))) {
                                device = prop.readPropFile("Devicename8");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL8")), capabilities);
                            }

                            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                        }
                    }
                }
            }
        }
        else if (appUnderTest.equalsIgnoreCase("Dektop")) {
            if (appType.equalsIgnoreCase("Web")) {
                if (prop.readPropFile("webBrowser").contains("chrome")) {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    System.out.println("Chrome");
                    System.setProperty("webdriver.chrome.driver", strRelPath
                            + "Drivers/chromedriver.exe");
                    caps = DesiredCapabilities.chrome();
                    ChromeOptions options = new ChromeOptions();
                    caps.setCapability(ChromeOptions.CAPABILITY, options);
                    wdriver = new ChromeDriver();
                } else if (prop.readPropFile("webBrowser").contains("safari")) {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    caps.setBrowserName("safari");
                    caps.setCapability("Platform", "Mac");
                    wdriver = new SafariDriver();
                    System.out.println(caps + "    in safari setings");
                } else if (prop.readPropFile("webBrowser").contains("firefox")) {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    caps.setBrowserName("firefox");
                    caps.setCapability("Platform", "Mac");
                    wdriver = new FirefoxDriver();

                }
            } else if (appType.equalsIgnoreCase("Standalone")) {

            }
        } else if (appUnderTest.equalsIgnoreCase("Api")) {
            sslcontext = SSLContext.getInstance("TLSv1.2");
            sslcontext.init(null, null, null);
            try {
                SSLConnectionSocketFactory socketFactory = new
                        SSLConnectionSocketFactory(sslcontext,
                                SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                client =
                        HttpClients.custom().setSSLSocketFactory(socketFactory).build();

            } catch (Exception e) {
                System.err.println("HttpsURLConnection Failed");
                e.printStackTrace();
            }

        }

    }

    // ////////////////Get failed screen
    // shot/////////////////////////////////////////////////
    public void getScreenshotFailed(AppiumDriver<WebElement> driver,
            String errMsg, boolean isScreenshotReqd) throws IOException {
        if (prop.readPropFile("screen").equalsIgnoreCase("fail") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            System.out.println("Taking screenshot");
            File srcfile = null;
            srcfile = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");
            }
        }
    }

    // //////////////////////////Current time
    // stap/////////////////////////////////////
    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");// dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate; // returns current date and time in format mentioned
    }

    // Screen Shot for Each Step
    public void getScreenshoteachStep(AppiumDriver<WebElement> driver, boolean isScreenshotReqd)
            throws Exception {
        if (prop.readPropFile("screen").equalsIgnoreCase("pass") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            File srcfile = null;
            srcfile = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");

            }

        }
    }

    
    // Web Screen Shot IE and Safari -- Muthu
    
    // Screen Shot for Each Step
    public void getScreenshoteachStepWeb(RemoteWebDriver wdriver, boolean isScreenshotReqd)
            throws Exception {
        if (prop.readPropFile("screen").equalsIgnoreCase("pass") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            File srcfile = null;
            srcfile = ((TakesScreenshot) wdriver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");

            }

        }
    }

    public void Syn_Click(WebElement element) throws Exception {
    	WebDriverWait wait = new WebDriverWait(wdriver,30);
    	 
		// Here we will wait until element is not visible, if element is visible then it will return web element
		// or else it will throw exception
		wait.until(ExpectedConditions.visibilityOf(element));
       
		// if element found then we will use- In this example I just called isDisplayed method
		//boolean status = element.isDisplayed();
    	String browser=prop.readPropFile("browsertype");
		try {
			if(browser.equalsIgnoreCase("ChromeAndSafari"))
			{
			if (element.isEnabled() && element.isDisplayed()) {
				System.out.println("Clicking on element with using java script click");

				((JavascriptExecutor) wdriver).executeScript("arguments[0].click();", element);
				
				System.out.println("clicking on Element");
			}
				
			
			}else if(browser.equalsIgnoreCase("InternetExplorer"))
			{
				 WebimplicitWait(wdriver);
				if (element.isEnabled() && element.isDisplayed()) 
				{
				element.click();
				}
			}
			
			
			else {
				System.out.println("Unable to click on element");
			}
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document "+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element was not found in DOM "+ e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Unable to click on element "+ e.getStackTrace());
		}
	}
    
    
    public static void WebimplicitWait(RemoteWebDriver wdriver) {
        wdriver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
    }

    
    public void switchToWindow(String title) throws InterruptedException {
    	Thread.sleep(2000);
		Set<String> availableWindows = wdriver.getWindowHandles();
		if (availableWindows.size() >= 1) {
			try {
				for (String windowId : availableWindows) {
					
					System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
					if (wdriver.switchTo().window(windowId).getTitle().equals(title));
						//return true;
						//return true;
				}
			} catch (NoSuchWindowException e) {
				
				//logger.handleError("No child window is available to switch ", e);
			}
		}
    }

    
    
    
    
    
    
    
    
    
    public void webexplicitlywait(WebDriver wdriver,String b) throws InterruptedException
    {
    	WebElement ele = null;
    	try
    	{
    	
    		 ele = wdriver.findElement(By.xpath(b));
    	}
    	
    	catch(Exception e)
    	{
    	for(int i=0;i<=2;i++)
    	{
    		try{
    			 ele = wdriver.findElement(By.xpath(b));
    		}
    		 catch(Exception el){
       if(ele!=null)
       {
    	
        	 break;//
         
        }else
        {
        	Thread.sleep(1500);
        	System.out.println("Element not found");
        	
        }
    		}
    	
    	}
    	}
    }
    
   
    public void implicitWait(AppiumDriver<WebElement> driver) {
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    }

    public void explicitlywait(By b)
    {
        WebDriverWait w = new WebDriverWait(driver, 20);
        w.until(ExpectedConditions.visibilityOfElementLocated(b));
    }

    public void explicitlywait(WebElement e, int timeout)
    {
        WebDriverWait w = new WebDriverWait(driver, timeout);
        w.until(ExpectedConditions.visibilityOf(e));
    }

    public void explicitlywaitiOS(By b)
    {
        WebDriverWait w = new WebDriverWait(driver, 10);
        w.until(ExpectedConditions.presenceOfElementLocated(b));
    }





    public void vefiryWhenElementVisible(WebElement element, int timeout) {

        WebDriverWait wait = new WebDriverWait(driver, timeout);

        element = wait.until(ExpectedConditions.visibilityOfElementLocated((By) element));

        element.isDisplayed();

    }

    public void clickWhenElementReady(By locator, int timeout) {

        WebElement element = null;

        WebDriverWait wait = new WebDriverWait(driver, timeout);

        element = wait.until(ExpectedConditions.elementToBeClickable(locator));

        element.click();

    }
    
    public void WebclickWhenElementReady(RemoteWebDriver wdriver,By locator, int timeout) {

        WebElement element = null;

        WebDriverWait wait = new WebDriverWait(wdriver, timeout);

        element = wait.until(ExpectedConditions.elementToBeClickable(locator));

        element.click();

    }

    public static boolean deleteDirectory() throws IOException {

        String dir1 = strRelPath + "target/surefire-reports";
        FileUtils.deleteDirectory(new File(dir1));
        return true;
    }

    public static void createDirectory() {
        File directory = new File(strRelPath + "target/surefire-reports");
        if (directory.exists()) {
            System.out.println("Directory already exists ...");
        }
        else {
            System.out.println("Directory not exists, creating now");
            boolean success = directory.mkdir();
            if (success) {
                System.out.printf("Successfully created new directory : %s%n", directory);
            }
            else {
                System.out.printf("Failed to create new directory: %s%n", directory);

            }
        }
    }

  
    //deleting as part of code cleanup
    /*private void scroll(AppiumDriver<WebElement> driver, int fromX, int fromY, int toX, int toY) {
        TouchAction touchAction = new TouchAction(driver);

        touchAction.longPress(fromX, fromY).moveTo(toX, toY).release().perform();

    }*/

   
    
    
    public void AssetTableDataSelect(String ColFieldVal) throws Exception
    {
    	boolean clickFlag=false;
    	 WebimplicitWait(wdriver);
    	 WebimplicitWait(wdriver);
    	//Identify the table
    			WebElement assetTable = wdriver.findElement(By.xpath("//table[@id='search']"));
    			
    	//To locate rows of table.
    			List < WebElement > rows_table = assetTable.findElements(By.tagName("tr"));
    	
    	//To calculate no of rows In table.
    			int rows_count = rows_table.size();
    			
    			 //Loop will execute for all the rows of the table
    			  for (int row = 0; row < rows_count; row++)
    			  {
    				  if(clickFlag==true)
    				  {
    					  break;
    				  }
    				  WebimplicitWait(wdriver); 
    			   //To locate columns(cells) of that specific row.
    			   List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));

    			   //To calculate no of columns(cells) In that specific row.
    			   int columns_count = Columns_row.size();
    			   System.out.println("Number of cells In Row " + row + " are " + columns_count);

    			   //Loop will execute till the last cell of that specific row.
    			   for (int column = 0; column < columns_count; column++)
    			   {
    			    //To retrieve text from the cells.
    			    String celltext = Columns_row.get(column).getText().trim();
    			    System.out.println("Cell Value Of row number " + row + " and column number " + column + " Is " + celltext);	
    			    //this is transaction number
    			    if(celltext.equalsIgnoreCase(ColFieldVal))
    			    {
    			    	 WebimplicitWait(wdriver);
    			    	 row=row+1; 
    			    	WebElement CellActionItem = wdriver.findElement(By.xpath("//table[@id='search']/tbody/tr["+row+"]/td[10]/input"));
    			    	System.out.println(CellActionItem.getText());
    			    	Syn_Click(CellActionItem);
    			    	clickFlag=true;
    			    	break;
    			    }
    			   }
                 }

    			 
    }	
    
    
    public static int getRandomNumberInRange(int min, int max) 
    {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
    			  
}

// ////////////////////////dump//////////////////

