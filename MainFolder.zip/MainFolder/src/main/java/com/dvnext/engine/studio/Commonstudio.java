package com.dvnext.engine.studio;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.IOSMobileCapabilityType;
import io.appium.java_client.remote.MobileBrowserType;
import io.appium.java_client.remote.MobileCapabilityType;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.xml.sax.SAXException;

import com.dvnext.engine.serviceClient.ServicesClient;
import com.dvnext.excelutils.ObjectMap;
import com.dvnext.mobile.propertyreader.PropertyFileReader;
import com.dvnext.mobile.testreport.TestReporter;
//import com.nbcu.assetTracker.web.Web_AssetTrack_AddAsset;
import com.relevantcodes.extentreports.ExtentReports;



public class Commonstudio extends ServicesClient  {


    public RemoteWebDriver wdriver;
    public AppiumDriver<WebElement> driver;
    public AndroidDriver adriver;
    public static boolean isDisplayed;

    public ObjectMap objMap;
    public String runType;
    public String tool;
    public String platform;
    public String webbrowser;
    PropertyFileReader prop = new PropertyFileReader();
    public String workingDir = System.getProperty("user.dir");
    public final ExtentReports logger = ExtentReports.get(Commonstudio.class);
    public final ExtentReports loggerE = ExtentReports.get(Commonstudio.class);
    static final String strRelPath = "./";
    public static String mobileServiceUrl;
    public static SSLContext sslcontext;
    public static HttpPost httpPost;
    public static HttpPost httpPostp;
    public static HttpGet httpGet;
    public static HttpDelete httpDelete;
    public static HttpClient client;
    public static HttpResponse httpResponse;
    public static String  KeyText ;
    public static String qrCodeApi;

    public static String emailAddress;

    public static StatusLine statusLine;
    public static String SNTToken;

    public static final long LOWWAIT = 3000;
    public static final long MEDIUMWAIT = 10000;
    public static final long LONGWAIT = 15000;
    public static final long HIGHWAIT = 22000;
    public static final String ANDROID = "Android";
    public static final String FORWARDSLASH = "/";
    public WebElement element;
    public String device;
    public String deviceConnectHost = "deviceconnect.inbcu.com";
    public String deviceConnectDeviceID;
    public String deviceConnectUserName;
    public String deviceConnectApiKey;
    public String serviceUrl = "http://" + deviceConnectHost + "/Appium";

   
    DesiredCapabilities capabilities = new DesiredCapabilities();
   
    @Parameters("DeviceID")
    //@Parameters({ "platform", "deviceID", "appUnderTest", "appType", "environment", "preconditionForPlatform" })
    @BeforeMethod
    public void setcaps(Method m, @Optional String deviceID) throws MalformedURLException, InterruptedException, KeyManagementException, NoSuchAlgorithmException {

        String testName = m.getName();
        runType = prop.readPropFile("runType");
        tool = prop.readPropFile("Tool");
        platform = prop.readPropFile("platform");
        webbrowser=prop.readPropFile("webBrowser");
        
       
        deviceConnectUserName = prop.readPropFile("deviceConnectUserName");
        deviceConnectApiKey = prop.readPropFile("deviceConnectApiKey");
        deviceConnectDeviceID=prop.readPropFile("deviceConnectDeviceID");
        
        System.out.println(tool);
        if (prop.readPropFile("runLocation").contains("local")) {
        	 if (prop.readPropFile("runType").contains("mobile")) {
                 if (prop.readPropFile("Tool").contains("Studio")) {
                     if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                             //DesiredCapabilities caps = new DesiredCapabilities();
                             //caps.setBrowserName(MobileBrowserType.SAFARI);
                             //caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                             //driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), caps);
                        	   DesiredCapabilities capabilities = new DesiredCapabilities();
                        	   // The name of a web browser to test on. Possible values are Safari or
                        	  // Chrome. If no device is specified, an
                        	   // appropriate iOS or Android device will be chosen automatically.
                        	                               capabilities.setCapability("browserName", "Safari");
                        	                               capabilities.setCapability("automationName", "XCUITest");
                        	                               capabilities.setCapability("deviceConnectUsername", deviceConnectUserName);
                        	                               capabilities.setCapability("deviceConnectApiKey", deviceConnectApiKey);
                        	                               capabilities.setCapability("deviceConnectDevice", deviceConnectDeviceID);
                        	                                 //capabilities.setCapability("orientation", "LANDSCAPE");
                        	                                 capabilities.setCapability("nativeWebTap", "true");
                        	                               //capabilities.setCapability("webkitResponseTimeout", "999999");
                        	                               //capabilities.setCapability("autoAcceptAlerts", "true");
                        	                               //capabilities.setCapability("safariAllowPopups","true");
                        	                               //capabilities.setCapability("safariOpenLinksInBackground","true");
                        	                               //capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
                        	                               URL url = new URL(serviceUrl);
                        	                               wdriver = new IOSDriver(url, capabilities);
                        	                             //  ((AppiumDriver) wdriver).rotate(org.openqa.selenium.ScreenOrientation.LANDSCAPE);
                        	 
                        	 
                        	 
                         }

                         else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setBrowserName(MobileBrowserType.CHROMIUM);
                             driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), caps);
                         }

                     } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                             DesiredCapabilities dc = new DesiredCapabilities();

                             dc.setCapability(MobileCapabilityType.PLATFORM, "ios");
                             dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                             dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);

                             driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), dc);

                         } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);

                             capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.readPropFile("appPackage"));
                             capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.readPropFile("appActivity"));

                             driver = new NewAndroidDriver<WebElement>(new URL("http://localhost:4723/wd/hub"), capabilities);

                         }
                     }
                 }
                 else if (prop.readPropFile("Tool").contains("Appium")) {

                     if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setCapability("browserName", "safari");
                             caps.setCapability("version", "11.0");
                             caps.setCapability("platform", "iOS");
                             caps.setCapability("deviceName", "iPhone X");
                             caps.setCapability("platformName", "iOS");
                             caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                             driver = new NewIOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                         }
                         else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setCapability("browserName", "browser");
                             caps.setCapability("version", "6.0");
                             caps.setCapability("platform", "android");
                             caps.setCapability("deviceName", "Nexus S");
                             caps.setCapability("platformName", "android");
                             caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.APPIUM);
                             driver = new NewAndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                         }

                     } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                         if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                             DesiredCapabilities caps = new DesiredCapabilities();
                             caps.setCapability("platformName", "iOS");
                             caps.setCapability("platformVersion", "11.3");
                             caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone");
                             caps.setCapability("automationName", "XCUITEST");
                             caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,300);
                             //caps.setCapability("autoWebview",true); 
                             caps.setCapability(MobileCapabilityType.UDID, prop.readPropFile("UDIDiOS"));
                             caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));

                             driver = new NewIOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

                         } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                             if (prop.readPropFile("Parallel").equalsIgnoreCase("No")) {
                                 DesiredCapabilities capabilities = new DesiredCapabilities();

                                 //capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

                                 capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
                                 capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.readPropFile("UDID"));
                                 capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
                                 capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
                                 capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,300);
                                 capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
                                 capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
                                 capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

                                 try {
                                     driver = new NewAndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

                                 } catch (MalformedURLException e) {
                                     e.printStackTrace();
                                 }
                             } else if (prop.readPropFile("Parallel").equalsIgnoreCase("Yes")) {

                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device1"))) {
                                     device = prop.readPropFile("Devicename1");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL1")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device2"))) {
                                     device = prop.readPropFile("Devicename2");

                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL2")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device3"))) {
                                     device = prop.readPropFile("Devicename3");

                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL3")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device4"))) {
                                     device = prop.readPropFile("Devicename4");

                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL4")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device5"))) {
                                     device = prop.readPropFile("Devicename5");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL5")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device6"))) {
                                     device = prop.readPropFile("Devicename6");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL6")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device7"))) {
                                     device = prop.readPropFile("Devicename7");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL7")), capabilities);
                                 }
                                 if (deviceID.equalsIgnoreCase(prop.readPropFile("Device8"))) {
                                     device = prop.readPropFile("Devicename8");
                                     setcapsforParallel(deviceID);
                                     driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL8")), capabilities);
                                 }

                                 driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                             }
                         }
                     }
                 }
             }
             else if (prop.readPropFile("runType").equalsIgnoreCase("desktop")) {
                 if (prop.readPropFile("webBrowser").contains("chrome")) {
                     DesiredCapabilities caps = new DesiredCapabilities();
                     System.out.println("Chrome");
                     System.setProperty("webdriver.chrome.driver", strRelPath
                             + "Drivers/chromedriver.exe");
                     caps = DesiredCapabilities.chrome();
                     ChromeOptions options = new ChromeOptions();
                     caps.setCapability(ChromeOptions.CAPABILITY, options);
                     wdriver = new ChromeDriver();
                 } else if (prop.readPropFile("webBrowser").contains("safari")) {
                     DesiredCapabilities caps = new DesiredCapabilities();
                     caps.setBrowserName("safari");
                     caps.setCapability("Platform", "Mac");
                     wdriver = new SafariDriver();
                     System.out.println(caps + "    in safari setings");
                 
                     
                 } 
                 
                 else if (prop.readPropFile("webBrowser").contains("InternetExplorer")) {
                     System.setProperty("webdriver.ie.driver", strRelPath
                             + "Drivers/IEDriverServer.exe");
             		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
                    capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
                    capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
                    capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
                   capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
                    capabilities.setJavascriptEnabled(true);
                    wdriver = new InternetExplorerDriver(capabilities);
                 } 
                 else if (prop.readPropFile("webBrowser").contains("firefox")) {
                     DesiredCapabilities caps = new DesiredCapabilities();
                     caps.setBrowserName("firefox");
                     caps.setCapability("Platform", "Mac");
                     wdriver = new FirefoxDriver();

                 }
             } else if (prop.readPropFile("runType").contains("api")) {
                 sslcontext = SSLContext.getInstance("TLSv1.2");
                 sslcontext.init(null, null, null);
                 try {
                     SSLConnectionSocketFactory socketFactory = new
                             SSLConnectionSocketFactory(sslcontext,
                                     SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                     client =
                             HttpClients.custom().setSSLSocketFactory(socketFactory).build();

                 } catch (Exception e) {
                     System.err.println("HttpsURLConnection Failed");
                     e.printStackTrace();
                 }

             }

        } else if (prop.readPropFile("runLocation").contains("jenkins")) {
            //setCapabilitiesFromXMLParameters(appUnderTest, appType, environment, platform, deviceID, preconditionForPlatform);
        }
    }

    @AfterSuite
    public void tearDown() throws Exception {
        logger.endTest();
    }

    @AfterMethod
    public void closeapp() {
    	//try {
        if (prop.readPropFile("runType").equalsIgnoreCase("mobile")) {
        	
            //driver.quit();
        	//added muthu
        	wdriver.quit();
        	
        }
        else if (prop.readPropFile("runType").equalsIgnoreCase("desktop")) {
            wdriver.quit();
        }
    /*	}catch(Exception e) {
    		e.printStackTrace();
    	}*/
    }

 
    @BeforeSuite
    public void ereport() throws ParserConfigurationException, IOException, SAXException {
        deleteDirectory();
        createDirectory();
        platform = prop.readPropFile("platform");
        webbrowser = prop.readPropFile("webBrowser");
        System.out.println(platform);
        String dir = strRelPath + "Reports/EReports";
        File directory = new File(dir);
        directory.mkdirs();
        //loggerE.init(directory + "/AssetTrackerReport_" + webbrowser+"_" + getCurrentTimeStamp() + ".html", true);
        logger.init(directory + "/AssetTrackerReport_" + webbrowser+"_" +platform+"_"+ getCurrentTimeStamp() + ".html", true);
        //logger.init(directory + "/AssetTrackerReport_"+webbrowser+".html", true);
    }

    public void setcapsforParallel(String device) {

        capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, device);
        capabilities.setCapability(MobileCapabilityType.UDID, device);
        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);

        capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
        capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
    }

    public void setcapsforNEWParallel(String platform, String deviceID, String systemPort) throws MalformedURLException {
        String[] platformInfo = platform.split(" ");

        capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, platformInfo[0]);
        capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, platformInfo[1]);
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android1");
        capabilities.setCapability(MobileCapabilityType.UDID, deviceID);

        capabilities.setCapability(MobileCapabilityType.NO_RESET, true);

        capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
        capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));

    }

    public void setcapsWeb() {
        DesiredCapabilities caps = new DesiredCapabilities();
        System.out.println("Chrome");
        System.setProperty("webdriver.chrome.driver", strRelPath
                + "Drivers/chromedriver.exe");
        caps = DesiredCapabilities.chrome();
        ChromeOptions options = new ChromeOptions();
        caps.setCapability(ChromeOptions.CAPABILITY, options);
        wdriver = new ChromeDriver();
    }

    public void setCapabilitiesFromProperties(String deviceID) throws MalformedURLException, NoSuchAlgorithmException, KeyManagementException {
        if (prop.readPropFile("runType").contains("mobile")) {
            if (prop.readPropFile("Tool").contains("Studio")) {
                if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.SAFARI);
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                    else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.CHROMIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                        DesiredCapabilities dc = new DesiredCapabilities();

                        dc.setCapability(MobileCapabilityType.PLATFORM, "ios");
                        dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);

                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), dc);

                    } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);

                        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.readPropFile("appPackage"));
                        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.readPropFile("appActivity"));

                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), capabilities);

                    }
                }
            }
            else if (prop.readPropFile("Tool").contains("Appium")) {

                if (prop.readPropFile("appType").equalsIgnoreCase("web")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "safari");
                        caps.setCapability("version", "11.0");
                        caps.setCapability("platform", "iOS");
                        caps.setCapability("deviceName", "iPhone X");
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }
                    else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "browser");
                        caps.setCapability("version", "6.0");
                        caps.setCapability("platform", "android");
                        caps.setCapability("deviceName", "Nexus S");
                        caps.setCapability("platformName", "android");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.APPIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }

                } else if (prop.readPropFile("appType").equalsIgnoreCase("native")) {
                    if (prop.readPropFile("platform").equalsIgnoreCase("iOS")) {

                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability("platformVersion", "11.3");
                        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone");
                        caps.setCapability("automationName", "XCUITEST");
                        caps.setCapability(MobileCapabilityType.UDID, prop.readPropFile("UDIDiOS"));
                        caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                        caps.setCapability(MobileCapabilityType.BROWSER_NAME, MobileBrowserType.SAFARI);
                        caps.setCapability("startIWDP", true);
                          caps.setCapability("udid", "auto");
                       

                        driver = new NewIOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

                    } else if (prop.readPropFile("platform").equalsIgnoreCase(ANDROID)) {
                        if (prop.readPropFile("Parallel").equalsIgnoreCase("No")) {
                            DesiredCapabilities capabilities = new DesiredCapabilities();

                            capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

                            capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
                            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.readPropFile("UDID"));
                            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
                            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
                            capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
                            capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
                            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

                            try {
                                driver = new NewAndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }
                        } else if (prop.readPropFile("Parallel").equalsIgnoreCase("Yes")) {

                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device1"))) {
                                device = prop.readPropFile("Devicename1");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL1")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device2"))) {
                                device = prop.readPropFile("Devicename2");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL2")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device3"))) {
                                device = prop.readPropFile("Devicename3");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL3")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device4"))) {
                                device = prop.readPropFile("Devicename4");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL4")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device5"))) {
                                device = prop.readPropFile("Devicename5");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL5")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device6"))) {
                                device = prop.readPropFile("Devicename6");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL6")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device7"))) {
                                device = prop.readPropFile("Devicename7");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL7")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device8"))) {
                                device = prop.readPropFile("Devicename8");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL8")), capabilities);
                            }

                            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                        }
                    }
                }
            }
        }
        else if (prop.readPropFile("runType").equalsIgnoreCase("desktop")) {
            if (prop.readPropFile("webBrowser").contains("chrome")) {
                DesiredCapabilities caps = new DesiredCapabilities();
                System.out.println("Chrome");
                System.setProperty("webdriver.chrome.driver", strRelPath
                        + "Drivers/chromedriver.exe");
                caps = DesiredCapabilities.chrome();
                ChromeOptions options = new ChromeOptions();
                caps.setCapability(ChromeOptions.CAPABILITY, options);
                wdriver = new ChromeDriver();
            } else if (prop.readPropFile("webBrowser").contains("safari")) {
                DesiredCapabilities caps = new DesiredCapabilities();
                caps.setBrowserName("safari");
                caps.setCapability("Platform", "Mac");
                wdriver = new SafariDriver();
                System.out.println(caps + "    in safari setings");
            } else if (prop.readPropFile("webBrowser").contains("firefox")) {
                DesiredCapabilities caps = new DesiredCapabilities();
                caps.setBrowserName("firefox");
                caps.setCapability("Platform", "Mac");
                wdriver = new FirefoxDriver();

            }
        } else if (prop.readPropFile("runType").contains("api")) {
            sslcontext = SSLContext.getInstance("TLSv1.2");
            sslcontext.init(null, null, null);
            try {
                SSLConnectionSocketFactory socketFactory = new
                        SSLConnectionSocketFactory(sslcontext,
                                SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                client =
                        HttpClients.custom().setSSLSocketFactory(socketFactory).build();

            } catch (Exception e) {
                System.err.println("HttpsURLConnection Failed");
                e.printStackTrace();
            }

        }

    }

    public void setCapabilitiesFromXMLParameters(String appUnderTest, String appType, String environment, String platform, String deviceID, String preconditionForPlatform) throws MalformedURLException, NoSuchAlgorithmException, KeyManagementException {
        if (appUnderTest.equalsIgnoreCase("Mobile")) {
            if (prop.readPropFile("Tool").contains("Studio")) {
                if (appType.equalsIgnoreCase("Web")) {
                    if (platform.equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.SAFARI);
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                    else if (platform.equalsIgnoreCase("Android")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setBrowserName(MobileBrowserType.CHROMIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), caps);
                    }

                } else if (appType.equalsIgnoreCase("Native")) {
                    if (platform.equalsIgnoreCase("iOS")) {

                        DesiredCapabilities dc = new DesiredCapabilities();

                        dc.setCapability(MobileCapabilityType.PLATFORM, "ios");
                        dc.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));
                        dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);

                        driver = new NewIOSDriver<IOSElement>(new URL("http://localhost:4723/wd/hub"), dc);

                    } else if (platform.equalsIgnoreCase("Android")) {
                        capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);

                        capabilities.setCapability(AndroidMobileCapabilityType.APP_PACKAGE, prop.readPropFile("appPackage"));
                        capabilities.setCapability(AndroidMobileCapabilityType.APP_ACTIVITY, prop.readPropFile("appActivity"));

                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://localhost:4723/wd/hub"), capabilities);

                    }
                }
            }
            else if (prop.readPropFile("Tool").contains("Appium")) {

                if (appType.equalsIgnoreCase("Web")) {
                    if (platform.equalsIgnoreCase("iOS")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "safari");
                        caps.setCapability("version", "11.0");
                        caps.setCapability("platform", "iOS");
                        caps.setCapability("deviceName", "iPhone X");
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
                        driver = new NewIOSDriver<IOSElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }
                    else if (platform.equalsIgnoreCase("Android")) {
                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("browserName", "browser");
                        caps.setCapability("version", "6.0");
                        caps.setCapability("platform", "android");
                        caps.setCapability("deviceName", "Nexus S");
                        caps.setCapability("platformName", "android");
                        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.APPIUM);
                        driver = new NewAndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
                    }

                } else if (appType.equalsIgnoreCase("Native")) {
                    if (platform.equalsIgnoreCase("iOS")) {

                        DesiredCapabilities caps = new DesiredCapabilities();
                        caps.setCapability("platformName", "iOS");
                        caps.setCapability("platformVersion", "11.3");
                        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone");
                        caps.setCapability("automationName", "XCUITEST");
                        caps.setCapability(MobileCapabilityType.UDID, prop.readPropFile("UDIDiOS"));
                        caps.setCapability(IOSMobileCapabilityType.BUNDLE_ID, prop.readPropFile("bundleId"));

                        driver = new NewIOSDriver<IOSElement>(new URL("http://127.0.0.1:4723/wd/hub"), caps);

                    } else if (platform.equalsIgnoreCase("Android")) {
                        if (prop.readPropFile("Parallel").equalsIgnoreCase("No")) {
                            DesiredCapabilities capabilities = new DesiredCapabilities();

                            capabilities.setCapability(CapabilityType.BROWSER_NAME, "");

                            capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, ANDROID);
                            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.readPropFile("UDID"));
                            capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
                            capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
                            capabilities.setCapability("appPackage", prop.readPropFile("appPackage"));
                            capabilities.setCapability("appActivity", prop.readPropFile("appActivity"));
                            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");

                            try {
                                driver = new NewAndroidDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

                            } catch (MalformedURLException e) {
                                e.printStackTrace();
                            }
                        } else if (prop.readPropFile("Parallel").equalsIgnoreCase("Yes")) {

                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device1"))) {
                                device = prop.readPropFile("Devicename1");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL1")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device2"))) {
                                device = prop.readPropFile("Devicename2");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL2")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device3"))) {
                                device = prop.readPropFile("Devicename3");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL3")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device4"))) {
                                device = prop.readPropFile("Devicename4");

                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL4")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device5"))) {
                                device = prop.readPropFile("Devicename5");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL5")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device6"))) {
                                device = prop.readPropFile("Devicename6");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL6")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device7"))) {
                                device = prop.readPropFile("Devicename7");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL7")), capabilities);
                            }
                            if (deviceID.equalsIgnoreCase(prop.readPropFile("Device8"))) {
                                device = prop.readPropFile("Devicename8");
                                setcapsforParallel(deviceID);
                                driver = new NewAndroidDriver<WebElement>(new URL(prop.readPropFile("AppiumURL8")), capabilities);
                            }

                            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

                        }
                    }
                }
            }
        }
        else if (appUnderTest.equalsIgnoreCase("Dektop")) {
            if (appType.equalsIgnoreCase("Web")) {
                if (prop.readPropFile("webBrowser").contains("chrome")) {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    System.out.println("Chrome");
                    System.setProperty("webdriver.chrome.driver", strRelPath
                            + "Drivers/chromedriver.exe");
                    caps = DesiredCapabilities.chrome();
                    ChromeOptions options = new ChromeOptions();
                    caps.setCapability(ChromeOptions.CAPABILITY, options);
                    wdriver = new ChromeDriver();
                } else if (prop.readPropFile("webBrowser").contains("safari")) {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    caps.setBrowserName("safari");
                    caps.setCapability("Platform", "Mac");
                    wdriver = new SafariDriver();
                    System.out.println(caps + "    in safari setings");
                } else if (prop.readPropFile("webBrowser").contains("firefox")) {
                    DesiredCapabilities caps = new DesiredCapabilities();
                    caps.setBrowserName("firefox");
                    caps.setCapability("Platform", "Mac");
                    wdriver = new FirefoxDriver();

                }
            } else if (appType.equalsIgnoreCase("Standalone")) {

            }
        } else if (appUnderTest.equalsIgnoreCase("Api")) {
            sslcontext = SSLContext.getInstance("TLSv1.2");
            sslcontext.init(null, null, null);
            try {
                SSLConnectionSocketFactory socketFactory = new
                        SSLConnectionSocketFactory(sslcontext,
                                SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                client =
                        HttpClients.custom().setSSLSocketFactory(socketFactory).build();

            } catch (Exception e) {
                System.err.println("HttpsURLConnection Failed");
                e.printStackTrace();
            }

        }

    }

    // ////////////////Get failed screen
    // shot/////////////////////////////////////////////////
    public void getScreenshotFailed(AppiumDriver<WebElement> driver,
            String errMsg, boolean isScreenshotReqd) throws IOException {
        if (prop.readPropFile("screen").equalsIgnoreCase("fail") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            System.out.println("Taking screenshot");
            File srcfile = null;
            srcfile = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");
            }
        }
    }
    
    public void getScreenshotFailedWeb(RemoteWebDriver wdriver,
            String errMsg, boolean isScreenshotReqd) throws IOException {
        if (prop.readPropFile("screen").equalsIgnoreCase("fail") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            System.out.println("Taking screenshot");
            File srcfile = null;
            srcfile = ((TakesScreenshot) wdriver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");
            }
        }
    }

    // //////////////////////////Current time
    // stap/////////////////////////////////////
    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");// dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate; // returns current date and time in format mentioned
    }

    // Screen Shot for Each Step
    public void getScreenshoteachStep(AppiumDriver<WebElement> driver, boolean isScreenshotReqd)
            throws Exception {
        if (prop.readPropFile("screen").equalsIgnoreCase("pass") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            File srcfile = null;
            srcfile = ((TakesScreenshot) driver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");

            }

        }
    }

    
    // Web Screen Shot IE and Safari -- Muthu
    
    // Screen Shot for Each Step
    public void getScreenshoteachStepWeb(RemoteWebDriver wdriver, boolean isScreenshotReqd)
            throws Exception {
        if (prop.readPropFile("screen").equalsIgnoreCase("pass") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
            File srcfile = null;
            srcfile = ((TakesScreenshot) wdriver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");

            }

        }
    }
    
    public void getScreenshoteachStepWebHighlight(RemoteWebDriver wdriver, boolean isScreenshotReqd,WebElement highlightedElement)
            throws Exception {
        if (prop.readPropFile("screen").equalsIgnoreCase("pass") || (prop.readPropFile("screen").equalsIgnoreCase("both"))) {
                JavascriptExecutor jseHighlightEle = (JavascriptExecutor) wdriver;
                jseHighlightEle.executeScript("arguments[0].style.border='2px solid green'", highlightedElement);
                File srcfile = null;
            srcfile = ((TakesScreenshot) wdriver)
                    .getScreenshotAs(OutputType.FILE);
            if (isScreenshotReqd) {

                FileUtils.copyFile(srcfile, new File(strRelPath + FORWARDSLASH
                        + "Reports" + FORWARDSLASH + "EReports" + FORWARDSLASH + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png"));
                logger.attachScreenshot(strRelPath + "ScreenShots" + FORWARDSLASH
                        + Commonstudio.getCurrentTimeStamp() + ".png");

            }

        }
    }
    
// to select value from drop down using java script click
    
    public void dropDownSelectJavaScript(WebElement element,String valueToSelect)
    {
    	WebDriverWait wait = new WebDriverWait(wdriver,30);
   	 
		// Here we will wait until element is not visible, if element is visible then it will return web element
		// or else it will throw exception
		wait.until(ExpectedConditions.visibilityOf(element));	
		((JavascriptExecutor)wdriver).executeScript("var select = arguments[0]; for(var i = 0; i < select.options.length; i++){ if(select.options[i].text == arguments[1]){ select.options[i].selected = true; } }", element, valueToSelect);
    }

    public void Syn_Click(WebElement element) throws Exception {
    	WebDriverWait wait = new WebDriverWait(wdriver,30);
    	 
		// Here we will wait until element is not visible, if element is visible then it will return web element
		// or else it will throw exception
		wait.until(ExpectedConditions.visibilityOf(element));
       
		// if element found then we will use- In this example I just called isDisplayed method
		//boolean status = element.isDisplayed();
    	String browser=prop.readPropFile("browsertype");
		
			if(browser.equalsIgnoreCase("Safari"))
			{
			if (element.isEnabled() && element.isDisplayed()) {
				System.out.println("Clicking on element with using java script click");

				((JavascriptExecutor) wdriver).executeScript("arguments[0].click();", element);
				
				System.out.println("clicking on Element -"+element.getText());
				TestReporter.logStep("clicking on Element -"+element.getText());
			}
				
			
			}else if(browser.equalsIgnoreCase("InternetExplorer"))
			{
				 WebimplicitWait(wdriver);
				if (element.isEnabled() && element.isDisplayed()) 
				{
				element.click();
				//TestReporter.logStep("clicking on Element -"+element.getText());
				}
			}
			
			
			else {
				System.out.println("Unable to click on element");
			}
		
	}
    
    //Pass browser type and type of click Eg (Java script click or click method)
    public void Syn_Click_RunTime(WebElement element,String clickType) throws Exception {
    	WebDriverWait wait = new WebDriverWait(wdriver,30);
    	 
		// Here we will wait until element is not visible, if element is visible then it will return web element
		// or else it will throw exception
		wait.until(ExpectedConditions.visibilityOf(element));
       
		// if element found then we will use- In this example I just called isDisplayed method
		//boolean status = element.isDisplayed();
    	//String browser=prop.readPropFile("browsertype");
		  //clickType="JavaScriptClick";
			if(clickType.equalsIgnoreCase("JavaScriptClick"))
			{
			if (element.isEnabled() && element.isDisplayed()) {
				System.out.println("Clicking on element with using java script click");

				((JavascriptExecutor) wdriver).executeScript("arguments[0].click();", element);
				
				System.out.println("clicking on Element");
			}
				
			
			}
			else
			{
				 WebimplicitWait(wdriver);
				if (element.isEnabled() && element.isDisplayed()) 
				{
				element.click();
				}
			}
			
			
			
		
	}
    

    
    
    public static void WebimplicitWait(RemoteWebDriver wdriver) {
        wdriver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
    }

    
    public void switchToWindow(String title) throws InterruptedException {
    	Thread.sleep(4000);
		Set<String> availableWindows = wdriver.getWindowHandles();
		//System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
		if (availableWindows.size() >= 1) {
			try {
				for (String windowId : availableWindows) {
					
					System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
					if (wdriver.switchTo().window(windowId).getTitle().equals(title)){
						break;
					}
						//return true;
						//return true;
					  //break;
				}
			} catch (NoSuchWindowException e) {
				
				//logger.handleError("No child window is available to switch ", e);
			}
		}
    }

    
    
    public void switchToWindow1(String title) throws InterruptedException {
    	Thread.sleep(4000);
    	String child=null;
		Set<String> availableWindows = wdriver.getWindowHandles();
		String Parent =wdriver.getWindowHandle();
		availableWindows.remove(Parent);
		try {
		Iterator<String> it =availableWindows.iterator();
		while(it.hasNext()){
			child=(String)it.next();
			wdriver.switchTo().window(child).getTitle().equals(title);
		}
		/*//System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
		if (availableWindows.size() >= 1) {
			try {
				for (String windowId : availableWindows) {
					
					System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
					if (wdriver.switchTo().window(windowId).getTitle().equals(title)){
						//break;
					}
						//return true;
						//return true;
					  //break;
				}*/
			} 
		catch (NoSuchWindowException e) {
				
				//logger.handleError("No child window is available to switch ", e);
			}
		}
    

    
    
    
    
    
    
    public void webexplicitlywait(WebDriver wdriver,String b) throws InterruptedException
    {
    	WebElement ele = null;
    	try
    	{
    	
    		 ele = wdriver.findElement(By.xpath(b));
    	}
    	
    	catch(Exception e)
    	{
    	for(int i=0;i<=2;i++)
    	{
    		try{
    			 ele = wdriver.findElement(By.xpath(b));
    		}
    		 catch(Exception el){
       if(ele!=null)
       {
    	
        	 break;//
         
        }else
        {
        	Thread.sleep(1500);
        	System.out.println("Element not found");
        	
        }
    		}
    	
    	}
    	}
    }
    
   
    public void implicitWait(AppiumDriver<WebElement> driver) {
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    }

    public void explicitlywait(By b)
    {
        WebDriverWait w = new WebDriverWait(driver, 20);
        w.until(ExpectedConditions.visibilityOfElementLocated(b));
    }
    
    public void explicitlywaitAlert_Web()
    {
    	WebDriverWait wait = new WebDriverWait(wdriver,30);
        wait.until(ExpectedConditions.alertIsPresent());
    }

    public void explicitlywait(WebElement e, int timeout)
    {
        WebDriverWait w = new WebDriverWait(driver, timeout);
        w.until(ExpectedConditions.visibilityOf(e));
    }

    public void explicitlywaitiOS(By b)
    {
        WebDriverWait w = new WebDriverWait(driver, 10);
        w.until(ExpectedConditions.presenceOfElementLocated(b));
    }

    public void clicklongPresselement(AppiumDriver<WebElement> driver, WebElement name) {
        TouchAction longPress = new TouchAction(driver);
        String txt = null;
        WebElement cardList = null;
        if (cardList == null)
        {
            try {
                cardList = name;
            } catch (Exception e)
            {
                cardList = null;
            }
        }

        if (cardList == null) {
            try {
                cardList = name;
            } catch (Exception e)
            {
                cardList = null;
            }
        }
        if (cardList != null)
        {
            //longPress.longPress(cardList).perform();
        } else {
            System.out.println("Error while clicking");
        }
        System.out.println("Outer loop");

    }

    public void clicklongPress(AppiumDriver<WebElement> driver, WebElement name) {
        TouchAction longPress = new TouchAction(driver);

        //longPress.longPress(name);

    }

    public void vefiryWhenElementVisible(WebElement element, int timeout) {

        WebDriverWait wait = new WebDriverWait(driver, timeout);

        element = wait.until(ExpectedConditions.visibilityOfElementLocated((By) element));

        element.isDisplayed();

    }

    public void clickWhenElementReady(By locator, int timeout) {

        WebElement element = null;

        WebDriverWait wait = new WebDriverWait(driver, timeout);

        element = wait.until(ExpectedConditions.elementToBeClickable(locator));

        element.click();

    }
    
    public void WebclickWhenElementReady(RemoteWebDriver wdriver,By locator, int timeout) {

        WebElement element = null;

        WebDriverWait wait = new WebDriverWait(wdriver, timeout);

        element = wait.until(ExpectedConditions.elementToBeClickable(locator));

        element.click();

    }

    public static boolean deleteDirectory() throws IOException {

        String dir1 = strRelPath + "target/surefire-reports";
        FileUtils.deleteDirectory(new File(dir1));
        return true;
    }

    public static void createDirectory() {
        File directory = new File(strRelPath + "target/surefire-reports");
        if (directory.exists()) {
            System.out.println("Directory already exists ...");
        }
        else {
            System.out.println("Directory not exists, creating now");
            boolean success = directory.mkdir();
            if (success) {
                System.out.printf("Successfully created new directory : %s%n", directory);
            }
            else {
                System.out.printf("Failed to create new directory: %s%n", directory);

            }
        }
    }

    public boolean swipeTillElementFind(AppiumDriver<WebElement> driver, List<WebElement> list) {
        int pressX = driver.manage().window().getSize().width / 2;

        int bottomY = driver.manage().window().getSize().height * 4 / 5;

        int topY = driver.manage().window().getSize().height / 8;

        int i = 1;
        do {

            Boolean isPresent = list.isEmpty();
            if (isPresent) {
                element.isDisplayed();
                break;
            }
            else {
                if (i <= 4) {
                    scroll(driver, pressX, bottomY, pressX, topY);
                } else if (i > 4) {
                    scrollDown(driver, 500, 600, 500, 1200);
                }
            }
            i++;

        } while (i <= 8);

        return element.isDisplayed();
    }

    private void scroll(AppiumDriver<WebElement> driver, int fromX, int fromY, int toX, int toY) {
        TouchAction touchAction = new TouchAction(driver);

        //touchAction.longPress(fromX, fromY).moveTo(toX, toY).release().perform();

    }

    private void scrollDown(AppiumDriver<WebElement> driver, int fromX, int fromY, int toX, int toY) {
        TouchAction touchAction = new TouchAction(driver);

        //touchAction.longPress(500, 600).moveTo(500, 1200).release().perform();

    }
    
    
    public void AssetTableDataSelect(String ColFieldVal,int ColNo,String Action) throws Exception
    {
    	boolean clickFlag=false;
    	 WebimplicitWait(wdriver);
    	 WebimplicitWait(wdriver);
    	//Identify the table
    			WebElement assetTable = wdriver.findElement(By.xpath("//table[@id='search']"));
    			
    	//To locate rows of table.
    			List < WebElement > rows_table = assetTable.findElements(By.tagName("tr"));
    	
    	//To calculate no of rows In table.
    			int rows_count = rows_table.size();
    			
    			 //Loop will execute for all the rows of the table
    			  for (int row = 0; row < rows_count; row++)
    			  {
    				  if(clickFlag==true)
    				  {
    					  break;
    				  }
    				  WebimplicitWait(wdriver); 
    			   //To locate columns(cells) of that specific row.
    			   List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));

    			   //To calculate no of columns(cells) In that specific row.
    			   int columns_count = Columns_row.size();
    			   System.out.println("Number of cells In Row " + row + " are " + columns_count);

    			   //Loop will execute till the last cell of that specific row.
    			   for (int column = 0; column < columns_count; column++)
    			   {
    			    //To retrieve text from the cells.
    			    String celltext = Columns_row.get(column).getText().trim();
    			    System.out.println("Cell Value Of row number " + row + " and column number " + column + " Is " + celltext);	
    			    //this is transaction number
    			    if(celltext.equalsIgnoreCase(ColFieldVal))
    			    {
    			    	 WebimplicitWait(wdriver);
    			    	 row=row+1; 
    			    	WebElement CellActionItem = wdriver.findElement(By.xpath("//table[@id='search']/tbody/tr["+row+"]/td["+ColNo+"]/input"));
    			    	if(Action=="click")
    			    	{	
    			    	System.out.println(CellActionItem.getText());
    			    	Syn_Click(CellActionItem);
    			    	clickFlag=true;
    			    	break;
    			    	}
    			    }
    			   }
                 }
	 
    }	
    
 
    public void ShipmentTableDataSelect(String ColFieldVal) throws Exception
    {
    	boolean clickFlag=false;
    	 WebimplicitWait(wdriver);
    	 WebimplicitWait(wdriver);
    	//Identify the table
    			WebElement shipmentTable = wdriver.findElement(By.xpath("//table[@id='search']"));
    			
    	//To locate rows of table.
    			List < WebElement > rows_table = shipmentTable.findElements(By.tagName("tr"));
    	
    	//To calculate no of rows In table.
    			int rows_count = rows_table.size();
    			
    			 //Loop will execute for all the rows of the table
    			  for (int row = 0; row < rows_count; row++)
    			  {
    				  if(clickFlag==true)
    				  {
    					  break;
    				  }
    				  WebimplicitWait(wdriver); 
    			   //To locate columns(cells) of that specific row.
    			   List < WebElement > Columns_row = rows_table.get(row).findElements(By.tagName("td"));

    			   //To calculate no of columns(cells) In that specific row.
    			   int columns_count = Columns_row.size();
    			   System.out.println("Number of cells In Row " + row + " are " + columns_count);

    			   //Loop will execute till the last cell of that specific row.
    			   for (int column = 0; column < columns_count; column++)
    			   {
    			    //To retrieve text from the cells.
    			    String celltext = Columns_row.get(column).getText().trim();
    			    System.out.println("Cell Value Of row number " + row + " and column number " + column + " Is " + celltext);	
    			    //this is transaction number
    			    if(celltext.equalsIgnoreCase(ColFieldVal))
    			    {
    			    	 WebimplicitWait(wdriver);
    			    	 row=row+1; 
    			    	WebElement CellActionItem = wdriver.findElement(By.xpath("//table[@id='search']/tbody/tr["+row+"]/td[7]/input"));
    			    	System.out.println(CellActionItem.getText());
    			    	Syn_Click(CellActionItem);
    			    	clickFlag=true;
    			    	break;
    			    }
    			   }
                 }

    			 
    }	
    
    public static int getRandomNumberInRange(int min, int max) 
    {

		if (min >= max) {
			throw new IllegalArgumentException("max must be greater than min");
		}

		Random r = new Random();
		return r.nextInt((max - min) + 1) + min;
	}
    			  


// ////////////////////////dump//////////////////
//Satish
public void Syn_Clickupd(WebElement element,RemoteWebDriver wdriver) throws Exception {
    WebDriverWait wait = new WebDriverWait(wdriver,30);
    
// Here we will wait until element is not visible, if element is visible then it will return web element
// or else it will throw exception
wait.until(ExpectedConditions.visibilityOf(element));
       
// if element found then we will use- In this example I just called isDisplayed method
//boolean status = element.isDisplayed();
    String browser=prop.readPropFile("browsertype");

if(browser.equalsIgnoreCase("Safari"))
{
if (element.isEnabled() && element.isDisplayed()) {
System.out.println("Clicking on element with using java script click");

((JavascriptExecutor) wdriver).executeScript("arguments[0].click();", element);

System.out.println("clicking on Element");
}


}else if(browser.equalsIgnoreCase("InternetExplorer"))
{
WebimplicitWait(wdriver);
if (element.isEnabled() && element.isDisplayed()) 
{
element.click();
}
}


else {
System.out.println("Unable to click on element");
}

}



public void switchToWindowupd(String title,RemoteWebDriver wdriver) throws InterruptedException {
    Thread.sleep(2000);
Set<String> availableWindows = wdriver.getWindowHandles();
//System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
if (availableWindows.size() >= 1) {
try {
for (String windowId : availableWindows) {

System.out.println("windown name"+wdriver.switchTo().window(windowId).getTitle());
if (wdriver.switchTo().window(windowId).getTitle().equals(title));
//return true;
//return true;
}
} catch (NoSuchWindowException e) {

//logger.handleError("No child window is available to switch ", e);
}
}
}

public void Syn_Sleep() throws Exception {
    
    
String browser=prop.readPropFile("platform");
  if(browser.equalsIgnoreCase("Mac"))
{
Thread.sleep(200000);
}else 
{
WebimplicitWait(wdriver);
}
}
public void selValueWindow(RemoteWebDriver wdriver)
{

element = wdriver.findElement(By.xpath("(//*[@type='radio'])[1]"));
element.click();
}

public boolean isMultiple_AlertPresents(RemoteWebDriver wdriver) {
    try {
           wdriver.switchTo().alert();
           return true;
    } // try
    catch (Exception e) {
           e.printStackTrace();
           return false;
    } // catch
}

public void selectDateJavScriptExe(String datefieldVal,WebElement element1){

    String _date = new String();

   

    //m_driver.findElement(By.xpath("//input[@name='inServiceWarrantyDate']"));

    //String script= "arguments[0].setAttribute('value','09/26/2019');";

    //m_jsDriver.executeScript(script, m_driver.findElement(By.xpath("//input[@name='inServiceWarrantyDate']")));



   

    try{

       

          String script= "arguments[0].setAttribute('value','"+datefieldVal+"');";

        JavascriptExecutor js = ((JavascriptExecutor) wdriver);

//        WebElement ele= wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']"));

        //js.executeScript(script, wdriver.findElement(By.xpath("//*[@name='dateExpectedBack']")));
        js.executeScript(script, element1);
          /*if(!datePickerDiv.isDisplayed()){

                datefield.click();

          }

          WebElement _elem = datePickerDiv.findElement(By.cssSelector(".ui-datepicker-next.ui-corner-all"));

          _elem.click();



          List<WebElement> _elems = datePickerDiv.findElements(By.cssSelector(".ui-state-default"));

          for(WebElement _item : _elems){

                _date = _item.getText();

                _item.click();

                sleep(1);

                //return _date;

          }*/              

    }catch(Exception e)

    {

          e.printStackTrace();

    }
}



}
