package com.dvnext.engine.serviceClient;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.commons.io.FileUtils;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.json.simple.JSONArray;
import org.json.JSONException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.xml.sax.SAXException;

import com.dvnext.mobile.propertyreader.PropertyFileReader;
//import com.nbcu.mobile.constants.Constant;
//import com.relevantcodes.extentreports.ExtentReports;
//import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.ExtentReports;

public class ServicesClient {
    public static String mobileServiceUrl;
    public static String dmpServiceUrl;
    public static HttpPost pcsServiceUrl;
    public static HttpPost patronService;
    public static SSLContext sslcontext;
    public static HttpPost httpPost;

    public static HttpGet httpGet;
    public static HttpDelete httpDelete;
    public static HttpClient client;
    public static HttpClient client_withProxy;
    public static HttpResponse httpResponse;
    final static String strRelPath = "./";
    public static ExtentReports logger = ExtentReports.get(HttpClient.class);
    public static PropertyFileReader prop = new PropertyFileReader();
    public static String Environment;
    public static HttpPost operaHttpPost;
    public static StatusLine statusLine;
    public static String SNTToken;
    public static HttpPost assignRoomHttpPost;
    public static String email_Dining;
    public static String roomKeyVendor;
    public static JSONArray availability;
    public static String qRCode;
    public static int today = 1;
    public static boolean idVerified;
    public static String proxy = prop.readPropFile("proxy");
    public static int todayUI=1;
    public static int todayA=0;
    @Parameters("environment")
    @SuppressWarnings("deprecation")
    @BeforeMethod
    public static void main(@Optional String environment) throws NoSuchAlgorithmException, KeyManagementException, IOException, JSONException {
        sslcontext = SSLContext.getInstance("TLSv1.2");
        TrustManager trustManager = new X509TrustManager() {
            @Override
            public void checkClientTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
            }

            @Override
            public void checkServerTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {

            }

            @Override
            public X509Certificate[] getAcceptedIssuers() {
                return null;
            }
        };
        sslcontext.init(null, new TrustManager[] { trustManager }, null);
        String MGM_PROXYHOST = "mproxy.mgmresorts.local";
        int MGM_PROXYPORT = 8080;
        HttpHost myProxy = new HttpHost(MGM_PROXYHOST, MGM_PROXYPORT);

        try {
            if (proxy.equals("mgm")) {
                // run with mgm proxy
                SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslcontext,
                        SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                client = HttpClients.custom().setProxy(myProxy).setSSLSocketFactory(socketFactory).build();
            } else if (proxy.equals("capgemini")) {
                // no proxy required
                SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslcontext,
                        SSLConnectionSocketFactory.BROWSER_COMPATIBLE_HOSTNAME_VERIFIER); // Socket
                client = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
            }
        } catch (Exception e1) {
            System.err.println("HttpsURLConnection Failed");
            e1.printStackTrace();

        }
        patronService = new HttpPost("http://10.199.131.86:80");
        if (prop.readPropFile("runLocation").equalsIgnoreCase("Local"))

        {

            Environment = prop.readPropFile("Environment");
            if (Environment.equalsIgnoreCase("QA")) {
                //mobileServiceUrl = Constant.mobileServiceUrl_QA;
                dmpServiceUrl = "https://aws-qa.mgmresorts.com";
                operaHttpPost = new HttpPost("https://owsqa.mgmresorts.com/OWS_WS_51/Reservation.asmx");
                pcsServiceUrl = new HttpPost("https://PCS2-QA.MGMRESORTS.COM/mgm-ota/expedia/bookingnotification/");
                System.out.println("QA");
            } else if (Environment.equalsIgnoreCase("Preprod")) {
                mobileServiceUrl = "https://preprod-api.mgmresorts.com";
                dmpServiceUrl = "https://preprod.mgmresorts.com";
                operaHttpPost = new HttpPost("https://owsr.mgmresorts.com/OWS_WS_51/Reservation.asmx");
            } else if (Environment.equalsIgnoreCase("Dev")) {
                mobileServiceUrl = "https://dev-api.mgmresorts.com";
                dmpServiceUrl = "https://dev.mgmresorts.com";
            } else if (Environment.equalsIgnoreCase("QA4")) {
                mobileServiceUrl = "https://qa4-api.mgmresorts.com";
                dmpServiceUrl = "https://aws-origin-test.mgmresorts.com";
                operaHttpPost = new HttpPost("https://v00wwowssnt01t.nonprod.org/OWS_WS_51/Reservation.asmx");

            } else if (Environment.equalsIgnoreCase("prod")) {
                mobileServiceUrl = "https://api.mgmresorts.com";
                dmpServiceUrl = "https://mgmresorts.com";
            }

        } else if (prop.readPropFile("runLocation").equalsIgnoreCase("Jenkins")) {
            if (environment.equalsIgnoreCase("QA")) {
                mobileServiceUrl = "https://uat-api.mgmresorts.com";
                dmpServiceUrl = "https://aws-qa.mgmresorts.com";
                operaHttpPost = new HttpPost("https://owsqa.mgmresorts.com/OWS_WS_51/Reservation.asmx");
                pcsServiceUrl = new HttpPost("https://PCS2-QA.MGMRESORTS.COM/mgm-ota/expedia/bookingnotification/");
                System.out.println("QA");
            } else if (environment.equalsIgnoreCase("Preprod")) {
                mobileServiceUrl = "https://preprod-api.mgmresorts.com";
                String dmpServiceUrl = "https://preprod.mgmresorts.com";
                operaHttpPost = new HttpPost("https://owsr.mgmresorts.com/OWS_WS_51/Reservation.asmx");
            } else if (environment.equalsIgnoreCase("Dev")) {
                mobileServiceUrl = "https://dev-api.mgmresorts.com";
                String dmpServiceUrl = "https://dev.mgmresorts.com";
            } else if (environment.equalsIgnoreCase("prod")) {
                mobileServiceUrl = "https://api.mgmresorts.com";
                dmpServiceUrl = "https://mgmresorts.com";
            } else if (environment.equalsIgnoreCase("QA4")) {
                mobileServiceUrl = "https://qa4-api.mgmresorts.com";
                dmpServiceUrl = "https://aws-origin-test.mgmresorts.com";
                operaHttpPost = new HttpPost("https://v00wwowssnt01t.nonprod.org/OWS_WS_51/Reservation.asmx");
            }
        }

    }

    @BeforeSuite
    public void Ereport() throws ParserConfigurationException, IOException, SAXException, JSONException {
        deleteDirectory();
        createDirectory();
        Environment = prop.readPropFile("Environment");
        System.out.println(Environment);
        String dir = strRelPath + "Reports/html";
        File directory = new File(dir);
        directory.mkdirs();
        logger.init(directory + "/MobileAPI" + Environment + getCurrentTimeStamp() + ".html", true);
        logger.init(directory + "/MobileAPI.html", true);
    }

    public static String getCurrentTimeStamp() {
        SimpleDateFormat sdfDate = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");// dd/MM/yyyy
        Date now = new Date();
        String strDate = sdfDate.format(now);
        return strDate; // returns current date and time in format mentioned
    }

    public static boolean deleteDirectory() throws IOException {
        // File dir = new File(strRelPath+"target/surefire-reports");
        String dir1 = strRelPath + "target/surefire-reports";
        FileUtils.deleteDirectory(new File(dir1));
        return true;
    }

    public static void createDirectory() {
        File directory = new File(strRelPath + "target/surefire-reports");
        if (directory.exists()) {
            System.out.println("Directory already exists ...");
        } else {
            System.out.println("Directory not exists, creating now");
            boolean success = directory.mkdir();
            if (success) {
                System.out.printf("Successfully created new directory : %s%n", directory);
            } else {
                System.out.printf("Failed to create new directory: %s%n", directory);
            }
        }
    }

    public String getAllCookies() {
        String cookies = null;
        int i = 0;
        System.out.println(httpResponse.getAllHeaders());
        for (Header header : httpResponse.getAllHeaders()) {
            if (header.getName().equalsIgnoreCase("Set-Cookie")) {
                if (i == 0) {
                    // cookies = header.getValue();
                    cookies = header.getValue().split(";")[0];
                } else {
                    // cookies = cookies + "," + header.getValue();
                    cookies = cookies + "; " + header.getValue().split(";")[0];
                }
                i = i + 1;
            }
        }
        return cookies;
    }

    public Header[] getHeaders() {
        return httpResponse.getAllHeaders();
    }

    public String getCookie(String cookieName) {
        for (Header header : httpResponse.getAllHeaders()) {
            if (header.getName().equalsIgnoreCase("Set-Cookie")) {
                if (header.getValue().contains(cookieName)) {
                    // return header.getValue();
                    return header.getValue().split(";")[0];
                }
            }
        }
        return null;
    }

    public void httpPostHeaders() {

        httpPost.setHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
        httpPost.setHeader("Accept", "application/json, text/plain, */*");
    }

    public void httpGetHeaders() {

        httpGet.setHeader("Content-type", "application/x-www-form-urlencoded; charset=UTF-8");
        httpGet.setHeader("Accept", "application/json, text/plain, */*");
    }

    public void executeGet() throws ClientProtocolException, IOException {
        httpResponse = client.execute(httpGet);
    }

}