package com.Nbcu.AssetTracker.Web.LoginComponents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_LoginPage;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.testreport.TestReporter;
import com.dvnext.mobile.utils.PropertyFileReader;
//import com.nbcu.mobile.constants.Constant;
//import com.mgm.mobile.or.BookLocator;
//import com.mgm.mobile.or.MlifeLocator;
//import com.mgm.mobile.or.MyStayLocator;
import com.relevantcodes.extentreports.ExtentReports;
/*
 * AndroidMyStayModules: Methods for rooms reservation(Check in, checkout, retrieve reservations,card details, room upgrade, precheckin) related screen for IOS and Android.
 * Modified On:20-Apr-2019
 * Modified By: Giri
 * Modified deails:Logs Updated
 */
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

public class AssetTrack_LoginModules extends Commonstudio {

    PropertyFileReader prop = new PropertyFileReader();
    Commonstudio objCommStudio = new Commonstudio();
    AssetTrack_LoginPage assetLoginPge=new AssetTrack_LoginPage();
    //MyStayLocator objMyStayLoc = new MyStayLocator();
    //MlifeLocator objMLiLoc = new MlifeLocator();
    //BookLocator objBokLoc = new BookLocator();
    public String Confirmation;

    ExtentReports logger = ExtentReports.get(AssetTrack_LoginModules.class);

    public void mob_MyStayTab(AppiumDriver<WebElement> driver) throws Exception
    {
        //Constant.home.mBtn_Mob_HomeTab(driver).click();
        objCommStudio.getScreenshoteachStep(driver, true);
        Thread.sleep(1000);

    }
    
    
    public void AssetTrack_Login(RemoteWebDriver wdriver,String username, String password) throws Exception
    {
    	
        //Constant.home.mBtn_Mob_HomeTab(wdriver).click();
        //objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        Thread.sleep(1000);
        try
        {
        	String AppURLAsset;
        	AppURLAsset="https://assettrackerqa.inbcu.com";
        	
        	TestReporter.logStep("Launch Asset Tracker ");
        	logger.log(LogStatus.INFO,"Launch Application","Login to Application-->"+AppURLAsset);
        	wdriver.get(AppURLAsset);
        	logger.log(LogStatus.INFO,"Login","Login to Application");
            WebimplicitWait(wdriver);
        	TestReporter.logStep("Enter login details User name and Password");
        	assetLoginPge.txt_Username(wdriver).sendKeys(username);
        	assetLoginPge.txt_Password(wdriver).sendKeys(password);
        	org.openqa.selenium.By my_button = By.xpath("//button[contains(text(),'SIGN IN')]");
        	WebclickWhenElementReady(wdriver,my_button,10);
        	
        	//assetLoginPge.btn_SignIn(wdriver).click();
        	
        	
        	
        	
        	WebimplicitWait(wdriver);
        	TestReporter.logStep("Signed In Successfully");
        	
        	logger.log(LogStatus.PASS,"Logged IN","Logged into Application Successfully");
        	WebimplicitWait(wdriver);
      
        	objCommStudio.getScreenshoteachStepWeb(wdriver, true);
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
        

    }


    

   /* public void mob_UpcomingDining(AppiumDriver<WebElement> driver) throws Exception
    {
        objMyStayLoc.firstDining(driver).click();
        Thread.sleep(1000);
        Confirmation = objMyStayLoc.captureConfNum(driver).getText();
        objCommStudio.getScreenshoteachStep(driver, true);
        Constant.commBtn.mBtn_Mob_Back(driver).click();

    }
    */
}
