package com.Nbcu.AssetTracker.Web.AddAsset;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.AssetTracker.Web.ObjectRepo.AssetTrack_AssetsPage;
import com.AssetTracker.Web.ObjectRepo.AssetTrack_LoginPage;
import com.Nbcu.AssetTracker.Web.LoginComponents.AssetTrack_LoginModules;
import com.dvnext.engine.studio.Commonstudio;
import com.dvnext.mobile.testreport.TestReporter;
import com.dvnext.mobile.utils.PropertyFileReader;
//import com.nbcu.mobile.constants.Constant;
//import com.mgm.mobile.or.BookLocator;
//import com.mgm.mobile.or.MlifeLocator;
//import com.mgm.mobile.or.MyStayLocator;
import com.relevantcodes.extentreports.ExtentReports;
/*
 * AndroidMyStayModules: Methods for rooms reservation(Check in, checkout, retrieve reservations,card details, room upgrade, precheckin) related screen for IOS and Android.
 * Modified On:20-Apr-2019
 * Modified By: Giri
 * Modified deails:Logs Updated
 */
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.AppiumDriver;

//Code for Entering Asset


public class EnterAssetModules extends Commonstudio {
	PropertyFileReader prop = new PropertyFileReader();
  Commonstudio objCommStudio = new Commonstudio();
  AssetTrack_AssetsPage addasset=new  AssetTrack_AssetsPage();
 // EnterAsset_AddAsset addasset=new EnterAsset_AddAsset();
  AssetTrack_LoginModules assetTrackLoginModPge=new AssetTrack_LoginModules();
  
  //MyStayLocator objMyStayLoc = new MyStayLocator();
  //MlifeLocator objMLiLoc = new MlifeLocator();
  //BookLocator objBokLoc = new BookLocator();
  public String Confirmation;

  ExtentReports logger = ExtentReports.get(EnterAssetModules.class);

  public void mob_MyStayTab(AppiumDriver<WebElement> driver) throws Exception
  {
      //Constant.home.mBtn_Mob_HomeTab(driver).click();
      objCommStudio.getScreenshoteachStep(driver, true);
      Thread.sleep(1000);

  }
  
  public void Asset_AddAsset(RemoteWebDriver wdriver,String username, String password,String firstcost ) throws Exception
  {
  	try
  	{
  	//Click on the EnterAsset link	
		Syn_Clickupd((addasset.btn_EnterAsset(wdriver)), wdriver);
		logger.log(LogStatus.PASS, "EnterAsset should be clicked", "EnterAsset is clicked");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);

	
	//Click on Enter Without PO#
		 Syn_Clickupd((addasset.btn_EnterWithoutPO(wdriver)), wdriver);
		logger.log(LogStatus.PASS, "Enter Without PO# should be clicked", "Enter Without PO# is clicked");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);

//Entering mandatory fields for creating Asset
		
	//Selecting vendor value
		 Syn_Clickupd((addasset.selectVendor(wdriver)), wdriver);
		Thread.sleep(5000);
		switchToWindowupd("Tab Search",wdriver);
		String title= wdriver.getTitle();
		if(title.equalsIgnoreCase("NBCUniversal SSO Login"))
		{
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);; //select vendor 1st option
		}
		else
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver); //select vendor 1st option
	//	wdriver.close();
		switchToWindowupd("Asset Tracker v2.2.1",wdriver);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		

	//firstCost
		Syn_Clickupd((addasset.firstCost(wdriver)),wdriver);
		addasset.firstCost(wdriver).sendKeys(firstcost);
		logger.log(LogStatus.PASS, "Firstcost should be entered", "Firstcost is entered");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 
		 Syn_Clickupd((addasset.trackingno(wdriver)),wdriver);
		 
		 int RandomValue;
	        RandomValue=getRandomNumberInRange(1000,20000);
	        String RandomValueTracking;
	        RandomValueTracking=RandomValue+"T";
		 addasset.trackingno(wdriver).sendKeys(RandomValueTracking);

	
	//selecting cost object
		 Syn_Clickupd((addasset.costObject(wdriver)),wdriver);
		Thread.sleep(5000);
		logger.log(LogStatus.PASS, "Costobject should be entered", "Costobject is entered");
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
/*		switchToWindow("Tab Search");
		String title1= wdriver.getTitle();
		if(title1.equalsIgnoreCase("NBCUniversal SSO Login"))
		{
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
		}
		else
		Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));	
	//	wdriver.close();
		switchToWindow("Asset Tracker v2.2.1");
*/	
	//selecting model
		 Syn_Clickupd((addasset.model(wdriver)),wdriver);
		 Thread.sleep(25000);
		switchToWindowupd("Tab Search",wdriver);
		String title2= wdriver.getTitle();
		if(title2.equalsIgnoreCase("NBCUniversal SSO Login"))
		{
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);	
			
		}
		else
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);	
	//	wdriver.close();
		logger.log(LogStatus.PASS, "Model should be selected", "Model is selected");
		switchToWindowupd("Asset Tracker v2.2.1",wdriver);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		 
	
	//selecting status
		Syn_Clickupd((addasset.status(wdriver)),wdriver);
		Thread.sleep(20000);
		switchToWindowupd("Tab Search",wdriver);
		String title3= wdriver.getTitle();
		if(title3.equalsIgnoreCase("NBCUniversal SSO Login"))
		{
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);
		}
		else
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);
	//	wdriver.close();
		logger.log(LogStatus.PASS, "Status should be selected", "Status is selected");
		 switchToWindowupd("Asset Tracker v2.2.1",wdriver);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);

		
		
	//selecting country of origin
		Syn_Clickupd((addasset.countryOfOrigin(wdriver)),wdriver);
		Thread.sleep(20000);
		switchToWindowupd("Tab Search",wdriver);
		String title4= wdriver.getTitle();
		if(title2.equalsIgnoreCase("NBCUniversal SSO Login"))
		{
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);
		}
		else
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);
		logger.log(LogStatus.PASS, "Country of origin should be selected", "country of origin is selected");
		switchToWindowupd("Asset Tracker v2.2.1",wdriver);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
	//	wdriver.close();
		 
		
	//selecting current-sub-location
		Syn_Clickupd((addasset.currentSubLocation(wdriver)),wdriver);
		Thread.sleep(10000);
		switchToWindowupd("Tab Search",wdriver);
		String title5= wdriver.getTitle();
		if(title5.equalsIgnoreCase("NBCUniversal SSO Login"))
		{
			assetTrackLoginModPge.AssetTrack_Login(wdriver, username, password);
			WebimplicitWait(wdriver);
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);
		}
		else
			Syn_Clickupd((addasset.selValueWindow(wdriver)),wdriver);
	//	wdriver.close();
		logger.log(LogStatus.PASS, "Current sublocation should be selected", "current sub location is selected");
		 switchToWindowupd("Asset Tracker v2.2.1",wdriver);
		 objCommStudio.getScreenshoteachStepWeb(wdriver, true);
		
	//	switchToWindow("Tab Search");
	//	Syn_Click(assetTrackAssetsPge.selValueWindow(wdriver));
		
	//Parent Tracking number
		
	//click on Add Asset
		Syn_Clickupd((addasset.btn_addAsset(wdriver)),wdriver);
		Thread.sleep(5000);
		
		addasset.confirmation(wdriver).isDisplayed();
		logger.log(LogStatus.PASS, "Asset added confirmation should be displayed", "Asset added confirmation is displayed");
		objCommStudio.getScreenshoteachStepWeb(wdriver, true);
  	}
  	
  	catch(Exception e)
      {
          System.out.println(e);
      }
  	
  	
	}

}

