package com.Nbcu.mobile.constants;

//import com.mgm.mobile.or.WaitForElement;
//import com.mgm.mobile.or.loginCheckinPage;

/* Description: Declare all the reusable instances
 * Created by: JyothiE
 * Created on: 04-May-19
 * Modified by:
 * Build No: 6.0
 */

public class Constant
{
	public static boolean isDisplayed;
	public String dateTimeInGMT;
	public static final  long LOWWAIT = 3000;
	public static final  long LONGWAIT =15000;
    public static final  long HIGHWAIT = 22000;
    public static final  long MEDIUMWAIT = 10000;
    
	//public static HomePage home = new HomePage();
	
	//public static WaitForElement eleWait=new WaitForElement();
	//public static DigitalKeyPage digitalKey=new DigitalKeyPage();
	
	

    // //////////QA Enivronment URLS/////////////
    public static String mobileServiceUrl_QA = "https://uat-api.mgmresorts.com";

}
