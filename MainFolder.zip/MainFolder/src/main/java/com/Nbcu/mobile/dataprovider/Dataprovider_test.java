package com.Nbcu.mobile.dataprovider;

import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;

import com.dvnext.excelutils.ExcelUtils;
import com.dvnext.mobile.propertyreader.PropertyFileReader;

public class Dataprovider_test {
    static PropertyFileReader fileReader = new PropertyFileReader();
    // String suite = fileReader.readPropFile("testSuite").trim();
    static String testDataPath = fileReader.readPropFile("testdatafile").trim();
    static String testDataSheet1Name = fileReader.readPropFile("sheet1").trim();
    static String testDataSheet2Name = fileReader.readPropFile("sheet2").trim();
    static String testDataSheet3Name = fileReader.readPropFile("sheet3").trim();

    @DataProvider()
    public static Object[][] MLife(Method m) throws Exception {
        Object[][] testObjArray = ExcelUtils.getTableArray(testDataPath, testDataSheet1Name);
        return (testObjArray);
    }

    @DataProvider()
    public static Object[][] MGMLogindata() throws Exception {
        Object[][] testObjArray = ExcelUtils.getTableArray(testDataPath, testDataSheet2Name);
        return (testObjArray);
    }

    @DataProvider()
    public static Object[][] MGMWebdata() throws Exception {
        Object[][] testObjArray = ExcelUtils.getTableArray(testDataPath, testDataSheet3Name);
        return (testObjArray);
    }

}
