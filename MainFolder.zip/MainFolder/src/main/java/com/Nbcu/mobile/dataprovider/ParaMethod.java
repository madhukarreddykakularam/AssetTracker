
package com.Nbcu.mobile.dataprovider;

import java.lang.reflect.Method;
import java.util.ArrayList;

import org.testng.annotations.DataProvider;

import com.dvnext.excelutils.ExcelReaderTestData;
import com.dvnext.mobile.propertyreader.PropertyFileReader;

public class ParaMethod
{
	static PropertyFileReader fileReader = new PropertyFileReader();
	
	/*##############TEST DATA SHEET DEATILS FOR API AUTOMATION################*/
	//Test Data API
	static String testDataPathAPI = fileReader.readPropFile("testdatafileAPI").trim();
    static String regressionAPI = fileReader.readPropFile("sheet1API").trim();
    static String sanityAPI = fileReader.readPropFile("sheet2API").trim();
    static String negativeAPI = fileReader.readPropFile("sheet3API").trim();
    static String multipleAPI = fileReader.readPropFile("sheet4API").trim();
    static String sanityOperaAPI = fileReader.readPropFile("sheet5API").trim();
    static String manualDataAPI = fileReader.readPropFile("sheet6API").trim();
    
    //Test Data OWS API
    static String testDataPathAPIOWS = fileReader.readPropFile("testdatafileAPIOWS").trim();
    static String sanityAPIOWS = fileReader.readPropFile("sheet1APIOWS").trim();
    static String regressionAPIOWS = fileReader.readPropFile("sheet2APIOWS").trim();
    static String OWSAPIOWS = fileReader.readPropFile("sheet3APIOWS").trim();
    static String negativeAPIOWS = fileReader.readPropFile("sheet4APIOWS").trim();

	// Test Data DMP API
    static String testDataPathAPIDMP = fileReader.readPropFile("testdatafileAPIDMP").trim();
    static String sanityAPIDMP = fileReader.readPropFile("sheet1APIDMP").trim();
    static String regressionAPIDMP = fileReader.readPropFile("sheet2APIDMP").trim();
    static String DMPAPIDMP = fileReader.readPropFile("sheet3APIDMP").trim();
    static String negativeAPIDMP = fileReader.readPropFile("sheet4APIDMP").trim();
    static String diningAPIDMP = fileReader.readPropFile("sheet5APIDMP").trim();
    static String negativeNewAPIDMP = fileReader.readPropFile("sheet6APIDMP").trim();
    static String manualPreconditionAPIDMP = fileReader.readPropFile("sheet7APIDMP").trim();
    
    //Test Data OTA API
    static String testDataPathAPIOTA = fileReader.readPropFile("testdatafileAPIPCS").trim();
    static String regressionAPIOTA = fileReader.readPropFile("sheet1APIDMP").trim();
    static String reservationsAPIOTA = fileReader.readPropFile("sheet2APIDMP").trim();
    
    //##############TEST DATA SHEET ASSETTRACKER FOR WEB################
    //Test Data Asset Tracker
    static String testDataPathAssetTrackWeb = fileReader.readPropFile("AssetTrackTestDataPath_Web").trim();
   // static String book1 = fileReader.readPropFile("sheet3iOS").trim();
    static String AssetTrackTestsheet = fileReader.readPropFile("sheet1Asset").trim();
  

    
    
   //##############TEST DATA SHEET DEATILS FOR UI AUTOMATION################
    //Test Data iOS
    static String testDataPathiOS = fileReader.readPropFile("testdatafileiOS").trim();
    static String mLife = fileReader.readPropFile("sheet1iOS").trim();
    static String myStay = fileReader.readPropFile("sheet2iOS").trim();
    static String book = fileReader.readPropFile("sheet3iOS").trim();
    static String sanityIOS = fileReader.readPropFile("sheet4iOS").trim();
    static String deepLinks = fileReader.readPropFile("sheet5iOS").trim();


    //Test Data Android
    static String testDataPathAd = fileReader.readPropFile("testdatafileAd").trim();
    static String mLifeAd = fileReader.readPropFile("sheet1Ad").trim();
    static String myStayAd = fileReader.readPropFile("sheet2Ad").trim();
    static String bookAd = fileReader.readPropFile("sheet3Ad").trim();
    static String sanityAd = fileReader.readPropFile("sheet4Ad").trim();
    static String myStayNegative = fileReader.readPropFile("sheet5Ad").trim();
    static String mLifeNeg = fileReader.readPropFile("sheet6Ad").trim();
    static String deepLinkAd = fileReader.readPropFile("sheet7Ad").trim();
    
   //Test Data DMP API for UI
    static String testdatafileUIDMP = fileReader.readPropFile("testdatafileUIDMP").trim();
    static String dMPSanity = fileReader.readPropFile("sheet1UIDMP").trim();
    static String dMPRegressionAndroid = fileReader.readPropFile("sheet2UIDMP").trim();

//
//  //Test Data OWS API for UI
//    static String testdatapathOWS = fileReader.readPropFile("testdatafileUIOWS").trim();
//    static String oWSRegression = fileReader.readPropFile("sheet1UIOWS").trim();

    //Test Data OWS API for UI
      static String testdatafileOWSAndroid = fileReader.readPropFile("testdatafileOWSAndroid").trim();
      static String OWSRegressionAndroid = fileReader.readPropFile("sheet1OWSAndroid").trim();
    //Test Data OTA API for UI
    static String testdatapathPCS = fileReader.readPropFile("testdatafileUIPCS").trim();
    static String pCSRegression = fileReader.readPropFile("sheet1UIPCS").trim();

    //Test Data WEB
    static String testDataPathWeb = fileReader.readPropFile("testdatafileWeb").trim();
    static String myStayWeb = fileReader.readPropFile("sheet1Web").trim();
    static String sanityWeb = fileReader.readPropFile("sheet2Web").trim();

    //Daily Test Data WEB
    static String testDataPathDaily = fileReader.readPropFile("testdatafileDaily").trim();
    static String e2E = fileReader.readPropFile("sheet1daily").trim();
    
     static final String NO_DATA_FOUND_MSG="No data found or File is corrupted!!!";
     
     
     
     @DataProvider(name = "AssetTrack_SheetData")
     public static Object[][] testDataAssetTrack(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAssetTrackWeb, AssetTrackTestsheet, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     
     
     
    /* @DataProvider(name = "AssetTrack_SheetData")
     public static Object[][] testDataAssetTrack(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAssetTrackWeb, AssetTrackTestsheet, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     */
     @DataProvider(name = "SanityAPI")
     public static Object[][] testCaseAPISanity(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPI, sanityAPI, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     
     @DataProvider(name = "NegativeAPI")
     public static Object[][] testCaseAPINegative(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPI, negativeAPI, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "MultipleAPI")
     public static Object[][] testCaseAPIMultiple(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPI, multipleAPI, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "SanityOperaAPI")
     public static Object[][] testCaseAPISanityOpera(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPI, sanityOperaAPI, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "ManualDataAPI")
     public static Object[][] testCaseAPIManualData(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPI, manualDataAPI, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     
     @DataProvider(name = "SanityAPIOWS")
     public static Object[][] testCaseAPISanityOWS(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIOWS, sanityAPIOWS, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "RegressionAPIOWS")
     public static Object[][] testCaseAPIOWSRegression(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIOWS, regressionAPIOWS, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "OWSAPIOWS")
     public static Object[][] testCaseAPIOWSOWS(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIOWS, OWSAPIOWS, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "NegativeAPIOWS")
     public static Object[][] testCaseAPINegativeOWS(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIOWS, negativeAPIOWS, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
    
     @DataProvider(name = "DiningAPIDMP")
     public static Object[][] testCaseAPIDiningDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, diningAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     
     @DataProvider(name = "NegativeNewAPIDMP")
     public static Object[][] testCaseAPINegativeNewDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, negativeNewAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "ManualPreconditionAPIDMP")
     public static Object[][] testCaseAPIManualPreconditionDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, manualPreconditionAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "SanityAPIDMP")
     public static Object[][] testCaseAPISanityDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, sanityAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "regressionAPIDMP")
     public static Object[][] testCaseAPIRegressionDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, regressionAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "DMPAPIDMP")
     public static Object[][] testCaseAPIDMPDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, DMPAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "NegativeAPIDMP")
     public static Object[][] testCaseAPINegativeDMP(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIDMP, negativeAPIDMP, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     @DataProvider(name = "RegressionAPIDMP")
     public static Object[][] testCaseAPIRegressionOTA(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIOTA, regressionAPIOTA, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     
     @DataProvider(name = "ReservationsAPIOTA")
     public static Object[][] testCaseAPIReservationsOTA(Method m) throws Exception {
         final ExcelReaderTestData readExl = new ExcelReaderTestData();

         String[][] tabArray = null;
         final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAPIOTA, reservationsAPIOTA, m.getName());
         if (getList == null || getList.isEmpty()) {
             System.out.println(NO_DATA_FOUND_MSG);
         }
        
         tabArray = new String[getList.size()][getList.get(0).size()];

         for (int ix = 0; ix < getList.size(); ix++) {
             for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                 tabArray[ix][ixx] = getList.get(ix).get(ixx);
             }
         }
         return tabArray;
     }
     
    
    @DataProvider(name = "MLife")
    public static Object[][] testCase1(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathiOS, mLife, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
       
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "MyStay")
    public static Object[][] testcase2(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathiOS, myStay, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }
    
    @DataProvider(name = "DeepLink")
    public static Object[][] testcaseDeepLink(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathiOS, deepLinks, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }
    @DataProvider(name = "DeepLinkAd")
    public static Object[][] testcaseDeepLinkAndroid(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathiOS, deepLinkAd, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "Book")
    public static Object[][] testCaseBook(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathiOS, book, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "SanityiOS")
    public static Object[][] testCaseSanityiOS(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathiOS, sanityIOS, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }
    
    
    @DataProvider(name = "MLifeAd", parallel = true)
    public static Object[][] testCaseMlifeAd(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAd, mLifeAd, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "MLifeNeg", parallel = true)
    public static Object[][] testCaseMLifeNeg(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAd, mLifeNeg, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }
    
  

    @DataProvider(name = "MyStayAd")
    public static Object[][] testCaseAd(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAd, myStayAd, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "BookAd")
    public static Object[][] testCaseBookAd(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();
       
        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAd, bookAd, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "SanityAd")
    public static Object[][] testcaseSanityAd(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAd, sanityAd, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "MyStay_Negative")
    public static Object[][] testCaseMyStayNegative(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathAd, myStayNegative, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "E2EMyStay")
    public static Object[][] testCaseMystayWeb(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathWeb, myStayWeb, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "E2ESanity")
    public static Object[][] testCaseSanityWeb(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathWeb, sanityWeb, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "E2E")
    public static Object[][] testCaseDaily(Method m) throws Exception {
        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testDataPathDaily, e2E, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }
        System.out.println();
        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "DMPSanity")
    public static Object[][] testCaseDMPSanity(Method m) throws Exception {

        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testdatafileUIDMP, dMPSanity, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }

        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "DMPRegressionAndroid")
    public static Object[][] testCaseDMPRegression(Method m) throws Exception {

        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testdatafileUIDMP, dMPRegressionAndroid, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }

        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }


  @DataProvider(name = "OWSRegressionAndroid")
    public static Object[][] testCaseOWSRegression(Method m) throws Exception {

        final ExcelReaderTestData readExl = new ExcelReaderTestData();
      
        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testdatafileOWSAndroid, OWSRegressionAndroid, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }

        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

    @DataProvider(name = "PCSRegression")
    public static Object[][] testCasePCSRegression(Method m) throws Exception {

        final ExcelReaderTestData readExl = new ExcelReaderTestData();

        String[][] tabArray = null;
        final ArrayList<ArrayList<String>> getList = readExl.setExcelFile(testdatapathPCS, pCSRegression, m.getName());
        if (getList == null || getList.isEmpty()) {
            System.out.println(NO_DATA_FOUND_MSG);
        }

        tabArray = new String[getList.size()][getList.get(0).size()];

        for (int ix = 0; ix < getList.size(); ix++) {
            for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
                tabArray[ix][ixx] = getList.get(ix).get(ixx);
            }
        }
        return tabArray;
    }

}

////////////////////////////////dump//////////////////////////
/*package com.capgemini.testdata;

import java.util.ArrayList;

import org.testng.annotations.DataProvider;

import com.sprintest.framework.ExcelReaderTestData;

public class ParaMethod {

	@DataProvider(name = "MGM2")
	public static Object[][] Testcase1() throws Exception {
		final ExcelReaderTestData readExl = new ExcelReaderTestData();
		String[][] tabArray = null;
		final ArrayList<ArrayList<String>> getList = readExl.getCellData("TestData_1");
		//System.out.println("--------------------"+getList);
		if (getList == null || getList.isEmpty()) {
			System.out.println(NO_DATA_FOUND_MSG);
		}
		System.out.println();
		tabArray = new String[getList.size()][getList.get(0).size()];

		for (int ix = 0; ix < getList.size(); ix++) {
			for (int ixx = 0; ixx < getList.get(ix).size(); ixx++) {
				tabArray[ix][ixx] = getList.get(ix).get(ixx);
			}
		}
		return tabArray;
	}


}*/

