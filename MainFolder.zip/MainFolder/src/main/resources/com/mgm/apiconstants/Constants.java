package com.mgm.apiconstants;

public class Constants {

    public final static String strRelPath = "./";

}
